/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.ecommerce.com/~assets/bby/_com/bestbuy/homepage/_next/static/chunks/69635-5bf211f1848effd7.js
 * Detected Engine: Unknown
 * Vectors Invoked: 
 */

"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[69635],{51983:(e,n,t)=>{t.d(n,{CacheSeeder:()=>K,buildEntriesFromConfig:()=>A,buildSeederConfigs:()=>j});var i=Object.defineProperty,r=Object.defineProperties,a=Object.getOwnPropertyDescriptors,o=Object.getOwnPropertySymbols,l=Object.prototype.hasOwnProperty,s=Object.prototype.propertyIsEnumerable,u=(e,n,t)=>n in e?i(e,n,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[n]=t,d=(e,n)=>{for(var t in n||(n={}))l.call(n,t)&&u(e,t,n[t]);if(o)for(var t of o(n))s.call(n,t)&&u(e,t,n[t]);return e},y=t(7620),m=t(69160),p=t(31877);let g=(0,m.gql)`
	query VersionedJson_Init($key: String!) {
		versionedJsonByKey(key: $key) {
			versionedJsonId
			json
			__typename
		}
	}
`,c=(0,m.gql)`
	query ManagedContent_Init($catalog: String!, $id: String!, $type: String!) {
		managedContentByTypeAndId(
			managedContentInput: { catalog: $catalog, id: $id, type: $type }
		) {
			document
			id
			type
			catalog
			__typename
		}
	}
`,v=(0,m.gql)`
	query ManagedContentByKey_Init($key: String!) {
		managedContentByTypeAndId(
			managedContentInput: { type: "key-value", id: $key }
		) {
			document
			id
			type
			catalog
			__typename
		}
	}
`,f=(0,m.gql)`
	query WidgetFromSiteControlTimeline_Init(
		$page: String!
		$widgetType: String!
		$tenant: String
		$includeAllDimensions: String
		$dimensions: String
		$previewTimestamp: String
		$view: String
	) {
		widgetFromSiteControlTimeline(
			widgetFromSiteControlTimelineInput: {
				page: $page
				widgetType: $widgetType
				tenant: $tenant
				includeAllDimensions: $includeAllDimensions
				dimensions: $dimensions
				previewTimestamp: $previewTimestamp
				view: $view
			}
		) {
			widgets
		}
	}
`,b=(0,m.gql)`
	query SiteControlTimeline_Init(
		$dimensions: String
		$includeAllDimensions: String
		$page: String!
		$previewTimestamp: String
		$tenant: String
		$view: String
	) {
		siteControlTimeline(
			siteControlTimelineInput: {
				dimensions: $dimensions
				includeAllDimensions: $includeAllDimensions
				page: $page
				previewTimestamp: $previewTimestamp
				tenant: $tenant
				view: $view
			}
		) {
			endDateTime
			guid
			footer {
				disclaimer
				emailFooterTitle
				footerIconNavigation
				footerLegalNavigation
				footerMainNavigation
				footerMarketingNavigation
				globalNavigation
				utilityNavigation
			}
			krakenNodeConfigVersion
			layoutName
			nodeData {
				active
				activeDate
				analyticsPageType
				canonicalReference
				cobaltPowered
				cobaltQueryPath
				cobaltSearchKeyword
				cobaltSearchSort
				defaultParentPublicId
				hierarchyId
				hierarchyPublicId
				isDisplayable
				links {
					href
					rel
				}
				listingBanners {
					nodeName
					publicNodeId
					slot
				}
				mediaNetworkBanner
				metaDescription
				metaKeywords
				metaTitle
				noIndex
				nodeName
				nodeType
				preventGaps
				publicNodeId
				restrictedAccess
				shortName
				startDisplay
			}
			header {
				globalNavigation
				utilityNavigation
				valueProposition
			}
			pageHeadline
			rowContainer
			rows {
				columns {
					_meta {
						columnSizeLarge
						columnSizeMedium
						columnSizeSmall
						guid
					}
					columnSize
					guid
					widgets
				}
				guid
				isFluid
				removeMargin
				rowName
			}
			showB52
			showBreadcrumb
			showLargeViewAd
			showSmallViewAd
			startDateTime
			timelineID
		}
	}
`,k="[upa-operation-polling]",w=Symbol("upa-operation-polling.prefixed-logger");function C(e){return"string"==typeof e[0]?[`${k} ${e[0]}`,...e.slice(1)]:[k,...e]}function $(e){if(e[w])return e;let n={debug:(...n)=>e.debug(...C(n)),error:(...n)=>e.error(...C(n))};return n[w]=!0,n}let S=$({debug:(...e)=>console.debug(...e),error:(...e)=>console.error(...e)});function T(e){if("object"!=typeof e||null===e)return!1;let n=Object.getPrototypeOf(e);return n===Object.prototype||null===n}let h={versionedJson:{query:g,dataKey:"versionedJsonByKey"},managedContent:{query:c,dataKey:"managedContentByTypeAndId"},managedContentByKey:{query:v,dataKey:"managedContentByTypeAndId"},widgetFromSiteControl:{query:f,dataKey:"widgetFromSiteControlTimeline"},siteControlTimeline:{query:b,dataKey:"siteControlTimeline"}},q="operation";function D(e,n,t){let{query:i,dataKey:r}=h[n];return{key:e,queryType:n,query:i,variables:t,dataKey:r}}function I(e){var n,t,i;let r;if(null===e||"object"!=typeof e)return{valid:!1,reason:"entry must be an object"};if("string"!=typeof e.key||0===e.key.length)return{valid:!1,reason:"`key` must be a non-empty string"};if("string"!=typeof e.document||""===e.document.trim())return{valid:!1,reason:"`document` must be a non-empty printed GraphQL string"};try{r=(0,m.gql)(e.document)}catch(e){return{valid:!1,reason:`\`document\` does not parse as GraphQL: ${e instanceof Error?e.message:String(e)}`}}let a=r.definitions,o=a.filter(e=>"OperationDefinition"===e.kind);if(a.some(e=>"OperationDefinition"!==e.kind&&"FragmentDefinition"!==e.kind))return{valid:!1,reason:"`document` must contain only executable definitions (one operation plus optional fragments)"};if(1!==o.length)return{valid:!1,reason:`\`document\` must contain exactly one operation (found ${o.length})`};let l=o[0];if("query"!==l.operation)return{valid:!1,reason:`only query operations are supported (found ${l.operation})`};if(!(null==(n=l.name)?void 0:n.value))return{valid:!1,reason:"the query operation must be named"};if(void 0!==e.variables&&!function e(n,t){if(null==n)return!0;switch(typeof n){case"string":case"number":case"boolean":return!0;case"object":break;default:return!1}if(t.has(n)||!Array.isArray(n)&&!T(n))return!1;t.add(n);let i=(Array.isArray(n)?n:Object.values(n)).every(n=>e(n,t));return t.delete(n),i}(e.variables,new Set))return{valid:!1,reason:"`variables` must be JSON-serializable plain data"};let s=null!=(t=l.variableDefinitions)?t:[],u=s.filter(e=>"NonNullType"===e.type.kind&&void 0===e.defaultValue).map(e=>e.variable.name.value).filter(n=>{var t;return(null==(t=e.variables)?void 0:t[n])==null});if(u.length>0)return{valid:!1,reason:`missing required variable(s): ${u.join(", ")}`};let d=new Set(s.map(e=>e.variable.name.value)),y={},p=[];for(let[n,t]of Object.entries(null!=(i=e.variables)?i:{}))d.has(n)?y[n]=t:void 0!==t&&p.push(n);return{valid:!0,query:r,variables:y,ignoredVariables:p}}function N(e,n,t){n.length>0&&t.debug(`Operation entry '${e}' ignores undeclared variable(s): ${n.join(", ")}`)}function A(e=[],n=[],t=[],i=[],r=[],a=S){return(function(e,n=S){let{platmanEntries:t=[],managedContentEntries:i=[],widgetFromSiteControlEntries:r=[],siteControlTimelineEntries:a=[],operationEntries:o=[]}=e;return[...t.map(e=>D(e.key,"versionedJson",{key:e.key})),...i.map(e=>e.catalog&&e.id&&e.type?D(e.key,"managedContent",{catalog:e.catalog,id:e.id,type:e.type}):D(e.key,"managedContentByKey",{key:e.key})),...r.map(e=>D(e.key,"widgetFromSiteControl",{page:e.page,widgetType:e.widgetType,tenant:e.tenant,includeAllDimensions:e.includeAllDimensions,dimensions:e.dimensions,previewTimestamp:e.previewTimestamp,view:e.view})),...a.map(e=>D(e.key,"siteControlTimeline",{page:e.page,view:e.view,previewTimestamp:e.previewTimestamp,tenant:e.tenant,includeAllDimensions:e.includeAllDimensions,dimensions:e.dimensions})),...function(e,n){let t=[],i=new Set;for(let r of e){let e=I(r);if(!e.valid){n.error(`Skipping invalid operation entry '${null==r?void 0:r.key}': ${e.reason}`);continue}N(r.key,e.ignoredVariables,n),i.has(r.key)&&n.error(`Duplicate operation entry key '${r.key}'; the last entry provides its value`),i.add(r.key),t.push({key:r.key,queryType:q,query:e.query,variables:e.variables,document:r.document})}return t}(o,$(n))]})({platmanEntries:e,managedContentEntries:n,widgetFromSiteControlEntries:t,siteControlTimelineEntries:i,operationEntries:r},a).map(e=>e.queryType===q?{key:e.key,queryType:q,document:e.document,variables:e.variables}:{key:e.key,queryType:e.queryType,variables:e.variables,dataKey:e.dataKey})}function j(e,n=S){let t=[],i=$(n);for(let n of e){if(n.queryType===q&&"string"==typeof n.document){let e=I({key:n.key,document:n.document,variables:n.variables});if(!e.valid){i.error(`Skipping invalid operation entry '${n.key}': ${e.reason}`);continue}N(n.key,e.ignoredVariables,i),t.push({key:n.key,query:e.query,variables:e.variables,document:n.document});continue}let e=h[n.queryType];e&&t.push({key:n.key,query:e.query,variables:n.variables||{key:n.key},dataKey:n.dataKey||"versionedJsonByKey"})}return t}let K=({data:e={},children:n,configs:t,configEntries:i,additionalConfigEntries:o=[],operationPollingConfig:l})=>{let s=(0,m.useApolloClient)(),u=(0,p.Ul)({logger:"upa-operation-polling"}),g=(0,y.useRef)(!1);if(Object.keys(e).length>0&&!g.current){let{writes:n,failures:y}=function(e,n){var t,i;let{client:o,skipCachedDataForRequest:l=!1,logger:s=S}=n,u={writes:0,failures:0};if(l)return u;let y=$(s),m=null!=(t=e.data)?t:{},p=(e,n)=>{try{o.cache.writeQuery(n),u.writes++}catch(n){u.failures++,y.error(`Seeding write failed for key: ${e}`,n)}};for(let n of function(e,n=S){if(e.configs)return e.configs;let{configEntries:t,additionalConfigEntries:i=[],operationPollingConfig:r}=e,a=[];return t?a=t:((null==r?void 0:r.platmanEntries)||(null==r?void 0:r.managedContentEntries)||(null==r?void 0:r.widgetFromSiteControlEntries)||(null==r?void 0:r.siteControlTimelineEntries)||(null==r?void 0:r.operationEntries))&&(a=A(r.platmanEntries,r.managedContentEntries,r.widgetFromSiteControlEntries,r.siteControlTimelineEntries,r.operationEntries,n)),j([...a,...i],n)}(e,y)){let e=m[n.key];if(null!=e&&n.query){if("string"==typeof n.document){p(n.key,{query:n.query,variables:null!=(i=n.variables)?i:{},data:e});continue}n.variables&&n.dataKey&&p(n.key,{query:n.query,variables:n.variables,data:{[n.dataKey]:function(e){if(T(e)){if(T(e.json)){let n,t;return n=d({},e),t={json:r(d({},e.json),a({fromL1:!0}))},r(n,a(t))}if(T(e.document)){let n,t;return n=d({},e),t={document:r(d({},e.document),a({fromL1:!0}))},r(n,a(t))}}return e}(e)}})}}return u}({data:e,configs:t,configEntries:i,additionalConfigEntries:o,operationPollingConfig:l},{client:s,logger:u});n+y>0&&(g.current=!0)}return y.createElement(y.Fragment,null,n)};K.displayName="CacheSeeder"},63173:(e,n,t)=>{t.r(n),t.d(n,{LiveConfigContext:()=>o,LiveConfigContextProvider:()=>l,default:()=>s});var i=t(22407),r=t.n(i),a=t(7620);let o=(0,a.createContext)({createChildContext:e=>r().merge({},e),getBucket:()=>void 0,getLiveConfig:()=>void 0}),l=({liveConfig:e,doNotExtendParentContext:n,children:t})=>{let i=a.useContext(o),l=n?e:i.createChildContext(e);return a.createElement(o.Provider,{value:{createChildContext:e=>r().merge({},l,e),getBucket:e=>l[e],getLiveConfig:()=>l}},t)};var s=o}}]);
//# sourceMappingURL=69635-5bf211f1848effd7.js.map