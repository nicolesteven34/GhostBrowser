/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.ecommerce.com/~assets/bby/_com/bestbuy/homepage/_next/static/chunks/app/not-found-bdb88d33ec6a989d.js
 * Detected Engine: Unknown
 * Vectors Invoked: 
 */

(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[24345],{2825:(e,r,n)=>{"use strict";n.r(r),n.d(r,{default:()=>s});var o=n(54568);function s(){return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("h1",{children:"Oops! Sorry, we could not find the page you are looking for."}),(0,o.jsx)("p",{children:"Please check the URL or navigate back to the homepage."})]})}n(7620)},93741:(e,r,n)=>{Promise.resolve().then(n.bind(n,2825))}},e=>{e.O(0,[587,61968,77358],()=>e(e.s=93741)),_N_E=e.O()}]);
//# sourceMappingURL=not-found-bdb88d33ec6a989d.js.map