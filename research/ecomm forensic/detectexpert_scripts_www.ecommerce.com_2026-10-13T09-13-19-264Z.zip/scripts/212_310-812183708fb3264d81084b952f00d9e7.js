/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.ecommerce.com/~assets/bby/_com/shop/header/dist/client/310-812183708fb3264d81084b952f00d9e7.js
 * Detected Engine: Unknown
 * Vectors Invoked: 
 */

(self.webpackChunkgvpc_shop_header_v1_1_1_307=self.webpackChunkgvpc_shop_header_v1_1_1_307||[]).push([[310],{22310:(e,n,a)=>{"use strict";var r=a(94980),o=a.n(r),t=a(78561),s=a.n(t),c=a(8683),i=a(19453),{rE:l}={rE:"1.1.307"},p={componentId:i.componentId,componentVersion:l,contractVersion:i.contractVersion,creatorNamespace:i.creatorNamespace};o().registerComponent(p,((e,n,r)=>{var o=a=>{var o,{default:t}=a,i={app:r.app,bannerConfigs:r.bannerConfigs,banners:r.banners,instanceId:e,isSmallView:r.isSmallView,liveConfig:r.liveConfig,metaLayer:r.metaLayer,universalNavConfig:r.universalNavConfig},l=document.querySelector(n),p=null!==(o=null==l?void 0:l.querySelector("[data-header-hydration-root]"))&&void 0!==o?o:l;(0,c.hydrateRoot)(p,s().createElement(t,{stateFromServer:i}))};"s"!==r.app.deviceClass?Promise.all([a.e(306),a.e(401)]).then(a.bind(a,67718)).then(o).catch(console.error):Promise.all([a.e(306),a.e(401),a.e(0)]).then(a.bind(a,71032)).then(o).catch(console.error)}))},19453:e=>{e.exports={assetBasePath:"dist/client",componentId:"header",componentVersion:"",contractVersion:"v1",creatorNamespace:"shop"}}}]);
//# sourceMappingURL=310-812183708fb3264d81084b952f00d9e7.js.map