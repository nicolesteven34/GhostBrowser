/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.ecommerce.com/~assets/bby/_com/analytics-dotcom/chunks/mtSpan-7dc1e213e579391d851e.js
 * Detected Engine: Unknown
 * Vectors Invoked: 
 */

/*! For license information please see mtSpan-7dc1e213e579391d851e.js.LICENSE.txt */
"use strict";(self.webpackJsonpAnalytics=self.webpackJsonpAnalytics||[]).push([[9124],{32479(e,n,t){t.r(n),t.d(n,{default:()=>c}),t.dn(c);var a=t(53811),i=t(86133),s=t(71738);function c(){var e=s.A.get("isBfCache");window.analyticsQ&&!e&&window.analyticsQ.listen(function(e){if("SPAN_EVENT"===e.type){var n=(0,a.A)({},e);if(delete n.type,"PAGE_LOAD"===n.eventType||"PLP_LOAD"===n.eventType)return void console.warn("".concat(n.eventType," span events are deprecated"));(0,i.writeDataTopic)(n.eventType,n)}})}}}]);
//# sourceMappingURL=mtSpan-7dc1e213e579391d851e.js.map