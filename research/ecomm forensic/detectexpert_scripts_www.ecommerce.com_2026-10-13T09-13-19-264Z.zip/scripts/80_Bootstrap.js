/**
 * DetectExpert Pro Extracted Script
 * Target: at Navigator.g [as sendBeacon] (https://nexus.ensighten.com/bestbuy/privacy_prod/Bootstrap.js
 * Detected Engine: Unknown
 * Vectors Invoked: network.sendBeacon
 */

// Script URL: at Navigator.g [as sendBeacon] (https://nexus.ensighten.com/bestbuy/privacy_prod/Bootstrap.js
// Detected Anti-Fraud Engine: Unknown
// Calls observed: 18
