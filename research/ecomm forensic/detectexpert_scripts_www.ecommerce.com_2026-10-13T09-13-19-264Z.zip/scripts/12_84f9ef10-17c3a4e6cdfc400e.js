/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.ecommerce.com/~assets/bby/_com/bestbuy/homepage/_next/static/chunks/84f9ef10-17c3a4e6cdfc400e.js
 * Detected Engine: Unknown
 * Vectors Invoked: 
 */

"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[1634],{30920:(e,t,i)=>{i.d(t,{$D2:()=>J,$KL:()=>iJ,$Xs:()=>iT,$gu:()=>e6,AMT:()=>nj,AsH:()=>aV,AvJ:()=>iK,B58:()=>e4,BFk:()=>a.i,BM4:()=>iD,BwI:()=>ad,BxY:()=>Q,CkD:()=>tH,DOQ:()=>sJ,Dx8:()=>i2,E$1:()=>tK,E0S:()=>a3,FMk:()=>t$,FyO:()=>iw,GeS:()=>ou,HBj:()=>iq,HZX:()=>tN,HfU:()=>au,HiD:()=>s0,IK8:()=>tB,J07:()=>eN,JRB:()=>tv,K11:()=>af,LLD:()=>a.p,Lrj:()=>ay,LtX:()=>tG,M$F:()=>sX,MRp:()=>ac,Mrr:()=>aZ,NE:()=>aR,Nlv:()=>tR,P8Y:()=>ey,PkO:()=>a.o,RHo:()=>am,RXx:()=>it,Rbe:()=>om,S$s:()=>e5,SB3:()=>is,SCr:()=>iH,Ti6:()=>t7,Uen:()=>ot,W35:()=>tF,WLZ:()=>tU,WUg:()=>od,Wlr:()=>r.a,WtH:()=>i3,Wt_:()=>aN,X5U:()=>ie,X8X:()=>ik,Xj2:()=>i8,YD0:()=>il,YU0:()=>oy,ZFW:()=>aQ,Zc1:()=>e8,_s:()=>i4,a7y:()=>t5,aAJ:()=>im,ah7:()=>on,amC:()=>e0,anb:()=>n$,bzH:()=>nh,cDy:()=>tW,coH:()=>e1,cyD:()=>ii,eDy:()=>tk,eGL:()=>tM,eKD:()=>a.j,edf:()=>tD,fPb:()=>nk,fVW:()=>nS,getPriceBlockProductFragment:()=>aJ,gln:()=>iY,gmi:()=>sQ,gry:()=>s1,h9n:()=>oP,h_i:()=>iu,hjn:()=>eQ,iDT:()=>iX,ic3:()=>tL,ifZ:()=>ee,jSN:()=>iE,jTl:()=>t6,k3B:()=>eZ,kBK:()=>iL,kLY:()=>aY,ku6:()=>tE,lH2:()=>aM,lhn:()=>tP,m5t:()=>aG,mrY:()=>a.h,nGN:()=>aP,nK1:()=>eq,nbN:()=>ag,npo:()=>tw,okO:()=>a.k,olN:()=>a.q,pHT:()=>nL,pdM:()=>iS,puk:()=>tA,qQr:()=>os,qf8:()=>t9,rWz:()=>a.l,tCB:()=>iZ,t_B:()=>a7,tmp:()=>oi,uQw:()=>nF,ufg:()=>eh,uwh:()=>ap,xNZ:()=>tx,xlo:()=>ir,xmy:()=>aD,yF8:()=>iB,yIq:()=>ix,zhk:()=>iV,zuO:()=>e9}),i(94355);var n,r=i(57046),a=i(93398),o=i(36615),s=i(53802),l=i(7620),d=i(57825),c=i(9735),u=i(41756),p=i(30983),m=i(29586),f=i(24391),g=i(54568),y=i(92892),P=i(90296),h=i(86575),I=i(4349),C=i(72759),_=i(8012),b=i(52957),T=i(62024),S=i(66101),O=i(88858),v=i(330),w=i(22548),A=i(73322),E=i(76526),x=i(1920),L=i(13211),k=i(36461),B=i(87861),D=i(73227),R=i(93243),M=i(73744),N=i(85667),$=i(71674),W=i(98802),F=i(77518),G=i(82050),j=i(77572),U=i(77808),H=i(3266),z=i(93368),V=i(63409),K=i(18648),Y=(i(40459),(0,o.a)(e=>{function t(e,t){var i=e.length;for(e.push(t);0<i;){var n=i-1>>>1,a=e[n];if(0<r(a,t))e[n]=t,e[i]=a,i=n;else break}}function i(e){return 0===e.length?null:e[0]}function n(e){if(0===e.length)return null;var t=e[0],i=e.pop();if(i!==t){e[0]=i;for(var n=0,a=e.length,o=a>>>1;n<o;){var s=2*(n+1)-1,l=e[s],d=s+1,c=e[d];if(0>r(l,i))d<a&&0>r(c,l)?(e[n]=c,e[d]=i,n=d):(e[n]=l,e[s]=i,n=s);else if(d<a&&0>r(c,i))e[n]=c,e[d]=i,n=d;else break}}return t}function r(e,t){var i=e.sortIndex-t.sortIndex;return 0!==i?i:e.id-t.id}e.unstable_now=void 0,"object"==typeof performance&&"function"==typeof performance.now?(l=performance,e.unstable_now=function(){return l.now()}):(c=(d=Date).now(),e.unstable_now=function(){return d.now()-c});var a,o,s,l,d,c,u=[],p=[],m=1,f=null,g=3,y=!1,P=!1,h=!1,I=!1,C="function"==typeof setTimeout?setTimeout:null,_="function"==typeof clearTimeout?clearTimeout:null,b="u">typeof setImmediate?setImmediate:null;function T(e){for(var r=i(p);null!==r;){if(null===r.callback)n(p);else if(r.startTime<=e)n(p),r.sortIndex=r.expirationTime,t(u,r);else break;r=i(p)}}function S(e){if(h=!1,T(e),!P)if(null!==i(u))P=!0,O||(O=!0,a());else{var t=i(p);null!==t&&L(S,t.startTime-e)}}var O=!1,v=-1,w=5,A=-1;function E(){return!!I||!(e.unstable_now()-A<w)}function x(){if(I=!1,O){var t=e.unstable_now();A=t;var r=!0;try{e:{P=!1,h&&(h=!1,_(v),v=-1),y=!0;var o=g;try{t:{for(T(t),f=i(u);null!==f&&!(f.expirationTime>t&&E());){var s=f.callback;if("function"==typeof s){f.callback=null,g=f.priorityLevel;var l=s(f.expirationTime<=t);if(t=e.unstable_now(),"function"==typeof l){f.callback=l,T(t),r=!0;break t}f===i(u)&&n(u),T(t)}else n(u);f=i(u)}if(null!==f)r=!0;else{var d=i(p);null!==d&&L(S,d.startTime-t),r=!1}}break e}finally{f=null,g=o,y=!1}}}finally{r?a():O=!1}}}function L(t,i){v=C(function(){t(e.unstable_now())},i)}"function"==typeof b?a=function(){b(x)}:"u">typeof MessageChannel?(s=(o=new MessageChannel).port2,o.port1.onmessage=x,a=function(){s.postMessage(null)}):a=function(){C(x,0)},e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(e){e.callback=null},e.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):w=0<e?Math.floor(1e3/e):5},e.unstable_getCurrentPriorityLevel=function(){return g},e.unstable_next=function(e){switch(g){case 1:case 2:case 3:var t=3;break;default:t=g}var i=g;g=t;try{return e()}finally{g=i}},e.unstable_requestPaint=function(){I=!0},e.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var i=g;g=e;try{return t()}finally{g=i}},e.unstable_scheduleCallback=function(n,r,o){var s=e.unstable_now();switch(o="object"==typeof o&&null!==o&&"number"==typeof(o=o.delay)&&0<o?s+o:s,n){case 1:var l=-1;break;case 2:l=250;break;case 5:l=0x3fffffff;break;case 4:l=1e4;break;default:l=5e3}return l=o+l,n={id:m++,callback:r,priorityLevel:n,startTime:o,expirationTime:l,sortIndex:-1},o>s?(n.sortIndex=o,t(p,n),null===i(u)&&n===i(p)&&(h?(_(v),v=-1):h=!0,L(S,o-s))):(n.sortIndex=l,t(u,n),P||y||(P=!0,O||(O=!0,a()))),n},e.unstable_shouldYield=E,e.unstable_wrapCallback=function(e){var t=g;return function(){var i=g;g=t;try{return e.apply(this,arguments)}finally{g=i}}}}));(0,o.a)(e=>{});var q=(0,o.a)((e,t)=>{t.exports=Y()}),X=(0,o.a)((e,t)=>{var i=function(e){var t,i,r;return!!(t=e)&&"object"==typeof t&&(i=e,"[object RegExp]"!==(r=Object.prototype.toString.call(i))&&"[object Date]"!==r&&i.$$typeof!==n)},n="function"==typeof Symbol&&Symbol.for?Symbol.for("react.element"):60103;function r(e,t){return!1!==t.clone&&t.isMergeableObject(e)?l(Array.isArray(e)?[]:{},e,t):e}function a(e,t,i){return e.concat(t).map(function(e){return r(e,i)})}function o(e){return Object.keys(e).concat(Object.getOwnPropertySymbols?Object.getOwnPropertySymbols(e).filter(function(t){return Object.propertyIsEnumerable.call(e,t)}):[])}function s(e,t){try{return t in e}catch{return!1}}function l(e,t,n){(n=n||{}).arrayMerge=n.arrayMerge||a,n.isMergeableObject=n.isMergeableObject||i,n.cloneUnlessOtherwiseSpecified=r;var d,c,u=Array.isArray(t);return u===Array.isArray(e)?u?n.arrayMerge(e,t,n):(c={},(d=n).isMergeableObject(e)&&o(e).forEach(function(t){c[t]=r(e[t],d)}),o(t).forEach(function(i){s(e,i)&&!(Object.hasOwnProperty.call(e,i)&&Object.propertyIsEnumerable.call(e,i))||(s(e,i)&&d.isMergeableObject(t[i])?c[i]=(function(e,t){if(!t.customMerge)return l;var i=t.customMerge(e);return"function"==typeof i?i:l})(i,d)(e[i],t[i],d):c[i]=r(t[i],d))}),c):r(t,n)}l.all=function(e,t){if(!Array.isArray(e))throw Error("first argument should be an array");return e.reduce(function(e,i){return l(e,i,t)},{})},t.exports=l});function Z(e){window?.analyticsQ?.dispatch&&window.analyticsQ.dispatch(e)}function J({data:e}){Z({type:"CLICK",schemaData:{...e,event:{type:"interaction",...e.event}}})}function Q({data:e}){Z({type:"TRACK_DATA",schemaData:{...e,event:{...e.event}}})}function ee({data:e,type:t}){Z({type:t??"IMPRESSION",schemaData:{...e}})}var et=e=>"object"==typeof e&&null!==e;function ei(e,t){return et(e)&&"__typename"in e&&e.__typename===t}function en(e){return ei(e,"BundlePrice")}function er(e){return ei(e,"ItemPrice")}function ea(e){return ei(e,"BundleSkuLine")}function eo(e){return ei(e,"BundlePricing")}function es(e){return ei(e,"Product")}function el(e){return ei(e,"TermLength")}function ed(e){return ei(e,"InboundBuyingOption")}function ec(e){return void 0===e}function eu(e){return null==e}function ep(e){return"number"==typeof e&&!Number.isNaN(e)}function em(e){return ep(e)&&e>0}function ef(e){return"string"==typeof e}function eg(e){return ef(e)&&e.trim().length>0}var ey={PDP:"Product Display Page",PROMO_LIST:"Promo List Page",BROWSE_LIST:"Browse List Page",SEARCH_RESULTS:"Search Results",PLP:"Product List Page"},eP={pdpLarge:ey.PDP,pdpLargeApp:ey.PDP,pdpCurrentlyViewing:ey.PDP,promoList:ey.PROMO_LIST,promoListApp:ey.PROMO_LIST,browseList:ey.BROWSE_LIST,browseListApp:ey.BROWSE_LIST,searchResults:ey.SEARCH_RESULTS,searchResultsApp:ey.SEARCH_RESULTS,plpMedium:ey.PLP,plpMediumApp:ey.PLP};function eh({displayLocation:e}){let t=eP[e];return ef(t)?t:"Unknown page"}var eI=(0,o.b)(q(),1),eC=Symbol(),e_=Symbol(),eb=typeof window>"u"||/ServerSideRendering/.test(window.navigator&&window.navigator.userAgent)?l.useEffect:l.useLayoutEffect,eT=eI.unstable_runWithPriority?e=>{try{(0,eI.unstable_runWithPriority)(eI.unstable_NormalPriority,e)}catch(t){if("Not implemented."===t.message)e();else throw t}}:e=>e();function eS(e){let t,i=(0,l.createContext)({[eC]:{v:{current:e},n:{current:-1},l:new Set,u:e=>e()}});return i[e_]=i.Provider,t=i.Provider,i.Provider=({value:e,children:i})=>{let n=(0,l.useRef)(e),r=(0,l.useRef)(0),[a,o]=(0,l.useState)(null);a&&(a(e),o(null));let s=(0,l.useRef)();if(!s.current){let e=new Set;s.current={[eC]:{v:n,n:r,l:e,u:(t,i)=>{r.current+=1;let n={n:r.current};i?.suspense&&(n.n*=-1,n.p=new Promise(e=>{o(()=>t=>{n.v=t,delete n.p,e(t)})})),e.forEach(e=>e(n)),t()}}}}return eb(()=>{n.current=e,r.current+=1,eT(()=>{s.current[eC].l.forEach(t=>{t({n:r.current,v:e})})})},[e]),(0,l.createElement)(t,{value:s.current},i)},delete i.Consumer,i}function eO(e,t){let{v:{current:i},n:{current:n},l:r}=(0,l.useContext)(e)[eC],a=t(i),[o,s]=(0,l.useReducer)((e,r)=>{if(!r)return[i,a];if("p"in r)throw r.p;if(r.n===n)return Object.is(e[1],a)?e:[i,a];try{if("v"in r){if(Object.is(e[0],r.v))return e;let i=t(r.v);return Object.is(e[1],i)?e:[r.v,i]}}catch{}return[...e]},[i,a]);return Object.is(o[1],a)||s(),eb(()=>(r.add(s),()=>{r.delete(s)}),[r]),o[1]}var ev={BLACK_FRIDAY:"blackfriday",BUSINESS_ONLY_PRICE:"businessonlyprice",CABO:"cabo",CYBER_MONDAY_DEAL:"cybermondaydeal",DOOR_BUSTER:"doorbuster",EARLY_ACCESS:"earlyaccess",MY_BBY_ELITE_LOYALTY:"mybbyeliteloyalty",MY_BBY_ELITE_PLUS_LOYALTY:"mybbyelite+loyalty",MY_BBY_LOYALTY:"mybbyloyalty",PACKAGE_PRICE:"packageprice",PAID_MEMBER:"paidmember",PLAN_PAID_MEMBER_2:"mybbyplus",PLAN_PAID_MEMBER_3:"mybbytotal",PLUS_MEMBER_EARLY_ACCESS:"mybbyplusearlyaccess",SUCO:"suco",TOTAL_MEMBER_EARLY_ACCESS:"mybbytotalearlyaccess",TOTAL_TECH_EARLY_ACCESS:"totaltechearlyaccess",TOTAL_TECH_SUPPORT:"totaltechsupport"},ew=(Object.values(ev),ev.BLACK_FRIDAY,ev.CYBER_MONDAY_DEAL,ev.DOOR_BUSTER,["proposalprice",ev.CABO,ev.SUCO,"mobileapponly",ev.EARLY_ACCESS,ev.PLAN_PAID_MEMBER_3,ev.PAID_MEMBER,ev.PLAN_PAID_MEMBER_2,ev.TOTAL_TECH_SUPPORT,ev.MY_BBY_LOYALTY,ev.BUSINESS_ONLY_PRICE]),eA=["Proposal Price","My Best Buy Member Price","Offer Pricing","Mobile App Only","my BEST BUY early access","Total Member Price","Totaltech Price","Plus Member Price","Total Tech Support Price","my BEST BUY member pricing","Business Only Price"],eE=[ev.PLAN_PAID_MEMBER_2,ev.PLAN_PAID_MEMBER_3,"Total Member Price","Plus Member Price"],ex="clearance",eL={BUNDLE_AND_SAVE:"bundleandsave",OPEN_BOX_AS_LOW_AS:"open-box-as-low-as",OPEN_BOX_FROM:"open-box-from"},ek=(Object.values(eL),{[ev.BLACK_FRIDAY]:{text:"Black Friday Deal"},[ev.BUSINESS_ONLY_PRICE]:{text:"Business Only Price"},[ev.CABO]:{text:"My Best Buy Offer"},[ev.CYBER_MONDAY_DEAL]:{text:"Cyber Deal"},[ev.DOOR_BUSTER]:{text:"Doorbuster"},[ev.EARLY_ACCESS]:{text:"early access"},[ev.MY_BBY_ELITE_LOYALTY]:{text:"BEST BUY elite"},[ev.MY_BBY_ELITE_PLUS_LOYALTY]:{text:"BEST BUY elite plus"},[ev.MY_BBY_LOYALTY]:{text:"My Best Buy Member Price"},[ev.PACKAGE_PRICE]:{text:"Package Price"},[ev.PAID_MEMBER]:{text:"Total Tech Support Price"},[ev.PLAN_PAID_MEMBER_2]:{text:"Plus Member Price"},[ev.PLAN_PAID_MEMBER_3]:{text:"Total Member Price"},[ev.PLUS_MEMBER_EARLY_ACCESS]:{text:"Plus member early access"},[ev.SUCO]:{text:"Offer Pricing"},[ev.TOTAL_MEMBER_EARLY_ACCESS]:{text:"Total member early access"},[ev.TOTAL_TECH_EARLY_ACCESS]:{text:"BEST BUY early access"},[ev.TOTAL_TECH_SUPPORT]:{text:"Total Tech Support Price"},[eL.BUNDLE_AND_SAVE]:{text:"Bundle & save"},[eL.OPEN_BOX_AS_LOW_AS]:{text:"Open-box as low as"},[eL.OPEN_BOX_FROM]:{text:"Open-box from"}});function eB(e){return eE.includes(e)}function eD(e){return!!(e&&e.toLowerCase().startsWith("bundle & save"))}function eR(e){if(!e)return!1;let t=e.preferredBadging,i=!!t&&!ew.includes(t.toLowerCase());if(!er(e))return i;let n=e.puckDisplayMessage;return!!n&&!eA.includes(n)||i}var eM=e=>"object"==typeof e&&null!==e;function eN(e){if(!e)return;if(!("__typename"in e||eM(e.name)||eM(e.identity)||eM(e.contact)||eM(e.planPaidMembership)))return e;let t=e.profileLabels?.flatMap(e=>null===e?[]:[{label:e.label??null,value:e.value??void 0}]);return{displayName:e.name?.firstName,memberId:e.identity?.memberId,planPaidMembershipActiveType:e.planPaidMembership?.activeType,planPaidMembershipEffectiveType:e.planPaidMembership?.effectiveType,planPaidMembershipPendingType:e.planPaidMembership?.pendingType,primaryShippingAddressZipCode:e.contact?.primaryShippingAddress?.zip,profileLabels:t,creditCards:e.creditCards}}var e$=["pdpLarge","pdpLargeApp","pdpCurrentlyViewing"],eW=["pdpInStore"],eF=["medium-plp"];function eG(e){return e$.includes(e)}function ej(e){return eW.includes(e)}function eU(e){return eF.includes(e)}var eH="BundlePrice",ez="BundleSkuLine",eV="Product";function eK(e){return null!=e&&e.length>0&&"NULL"!==e.toUpperCase()}var eY=e=>et(e)&&"label"in e&&"string"==typeof e.label;function eq(e){return e&&eK(e.planPaidMembershipEffectiveType)?e.planPaidMembershipEffectiveType:null}var eX={lv:"LargeView",mobile:"mobile",AndroidPhone:"AndroidPhone",AndroidTablet:"AndroidTablet",iOSPhone:"iOSPhone",iOSTablet:"iOSTablet",sv:"SmallView"};function eZ(e){return eX[e]||"mobile"}var eJ=(e,{agentLocId:t,cartTimestamp:i,customerToken:n,parameters:r,customerId:a,employeeToken:o,liveConfig:s,locStoreId:l,visitorId:d})=>{switch(e){case eV:return function({agentLocId:e,cartTimestamp:t,customerToken:i,customerId:n,employeeToken:r,liveConfig:a,locStoreId:o,parameters:s,visitorId:l}){let d=function({parameters:e,customerId:t,cartTimestamp:i,displayLocation:n,visitorId:r,selectedCabo:a,selectedSuco:o,employeeToken:s,customerToken:l,agentLocId:d,locStoreId:c,liveConfig:u}){var p;let m,f,g=eN(e.customer),y=u?.["egp.itemPriceInput.context.enabled"],P=eZ(e.platform),h=eq(g),I=`(input: {salesChannel:"${P}",usePriceWithCart:true`,C=function({agentLocId:e,customerToken:t,employeeToken:i,locStoreId:n}){if(eK(i)){let i=",isStoreAgent:true";eK(t)&&(i+=`,ct:"${t}"`);let r=e??n;return eK(r)&&(i+=`,locationId:"${r}"`),i}}({agentLocId:d,customerToken:l,employeeToken:s,locStoreId:c});ef(C)&&(I+=C),null!==h&&(I+=`,planPaidMemberType:"${h}"`),I+=(p=u?.["egp.itemPriceInput.visitorId.enabled"]??!0?r:void 0,m="",ef(t)&&(m+=`,customerId:"${t}"`),ef(i)&&(m+=`,cartTimestamp:"${i}"`),eK(p)&&(m+=`,visitorId:"${p}"`),m),I+=(f=",useCabo:true,useSuco:true",eK(a)&&(f+=`,selectedCabo:"${a}"`),eK(o)&&(f+=`,selectedSuco:"${o}"`),f);let _=function(e){if(void 0===e||!Array.isArray(e)||0===e.length)return null;let t=e.filter(eY).map(e=>e.label);return t.length>0?t:null}(g?.profileLabels);_&&(I+=`,customerAttributes:${JSON.stringify(_)}`),I+=function(e,t=!1){if(t){if(eG(e))return',context: "Product-Page"';if(eU(e))return',context: "plp"';if(ej(e))return',context: "retail-pdp"'}return""}(n??e.displayLocation,y);let b=u?.["egp.itemPriceInput.displayLocation.allowedDisplayLocations"];return eK(n)&&b?.includes(n)&&(I+=`,displayLocation:"${n}"`),`${I}})`}({agentLocId:e,cartTimestamp:t,customerToken:i,customerId:n,displayLocation:s.displayLocation,employeeToken:r,liveConfig:a,locStoreId:o,parameters:s,selectedCabo:s.selectedCabo,selectedSuco:s.selectedSuco,visitorId:l}),u=function(e,t){let{platform:i}=e,n=eN(e.customer),{maxOffers:r,checkmarkMessagingRequired:a,filterFinanceMinPurchaseAmount:o}=t?.specialOffersList??{},s=eZ(i),l=eq(n),d=`(input: {salesChannel:"${s}"`;return null!==l&&(d+=`,effectivePlanPaidMemberType:"${l}"`),void 0!==r&&(d+=`,maxOffers:${r}`),void 0!==a&&(d+=`,checkmarkMessagingRequired:${a.toString()}`),void 0!==o&&(d+=`,filterFinanceMinPurchaseAmount:${o.toString()}`),`${d}})`}(s,a),p="priceXProductFragment",m=a?.["displayablePriceFields.enabled"]?`
        restrictedPriceDisplayMessage
        displayableCustomerPrice
        displayableRegularPrice
        icrCode
      `:`
        regularPrice
        customerPrice
        isMAP
        icrCode
        strictMapIcr
      `;return{fragment:(0,c.J1)`
    fragment ${p} on Product {
      skuId
      buyingOptions {
        __typename
        pdpUrl
        type
        ${ep(s.lowestAvailableOpenBoxCondition)?`product {
                price ${d} {
                  skuId
                  ${m}
                  openBoxPrice
                  openBoxSavings
                  openBoxCondition
                  totalSavingsPercent
                  showTotalSavings
                }
              }`:""}
      }
      termLength {
        __typename
        unitOfMeasure
        value
      }
      name {
        short
      }
      primaryImage {
        piscesHref
      }
      price ${d} {
        __typename
        showPriceAssistant
        showTotalSavings
        totalSavings
        totalSavingsPercent
        totalPaidMemberSavings
        totalNonPaidMemberSavings
        preferredBadging
        puckDisplayMessage
        puckMessageURL
        dealExpirationTimeStamp
        ${m}
        isEcoRebateEligible
        heroRenderPriceOptions
        openBoxPrice
        openBoxSavings
        openBoxCondition
        lowestOpenboxPrice
        showLeasingOption
        connectionType
        skuId
        regularPriceMessageType
        subscriptionSummary {
          __typename
          initialPrice
          initialTermType
          renewalPrice
          renewalTermType
        }
        paymentOptions {
          __typename
          numberOfInstallments
          installmentAmount
          installmentServiceFee
          vendor
          isDisplayable
          type
        }
        isBbyCardMember
        financeOption {
          __typename
          financeTerm
          monthlyPayment
          offerId
          planType
          rate
          totalCost
          totalCostIncludingTax
        }
        mobileContracts {
          __typename
          billCreditAmount
          carrierCode
          currentPrice
          customerPrice
          isDefaultContract
          regularPrice
          regularPriceMessageType
          purchaseType
          matchesCurrentPrice
          numberOfPayments
          hasPriceRange
          downPaymentAmount
          totalSavingsPerTerm
          instantSavings
          contractTotalSavings
          id
          type
          taxBasis
          showTotalSavings
          totalSavingsPercent
        }
        giftSkus {
          __typename
          brand
          isGiftCard
          isRequiredWithOffer
          offerId
          parentSkus
          quantity
          savings
          skuId
        }
        priceWithCart {
          adjustedCartItems {
            __typename
            skuId
            savingsAdjustment
            previousCustomerPrice
            newCustomerPrice
          }
          giftSkus {
            __typename
            brand
            isGiftCard
            isRequiredWithOffer
            offerId
            parentSkus
            quantity
            savings
            skuId
          }
          totalOfferSavings
          totalGiftSavings
        }
        customerSelectedDiscountsAvailable {
          offerId
          offerName
          type
          couponId
          savingsAdjustment
          effectiveStartDate
          effectiveEndDate
          effectiveEndTime
          isDiscountSelected
          offerPrice
          businessUnit
          customerAttribute
        }
        spendAndGetCabosAvailable {
          offerId
          offerName
          optInCode
          isOfferActivated
          effectiveStartDate
          effectiveEndDate
        }
        tieredOffersTracking {
          amountConsideredToNextTier
          amountRemainingToNextTier
          nextTierId
          quantityConsideredToNextTier
          quantityRemainingToNextTier
          savings
          savingsType
          tieredOffersGroupName
          trackingBy
          tiers {
            discountValue
            minPurchaseAmount
            minQuantity
            offerId
            qualified
            tierId
          }
        }
        whatIfPrice {
          __typename
          planPaidMember2 {
            __typename
            price
            savings
            savingsPercent
            warranty {
              __typename
              skuId
              fullTermSavings
              termLength
            }
          }
          planPaidMember3 {
            __typename
            price
            savings
            savingsPercent
            warranty {
              __typename
              skuId
              fullTermSavings
              termLength
            }
          }
        }
      }
      offers ${u} {
        __typename
        offers {
          __typename
          hotOffer
          offerId
          offerType
          complexMemberOffer
        }
      }
    }
  `,name:p}}({agentLocId:t,cartTimestamp:i,customerToken:n,customerId:a,employeeToken:o,liveConfig:s,locStoreId:l,parameters:r,visitorId:d});case eH:let u;return u="priceXBundlePriceFragment",{fragment:(0,c.J1)`
    fragment ${u} on BundlePricing {
      __typename
      bundlePrice {
        __typename
        customerPrice
        deliveryAndServices {
          __typename
          totalSavings
          regularPrice
        }
        deliveryAndInstallationTotal
        deliveryTotal
        regularPrice
        totalSavings
        totalSavingsPercent
        preferredBadging
      }
      giftSkus {
        __typename
        brand
        isGiftCard
        isRequiredWithOffer
        offerId
        parentSkus
        quantity
        savings
        skuId
      }
      priceWithCart {
        giftSkus {
          __typename
          brand
          isGiftCard
          isRequiredWithOffer
          offerId
          parentSkus
          quantity
          savings
          skuId
        }
        totalGiftSavings
      }
      paymentOptions {
        __typename
        numberOfInstallments
        installmentAmount
        installmentServiceFee
        vendor
        isDisplayable
        type
      }
      financeOption {
        __typename
        financeTerm
        monthlyPayment
        offerId
        planType
        rate
        totalCost
        totalCostIncludingTax
      }  
    }
  `,name:u};case ez:let p;return p="priceXBundleSkuLineFragment",{fragment:(0,c.J1)`
    fragment ${p} on BundlePricing {
      skus {
        __typename
        id
        customerPrice
        customerSubBundlePrice
        regularPrice
        regularSubBundlePrice
        regularPriceMessageType
        subBundleLineIds
        showTotalSavings
        totalSavings
        dealExpirationTimeStamp
        isMAP
        icrCode
        strictMapIcr
        preferredBadging
        puckDisplayMessage
        puckMessageURL
        skuId
        openBoxCondition
        mobileContracts {
          __typename
          billCreditAmount
          carrierCode
          currentPrice
          customerPrice
          isDefaultContract
          regularPrice
          regularPriceMessageType
          purchaseType
          matchesCurrentPrice
          numberOfPayments
          hasPriceRange
          downPaymentAmount
          totalSavingsPerTerm
          instantSavings
          contractTotalSavings
          id
          type
          taxBasis
          showTotalSavings
          totalSavingsPercent
        }
      }
    }
  `,name:p};default:throw Error(`Fragment for ${e} not implemented`)}};function eQ(e,t){if(ep(t.lowestAvailableOpenBoxCondition)){let i=function(e,t){if(es(e)&&Array.isArray(e.buyingOptions))return e.buyingOptions.find(e=>ed(e)&&es(e.product)&&er(e.product.price)&&e.product.price.openBoxCondition===t)}(e,t.lowestAvailableOpenBoxCondition);return ed(i)&&es(i.product)&&er(i.product.price)?i.product.price:null}return es(e)&&er(e.price)?e.price:eo(e)?function(e,t){if(ef(t.lineId)&&Array.isArray(e.skus))return e.skus.find(e=>ea(e)&&e.id===t.lineId);if(ef(t.skuId)&&Array.isArray(e.skus)){let i=e.skus.find(e=>ea(e)&&e.skuId===t.skuId);if(i)return i}if(en(e.bundlePrice))return e.bundlePrice}(e,t):null}function e0(e){return e?.displayableCustomerPrice??e?.customerPrice}function e1(e){return e?.displayableRegularPrice??e?.regularPrice}var e2=null,e3=null;function e6(e,t){let{zeroStrategy:i="showFreeText",decimalStrategy:n="show-decimals"}=t??{};if(Number.isNaN(e)||!ep(e))throw Error(`Expected value to be a number, instead received ${e}`);if(e<0)throw Error(`Expected value to be a number greater than or equal to 0, instead received ${e}`);let r="hide-decimals"===n||"show-decimals"!==n&&Number.isInteger(e),a=function(e=!1){return e?e3??=new Intl.NumberFormat("en-US",{currency:"USD",maximumFractionDigits:0,minimumFractionDigits:0,roundingMode:"halfCeil",style:"currency"}):e2??=new Intl.NumberFormat("en-US",{currency:"USD",maximumFractionDigits:2,minimumFractionDigits:2,roundingMode:"halfCeil",style:"currency"})}(r);if(0===e){if("showCurrency"===i)return a.format(e);if("showFreeText"===i)return"FREE";throw Error(`Expected value to be a number greater than 0, instead received ${e}`)}return r?a.format(Math.floor(e)):a.format(e)}function e5(){return typeof window>"u"}var e4=(0,l.createContext)({AddToCartButton:{__brand:"AddToCartButton"},SpendAndGetMembershipBanner:{__brand:"SpendAndGetMembershipBanner"},ModalView:{__brand:"ModalView"},Snackbar:{__brand:"Snackbar"},ZipLearnMoreLink:{__brand:"ZipLearnMoreLink"},ZipLogo:{__brand:"ZipLogo"},ZipModal:{__brand:"ZipModal"},FinanceOptionPayment:{__brand:"FinanceOptionPayment"},BuyNowPayLaterView:{__brand:"BuyNowPayLaterView"}});e4.displayName="VisitingComponentsContext";var e8=({AddToCartButton:e,SpendAndGetMembershipBanner:t,ModalView:i,Snackbar:n,ZipLearnMoreLink:r,ZipLogo:o,ZipModal:s,FinanceOptionPayment:d,BuyNowPayLaterView:c,children:u})=>{let p=(0,l.useMemo)(()=>({AddToCartButton:{__brand:"AddToCartButton",Component:e},BuyNowPayLaterView:{__brand:"BuyNowPayLaterView",Component:c},Snackbar:{__brand:"Snackbar",Component:n},SpendAndGetMembershipBanner:{__brand:"SpendAndGetMembershipBanner",Component:t},FinanceOptionPayment:{__brand:"FinanceOptionPayment",Component:d},ModalView:{__brand:"ModalView",Component:i},ZipLearnMoreLink:{__brand:"ZipLearnMoreLink",Component:r},ZipLogo:{__brand:"ZipLogo",Component:o},ZipModal:{__brand:"ZipModal",Component:s}}),[e,c,n,t,d,i,r,o,s]);return(0,g.jsx)(e4.Provider,{"data-testid":a.a.VISITING_COMPONENT_PROVIDER,value:p,children:u})},e9=({_name:e,...t})=>{let{Component:i}=(0,l.useContext)(e4)[e],n=(0,s.U)();return i?(0,g.jsx)(i,{...t}):(n.warn(`VisitingComponent '${e}' is not defined`),null)},e7=(0,o.b)(X()),te="Badge Engagement",tt="Price Block",ti="Badge",tn="Badge Modal Engagement",tr="link",ta="I button",to={activatedTradeIn:[{disclaimer:"*Maximum estimated trade-in value applied. The condition of your trade-in and the plan you select will affect the trade-in value. Trade-in value is applied as a bill credit over {numberOfPayments} months and appears on your bill after 1-3 billing cycles. Terms and conditions apply. $0.00 down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${customerPrice}.",name:"activatedTradeInDisclaimer"}],carrierDetails:[{code:"SPR",logoPath:"https://pisces.bbystatic.com/image2/vector/BestBuy_US/Gallery/sprintTmobile200X50-176750.svg",name:"Sprint",priceProgram:[{disclaimer:"Down payment may be required. Monthly term may vary. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"Sprint Monthly Installments",numberOfPayments:"24",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with Sprint Monthly Installments",type:"WITHOUT_DOWN"},{name:"for {numberOfPayments} months with Sprint Monthly Installments +  {downPaymentAmount} down payment",type:"WITH_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"Down payment may be required. Monthly term may vary. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"Sprint Monthly Installments",numberOfPayments:"30",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with Sprint Monthly Installments",type:"WITHOUT_DOWN"},{name:"for {numberOfPayments} months with Sprint Monthly Installments +  {downPaymentAmount} down payment",type:"WITH_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"${downPaymentAmount} down for qualified customers. Full price: ${taxBasis}.",name:"Sprint Flex Lease",numberOfPayments:"18",priceNote:[{description:[{name:"for {numberOfPayments} month lease + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} month lease",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with Sprint Flex Lease",type:"WITHOUT_DOWN"},{name:"for {numberOfPayments} months with Sprint Flex Lease +  {downPaymentAmount} down payment",type:"WITH_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"LEASED"},{name:"Activate Today",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"Starting at",type:"FULL_SRP"}],description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"FULL_SRP"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FULL_SRP"},{name:"with 2-year contract",numberOfPayments:"1",priceNote:[{description:[{name:"with 2-year contract",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"With 2-year new contract",type:"new"},{name:"With 2-Year contract extension",type:"upgrade"}],description:[{name:"with 2-year contract",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"SUBSIDIZED"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}],pricingOptionsModel:[{programContent:[{description:"${downPaymentAmount} down for well-qualified buyers (tax due today).",type:"DYNAMIC-BULLET"},{description:"Pay for your phone over 24 monthly payments to Sprint.",type:"BULLET"},{description:"Upgrade any time after paying off the remaining balance on your phone.",type:"BULLET"}],programName:"Sprint Monthly Installments"},{programContent:[{description:"No contract. No monthly payments. Own your phone right away by paying the full price upfront and activating it with Sprint today.",type:"CONTENT"}],programName:"One-Time Payment"}]},{code:"TMO",logoPath:"https://pisces.bbystatic.com/image2/vector/BestBuy_US/Gallery/T-MobileLogo-215219.svg;maxHeight=50;maxWidth=200",name:"T-Mobile",priceProgram:[{disclaimer:"Down payment may be required. Monthly term may vary. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"T-Mobile Monthly Installments",numberOfPayments:"24",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with T-Mobile Monthly Installments",type:"WITHOUT_DOWN"},{name:"for {numberOfPayments} months with T-Mobile Monthly Installments +  {downPaymentAmount} down payment",type:"WITH_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"Down payment may be required. Monthly term may vary. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"T-Mobile Monthly Installments",numberOfPayments:"30",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with T-Mobile Monthly Installments",type:"WITHOUT_DOWN"},{name:"for {numberOfPayments} months with T-Mobile Monthly Installments +  {downPaymentAmount} down payment",type:"WITH_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"Down payment may be required. Monthly term may vary. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"T-Mobile Monthly Installments",numberOfPayments:"36",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with T-Mobile Monthly Installments",type:"WITHOUT_DOWN"},{name:"for {numberOfPayments} months with T-Mobile Monthly Installments +  {downPaymentAmount} down payment",type:"WITH_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{name:"Activate Today",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"Starting at",type:"FULL_SRP"}],description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"FULL_SRP"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FULL_SRP"},{name:"with 2-year contract",numberOfPayments:"1",priceNote:[{description:[{name:"with 2-year contract",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"With 2-year new contract",type:"new"},{name:"With 2-Year contract extension",type:"upgrade"}],description:[{name:"with 2-year contract",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"SUBSIDIZED"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}],pricingOptionsModel:[{programContent:[{description:"${downPaymentAmount} down for well-qualified buyers (tax due today).",type:"DYNAMIC-BULLET"},{description:"Pay for your phone over 24 monthly payments to T-Mobile.",type:"BULLET"}],programName:"T-Mobile Monthly Installments"},{programContent:[{description:"No contract. No monthly payments. Own your phone right away by paying the full price upfront and activating it with T-Mobile today.",type:"CONTENT"}],programName:"One-Time Payment"}]},{code:"ATT",logoPath:"https://pisces.bbystatic.com/image2/BestBuy_US/Gallery/attLogo-15210.png;maxHeight=50;maxWidth=200",name:"AT&T",priceProgram:[{disclaimer:"${downPaymentAmount} down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"AT&T Next Every Year",numberOfPayments:"24",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months; 0% APR",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with AT&T Next Every Year",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"${downPaymentAmount} down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"AT&T Next",numberOfPayments:"30",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months; 0% APR",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with AT&T Installment Plan",type:"WITHOUT_DOWN"},{name:"for {numberOfPayments} months with AT&T Installment Plan +  {downPaymentAmount} down payment",type:"WITH_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"${downPaymentAmount} down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"AT&T Next",numberOfPayments:"36",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months; 0% APR",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with AT&T Installment Plan",type:"WITHOUT_DOWN"},{name:"for {numberOfPayments} months with AT&T Installment Plan +  {downPaymentAmount} down payment",type:"WITH_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"${downPaymentAmount} down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",numberOfPayments:"20",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months; 0% APR",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{name:"Activate Today",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"Starting at",type:"FULL_SRP"}],description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"FULL_SRP"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FULL_SRP"},{name:"with 2-year contract",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"With 2-year new contract",type:"new"},{name:"With 2-Year contract extension",type:"upgrade"}],description:[{name:"with 2-year contract",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"With 2-year new contract",type:"new"},{name:"With 2-Year contract extension",type:"upgrade"}],description:[{name:"with 2-year contract",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"SUBSIDIZED"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}],pricingOptionsModel:[{programContent:[{description:"${downPaymentAmount} down for well-qualified buyers (tax due today).",type:"DYNAMIC-BULLET"},{description:"Pay for your phone over 36 monthly payments to AT&T.",type:"BULLET"},{description:"Add AT&T Next Up for 6.00/mo. and upgrade after paying 50% cost of your phone and trading it in. Applicable to mobile phones only.",type:"BULLET"}],programName:"AT&T Installment Plan"},{programContent:[{description:"No contract. No monthly payments. Own your phone right away by paying the full price upfront and activating it with AT&T today.",type:"CONTENT"}],programName:"One-Time Payment"}]},{code:"VEZ",logoPath:"https://pisces.bbystatic.com/image2/BestBuy_US/Gallery/verizonLogo-15211.png;maxHeight=50;maxWidth=200",name:"Verizon",priceProgram:[{disclaimer:"${downPaymentAmount} down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"Verizon Device Payments",numberOfPayments:"24",priceNote:[{description:[{name:"for {numberOfPayments} months; 0% APR + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months; 0% APR",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with Verizon Device Payments",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"${downPaymentAmount} down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"Verizon Device Payments",numberOfPayments:"6",priceNote:[{description:[{name:"for {numberOfPayments} months + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with Verizon Device Payments",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"${downPaymentAmount} down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"Verizon Device Payments",numberOfPayments:"30",priceNote:[{description:[{name:"for {numberOfPayments} months; 0% APR + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months; 0% APR",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with Verizon Device Payments",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{disclaimer:"${downPaymentAmount} down for qualified customers. Tax on full retail price due at time of sale. 0% APR, Full price: ${taxBasis}.",name:"Verizon Device Payments",numberOfPayments:"36",priceNote:[{description:[{name:"for {numberOfPayments} months; 0% APR + ${downPaymentAmount} down payment",type:"WITH_DOWN"},{name:"for {numberOfPayments} months; 0% APR",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(New line or Account)",type:"new"},{name:"(Upgrade)",type:"upgrade"}],description:[{name:"for {numberOfPayments} months with Verizon Device Payments",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FINANCED"},{name:"Activate Today",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"Starting at",type:"FULL_SRP"}],description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"FULL_SRP"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FULL_SRP"},{name:"with 2-year contract",numberOfPayments:"1",priceNote:[{description:[{name:"with 2-year contract",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"With 2-year new contract",type:"new"},{name:"With 2-Year contract extension",type:"upgrade"}],description:[{name:"with 2-year contract",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"SUBSIDIZED"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}],pricingOptionsModel:[{programContent:[{description:"${downPaymentAmount} down for well-qualified buyers (tax due today).",type:"DYNAMIC-BULLET"},{description:"Pay for your phone over 36 monthly payments to Verizon.",type:"BULLET"},{description:"Upgrade any time after paying off the full balance on the device. Or, upgrade early when you trade in your iPhone XR, XS or XS Max (as part of Verizon’s Annual Upgrade program) after your device is 50% paid off.",type:"BULLET"}],programName:"Verizon Device Payments"},{programContent:[{description:"No contract. No monthly payments. Own your phone right away by paying the full price upfront and activating it with Verizon today.",type:"CONTENT"}],programName:"One-Time Payment"}]},{code:"CKT",logoPath:"https://pisces.bbystatic.com/image2/vector/BestBuy_US/Gallery/cricket_logo-104844-63088.svg",name:"Cricket",priceProgram:[{name:"Activate Today",numberOfPayments:"1",priceNote:[{description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"PREPAID"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"PREPAID"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}]},{code:"ATG",logoPath:"https://pisces.bbystatic.com/image2/vector/BestBuy_US/Gallery/att_prepaid-63086.svg",name:"AT&T Go Prepaid",priceProgram:[{name:"Activate Today",numberOfPayments:"1",priceNote:[{description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"PREPAID"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"PREPAID"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}]},{code:"VZP",logoPath:"https://pisces.bbystatic.com/image2/vector/BestBuy_US/Gallery/verizon_prepaid_logo-63089.svg",name:"Verizon Prepaid",priceProgram:[{name:"Activate Today",numberOfPayments:"1",priceNote:[{description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"PREPAID"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"PREPAID"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}]},{code:"SPM",logoPath:"https://pisces.bbystatic.com/image2/vector/BestBuy_US/Gallery/simple_mobile-112225.svg",name:"Simple Mobile",priceProgram:[{name:"Activate Today",numberOfPayments:"1",priceNote:[{description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"PREPAID"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"PREPAID"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}]},{code:"TWM",logoPath:"https://pisces.bbystatic.com/image2/vector/BestBuy_US/Gallery/total_wireless-112226.svg",name:"Total Wireless",priceProgram:[{name:"Activate Today",numberOfPayments:"1",priceNote:[{description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"PREPAID"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"PREPAID"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}]},{code:"TRF",logoPath:"https://pisces.bbystatic.com/image2/vector/BestBuy_US/Gallery/tracfoneLogo-142447.svg",name:"Tracfone",priceProgram:[{name:"Activate Today",numberOfPayments:"1",priceNote:[{description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"PREPAID"},{name:"with a new line or account",type:"new"},{name:"when you upgrade",type:"upgrade"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"PREPAID"},{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"One-time payment",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"}]}],unlocked:[{headerText:"No contract. No monthly payments. With an unlocked phone, you can switch carriers whenever you want and take it with you wherever you go.",logoPath:"https://pisces.bbystatic.com/image2/BestBuy_US/Gallery/unlockedLogo-22578.png",priceProgram:[{name:"Unactivated Price",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"(Activate Later)",type:"STANDARD"}],description:[{name:"Connect this phone to any carrier later",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"STANDARD"},{name:"Activate Today",numberOfPayments:"1",priceNote:[{additionalInfo:[{name:"Starting at",type:"FULL_SRP"}],description:[{name:"with activation today",type:"WITHOUT_DOWN"}],section:"HERO_PRICE_BLOCK"},{additionalInfo:[{name:"(Activate Today)",type:"FULL_SRP"}],description:[{name:"Connect this phone to any carrier later",upbName:"We'll help you connect this phone to {carrierNames}",type:"WITHOUT_DOWN"}],section:"PRICE_OPTIONS_TOGGLE_BLOCK"}],purchaseType:"FULL_SRP"}],pricingOptionsModel:[{programContent:[{description:"To save you time, we'll help you get your new phone set up on a carrier's network before it arrives (and you might save some money in the process).",type:"CONTENT"}],programName:"Let us help you connect."},{programContent:[{description:"No, your phone stays unlocked. You have the freedom to take your phone to any carrier.",type:"CONTENT"}],programName:"But won't that lock my phone?"},{programContent:[{description:"When you get your new phone, you'll need to contact your carrier to connect it.",type:"CONTENT"}],programName:"Connect to any carrier later."}],type:"unlockedPhone"}]},ts="View offer page",tl="activated",td="activatedFullPrice",tc="badging",tu="bottomPriceMessage",tp="bundleAndSave",tm="openBoxPrice",tf="lowestOpenBoxPrice",tg={"offerContainer.allowedDisplayLocations":[],"pdp.promotionalOptionList.deniedDisplayLocations":["pdpCurrentlyViewing"],"bundleAndSave.enabled":!1,"dealAlert.enabled":!1,"pdp.dealAlertStandalone.enabled":!1,"guestUser.dealAlert.enabled":!1,"newCCRewardsEntrypoints.enabled":!1,"legacyCCRewardsEntrypoints.enabled":!0,"migration.validated.placements":[],"migration.unvalidated.placements":[],"migration.unvalidated.visitorTokens":[],"dealExpirationTimer.enabled":!0,"dealExpirationTimer.showWithinHours":96,"dealExpirationTimer.endsSoonHours":1,"egp.itemPriceInput.displayLocation.allowedDisplayLocations":[],"egp.itemPriceInput.customerAttributes.enabled":!0,"egp.itemPriceInput.useCabo.enabled":!0,"egp.itemPriceInput.useSuco.enabled":!0,"egp.itemPriceInput.usePriceWithCart.enabled":!0,"showTotalSavings.percent.threshold":1,"showTotalSavings.threshold":1,"highlightedSavings.greenSavingsBadge.enabled":!1,"egp.itemPriceInput.visitorId.enabled":!0,"removePdpSliders.enabled":!1,"removePdpSliders.ABTestEnabled":!1,"removePdpSliders.ABTestKey":"exp0482","removePdpSliders.allowedDisplayLocations":["pdpLarge"],"removePlpPlusOffers.allowedDisplayLocations":["searchResults","plp-medium","browserList","promoList"],"removePlpPlusOffers.enabled":!1,"removePlpPlusOffers.ABTestEnabled":!1,"removePlpPlusOffers.ABTestKey":"exp0481","pdp.enableActivatedOnly":!0,"performanceToolsPreferences.customSpansPrefs.isCustomSpansEnabled":!1,"performanceToolsPreferences.customSpansPrefs.perSpan":{},"performanceToolsPreferences.sentryLib":null,"pdp.activated.activateLater.financeOptions.enabled":!1,"pdp.promotionalOptionList.enabled":!0,"pdp.spendAndGetCarousel.enabled":!1,"pdp.spendAndGetCarousel.spendAndGet.enabled":!1,"pdp.offerCarousel.standalone.enabled":!1,"plusX.offerCarousel.standalone.enabled":!1,"pdp.spendAndGetCarousel.rewardCabos.enabled":!1,"spendAndGetCarousel.rewardCabos.priorityOfferIds":[],"membershipUpsellStandalone.enabled":!1,"egp.itemPriceInput.context.enabled":!1,"plp.legacyMediumFragment.enabled":!1,"plp.suggestedMonthlyPayment.enabled":!1,"suppressBadging.allowedDisplayLocations":[],"profileBasedFragments.enabled":!1,"profileBasedFragments.validationDisplayLocations":[],"specialOffersList.offerTypes.allowed":["PWP Global"],"financeOptions.enableBrandedCardRewards":!0,"financeOptions.enableCreditCardArtIcon":!1,"financeOptions.slider.enabled":!1,specialOffersList:{maxOffers:20,checkmarkMessagingRequired:!1,filterFinanceMinPurchaseAmount:!1,viewableOfferLimit:5},"plusX.membershipUpsell.enabled":!0,"plusX.ecoRebatesStandalone.enabled":!1,"plusX.giftWithPurchase.enabled":!0,"plusX.rebates.enabled":!1,"plusX.rebates.excludeFromCount.enabled":!1,"plusX.rebates.countByContent.enabled":!0,"plusX.spendAndGet.enabled":!1,"plusX.spendAndGetCarousel.enabled":!1,"plusX.spendAndGetCarousel.rewardCabos.enabled":!1,"plusX.topOffers.countByContent.enabled":!1,"plusX.topOffers.countByContent.countTotal":!1,"plusX.topOffers.enabled":!1,"plusX.topOffers.hotOfferOnly.enabled":!1,"plusX.activatedTopOffers.enabled":!0,"plusX.caboSuco.enabled":!1,"caboSuco.standalone.enabled":!1,"personalizedOfferBlock.enabled":!1,"priceAssistant.entryPoint.enabled":!1,"priceAssistant.entryPoint.forceVisible.enabled":!1,"priceAssistant.entryPoint.destinationUrl":"https://connect-pl.ecommerce.com/ai-assist/ui/price-agent?sku={sku}&storeId={storeId}","specialOffersList.activatedTopOffers.enabled":!0,"specialOffersList.topOffers.enabled":!0,"specialOffersList.topOffers.hotOfferOnly.enabled":!1,"progressiveLeasing.enabled":!0,"getItForLess.ecoRebates.enabled":!0,"getItForLess.ecoRebatesStandalone.enabled":!1,"ecoRebatesStandalone.noRebatesMessage":"We couldn't find any rebates in your area.","personalizedOfferBlock.experiment":"B","getItForLess.useUpsellPriceXBanner":!1,"displayablePriceFields.enabled":!1,"price.customerPriceSuperscriptAndSize.enabled":!1,"price.customerPriceSuperscriptAndSize.excludedProfiles":["SINGLE","ATTACH","WARRANTY_SELECTOR","WARRANTY_INTERRUPTOR"],"layout.horizontalDisplayLocations":["discoverTopRatedHorizontal","plpNewtoBestBuyHorizontal"],customerSelectedDiscount:{caboDaysDisplayOffset:3,campaignLabels:{"Student Deals":{unapplied:"with your Student Deal",unappliedPLP:"with your Student Deal",applied:"Student Deal applied",modalLabel:"my BEST BUY offer",modalLabel1:"",modalLabel2:"",plusMember:"Plus Member",totalMember:"Total Member"},Movers:{unapplied:"with your Movers Offer",unappliedPLP:"with your Movers Offer",applied:" Movers Offer applied",modalLabel:"my Movers offer",modalLabel1:"",modalLabel2:"",plusMember:"Plus Member",totalMember:"Total Member"},Birthday:{unappliedPLP:"with your Birthday Offer",unapplied:"with your Birthday Offer",applied:"Birthday Offer applied",modalLabel:"my Birthday offer",modalLabel1:"",modalLabel2:"",plusMember:"Plus Member",totalMember:"Total Member"},"Business Offer":{unapplied:"with your Business Offer",unappliedPLP:"with your Business Offer",applied:"Business Offer applied",modalLabel:"my BEST BUY offer",modalLabel1:"",modalLabel2:"",plusMember:"Plus Member",totalMember:"Total Member"},"Cardmember Offer":{unapplied:"with your Cardmember Offer",unappliedPLP:"with your Cardmember Offer",applied:"Cardmember Offer applied",modalLabel:"my BEST BUY offer",modalLabel1:"",modalLabel2:"",plusMember:"Plus Member",totalMember:"Total Member"},"default-cabo":{unapplied:"with your my %%member%% Offer",unappliedPLP:"with your my %%member%% Offer",applied:"my %%member%% Offer applied",modalLabel:"my BEST BUY offer",modalLabel1:"",modalLabel2:"",plusMember:"Plus Member",totalMember:"Total Member"},"cabo-total-plus":{unapplied:"with your %%member%% Offer",applied:"%%member%% Offer applied",unappliedPLP:"with %%member%% Offer",modalLabel1:"my BEST BUY",modalLabel2:"offer",totalMember:"Total Member",plusMember:"Plus Member",modalLabel:""},default:{unapplied:"with your my %%member%% Offer",applied:"my %%member%% Offer applied",modalLabel:"Your Exclusive Offer",modalLabel1:"",modalLabel2:"",plusMember:"Plus Member",totalMember:"Total Member",unappliedPLP:"with your my %%member%% Offer"},"suco-total-plus":{unapplied:"with your %%member%% Offer",applied:"%%member%% Offer applied",unappliedPLP:"with %%member%% Offer",modalLabel1:"Your Exclusive",modalLabel2:"offer",totalMember:"Total Member",plusMember:"Plus Member",modalLabel:""}}}},ty={SINGLE:"sn",SMALL:"s",LARGE:"lg",MEDIUM:"md",MINI:"xs",PRODUCT_CARD_PRICE:"pc",PRODUCT_CARD_TOTAL_SAVINGS:"ts",WARRANTY_SELECTOR:"ws",WARRANTY_INTERRUPTOR:"wi",ATTACH:"a",STANDALONE_VALUE_PROPS:"sv",ALL_IN_SUBTOTAL:"ai",ALL_IN_SAVINGS:"as"},tP={ACTIVATED_PRICING_OPTIONS:"ap",ALL_IN_PRICE_EXPERIENCE:"ae",CUSTOMER_PRICE:"pc",OFFER_CAROUSEL:"oc",PLUS_X_OFFERS:"px",PROMOTIONAL_OPTIONS:"po",DATA_PRICE_READY:"dr",PRICE_READY:"r",PRICE_BLOCK_CONTENT:"c"},th="attach-delivery-and-install-tv",tI="drops",tC=(0,c.J1)`
  query PlatmanQuery($key: String!) {
    versionedJsonByKey(key: $key) {
      versionedJsonId
      json
    }
  }
`,t_=e=>et(e)&&Object.keys(tg).some(t=>t in e);function tb(e){let t=(0,l.useContext)((0,y.l)()).client,i="web"===u.A.OS?"price-experience-config":"price-experience-app-config",[n,r]=(0,l.useState)(null);return(0,l.useEffect)(()=>{if(null!=e||!t)return;r(null);let n=!1;return(async()=>{try{let e=await t.query({query:tC,variables:{key:i},fetchPolicy:"cache-first"});if(n)return;let a=e.data?.versionedJsonByKey?.json;t_(a)&&r(a)}catch{}})(),()=>{n=!0}},[e,t,i]),e||n}var tT=(0,o.b)(X()),tS=e=>{if(!e)return tg;let t=(0,tT.default)(tg,e,{arrayMerge:(e,t)=>t});return t_(e)?t:tg},tO=eS({agentLocId:void 0,baseUrl:void 0,basketTimestamp:void 0,configuration:void 0,customer:null,customerToken:void 0,employeeToken:void 0,eventNavigation:void 0,locStoreId:void 0,lowerEnvironmentToken:void 0,platform:"lv",setBasketTimestamp:()=>{},userAgent:void 0,userToken:void 0,visitorToken:void 0});tO.displayName="PriceContext";var tv=({children:e,customer:t,eventNavigation:i,visitorToken:n,basketTimestamp:r,userToken:o,platform:s,configuration:d,baseUrl:c,lowerEnvironmentToken:u,userAgent:p,locStoreId:m,agentLocId:f,customerToken:y,employeeToken:P})=>{let h=tb(d),[I,C]=(0,l.useState)(r),_=(0,l.useRef)(r);r!==_.current&&(_.current=r,C(r));let b=(0,l.useMemo)(()=>({locStoreId:m,agentLocId:f,customerToken:y,employeeToken:P,visitorToken:n,platform:s,customer:t,baseUrl:c,eventNavigation:i,basketTimestamp:I,setBasketTimestamp:C,userToken:o,lowerEnvironmentToken:u,userAgent:p,configuration:tS(h)}),[m,f,y,P,n,s,t,c,i,I,C,o,h,u,p]);return(0,g.jsx)(tO.Provider,{"data-testid":a.a.PRICE_PROVIDER,value:b,children:e})},tw=(e={})=>{let t=eO(tO,e=>e.configuration),i=tb(t),n=(0,l.useMemo)(()=>t_(t)?t:tS(i),[t,i]);if(0===Object.keys(e).length)return t_(n)?n:tg;let r=(0,e7.default)(n,e,{arrayMerge:(e,t)=>t});return t_(r)?r:tg},tA=()=>eO(tO,e=>e.customer),tE=()=>eO(tO,e=>e.platform),tx=()=>eO(tO,e=>e.visitorToken),tL=()=>eO(tO,e=>e.userToken),tk=()=>eO(tO,e=>e.basketTimestamp),tB=()=>eO(tO,e=>e.eventNavigation),tD=()=>eO(tO,e=>e.baseUrl),tR=()=>eO(tO,e=>e.lowerEnvironmentToken),tM=()=>eO(tO,e=>e.userAgent),tN=()=>eO(tO,e=>{if(eg(e.customerToken))return e.customerToken}),t$=()=>eO(tO,e=>{if(eg(e.employeeToken))return e.employeeToken}),tW=()=>eO(tO,e=>{if(eg(e.agentLocId))return e.agentLocId}),tF=()=>eO(tO,e=>{if(eg(e.locStoreId))return e.locStoreId}),tG=()=>{let[e,t]=(0,l.useState)(null),i=tD();return{openURL:(0,l.useCallback)(async e=>{let n=e;"web"!==u.A.OS&&e.startsWith("/")&&i&&(n=`${i.replace(/\/$/,"")}${e}`),await p.A.canOpenURL(n)&&("web"===u.A.OS?await p.A.openURL(n):t(n))},[i]),ModalComponent:e?(0,g.jsx)(e9,{_name:"ModalView",dismissModal:()=>{t(null)},modalVisible:!!e,url:e}):null}},tj=({id:e,node:t,value:i})=>{let n,{openURL:r,ModalComponent:a}=tG(),o="object"==typeof(n=t.attrs)&&null!==n&&"href"in t.attrs&&"string"==typeof t.attrs.href?t.attrs.href:void 0;return(0,g.jsx)(m.default,{children:(0,g.jsxs)(g.Fragment,{children:["web"===u.A.OS?(0,g.jsx)("a",{href:o,...t.attrs,onClick:e=>{e.stopPropagation(),e.preventDefault(),o&&window.open(o,"_blank")},rel:"noopener noreferrer",target:"_blank",children:i},e):(0,g.jsx)(f.default,{onPress:()=>{o&&r(o)},role:"link",...t.attrs,children:i},e),"web"!==u.A.OS&&a]})})};function tU(e){e.forEach(e=>{let{key:t,variation:i}=e;if(t&&("string"==typeof i||"number"==typeof i&&!Number.isNaN(i)))try{t.length>10&&d.Ay.warn(`[logLuxExperiment] Experiment key "${t}" exceeds the 10 character limit (${t.length} characters). SpeedCurve will truncate this key, which may cause issues in dashboards.`),(0,P.Q_)(t,i)}catch(e){d.Ay.warn(`[logLuxExperiments] Failed to log experiment "${t}":`,e)}})}var tH=e=>["AndroidPhone","AndroidTablet","iOSPhone","iOSTablet","mobile"].includes(e),tz={LARGE:{dealAlert:{show:!0},badge:{location:"header",show:!0,showBackground:!0,clickableInWeb:!0,clickableInApp:!0},dealExpirationTimer:{location:"header",show:!0},plusOffers:{show:!0},footerMessage:{show:!0,showWith:{[tc]:!1}},price:{bottomMessage:{show:!0,enableSeeDetails:!0,showWith:{[td]:!0}},show:!0,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!0}},suggestedMonthlyPayment:{show:!0},buyNowPayLater:{show:!0},priceSavingsWrapper:{wrapped:!1,wrappedThreshold:1e3},restrictedPrice:{lvMessage:"See price in cart",svMessage:"Tap for price"},savings:{regularPrice:{show:!0,showStrikeThru:!1,showInfoModal:!0},showWith:{[tc]:!0,[tu]:!0,[tm]:!0,[tf]:!1,[tl]:!0},totalSavings:{show:!0,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!0},wrapped:!0,wrappedThreshold:1e3,show:!0},size:"lg",variant:"default"},MEDIUM:{badge:{location:"header",show:!0,showBackground:!1,badgingTypeWith:{[tf]:"open-box-as-low-as"},clickableInWeb:!0,clickableInApp:!0},dealExpirationTimer:{location:"footer",show:!0},footerMessage:{show:!1,showWith:{[tc]:!1}},plusOffers:{show:!0},price:{bottomMessage:{show:!0,enableSeeDetails:!1,showWith:{[td]:!0}},show:!0,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!0}},suggestedMonthlyPayment:{show:!0},buyNowPayLater:{show:!1},priceSavingsWrapper:{wrapped:!0,wrappedThreshold:1e3},restrictedPrice:{lvMessage:"See price in cart",svMessage:"Tap for price"},savings:{regularPrice:{show:!0,showStrikeThru:!1,showInfoModal:!0},showWith:{[tc]:!0,[tu]:!0,[tm]:!1,[tf]:!1,[tl]:!0},totalSavings:{show:!0,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!0},wrapped:!0,wrappedThreshold:1e3,show:!0},size:"md",variant:"default"},MINI:{badge:{location:"header",show:!0,showBackground:!1,badgingTypeWith:{[tf]:"open-box-from"},clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{location:null,show:!1},plusOffers:{show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},price:{bottomMessage:{show:!0,enableSeeDetails:!1,showWith:{[td]:!1}},show:!0,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!0}},priceSavingsWrapper:{wrapped:!0,wrappedThreshold:1e3},restrictedPrice:{lvMessage:"See price in cart",svMessage:"Tap for price"},savings:{regularPrice:{show:!0,showStrikeThru:!0,showInfoModal:!1},showWith:{[tc]:!1,[tu]:!1,[tm]:!1,[tf]:!1,[tl]:!1},totalSavings:{show:!1,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},wrapped:!1,wrappedThreshold:1e3,show:!0},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"xsm",variant:"default"},PRODUCT_CARD_PRICE:{badge:{location:"header",show:!0,showBackground:!1,badgingTypeWith:{[tf]:"open-box-from"},clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{location:null,show:!1},plusOffers:{show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},price:{bottomMessage:{show:!0,enableSeeDetails:!1,showWith:{[td]:!1}},show:!0,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!0}},priceSavingsWrapper:{wrapped:!0,wrappedThreshold:1e3},restrictedPrice:{lvMessage:"See price in cart",svMessage:"Tap for price"},savings:{regularPrice:{show:!0,showStrikeThru:!0,showInfoModal:!1},showWith:{[tc]:!0,[tu]:!1,[tm]:!1,[tf]:!0,[tl]:!1},totalSavings:{show:!1,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},wrapped:!1,wrappedThreshold:1e3,show:!0},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"xsm",variant:"default"},PRODUCT_CARD_TOTAL_SAVINGS:{badge:{location:null,show:!1,showBackground:!1,clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{location:null,show:!1},plusOffers:{show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},price:{bottomMessage:{show:!1,enableSeeDetails:!1,showWith:{[td]:!1}},show:!1,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!1}},priceSavingsWrapper:{wrapped:!1,wrappedThreshold:1e3},restrictedPrice:{lvMessage:null,svMessage:null},savings:{regularPrice:{show:!1,showStrikeThru:!1,showInfoModal:!1},showWith:{[tc]:!0,[tu]:!0,[tm]:!1,[tf]:!0,[tl]:!1},totalSavings:{show:!0,showBackground:!0,decimalStrategy:"hide-decimals",showWith:{[tp]:!0},allowMonthlyPrice:!1},wrapped:!1,wrappedThreshold:1e3,show:!0},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"xsm",variant:"default"},SINGLE:{badge:{location:null,show:!1,showBackground:!1,clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{location:null,show:!1},plusOffers:{show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},price:{bottomMessage:{show:!1,enableSeeDetails:!1,showWith:{[td]:!1}},show:!0,seeDetailsText:{showWith:{activated:!0}},topMessage:{show:!1}},priceSavingsWrapper:{wrapped:!1,wrappedThreshold:1e3},restrictedPrice:{lvMessage:"See details",svMessage:"See details"},savings:{regularPrice:{show:!1,showStrikeThru:!1,showInfoModal:!1},showWith:{[tc]:!1,[tu]:!1,[tm]:!1,[tf]:!1,[tl]:!1},totalSavings:{show:!1,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},wrapped:!1,wrappedThreshold:1e3,show:!1},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"xsm",variant:"default"},SMALL:{badge:{location:"header",show:!0,showBackground:!1,badgingTypeWith:{[tf]:"open-box-as-low-as"},clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{location:"footer",show:!0},plusOffers:{show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},price:{bottomMessage:{show:!0,enableSeeDetails:!1,showWith:{[td]:!0}},show:!0,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!0}},priceSavingsWrapper:{wrapped:!0,wrappedThreshold:1e3},restrictedPrice:{lvMessage:"See price in cart",svMessage:"Tap for price"},savings:{regularPrice:{show:!0,showStrikeThru:!1,showInfoModal:!1},showWith:{[tc]:!0,[tu]:!0,[tm]:!1,[tf]:!1,[tl]:!0},totalSavings:{show:!0,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!0},wrapped:!0,wrappedThreshold:1e4,show:!0},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"sm",variant:"default"},WARRANTY_SELECTOR:{badge:{show:!0,location:"header",showBackground:!1,clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{show:!1,location:null},footerMessage:{show:!0,showWith:{[tc]:!1}},price:{show:!0,seeDetailsText:{showWith:{activated:!1}},bottomMessage:{show:!0,enableSeeDetails:!1,showWith:{[td]:!1}},topMessage:{show:!1}},restrictedPrice:{svMessage:null,lvMessage:null},plusOffers:{show:!1},priceSavingsWrapper:{wrapped:!0,wrappedThreshold:1e4},savings:{regularPrice:{show:!0,showStrikeThru:!0,showInfoModal:!1},totalSavings:{show:!1,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},showWith:{[tc]:!0,[tu]:!0,[tm]:!1,[tf]:!1,[tl]:!1},wrapped:!1,wrappedThreshold:1e4,show:!0},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"xsm",variant:"warranty"},WARRANTY_INTERRUPTOR:{badge:{show:!0,location:"header",showBackground:!1,clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{show:!1,location:null},footerMessage:{show:!0,showWith:{[tc]:!0}},plusOffers:{show:!1},price:{show:!0,seeDetailsText:{showWith:{activated:!1}},bottomMessage:{show:!0,enableSeeDetails:!1,showWith:{[td]:!1}},topMessage:{show:!1}},restrictedPrice:{svMessage:null,lvMessage:null},priceSavingsWrapper:{wrapped:!0,wrappedThreshold:1e4},savings:{regularPrice:{show:!0,showStrikeThru:!0,showInfoModal:!1},totalSavings:{show:!1,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},showWith:{[tc]:!1,[tu]:!0,[tm]:!1,[tf]:!1,[tl]:!1},wrapped:!1,wrappedThreshold:1e4,show:!0},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"xsm",variant:"warranty"},ATTACH:{badge:{location:"header",show:!0,showBackground:!1,clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{location:null,show:!1},plusOffers:{show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},price:{bottomMessage:{show:!0,enableSeeDetails:!1,showWith:{[td]:!1}},show:!0,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!0}},priceSavingsWrapper:{wrapped:!0,wrappedThreshold:1e3},restrictedPrice:{lvMessage:"See price in cart",svMessage:"Tap for price"},savings:{regularPrice:{show:!0,showStrikeThru:!0,showInfoModal:!1},showWith:{[tc]:!0,[tu]:!1,[tm]:!1,[tf]:!1,[tl]:!1},totalSavings:{show:!1,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},wrapped:!1,wrappedThreshold:1e3,show:!0},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"xsm",variant:"attach"},ALL_IN_SUBTOTAL:{badge:{location:"header",show:!1,showBackground:!1,clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{location:null,show:!1},plusOffers:{show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},price:{bottomMessage:{show:!1,enableSeeDetails:!1,showWith:{[td]:!1}},show:!0,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!1}},priceSavingsWrapper:{wrapped:!1,wrappedThreshold:1e3},restrictedPrice:{lvMessage:null,svMessage:null},savings:{regularPrice:{show:!1,showStrikeThru:!1,showInfoModal:!1},showWith:{[tc]:!1,[tu]:!1,[tm]:!1,[tf]:!1,[tl]:!1},totalSavings:{show:!1,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},wrapped:!1,wrappedThreshold:1e3,show:!1},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"md",variant:"attach"},ALL_IN_SAVINGS:{badge:{location:"header",show:!1,showBackground:!1,clickableInWeb:!1,clickableInApp:!1},dealExpirationTimer:{location:null,show:!1},plusOffers:{show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},price:{bottomMessage:{show:!1,enableSeeDetails:!1,showWith:{[td]:!1}},show:!1,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!1}},priceSavingsWrapper:{wrapped:!1,wrappedThreshold:1e3},restrictedPrice:{lvMessage:null,svMessage:null},savings:{regularPrice:{show:!1,showStrikeThru:!1,showInfoModal:!1},showWith:{[tc]:!1,[tu]:!1,[tm]:!1,[tf]:!1,[tl]:!1},totalSavings:{show:!0,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},wrapped:!1,wrappedThreshold:1e3,show:!0},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"xsm",variant:"attach"},STANDALONE_VALUE_PROPS:{badge:{location:"header",show:!1,showBackground:!1,clickableInWeb:!1,clickableInApp:!1},dealAlert:{show:!1},dealExpirationTimer:{location:"header",show:!1},footerMessage:{show:!1,showWith:{[tc]:!1}},plusOffers:{show:!1},price:{bottomMessage:{show:!1,enableSeeDetails:!1,showWith:{[td]:!1}},show:!1,seeDetailsText:{showWith:{activated:!1}},topMessage:{show:!1}},priceSavingsWrapper:{wrapped:!1,wrappedThreshold:1e3},restrictedPrice:{lvMessage:"See price in cart",svMessage:"Tap for price"},savings:{regularPrice:{show:!1,showStrikeThru:!1,showInfoModal:!1},showWith:{[tc]:!1,[tu]:!1,[tm]:!1,[tf]:!1,[tl]:!1},totalSavings:{show:!1,showBackground:!1,decimalStrategy:"hide-decimals-if-value-is-integer",showWith:{[tp]:!1},allowMonthlyPrice:!1},wrapped:!1,wrappedThreshold:1e3,show:!1},suggestedMonthlyPayment:{show:!1},buyNowPayLater:{show:!1},size:"lg",variant:"default"}};function tV(e){return h(e)&&e in tz&&"STANDALONE_VALUE_PROPS"!==e}function tK(e,t){let i=tz[e??"MINI"];return i.savings.wrapped=t?.savings?.wrapped??i.savings.wrapped,i.savings.wrappedThreshold=t?.savings?.wrappedThreshold??i.savings.wrappedThreshold,i.priceSavingsWrapper.wrapped=t?.priceSavingsWrapper?.wrapped??i.priceSavingsWrapper.wrapped,i.size=t?.size??i.size,i}var tY=["area","base","basefont","bgsound","br","col","command","embed","frame","hr","image","img","input","isindex","keygen","link","menuitem","meta","nextid","param","source","track","wbr"],tq=/\s([^'"/\s><]+?)[\s/>]|([^\s=]+)=\s?(".*?"|'.*?')/g,tX=function(e){var t={type:"tag",name:"",voidElement:!1,attrs:{},children:[]},i=e.match(/<\/?([^\s]+?)[/\s>]/);if(i&&(t.name=i[1],t.voidElement=tY.includes(i[1])||"/"===e.charAt(e.length-2),t.name.startsWith("!--"))){var n=e.indexOf("--\x3e");return{type:"comment",comment:-1!==n?e.slice(4,n):""}}for(var r=new RegExp(tq),a=null;null!==(a=r.exec(e));)if(a[0].trim())if(a[1]){var o=a[1].trim(),s=[o,""];o.indexOf("=")>-1&&(s=o.split("=")),t.attrs[s[0]]=s[1],r.lastIndex--}else a[2]&&(t.attrs[a[2]]=a[3].trim().substring(1,a[3].length-1));return t},tZ=/<[a-zA-Z0-9\-\!\/](?:"[^"]*"|'[^']*'|[^'">])*>/g,tJ=/^\s*$/,tQ=Object.create(null),t0=function(e,t){void 0===t&&(t={}),t||(t={}),t.components||(t.components=tQ);var i,n=[],r=[],a=-1,o=!1;if(0!==e.indexOf("<")){var s=e.indexOf("<");n.push({type:"text",content:-1===s?e:e.substring(0,s)})}return e.replace(tZ,function(s,l){if(o){if(s!=="</"+i.name+">")return"";o=!1}var d,c="/"!==s.charAt(1),u=s.startsWith("\x3c!--"),p=l+s.length,m=e.charAt(p);if(u){var f=tX(s);return a<0?n.push(f):(d=r[a])&&d.children&&Array.isArray(d.children)&&d.children.push(f),n}if(c&&(a++,"tag"===(i=tX(s)).type&&i.name&&t.components&&t.components[i.name]&&(i.type="component",o=!0),!i.voidElement&&!o&&m&&"<"!==m&&Array.isArray(i.children)&&i.children.push({type:"text",content:e.slice(p,e.indexOf("<",p))}),0===a&&n.push(i),(d=r[a-1])&&d.children&&d.children.push(i),r[a]=i),(!c||i.voidElement)&&(a>-1&&(i.voidElement||i.name===s.slice(2,-1))&&(i=-1==--a?n:r[a]),!o&&"<"!==m&&m)){d=-1===a?n:r[a].children;var g=e.indexOf("<",p),y=e.slice(p,-1===g?void 0:g);tJ.test(y)&&(y=" "),(g>-1&&a+d.length>=0||" "!==y)&&d&&Array.isArray(d)&&d.push({type:"text",content:y})}}),n},t1=C.A.create({br:{lineHeight:8}}),t2=()=>(0,g.jsx)(_.default,{style:t1.br,children:`
`}),t3=C.A.create({link:{color:"#014FD3"},text:{fontSize:a.d.size.font[2],fontFamily:a.d.font.family.sans,lineHeight:18}}),t6=e=>"string"!=typeof e?"":e.replaceAll("&nbsp;"," ").replaceAll("&amp;","&").replaceAll("&lt;","<").replaceAll("&gt;",">").replaceAll("&quot;",'"').replaceAll("&#039;","'").replaceAll("&#39;","'"),t5=e=>"string"!=typeof e?"":t6(e).replaceAll(/<[^>]*>/g,"").trim(),t4={a:({id:e,node:t,value:i})=>(0,g.jsx)(tj,{id:e,node:t,value:i}),br:()=>(0,g.jsx)(t2,{}),text:({id:e,isParentLink:t,node:i,value:n,textSize:r})=>(0,g.jsx)(I.E,{accessibilityRole:"text",style:[t3.text,t&&t3.link,{fontSize:r??t3.text.fontSize}],...i.attrs,children:"string"==typeof n&&t6(n)},e),p:({id:e,node:t,value:i,textSize:n})=>(0,g.jsx)(I.E,{accessibilityRole:"text",style:[t3.text,{fontSize:n??t3.text.fontSize}],...t.attrs,children:i},e)},t8=(e,t,i)=>e.map((e,n)=>{if(et(e)&&("type"in e&&"string"==typeof e.type||"name"in e&&"string"==typeof e.name)){let r=t4[e.name??e.type??""];if("function"==typeof r){let a=Array.isArray(e.children)&&e.children.length>0?t8(e.children,`${t}__child_${n}`,{isParentLink:"a"===e.name,textSize:i?.textSize}):e.content;return r({id:`${t}__${n}`,isParentLink:i?.isParentLink??!1,node:e,value:a,textSize:i?.textSize})}}}).filter(l.isValidElement),t9=(e,t,i)=>{if(!e)return;let n=t0(e);if(0!==n.length)return t8(n,i??`html_render_${Math.random().toString(36).slice(2)}`,{isParentLink:!1,textSize:t})},t7=(e,t)=>{let i=(0,l.useId)();return(0,l.useMemo)(()=>t9(e,t,i),[e,i,t])};function ie(e){if(!e)return null;if(Array.isArray(e.columns)&&e.columns.length>0){let t=e.columns[0];if(Array.isArray(t.widgets)&&t.widgets.length>0)return t.widgets[0]}return null}var it=e=>{if(e)return e.content?.skuPromotionalMessage??e.assets?.[0]?.content?.skuPromotionalMessage??void 0},ii=e=>e?Object.keys(e).map(t=>({key:t,siteControlTimeline:e[t]})).flatMap(({key:e,siteControlTimeline:t})=>{let i=t?.rows??[],n=e.replace("offer","");return i.map(e=>{let t;return{skuPromotionalMessage:it(t=ie(e)),offerId:(n||t?.offer?.offerId)??void 0,linkTo:t?.content?.linkTo??void 0,bodyCopy:t?.content?.bodyCopy??void 0,disclaimer:t?.content?.disclaimer??void 0}})}):[];function ir(e){if(!e?.siteControlTimeline)return null;let t=e.siteControlTimeline;return Array.isArray(t.rows)&&t.rows.length>0?t.rows[0]:null}function ia(e){return er(e)&&ep(e.openBoxCondition)}function io(e,t){return ep(t.lowestAvailableOpenBoxCondition)&&ia(eQ(e,t))}function is(e,t){return ia(eQ(e,t))}function il(e){return et(e)&&"mobileContracts"in e&&Array.isArray(e.mobileContracts)&&e.mobileContracts.length>0}function id(e){return e.mobileContracts.find(e=>e.isDefaultContract)??{}}function ic(e,t){return et(t)?t:il(e)?id(e):{}}function iu(e){if(er(e)||ea(e))return e.retailOption}function ip(e){return!!(er(e)||ea(e))&&"0"===e.connectionType}function im({egpData:e,parameters:t,selectedContract:i,showStandardPricing:n}){if(n)return!1;let r=eQ(e,t);return!is(e,t)&&(!!et(i)||!(ip(r)||eR(r))&&il(r)&&r.mobileContracts.some(e=>e.isDefaultContract))}function ig(e){if(!im(e))return!1;let{egpData:t,parameters:i,selectedContract:n}=e;return 1===ic(eQ(t,i),n).numberOfPayments}function iy(e,t){if(!eu(e))return Object.entries(t).reduce((e,[t,i])=>{if(ef(i)){let n=Number.parseFloat(i);return Number.isNaN(n)?e.replace("{"+t+"}",i):e.replace("${"+t+"}",e6(n,{zeroStrategy:"showCurrency"})).replace("{"+t+"}",i)}return ep(i)?e.replace("${"+t+"}",e6(i,{zeroStrategy:"showCurrency"})).replace("{"+t+"}",i.toString()):e},e)}function iP(e,t){return e.carrierDetails?.find(e=>e.code===t)}function ih(e,{numberOfPayments:t,purchaseType:i}){if(ep(t))return e?.priceProgram?.find(e=>e.purchaseType===i&&e.numberOfPayments===t.toString())}function iI(e,t){return e?.priceNote?.find(e=>e.section===t)}function iC(e,t){let i=(t??0)>0?"WITH_DOWN":"WITHOUT_DOWN",n=e?.description?.find(e=>e.type===i);return n?.upbName??n?.name}var i_=(e,t)=>{let i=t?.filter(Boolean).map(e=>e.carrierCode).map(t=>e.carrierDetails?.find(e=>e.code===t)?.name).filter(Boolean).filter((e,t,i)=>i.indexOf(e)===t)??[];if(0===i.length)return"a carrier";if(1===i.length)return i[0];let n=i.at(-1);return`${i.slice(0,-1).join(", ")} or ${n}`};function ib({content:e,contract:t,isUnlocked:i,section:n,mobileContracts:r}){var a;let o;if(i){let i=iI(function(e,{numberOfPayments:t,purchaseType:i}){if(Array.isArray(e.unlocked)&&e.unlocked.length>0&&ep(t))return e.unlocked[0].priceProgram?.find(e=>e.purchaseType===i&&e.numberOfPayments===t.toString())}(e,t),n),a=i_(e,r),o={...t,carrierNames:a};return{description:iy(iC(i,t.downPaymentAmount),o)}}let s=iI(ih(iP(e,t.carrierCode),t),n),l=i_(e,r),d={...t,carrierNames:l};return{description:iy(iC(s,t.downPaymentAmount),d),additionalInfo:(a=t.purchaseType,o=s?.additionalInfo?.find(e=>e.type===a),o?.upbName??o?.name)}}function iT({numberOfPayments:e,purchaseType:t,currentPrice:i,skuId:n}){return`${n}_${i}_${e}_${t}`}function iS(e){return e.purchaseType?.toLowerCase()==="standard"}function iO(e,{tradeInAppraisal:t}){return!eu(function(e,{tradeInAppraisal:t}){if(et(t)&&"carrierTradeInOffers"in t&&ep(e.numberOfPayments))return t.carrierTradeInOffers.find(t=>t.activationType.toLowerCase()===e.type?.toLowerCase()&&Number.parseInt(t.numberOfPayments,10)===e.numberOfPayments)}(e,{tradeInAppraisal:t}))}function iv({selectedContract:e,tradeInAppraisal:t}){return!!(e&&iO(e,{tradeInAppraisal:t}))}function iw({egpData:e,skuId:t}){let i=eQ(e,{skuId:t});if(il(i)){let e=i.skuId;if(!ef(e))return void d.Ay.warn("[deriveContracts] price.skuId is undefined, cannot derive contracts");let t=(function({contracts:e,isUnlocked:t}){let i=Object.values(e.reduce((e,t)=>{if(eu(t))return e;let i=iT(t);if(t.isDefaultContract)return{...e,[i]:t};let n=e[i];return"upgrade"!==t.type||n?.isDefaultContract?"new"===t.type&&eu(n)?{...e,[i]:t}:e:{...e,[i]:t}},{}));return t?i.filter(e=>!!e.isDefaultContract):i})({contracts:i.mobileContracts,isUnlocked:ip(i)}).map(t=>({...t,skuId:e}));if(!1===function(e){if(ei(e.retailOption,"ItemPriceRetailOption")||ei(e.retailOption,"RetailOption"))return e.retailOption.isInventorySkuIdActive}(i))return t;let n=t.concat({id:"standard-option",currentPrice:e0(i),purchaseType:"STANDARD",type:"standard",numberOfPayments:1,contractTotalSavings:i.totalSavings,carrierCode:id(i).carrierCode,skuId:e});return ip(i)||eR(i)?Array.from(n).sort((e,t)=>"STANDARD"===e.purchaseType?-1:1):n}}var iA=eS({});function iE(){return eO(iA,e=>e.selectedContract)}function ix(){return eO(iA,e=>e.tradeInAppraisal)}function iL(){let e=(0,s.U)();return eO(iA,t=>eu(t.setTradeInAppraisal)?t=>{e.warn(`PriceContext.setTradeInAppraisal is undefined, cannot set appraisal ${JSON.stringify(t)}`)}:t.setTradeInAppraisal)}function ik(){let e=(0,s.U)();return eO(iA,t=>{if(eu(t.setSelectedContract))return(t,i)=>{e.warn(`PriceContext.setSelectedContract is undefined, cannot set contract and retailOption ${JSON.stringify({contract:t,retailOption:i})}`)};let i=t.setSelectedContract;return(e,t)=>{let n=eu(t)||eu(t.inventorySkuId)||eu(t.isInventorySkuIdActive)?void 0:t;eu(e)||iS(e)?i({contract:void 0,retailOption:n}):i({contract:e,retailOption:n})}})}function iB(){return eO(iA,e=>e.showStandardPricing)}function iD(){let e=(0,s.U)();return eO(iA,t=>eu(t.clearActivatedMetaData)?()=>{e.warn("PriceContext.clearActivatedMetaData is undefined")}:t.clearActivatedMetaData)}iA.displayName="ActivatedPricingOptionsContext";var iR="We couldn't set your deal alert. Please try again.",iM={isDealAlertUpdated:!1,dealAlertModel:{customer:{dealAlerts:{items:[]}}}},iN=(0,v.v)()((e,t)=>({...iM,updateDealAlertList:i=>{O(i,t().dealAlertModel)||e({dealAlertModel:i,isDealAlertUpdated:!0})},clearData:()=>{e(iM)}})),i$="RE_FETCH",iW=(0,c.J1)`
  query GetDealAlert($effectivePlanPaidMemberType: String) {
    customer {
      dealAlerts(
        filter: {
          type: "customer-deal-alert-sku"
          status: ACTIVE
          effectivePlanPaidMemberType: $effectivePlanPaidMemberType
        }
      ) {
        items {
          ... on ProductDealAlert {
            product {
              name {
                short
              }
              primaryImage {
                piscesHref
              }
              skuId
            }
            type
            status
          }
        }
      }
    }
  }
`,iF=(0,c.J1)`
  mutation AddDealAlert(
    $skuId: String!
    $price: Float!
    $effectivePlanPaidMemberType: String
  ) {
    createDealAlert(
      dealAlert: {
        skuId: $skuId
        price: $price
        status: ACTIVE
        type: "customer-deal-alert-sku"
        effectivePlanPaidMemberType: $effectivePlanPaidMemberType
      }
    ) {
      skuId
      status
    }
  }
`,iG=(0,c.J1)`
  mutation DeleteDealAlert(
    $skuId: String!
    $effectivePlanPaidMemberType: String
  ) {
    deleteDealAlert(
      dealAlert: {
        skuId: $skuId
        status: INACTIVE
        type: "customer-deal-alert-sku"
        effectivePlanPaidMemberType: $effectivePlanPaidMemberType
      }
    ) {
      skuId
      status
    }
  }
`,ij="Set a Deal Alert",iU=(e,t)=>({event:{type:"interaction"},interaction:{name:"Deal Alert: Modal Engagement"},content:[{name:`Deal Alert: ${t}`,isClick:!0,region:e}]});function iH(e){let{isMobilePlatform:t,isUserLoggedIn:i,liveConfig:n}=e;if(!n["dealAlert.enabled"])return!1;if(t){let e=n["guestUser.dealAlert.enabled"];return i||e}return!0}var iz=(e,t)=>e.customer.dealAlerts.items?.some(e=>e.product.skuId===t)??!1;function iV(e,t=!1,i){let n=iN(e=>e.dealAlertModel),r=iN(e=>e.isDealAlertUpdated),a=iN(e=>e.updateDealAlertList),o=iz(n,e),[s,d]=(0,l.useState)({skuIdInDealAlert:o,dealAlertQueryType:"ACTIVE_LIST",querySkuId:e??""}),{data:c,loading:u,error:p,refetch:m}=(0,T.I)(iW,{variables:{effectivePlanPaidMemberType:i},errorPolicy:"all",fetchPolicy:"no-cache",skip:t});return(0,l.useEffect)(()=>{s.dealAlertQueryType===i$&&m()},[s.dealAlertQueryType,m]),(0,l.useEffect)(()=>{let t=iz(n,e);d(e=>({...e,skuIdInDealAlert:t,isFetching:!1}))},[n,e]),(0,l.useEffect)(()=>{if(!e)return;let t=s.dealAlertQueryType,i=!p&&!u,n=!r||t===i$;c&&i&&n&&a(c)},[c,s.dealAlertQueryType,p,r,u,e,a]),{dealAlertSkuStatus:s,refetchQuery:(0,l.useCallback)(()=>{d(e=>({...e,isFetching:!0,dealAlertQueryType:i$}))},[])}}function iK(e,t,i){let[n,r]=(0,l.useState)(),[a,{data:o,error:s,loading:d}]=(0,S.n)(iF,{errorPolicy:"all",fetchPolicy:"no-cache"});return(0,l.useEffect)(()=>{!o||s||d||r({skuAdded:{isUpdated:!0,loading:!1,errorMessage:""}}),s&&!d&&r({skuAdded:{isUpdated:!1,loading:!1,errorMessage:iR}})},[d,o,s]),{addItem:()=>{r({skuAdded:{isUpdated:!1,loading:!0,errorMessage:""}}),a({variables:{skuId:e,price:t,effectivePlanPaidMemberType:i}})},addSkuStatus:n}}function iY(e,t){let[i,n]=(0,l.useState)(),[r,{data:a,error:o,loading:s}]=(0,S.n)(iG,{errorPolicy:"all",fetchPolicy:"no-cache"});return(0,l.useEffect)(()=>{!a||o||s?o&&!s&&n({skuDeleted:{isUpdated:!1,loading:!1,errorMessage:iR}}):n({skuDeleted:{isUpdated:!0,loading:!1,errorMessage:""}})},[s,a,o]),{deleteItem:()=>{n({skuDeleted:{isUpdated:!1,loading:!0,errorMessage:""}}),r({variables:{skuId:e,effectivePlanPaidMemberType:t}})},deleteSkuStatus:i}}function iq(e){let{profile:t,feature:i,prefix:n="pb"}=e,r=t?ty[t]:null,a=t&&r?`${n}_${r}_${i}`:`${n}_${i}`;if(a.length+2>10)throw Error(`Feature ID "${a}" exceeds 10 character limit`);let{dataShown:o}=(0,P.ZF)({featureId:a,mountSpanSuffix:"m",dataShownSpanSuffix:"r"});return o}function iX(e,t=!1){let i=(0,l.useRef)(null);return t&&null===i.current&&(i.current=e),t?i.current:e}function iZ(e){let{heightKey:t,openBoxCondition:i}=e,[n,r]=(0,l.useState)(void 0),[a,o]=(0,l.useState)(!1);(0,l.useEffect)(()=>{r(void 0),o(!1)},[t,i]);let s=(0,l.useCallback)(e=>{o(e)},[]),d=(0,l.useCallback)(e=>{if(a)return;let{height:t}=e.nativeEvent.layout;t>0&&r(t)},[a]),c=(0,l.useMemo)(()=>n?{minHeight:n}:void 0,[n]),u=(0,l.useMemo)(()=>void 0===n?void 0:{height:n,overflow:"hidden"},[n]);return{handleContentLayout:d,wrapperStyle:c,preservedHeight:n,fallbackClampStyle:u,onShimmerVisibilityChange:s}}function iJ(e,t){let{data:i,...n}=(0,T.I)(tC,{...t,variables:{key:e}});return{...n,data:i?.versionedJsonByKey?.json}}var iQ=e=>{let t=new Date(e).getTime(),i=Number(e),n=Number.isNaN(t)?i:t;return Number.isNaN(n)?0:n},i0=(0,v.v)()(e=>({setTriggeredEntry:(t,i)=>{t&&e(e=>({triggeredEntries:{...e.triggeredEntries,[t]:i}}))},triggeredEntries:{}}));function i1(e,t){return i0((0,l.useCallback)(i=>e?i.triggeredEntries[e]?.[t]:void 0,[t,e]))}function i2(){let e=i0(e=>e.setTriggeredEntry);return(0,l.useCallback)((t,i,n)=>{e(t,{timestamp:i,...n})},[e])}function i3(e,t={}){let i=tx(),n=tL(),r=t.userTokenOverride??n,a=t$(),o=tN(),s=tW(),l=tF(),{cartTimestamp:d,selectionOverrideSpread:c,triggeredTimestamp:u}=function(e,t){let i=tk(),n=i1(e,"timestamp"),r={selectedCabo:i1(e,"selectedCabo"),selectedSuco:i1(e,"selectedSuco")};return{cartTimestamp:(t?[t,n]:[n,i]).filter(e=>void 0!==e).reduce((e,t)=>void 0===e||iQ(t)>iQ(e)?t:e,void 0),selectionOverrideSpread:{...void 0!==r.selectedSuco&&{selectedSuco:r.selectedSuco||void 0},...void 0!==r.selectedCabo&&{selectedCabo:r.selectedCabo||void 0}},triggeredTimestamp:n}}(e,t.basketTimestampOverride);return{agentLocId:s,cartTimestamp:d,customerId:r,customerToken:o,employeeToken:a,locStoreId:l,selectionOverrideSpread:c,triggeredTimestamp:u,visitorId:i}}var i6=(0,l.lazy)(async()=>await i.e(86185).then(i.bind(i,86185))),i5=(0,l.lazy)(async()=>await i.e(78885).then(i.bind(i,78885))),i4=(0,l.forwardRef)(({platform:e,...t},i)=>"sv"===e?(0,g.jsx)(l.Suspense,{children:(0,g.jsx)(i5,{...t,ref:i})}):(0,g.jsx)(l.Suspense,{children:(0,g.jsx)(i6,{...t,ref:i})}));i4.displayName="Drawer";var i8=({children:e,name:t,overrides:i})=>tw(i)[t]?e:null;function i9(e,t,i){let n;return!!i[`${e}.enabled`]||(n=`${e}.validationDisplayLocations`)in i&&Array.isArray(i[n])&&ef(t)&&i[`${e}.validationDisplayLocations`].includes(t)}var i7=C.A.create({close:{backgroundColor:"transparent",borderWidth:0,cursor:"pointer",margin:0,padding:0},header:{display:"flex",flexDirection:"row",alignItems:"flex-start",justifyContent:"space-between",paddingBottom:12},wrap:{display:"flex",flexDirection:"column"}}),ne={lg:800,md:560,sm:360},nt="__price-exp-modal-backdrop__",ni=(0,l.forwardRef)(({children:e,onClose:t,size:i="md",title:n,modalStyleOverrides:r,hideCloseIcon:o,headerStyle:s},d)=>{let[c,u]=(0,l.useState)(!1),p=(0,l.useRef)(null);(0,l.useEffect)(()=>{if(!(typeof document>"u"||document.querySelector(`#${nt}`))){let e;return(e=document.createElement("style")).id=nt,e.textContent=`.${nt}::backdrop { background-color: rgba(3, 3, 3, 0.6);font-family: ${a.d.font.family.sans}; }`,document.head.append(e),function(){e.remove()}}},[]);let y=(0,l.useMemo)(()=>({backgroundColor:"#fff",boxShadow:"0px 8px 24px 0px #0000004D",borderColor:"#E4E5E8",borderWidth:1,borderRadius:4,width:ne[i],paddingBottom:24,paddingLeft:24,paddingRight:24,paddingTop:24}),[i]);(0,l.useLayoutEffect)(()=>{if(p.current){let e=p.current,i=()=>{u(!1),"function"==typeof t&&t()};return e.addEventListener("close",i),()=>{e.removeEventListener("close",i)}}},[t]);let P=(0,l.useCallback)(()=>{p.current instanceof HTMLDialogElement&&(p.current.close(),u(!1))},[]),h=(0,l.useCallback)(()=>{p.current instanceof HTMLDialogElement&&(p.current.showModal(),u(!0))},[]);return(0,l.useImperativeHandle)(d,()=>({closeModal:P,openModal:h,modalStyleOverrides:r}),[P,h,r]),(0,g.jsxs)("dialog",{className:nt,"data-testid":a.a.MODAL_ROOT,ref:p,style:{...y,...r},tabIndex:-1,children:[(0,g.jsxs)(m.default,{"data-testid":a.a.MODAL_HEADER,style:[i7.header,s],children:[(0,g.jsx)(m.default,{"data-testid":a.a.MODAL_HEADER_TITLE,children:n}),!o&&(0,g.jsx)(f.default,{accessibilityLabel:"Close",accessibilityRole:"button","data-testid":a.a.MODAL_CLOSE_BUTTON,onPress:P,style:i7.close,children:(0,g.jsx)(a.m,{})})]}),(0,g.jsx)(m.default,{"data-testid":a.a.MODAL_BODY,style:i7.wrap,children:!!c&&e})]})});ni.displayName="Modal",C.A.create({div:{alignItems:"center",borderRadius:4,display:"flex",flexDirection:"row",gap:4,marginBottom:0,padding:4,paddingLeft:6,paddingRight:6},"light-pink":{backgroundColor:"#FFF4F3"},"light-yellow":{backgroundColor:"#FFF6D1"},wrapper:{display:"flex",flexDirection:"row"}});var nn=C.A.create({lg:{fontFamily:a.d.font.family.sans,fontSize:24,fontStyle:"normal",lineHeight:28},md:{fontFamily:a.d.font.family.sans,fontSize:20,fontStyle:"normal",lineHeight:24},sm:{fontFamily:a.d.font.family.sans,fontSize:16,fontStyle:"normal",lineHeight:20},xsm:{fontFamily:a.d.font.family.sans,fontSize:14,fontStyle:"normal",lineHeight:18}}),nr=C.A.create({lg:{fontFamily:a.d.font.family.sans,fontSize:14,fontStyle:"normal",lineHeight:18},md:{fontFamily:a.d.font.family.sans,fontSize:12,fontStyle:"normal",lineHeight:16},sm:{fontFamily:a.d.font.family.sans,fontSize:10,fontStyle:"normal",lineHeight:12}}),na=C.A.create({default:{color:"#000"},red:{color:"#E81E25"},subdued:{color:"#6C6F75"}}),no=C.A.create({normal:{fontWeight:"400"},semibold:{fontWeight:"500"}}),ns={caption:nr,price:nn};(0,l.forwardRef)(({color:e,size:t,style:i,variant:n,weight:r,...a},o)=>{let s=(0,l.useMemo)(()=>{let a=i?[i]:[];return"price"===n?a.push(ns[n][t],no[r??"semibold"]):a.push(ns[n][t??"sm"],na[e],no[r??"normal"]),a},[n,t,i,e,r]);return(0,g.jsx)(_.default,{...a,ref:o,role:"paragraph",style:s})}).displayName="Typography";var nl={event:{type:"interaction"},interaction:{name:"Price Choice Engagement"},content:[{name:"Information",isClick:!0,region:"Pricing Options"}]};function nd({contract:e,isUnlocked:t,programs:i}){if(Array.isArray(i))return i.reduce((i,{programName:n,programContent:r},a,o)=>ef(n)&&Array.isArray(r)?i.concat({title:n,divider:function({index:e,listLength:t,isUnlocked:i}){if(e===t-2)return i?"line-with-or":"line"}({isUnlocked:t,index:a,listLength:o.length}),items:function({contract:e,programContent:t}){return t.reduce((t,i)=>{let n=iy(i.description,e);return ef(n)?t.concat(n):t},[])}({contract:e,programContent:r})}):i,[])}var nc=C.A.create({modalContent:{width:"100%"},footer:{marginBottom:16},divider:{marginTop:24,height:1,backgroundColor:a.d.color.defaultMuted,width:"100%"},dividerWithOrContainer:{width:"100%",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",position:"relative"},dividerOrText:{position:"absolute",top:8,backgroundColor:"white",alignSelf:"center",padding:8,zIndex:100},logoContainer:{display:"flex",justifyContent:"center",flexDirection:"row",width:"100%"},logo:{width:120,height:50},logoUnlocked:{width:120,height:25},listContainer:{display:"flex",flexDirection:"column",gap:16,width:400,maxWidth:"100%",alignSelf:"center"},listSection:{display:"flex",flexDirection:"column"},listHeader:{fontFamily:a.d.font.family.sans,fontSize:15,fontWeight:"600",lineHeight:18,marginBottom:8,color:a.d.color.black},listItem:{fontFamily:a.d.font.family.sans,fontSize:13,lineHeight:16,flex:1,color:a.d.color.black},listContainerHeader:{flexDirection:"row",alignItems:"flex-start",gap:4}}),nu=({egpData:e,skuId:t})=>{let i=function({egpData:e,skuId:t}){let i=iE(),{data:n}=iJ("connected-device-carrier-content");return(0,l.useMemo)(()=>(function({egpData:e,carrierContent:t,selectedContract:i,skuId:n}){let r=eQ(e,{skuId:n}),a=ic(r,i);return ip(r)?{isUnlocked:!0,sections:nd({contract:a,isUnlocked:!0,programs:function(e){if(Array.isArray(e.unlocked)&&e.unlocked.length>0)return e.unlocked[0].pricingOptionsModel}(t)}),logoImageSource:{uri:function(e){if(Array.isArray(e.unlocked)&&e.unlocked.length>0)return e.unlocked[0].logoPath}(t)}}:{isUnlocked:!1,sections:nd({contract:a,isUnlocked:!1,programs:function(e,t){let i=iP(e,t.carrierCode);if(i)return i.pricingOptionsModel}(t,a)}),logoImageSource:{uri:function(e,t){let i=iP(e,t.carrierCode);if(i)return i.logoPath}(t,a)}}})({egpData:e,skuId:t,selectedContract:i,carrierContent:n??to}),[n,e,i,t])}({egpData:e,skuId:t}),n=(0,l.useRef)(null),r=(0,l.useCallback)(()=>{J({pageName:"Product Display Page",data:nl}),n.current?.openModal()},[]);return i.sections?(0,g.jsxs)(g.Fragment,{children:[(0,g.jsx)(w.default,{accessibilityLabel:"Pricing options info",accessibilityRole:"button",onPress:r,testID:a.a.CARRIER_INFO_BUTTON,children:(0,g.jsx)(a.g,{color:a.d.color.primaryEmphasisBlue,size:16})}),(0,g.jsx)(ni,{"data-testid":a.a.CARRIER_INFO_MODAL,ref:n,children:(0,g.jsxs)(m.default,{"data-testid":a.a.CARRIER_INFO_MODAL_CONTENT,style:nc.listContainer,children:[(0,g.jsx)(m.default,{"data-testid":a.a.CARRIER_LOGO_CONTAINER,style:[nc.logoContainer,nc.modalContent],children:(0,g.jsx)(A.default,{alt:"carrier logo",source:i.logoImageSource,style:i.isUnlocked?nc.logoUnlocked:nc.logo})}),i.sections.map(({title:e,items:t,divider:i})=>(0,g.jsxs)(m.default,{"data-testid":a.a.CARRIER_INFO_SECTION,style:nc.listSection,children:[(0,g.jsx)(_.default,{"aria-level":5,"data-testid":a.a.CARRIER_INFO_SECTION_TITLE,role:"heading",style:nc.listHeader,children:e}),t.map(e=>(0,g.jsxs)(m.default,{"data-testid":a.a.CARRIER_INFO_SECTION_ITEM,style:nc.listContainerHeader,children:[(0,g.jsxs)(_.default,{"data-testid":a.a.CARRIER_INFO_SECTION_BULLET,children:["•"," "]}),(0,g.jsx)(_.default,{"data-testid":a.a.CARRIER_INFO_SECTION_ITEM_TEXT,style:nc.listItem,children:e})]},e)),"line"===i&&(0,g.jsx)(m.default,{"data-testid":a.a.CARRIER_INFO_SECTION_DIVIDER,style:nc.divider}),"line-with-or"===i&&(0,g.jsxs)(m.default,{"data-testid":a.a.CARRIER_INFO_SECTION_DIVIDER_WITH_OR,style:nc.dividerWithOrContainer,children:[(0,g.jsx)(m.default,{"data-testid":a.a.CARRIER_INFO_SECTION_DIVIDER,style:nc.divider}),(0,g.jsx)(_.default,{"data-testid":a.a.CARRIER_INFO_SECTION_DIVIDER_WITH_OR,style:nc.dividerOrText,children:"OR"})]})]},e))]})})]}):null};function np(...e){let t=e.filter(e=>ef(e)&&e.length>0);if(0!==t.length)return t.join(" ")}nu.displayName="CarrierInfoModal";var nm={display:"flex",flexDirection:"row",alignItems:"center",gap:4},nf=({body:e,textClassName:t,textStyle:i,containerClassName:n,containerStyle:r,testID:o})=>(0,g.jsx)(b.S,{className:n,"data-testid":o,style:[nm,r],testID:o,children:e.filter(e=>ef(e.value)).map((e,n)=>(0,g.jsx)(I.E,{className:np(t,e.className),"data-testid":a.a.MESSAGE_PARTS_TEXT,style:[i,e.style],children:e.value},e.key??`${e.value}_${n}`))});nf.displayName="MessageParts";var ng=C.A.create({pricingOption:{borderStyle:"solid",borderRadius:a.d.size.radius.md,borderWidth:1,borderColor:a.d.color.techGray,padding:16},pricingOption_hovered:{borderColor:a.d.color.primaryEmphasisBlue},pricingOption_selected:{borderWidth:2,borderColor:a.d.color.primaryEmphasisBlue}}),ny=({isSelected:e,topMessage:t,bottomMessage:i,contract:n,retailOption:r})=>{let o=ik(),s=(0,l.useCallback)(()=>{J({pageName:"Product Display Page",data:{event:{type:"interaction"},interaction:{name:"Price Choice Engagement"},content:[{name:iS(n)?"Activate Later":1===n.numberOfPayments?"Activate Today":`${n.numberOfPayments} Monthly Installment`,isClick:!0,region:"Pricing Options"}],skus:[{id:n.skuId??"",unitPrice:n.customerPrice??n.currentPrice??void 0}]}}),o(n,r)},[n,r,o]),[d,c]=(0,l.useState)(!1),u=(0,l.useCallback)(()=>{c(!0)},[]),p=(0,l.useCallback)(()=>{c(!1)},[]);return(0,g.jsx)(w.default,{accessibilityRole:"button",onHoverIn:u,onHoverOut:p,onPress:s,testID:a.a.ACTIVATED_PRICE_OPTION_PRICING_OPTION_BUTTON,children:(0,g.jsxs)(b.S,{style:[ng.pricingOption,d&&ng.pricingOption_hovered,e&&ng.pricingOption_selected],testID:a.a.ACTIVATED_PRICE_OPTION_PRICING_OPTION_CONTENT,children:[(0,g.jsx)(nf,{body:t,testID:a.a.ACTIVATED_PRICE_OPTION_TOP_MESSAGE,textClassName:"font-500 text-3"}),(0,g.jsx)(nf,{body:i,testID:a.a.ACTIVATED_PRICE_OPTION_BOTTOM_MESSAGE,textClassName:"text-3"})]})})};ny.displayName="PricingOption";var nP=C.A.create({container:{display:"flex",flexDirection:"column",gap:16},header:{alignItems:"center",display:"flex",flexDirection:"row",gap:4},list:{display:"flex",flexDirection:"column",gap:16}}),nh=e=>{let{egpData:t,skuId:i,stylingClassName:n}=e,r=iu(eQ(t,{skuId:i})),{pricingOptions:o,disclaimer:s}=function({egpData:e,skuId:t}){let i=ix(),n=iE(),r=iB(),{data:a}=iJ("connected-device-carrier-content");return(0,l.useMemo)(()=>({pricingOptions:function(e){let{egpData:t,skuId:i}=e,n=iw({egpData:t,skuId:i});return eu(n)?void 0:n.map(t=>(function(e,{carrierContent:t,egpData:i,skuId:n,selectedContract:r,tradeInAppraisal:a}){if(!ep(e.numberOfPayments))return;let o=eQ(i,{skuId:n}),s=il(o)?o.mobileContracts:[],l=ib({content:t,contract:e,section:"PRICE_OPTIONS_TOGGLE_BLOCK",isUnlocked:ip(o),mobileContracts:s}),d=iO(e,{tradeInAppraisal:a}),c=e6(e.customerPrice??e.currentPrice,{zeroStrategy:"showCurrency"});return e.numberOfPayments>1&&(c+="/mo."),d&&(c+="*"),{derivedId:iT(e),contract:e,isSelected:function(e,{selectedContract:t,egpData:i,skuId:n}){if(e5()){let t=eQ(i,{skuId:n});return ip(t)||eR(t)?"STANDARD"===e.purchaseType:!!e.isDefaultContract}return et(t)?iT(e)===iT(t):iS(e)}(e,{selectedContract:r,egpData:i,skuId:n}),topMessage:[{value:c},{value:l.additionalInfo},{className:"text-1 font-400",value:d&&"Estimated trade-in value applied."}],bottomMessage:[{value:l.description}]}})(t,e)).filter(e=>!eu(e))}({carrierContent:a??to,egpData:e,selectedContract:n,skuId:t,tradeInAppraisal:i}),disclaimer:function({egpData:e,carrierContent:t,tradeInAppraisal:i,skuId:n,selectedContract:r,showStandardPricing:a}){let o=eQ(e,{skuId:n});if(e5()&&eR(o)||ip(o)||a)return;let s=ic(o,r);if(iO(s,{tradeInAppraisal:i})){let e=function(e){let t=e.activatedTradeIn?.find(e=>"activatedTradeInDisclaimer"===e.name);if(t)return t.disclaimer}(t),i=e0(o);return!ep(i)&&e?.includes("{customerPrice}")?void d.Ay.warn("Can't generate pricing options disclaimer because customerPrice is undefined"):iy(e,{...s,customerPrice:i})}return iy(function(e,t){let i=ih(e,t);if(i)return i.disclaimer}(iP(t,s.carrierCode),s),s)}({egpData:e,carrierContent:a??to,tradeInAppraisal:i,skuId:t,selectedContract:n,showStandardPricing:r})}),[a,e,n,r,t,i])}(e);return eu(o)?null:(0,g.jsxs)(b.S,{className:n?`brix ${n}`:"brix","data-testid":a.a.PRICE_BLOCK_ACTIVATED_PRICE_OPTION,style:nP.container,children:[(0,g.jsxs)(b.S,{"data-testid":a.a.ACTIVATED_PRICING_OPTIONS_HEADER,style:nP.header,children:[(0,g.jsx)(I.E,{className:"font-500 text-2 leading-2","data-testid":a.a.ACTIVATED_PRICING_OPTIONS_HEADER_TITLE,children:"Pricing Options:"}),(0,g.jsx)(nu,{"data-testid":a.a.CARRIER_INFO_MODAL,egpData:t,skuId:i})]}),(0,g.jsx)(b.S,{"data-testid":a.a.ACTIVATED_PRICING_OPTIONS_LIST,style:nP.list,children:o.map(({topMessage:e,bottomMessage:t,isSelected:i,derivedId:n,contract:o})=>(0,g.jsx)(ny,{bottomMessage:t,contract:o,"data-testid":a.a.ACTIVATED_PRICING_OPTIONS_LIST_ITEM,isSelected:i,retailOption:r,topMessage:e},n))}),ef(s)&&(0,g.jsx)(b.S,{"data-testid":a.a.ACTIVATED_PRICING_OPTIONS_DISCLAIMER_CONTAINER,children:(0,g.jsx)(I.E,{className:"text-brand-tech-black text-2 leading-1","data-testid":a.a.ACTIVATED_PRICING_OPTIONS_DISCLAIMER_TEXT,children:s})})]})};nh.displayName="ActivatedPricingOptionsView",(0,c.J1)`
  query productsBySkuIds(
    $skuIds: [String!]!
    $productPriceInput: ProductItemPriceInput!
  ) {
    productsBySkuIds(skuIds: $skuIds) {
      ... on Product {
        brand
        whatItIs
        price(input: $productPriceInput) {
          skuType
          whatIfPrice {
            planPaidMember2 {
              price
              savings
              savingsPercent
              warranty {
                skuId
                skuType
                brand
                fullTermSavings
                termLength
                shortName
                piscesHref
              }
            }
            planPaidMember3 {
              price
              savings
              savingsPercent
              warranty {
                skuId
                skuType
                brand
                fullTermSavings
                termLength
                shortName
                piscesHref
              }
            }
          }
        }
        skuId
        name {
          short
        }
        description {
          long
        }
        primaryImage {
          piscesHref
        }
      }
    }
  }
`;var nI=(0,c.J1)`
  query getProductDetail($skuIds: [String!]!) {
    productsBySkuIds(skuIds: $skuIds) {
      ... on Product {
        skuId
        brand
        whatItIs
        name {
          short
        }
        description {
          long
        }
        primaryImage {
          piscesHref
        }
      }
    }
  }
`,nC=e=>e?`offer${e}: siteControlTimeline(siteControlTimelineInput: {page: "${e}", view: "native"}) {
    rows {
      __typename
      columns {
        __typename
        widgets
      }
    }
  }`:"",n_=(e,t)=>{if(!e||0===e.length)return(0,c.J1)`
      query {
        __typename
      }
    `;let i=e.map(nC).join(`
`),n=t?.operationName??"getSiteControlTimelineForOfferIds";return(0,c.J1)`query ${n} {
    ${i}
  }`};(0,c.J1)`
  query PriceBlock_OffersContentForProductQuery(
    $siteControlTimelineInput: SiteControlTimelineInput!
  ) {
    siteControlTimeline(siteControlTimelineInput: $siteControlTimelineInput) {
      __typename
      rows {
        __typename
        columns {
          __typename
          widgets
        }
      }
    }
  }
`;var nb="bbyGiftCard",nT=1,nS=e=>{let t=[];return es(e)&&"price"in e&&er(e.price)&&(t=e.price.priceWithCart?.giftSkus??e.price.giftSkus??[]),eo(e)&&(t=e.giftSkus??e.priceWithCart?.giftSkus??[]),Array.from(t).sort((e,t)=>{let i=e.isGiftCard&&e.brand?.includes("Best Buy")?0:1,n=t.isGiftCard&&t.brand?.includes("Best Buy")?0:1;return i!==n?i-n:t.savings-e.savings})},nO=e=>e.map(e=>e.skuId).filter(ef),nv=e=>Array.from(new Set(Array.from(e).sort((e,t)=>t.savings-e.savings).map(e=>e.offerId).filter(ef))),nw=e=>e.reduce((e,t)=>Math.round((e+t.savings)*100)/100,0),nA=({value:e,prefix:t,suffix:i,threshold:n=nT})=>e>n?`${t}${e6(e,{decimalStrategy:"hide-decimals-if-value-is-integer"})}${i}`:"",nE=e=>{let t,{gifts:i,giftSkuType:n,skuPromotionalMessage:r,topGiftCard:a}=e,o=nw(i),s=i.length,l=nA({value:o,prefix:": ",suffix:" value",threshold:nT}),{title:d,description:c}=(({giftSkuType:e,gifts:t,skuPromotionalMessage:i})=>e&&0!==t.length?e===nb?(e=>{let t=e.filter(e=>e.isGiftCard&&e.isBestBuyGiftCard);if(0===t.length)return{};if(1===t.length)return{description:"included with purchase",title:`Free ${e6(t[0].savings,{decimalStrategy:"hide-decimals-if-value-is-integer"})} gift card`};let i=t.reduce((e,t)=>e+t.savings,0);return{description:"included with purchase",title:`${e6(i,{decimalStrategy:"hide-decimals-if-value-is-integer"})} in free gift cards`}})(t):(({gifts:e,skuPromotionalMessage:t})=>{let i=e.filter(e=>!e.isBestBuyGiftCard);if(0===i.length)return{};if(1===i.length)return ef(t)&&""!==t.trim()?{title:t}:{title:"Free gift",description:"included with purchase"};if(ef(t)&&""!==t.trim()){let e=i.length-1;return{title:t,description:`Plus ${e} other free ${1===e?"gift":"gifts"}`}}return{title:`${i.length} free gifts`,description:"included with purchase"}})({gifts:t,skuPromotionalMessage:i}):{})({gifts:i,giftSkuType:n,skuPromotionalMessage:r});return{...1===(t={totalGifts:s,skuPromotionalMessage:r,topGiftCard:a,suffixTotalGiftSavings:l}).totalGifts?(e=>{let{topGiftCard:t,skuPromotionalMessage:i,suffixTotalGiftSavings:n}=e;if(et(t)&&"number"==typeof t.savings){let e=`Free ${e6(t.savings,{decimalStrategy:"hide-decimals-if-value-is-integer"})} gift card with purchase`;return{giftCardMessage:e,gwpPromoMessage:e}}return ef(i)&&""!==i.trim()?{giftCardMessage:"",gwpPromoMessage:`${i}${n}`}:{giftCardMessage:"",gwpPromoMessage:`Free item with purchase${n}`}})(t):t.totalGifts>1?(e=>{let{totalGifts:t,topGiftCard:i,skuPromotionalMessage:n,suffixTotalGiftSavings:r}=e;return et(i)&&"number"==typeof i.savings?{giftCardMessage:`Free ${e6(i.savings,{decimalStrategy:"hide-decimals-if-value-is-integer"})} gift card with purchase`,gwpPromoMessage:`Free ${e6(i.savings,{decimalStrategy:"hide-decimals-if-value-is-integer"})} gift card & ${t-1} more with purchase${r}`}:ef(n)&&""!==n.trim()?{giftCardMessage:"",gwpPromoMessage:`${n} & ${t-1} more${r}`}:{giftCardMessage:"",gwpPromoMessage:`${t} free items with purchase${r}`}})(t):{giftCardMessage:"",gwpPromoMessage:`Free item(s) with purchase${t.suffixTotalGiftSavings}`},...d?{title:d}:{},...c?{description:c}:{}}},nx=(e,t,i)=>({giftCardLinkMessage:t.giftCardMessage,gwpPromotionalMessage:t.gwpPromoMessage,hasGifts:e.length>0,showGiftCardLink:i,totalGifts:e.length,...t.title?{title:t.title}:{},...t.description?{description:t.description}:{}});function nL(e,t){let{isComplex:i,giftSkus:n,giftSkuIds:r,giftOfferIds:a}=(0,l.useMemo)(()=>{let t=es(e)?"price"in e&&er(e.price)&&(e.price.priceWithCart?.giftSkus??[]).length>0:!!eo(e)&&((e.giftSkus?.length??0)>0||((e.priceWithCart?.giftSkus??[]).length??0)>0),i=nS(e),n=nO(i),r=nv(i);return{isComplex:t,giftSkus:i,giftSkuIds:n,giftOfferIds:r}},[e]),{data:o,loading:s}=(0,T.I)(nI,{skip:!Array.isArray(r)||0===r.length,variables:{skuIds:r}}),d=(0,l.useMemo)(()=>n_(a,{operationName:"GiftCard_GWPSiteControlTimeline"}),[a]),{data:c,loading:u}=(0,T.I)(d,{skip:!Array.isArray(r)||0===r.length,errorPolicy:"ignore"}),{data:p,loading:m}=iJ("complexgwp-offer-details",{skip:!Array.isArray(r)||0===r.length}),f=(0,l.useMemo)(()=>s||u||m||!Array.isArray(n)||0===n.length?null:(e=>{let{isComplex:t,giftSkus:i,productsResponse:n,offersRespons:r,offerDetailsResponse:a,giftSkuType:o}=e,s=((e,t,i)=>{if(!e||!t||e.length!==t.length)return[];let n=e.map((e,i)=>{let n=t[i];return{skuId:e.skuId,savings:e.savings,offerId:e.offerId,shortName:n.name?.short??"",longDescription:n.description?.long??"",primaryImage:n.primaryImage?.piscesHref??"",isBestBuyGiftCard:!!(e.isGiftCard&&n.brand?.includes("Best Buy"))}});return i===nb?n.filter(e=>e.isBestBuyGiftCard):"giftSku"===i?n.filter(e=>!e.isBestBuyGiftCard):n})(i,n?.productsBySkuIds?.filter(es)??[],o),l=nw(i);if(t){let e=a?.json?.OfferContent?.DefaultDisclaimer??"",i=ii(r);return{isComplex:t,gwpItems:s.map(t=>{let n=t.offerId,r=i?.find(e=>e.offerId===n);return{...t,offerDetails:e,linkTo:r?.linkTo??"",disclaimer:r?.disclaimer??"",skuPromotionalMessage:r?.skuPromotionalMessage??"",bodyCopy:r?.bodyCopy??""}}),totalGiftSavings:l}}return{isComplex:t,gwpItems:s,totalGiftSavings:l}})({isComplex:i,giftSkus:n,productsResponse:o,offersRespons:c,offerDetailsResponse:p,giftSkuType:t}),[o,c,p,i,n,s,u,m,t]);return{loading:s||u||m,gwpModalData:f,giftSkus:n}}function nk(e,t){let{giftSkus:i,giftSkuIds:n,giftOfferIds:r}=(0,l.useMemo)(()=>{let t=nS(e),i=nO(t),n=nv(t);return{giftSkus:t,giftSkuIds:i,giftOfferIds:n}},[e]),a=(0,l.useMemo)(()=>n_(r,{operationName:"GiftCard_GWPSiteControlTimeline"}),[r]),{data:o,loading:s}=(0,T.I)(a,{skip:!Array.isArray(n)||0===n.length,errorPolicy:"ignore"}),d=(0,l.useMemo)(()=>s||!Array.isArray(i)||0===i.length?null:((e,t,i)=>{let n;if(0===e.length)return{giftCardLinkMessage:"",gwpPromotionalMessage:"",hasGifts:!1,showGiftCardLink:!1,totalGifts:0};let r=e.map(e=>{let t=!!e.isGiftCard,i=!!(t&&e.brand?.includes("Best Buy"));return{...e,isGiftCard:t,isBestBuyGiftCard:i}}),a=r.some(e=>e.isGiftCard),o=(n=r.filter(e=>e.isGiftCard)).reduce((e,t)=>e.savings&&t.savings&&t.savings>e.savings||e.savings&&t.savings&&t.savings===e.savings&&t.isBestBuyGiftCard?t:e,n[0]),s=!!(a&&o.isBestBuyGiftCard);return s?nx(e,nE({gifts:r,topGiftCard:o,giftSkuType:i}),s):nx(e,nE({gifts:r,skuPromotionalMessage:ii(t).find(e=>ef(e.skuPromotionalMessage)&&""!==e.skuPromotionalMessage.trim())?.skuPromotionalMessage??"",giftSkuType:i}),s)})(i,o,t),[s,i,o,t]);return{loading:s,gwpPromoLink:d}}function nB(e,t){return t?.skuId?t.skuId:e&&es(e)?e.skuId??e.price?.skuId??void 0:void 0}function nD(e,t){if(es(e)&&er(e.price)){var i;let t=er(i=e.price)&&Object.prototype.hasOwnProperty.call(i,"restrictedPriceDisplayMessage"),{isMAP:n,strictMapIcr:r,icrCode:a,restrictedPriceDisplayMessage:o,displayableCustomerPrice:s}=e.price;return{isMAP:n,strictMapIcr:r,icrCode:a,restrictedPriceDisplayMessage:o,displayableCustomerPrice:s,isUsingRestrictedPriceMessage:t}}if(ea(e)){let{isMAP:t,strictMapIcr:i,icrCode:n}=e;return{isMAP:t,strictMapIcr:i,icrCode:n}}if(eo(e)&&Array.isArray(e.skus)){let i=t?.skuId?e.skus.find(e=>ea(e)&&e.skuId===t.skuId)??e.skus.find(ea):e.skus.find(ea);if(i){let{isMAP:e,strictMapIcr:t,icrCode:n}=i;return{isMAP:e,strictMapIcr:t,icrCode:n}}}return{}}function nR(e,t){return!!(function(e,t){let{strictMapIcr:i}=nD(e,t);return!!i}(e,t)||function(e,t){let{restrictedPriceDisplayMessage:i,isUsingRestrictedPriceMessage:n}=nD(e,t);return!!(n&&ef(i))}(e,t))||!t.isUserLoggedIn&&!!function(e,t){let{icrCode:i,isMAP:n}=nD(e,t);return!!n||"1"===i||"2"===i}(e,t)}function nM(e,t){let{icrCode:i}=nD(e,t);return"3"===i}var nN=(0,v.v)()((e,t)=>({tappedSkus:{},tapForPrice:t=>{t&&e(e=>t in e.tappedSkus?e:{tappedSkus:{...e.tappedSkus,[t]:!0}})},hasTappedForPrice:e=>!!t().tappedSkus[e]}));function n$(e){let[t,i]=(0,l.useState)(!1),n=nN((0,l.useCallback)(t=>!!e&&!!t.tappedSkus[e],[e])),r=nN(e=>e.tapForPrice),a=(0,l.useCallback)(()=>{e?r(e):i(!0)},[e,r]);return{hasTapped:e?n:t,handleTap:a}}var nW=(0,l.createContext)(void 0);nW.displayName="RestrictedPriceContext";var nF=({data:e,params:t,children:i})=>{let{hasTapped:n,handleTap:r}=n$(nB(e,t)),a=(0,l.useMemo)(()=>({isPriceHidden:null!=e&&!!(nM(e,t)||nR(e,t)&&!n),handleTapForPrice:r}),[n,r,e,t]);return(0,g.jsx)(nW.Provider,{value:a,children:i})};nF.displayName="RestrictedPriceProvider";var nG={isPriceHidden:!1,handleTapForPrice:()=>{}};function nj(){return(0,l.useContext)(nW)||nG}var nU=function(){return(nU=Object.assign||function(e){for(var t,i=1,n=arguments.length;i<n;i++)for(var r in t=arguments[i])Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r]);return e}).apply(this,arguments)},nH=new Map,nz=new Map,nV=!0,nK=!1;function nY(e){return e.replace(/[\s,]+/g," ").trim()}function nq(e){for(var t=[],i=1;i<arguments.length;i++)t[i-1]=arguments[i];"string"==typeof e&&(e=[e]);var n=e[0];return t.forEach(function(t,i){t&&"Document"===t.kind?n+=t.loc.source.body:n+=t,n+=e[i+1]}),function(e){var t=nY(e);if(!nH.has(t)){var i,n,r,a,o,s=(0,k.qg)(e,{experimentalFragmentVariables:nK,allowLegacyFragmentVariables:nK});if(!s||"Document"!==s.kind)throw Error("Not a valid GraphQL document.");nH.set(t,((a=new Set((i=new Set,n=[],s.definitions.forEach(function(e){if("FragmentDefinition"===e.kind){var t,r=e.name.value,a=nY((t=e.loc).source.body.substring(t.start,t.end)),o=nz.get(r);o&&!o.has(a)?nV&&console.warn("Warning: fragment with name "+r+` already exists.
graphql-tag enforces all fragment names across your application to be unique; read more about
this in the docs: http://dev.apollodata.com/core/fragments.html#unique-names`):o||nz.set(r,o=new Set),o.add(a),i.has(a)||(i.add(a),n.push(e))}else n.push(e)}),r=nU(nU({},s),{definitions:n})).definitions)).forEach(function(e){e.loc&&delete e.loc,Object.keys(e).forEach(function(t){var i=e[t];i&&"object"==typeof i&&a.add(i)})}),(o=r.loc)&&(delete o.startToken,delete o.endToken),r))}return nH.get(t)}(n)}var nX=nq;(n=nq||(nq={})).gql=nX,n.resetCaches=function(){nH.clear(),nz.clear()},n.disableFragmentWarnings=function(){nV=!1},n.enableExperimentalFragmentVariables=function(){nK=!0},n.disableExperimentalFragmentVariables=function(){nK=!1},nq.default=nq;var nZ=nq,nJ=nZ`
  fragment EcoRebatesExperience_ItemPrice on ItemPrice {
    isEcoRebateEligible
    icrCode
    restrictedPriceDisplayMessage
    openBoxCondition
    mobileContracts {
      isDefaultContract
    }
  }
`,nQ=nZ`
  fragment EcoRebatesExperience__EcoRebate on EcoRebate {
    area {
      zipCode
    }
    productRebateDetails {
      rebatePrograms {
        name
        homeUrl
        importantDetails
        id
        formLabel
        claimFormUrl
        amountLabel
        purchaseDates {
          buyAfter
          buyBefore
          claimBy
          claimWithin
        }
        offerTypes
      }
      maxRebateAmountLabel
    }
  }
`,n0=nZ`
  fragment FinanceOptionPaymentInit_ItemPrice on ItemPrice {
    heroRenderPriceOptions
    financeOption {
      financeTerm
      monthlyPayment
      offerId
      planType
      rate
      totalCost
      totalCostIncludingTax
    }
  }
`,n1=nZ`
  fragment FinanceOptionPaymentInit_BundlePrice on BundlePrice {
    __typename
  }
`,n2=nZ`
  fragment FinanceOptionPaymentInit_BundleSkuLine on BundleSkuLine {
    id
    skuId
  }
`,n3=(nZ`
  fragment FinanceOptionPaymentInit_BundlePricing on BundlePricing {
    bundlePrice {
      ...FinanceOptionPaymentInit_BundlePrice
    }
    skus {
      ...FinanceOptionPaymentInit_BundleSkuLine
    }
  }
  ${n1}
  ${n2}
`,nZ`
  fragment BottomPriceMessage_BundlePrice on BundlePrice {
    __typename
  }
`),n6=nZ`
  fragment BottomPriceMessage_BundleSkuLine on BundleSkuLine {
    id
    skuId
    mobileContracts {
      carrierCode
      downPaymentAmount
      matchesCurrentPrice
      isDefaultContract
    }
    connectionType
  }
`,n5=(nZ`
  fragment BottomPriceMessage_BundlePricing on BundlePricing {
    bundlePrice {
      ...BottomPriceMessage_BundlePrice
    }
    skus {
      ...BottomPriceMessage_BundleSkuLine
    }
  }
  ${n3}
  ${n6}
`,nZ`
  fragment ConditionalTapForPrice_BundlePrice on BundlePrice {
    customerPrice
  }
`),n4=nZ`
  fragment ConditionalTapForPrice_BundleSkuLine on BundleSkuLine {
    id
    skuId
    customerPrice
    isMAP
    strictMapIcr
    icrCode
  }
`,n8=(nZ`
  fragment ConditionalTapForPrice_BundlePricing on BundlePricing {
    bundlePrice {
      ...ConditionalTapForPrice_BundlePrice
    }
    skus {
      ...ConditionalTapForPrice_BundleSkuLine
    }
  }
  ${n5}
  ${n4}
`,nZ`
  fragment CustomerPrice_BundlePrice on BundlePrice {
    customerPrice
    deliveryTotal
    deliveryAndInstallationTotal
  }
`),n9=nZ`
  fragment CustomerPrice_BundleSkuLine on BundleSkuLine {
    id
    skuId
    customerPrice
    customerSubBundlePrice
    mobileContracts {
      customerPrice
      currentPrice
      numberOfPayments
      isDefaultContract
    }
  }
`,n7=(nZ`
  fragment CustomerPrice_BundlePricing on BundlePricing {
    bundlePrice {
      ...CustomerPrice_BundlePrice
    }
    skus {
      ...CustomerPrice_BundleSkuLine
    }
  }
  ${n8}
  ${n9}
`,nZ`
  fragment DealAlert_BundlePrice on BundlePrice {
    __typename
  }
`),re=nZ`
  fragment DealAlert_BundleSkuLine on BundleSkuLine {
    id
    skuId
  }
`,rt=(nZ`
  fragment DealAlert_BundlePricing on BundlePricing {
    bundlePrice {
      ...DealAlert_BundlePrice
    }
    skus {
      ...DealAlert_BundleSkuLine
    }
  }
  ${n7}
  ${re}
`,nZ`
  fragment FinanceOptions_BundlePrice on BundlePrice {
    __typename
  }
`),ri=nZ`
  fragment FinanceOptions_BundleSkuLine on BundleSkuLine {
    id
    skuId
  }
`,rn=(nZ`
  fragment FinanceOptions_BundlePricing on BundlePricing {
    bundlePrice {
      ...FinanceOptions_BundlePrice
    }
    skus {
      ...FinanceOptions_BundleSkuLine
    }
  }
  ${rt}
  ${ri}
`,nZ`
  fragment Footer_BundlePrice on BundlePrice {
    dealExpirationTimeStamp
    customerPrice
  }
`),rr=nZ`
  fragment Footer_BundleSkuLine on BundleSkuLine {
    id
    skuId
    dealExpirationTimeStamp
    customerPrice
    mobileContracts {
      billCreditAmount
      contractTotalSavings
      numberOfPayments
      purchaseType
      isDefaultContract
    }
  }
`,ra=(nZ`
  fragment Footer_BundlePricing on BundlePricing {
    bundlePrice {
      ...Footer_BundlePrice
    }
    skus {
      ...Footer_BundleSkuLine
    }
  }
  ${rn}
  ${rr}
`,nZ`
  fragment Header_BundlePrice on BundlePrice {
    preferredBadging
    dealExpirationTimeStamp
  }
`),ro=nZ`
  fragment Header_BundleSkuLine on BundleSkuLine {
    id
    skuId
    preferredBadging
    puckDisplayMessage
    puckMessageURL
    openBoxCondition
    dealExpirationTimeStamp
  }
`,rs=(nZ`
  fragment Header_BundlePricing on BundlePricing {
    bundlePrice {
      ...Header_BundlePrice
    }
    skus {
      ...Header_BundleSkuLine
    }
  }
  ${ra}
  ${ro}
`,nZ`
  fragment PaymentOptionsDetail on PaymentOption {
    numberOfInstallments
    installmentAmount
    installmentServiceFee
    vendor
    isDisplayable
    type
  }
`),rl=nZ`
  fragment PaymentOptions_BundleSkuLine on BundleSkuLine {
    id
    skuId
    paymentOptions {
      ...PaymentOptionsDetail
    }
  }
  ${rs}
`,rd=(nZ`
  fragment PaymentOptions_BundlePricing on BundlePricing {
    paymentOptions {
      ...PaymentOptionsDetail
    }
    skus {
      ...PaymentOptions_BundleSkuLine
    }
  }
  ${rs}
  ${rl}
`,nZ`
  fragment PriceBlockInit_Single_ItemPrice on ItemPrice {
    customerPrice @skip(if: $useDisplayablePriceFields)
    displayableCustomerPrice @include(if: $useDisplayablePriceFields)
    icrCode
    isMAP @skip(if: $useDisplayablePriceFields)
    restrictedPriceDisplayMessage @include(if: $useDisplayablePriceFields)
    strictMapIcr @skip(if: $useDisplayablePriceFields)
    openBoxCondition
    tieredOffersTracking {
      savings
    }
    connectionType
    mobileContracts {
      customerPrice
      currentPrice
      numberOfPayments
      isDefaultContract
    }
    skuId
  }
`),rc=nZ`
  fragment PriceBlockInit_Compact_ItemPrice on ItemPrice {
    displayableRegularPrice @include(if: $useDisplayablePriceFields)
    regularPrice @skip(if: $useDisplayablePriceFields)
    showTotalSavings
    totalSavings
    totalSavingsPercent
    openBoxSavings
    preferredBadging
    puckDisplayMessage
    puckMessageURL
    priceWithCart {
      totalOfferSavings
      adjustedCartItems {
        skuId
        savingsAdjustment
        previousCustomerPrice
        newCustomerPrice
      }
    }
    totalNonPaidMemberSavings
    totalPaidMemberSavings
    mobileContracts {
      hasPriceRange
      regularPrice
      contractTotalSavings
      showTotalSavings
      totalSavingsPercent
      instantSavings
      totalSavingsPerTerm
      carrierCode
      downPaymentAmount
      matchesCurrentPrice
      id
      purchaseType
    }
    ...PriceBlockInit_Single_ItemPrice
  }
  ${rd}
`,ru=nZ`
  fragment PriceBlockInit_Compact_Product on Product {
    price(input: $productPriceInput) {
      ...PriceBlockInit_Compact_ItemPrice
    }
    skuId
  }
  ${rc}
`,rp=nZ`
  fragment PriceBlockInit_Small_ItemPrice on ItemPrice {
    dealExpirationTimeStamp
    ...PriceBlockInit_Compact_ItemPrice
  }
  ${rc}
`,rm=nZ`
  fragment PriceBlockInit_Medium_ItemPrice on ItemPrice {
    heroRenderPriceOptions
    financeOption {
      financeTerm
      monthlyPayment
      offerId
      planType
      rate
      totalCost
      totalCostIncludingTax
    }
    skuId
    ...PriceBlockInit_Small_ItemPrice
  }
  ${rp}
`,rf=nZ`
  fragment PriceBlockInit_Large_ItemPrice on ItemPrice {
    paymentOptions {
      numberOfInstallments
      installmentAmount
      installmentServiceFee
      vendor
      isDisplayable
      type
    }
    ...PriceBlockInit_Medium_ItemPrice
  }
  ${rm}
`,rg=nZ`
  fragment PriceBlockInit_Large_Product on Product {
    buyingOptions {
      __typename
      pdpUrl
      type
    }
    price(input: $productPriceInput) {
      ...PriceBlockInit_Large_ItemPrice
    }
    skuId
  }
  ${rf}
`,ry=nZ`
  fragment PriceBlockInit_Medium_Product on Product {
    price(input: $productPriceInput) {
      ...PriceBlockInit_Medium_ItemPrice
    }
    skuId
  }
  ${rm}
`,rP=nZ`
  fragment PriceBlockInit_SavingsOnly_ItemPrice on ItemPrice {
    openBoxCondition
    showTotalSavings
    totalSavings
    tieredOffersTracking {
      savings
    }
    icrCode
    isMAP @skip(if: $useDisplayablePriceFields)
    restrictedPriceDisplayMessage @include(if: $useDisplayablePriceFields)
    strictMapIcr @skip(if: $useDisplayablePriceFields)
    puckDisplayMessage
    preferredBadging
    totalSavingsPercent
    connectionType
    mobileContracts {
      isDefaultContract
      contractTotalSavings
      totalSavingsPercent
      instantSavings
      totalSavingsPerTerm
      showTotalSavings
    }
    skuId
  }
`,rh=nZ`
  fragment PriceBlockInit_SavingsOnly_Product on Product {
    price(input: $productPriceInput) {
      ...PriceBlockInit_SavingsOnly_ItemPrice
    }
    skuId
  }
  ${rP}
`,rI=nZ`
  fragment PriceBlockInit_Single_Product on Product {
    price(input: $productPriceInput) {
      ...PriceBlockInit_Single_ItemPrice
    }
    skuId
  }
  ${rd}
`,rC=nZ`
  fragment PriceBlockInit_Small_Product on Product {
    price(input: $productPriceInput) {
      ...PriceBlockInit_Small_ItemPrice
    }
    skuId
  }
  ${rp}
`,r_=nZ`
  fragment PriceBlockInit_Warranty_ItemPrice on ItemPrice {
    preferredBadging
    puckDisplayMessage
    customerPrice @skip(if: $useDisplayablePriceFields)
    displayableCustomerPrice @include(if: $useDisplayablePriceFields)
    regularPrice @skip(if: $useDisplayablePriceFields)
    displayableRegularPrice @include(if: $useDisplayablePriceFields)
    totalSavings
    showTotalSavings
    skuId
  }
`,rb=nZ`
  fragment PriceBlockInit_Warranty_Product on Product {
    price(input: $productPriceInput) {
      ...PriceBlockInit_Warranty_ItemPrice
    }
    skuId
    termLength {
      value
      unitOfMeasure
    }
  }
  ${r_}
`,rT=nZ`
  fragment Savings_BundlePrice on BundlePrice {
    regularPrice
    totalSavings
    deliveryAndServices {
      regularPrice
      totalSavings
    }
  }
`,rS=nZ`
  fragment Savings_BundleSkuLine on BundleSkuLine {
    id
    skuId
    regularPrice
    regularSubBundlePrice
    showTotalSavings
    totalSavings
    mobileContracts {
      regularPrice
      contractTotalSavings
      totalSavingsPercent
      instantSavings
      totalSavingsPerTerm
      numberOfPayments
      isDefaultContract
      showTotalSavings
    }
  }
`,rO=(nZ`
  fragment Savings_BundlePricing on BundlePricing {
    bundlePrice {
      ...Savings_BundlePrice
    }
    skus {
      ...Savings_BundleSkuLine
    }
  }
  ${rT}
  ${rS}
`,nZ`
  fragment TopPriceMessage_BundlePrice on BundlePrice {
    __typename
  }
`),rv=nZ`
  fragment TopPriceMessage_BundleSkuLine on BundleSkuLine {
    id
    skuId
    __typename
  }
`,rw=(nZ`
  fragment TopPriceMessage_BundlePricing on BundlePricing {
    bundlePrice {
      ...TopPriceMessage_BundlePrice
    }
    skus {
      ...TopPriceMessage_BundleSkuLine
    }
  }
  ${rO}
  ${rv}
`,nZ`
  fragment ConditionalTapForPrice_ItemPrice on ItemPrice {
    isMAP @skip(if: $useDisplayablePriceFields)
    strictMapIcr @skip(if: $useDisplayablePriceFields)
    icrCode
    restrictedPriceDisplayMessage @include(if: $useDisplayablePriceFields)
    displayableCustomerPrice @include(if: $useDisplayablePriceFields)
    customerPrice @skip(if: $useDisplayablePriceFields)
  }
`),rA=nZ`
  fragment Header_ItemPrice on ItemPrice {
    preferredBadging
    puckDisplayMessage
    puckMessageURL
    priceWithCart {
      totalOfferSavings
      adjustedCartItems {
        skuId
        savingsAdjustment
        previousCustomerPrice
        newCustomerPrice
      }
    }
    totalNonPaidMemberSavings
    totalPaidMemberSavings
    openBoxCondition
    dealExpirationTimeStamp
  }
`,rE=nZ`
  fragment TopPriceMessage_ItemPrice on ItemPrice {
    mobileContracts {
      isDefaultContract
      hasPriceRange
      numberOfPayments
    }
    connectionType
    puckDisplayMessage
    preferredBadging
    openBoxCondition
    priceWithCart {
      totalOfferSavings
    }
    totalNonPaidMemberSavings
    totalPaidMemberSavings
  }
`,rx=nZ`
  fragment DealAlert_ItemPrice on ItemPrice {
    openBoxCondition
    isMAP
    strictMapIcr
    icrCode
    restrictedPriceDisplayMessage
    mobileContracts {
      __typename
    }
    displayableCustomerPrice @include(if: $useDisplayablePriceFields)
    customerPrice @skip(if: $useDisplayablePriceFields)
  }
`,rL=nZ`
  fragment CustomerPrice_ItemPrice on ItemPrice {
    displayableCustomerPrice @include(if: $useDisplayablePriceFields)
    customerPrice @skip(if: $useDisplayablePriceFields)
    mobileContracts {
      customerPrice
      currentPrice
      numberOfPayments
      isDefaultContract
    }
  }
`,rk=nZ`
  fragment Savings_ItemPrice on ItemPrice {
    displayableRegularPrice @include(if: $useDisplayablePriceFields)
    regularPrice @skip(if: $useDisplayablePriceFields)
    showTotalSavings
    totalSavings
    totalSavingsPercent
    openBoxSavings
    mobileContracts {
      regularPrice
      contractTotalSavings
      totalSavingsPercent
      instantSavings
      totalSavingsPerTerm
      numberOfPayments
      isDefaultContract
      showTotalSavings
    }
  }
`,rB=nZ`
  fragment BottomPriceMessage_ItemPrice on ItemPrice {
    mobileContracts {
      carrierCode
      downPaymentAmount
      matchesCurrentPrice
      isDefaultContract
    }
    connectionType
  }
`,rD=nZ`
  fragment FinanceOptions_ItemPrice on ItemPrice {
    heroRenderPriceOptions
    financeOption {
      financeTerm
      monthlyPayment
      offerId
      planType
      rate
      totalCost
      totalCostIncludingTax
    }
  }
`,rR=nZ`
  fragment PaymentOptions_ItemPrice on ItemPrice {
    paymentOptions {
      numberOfInstallments
      installmentAmount
      installmentServiceFee
      vendor
      isDisplayable
      type
    }
  }
`,rM=nZ`
  fragment Footer_ItemPrice on ItemPrice {
    dealExpirationTimeStamp
    displayableCustomerPrice @include(if: $useDisplayablePriceFields)
    customerPrice @skip(if: $useDisplayablePriceFields)
    mobileContracts {
      billCreditAmount
      contractTotalSavings
      numberOfPayments
      purchaseType
      isDefaultContract
    }
  }
`,rN=nZ`
  fragment PriceBlockInit_ItemPrice on ItemPrice {
    __typename
    skuId
    tieredOffersTracking {
      savings
    }
    ...ConditionalTapForPrice_ItemPrice
    ...Header_ItemPrice
    ...TopPriceMessage_ItemPrice
    ...DealAlert_ItemPrice
    ...CustomerPrice_ItemPrice
    ...Savings_ItemPrice
    ...BottomPriceMessage_ItemPrice
    ...FinanceOptions_ItemPrice
    ...PaymentOptions_ItemPrice
    ...Footer_ItemPrice
  }
  ${rw}
  ${rA}
  ${rE}
  ${rx}
  ${rL}
  ${rk}
  ${rB}
  ${rD}
  ${rR}
  ${rM}
`,r$=nZ`
  fragment PriceBlockInit_Product on Product {
    __typename
    skuId
    name {
      short
    }
    termLength {
      __typename
      unitOfMeasure
      value
    }
    buyingOptions {
      __typename
      pdpUrl
      type
    }
    price(input: $productPriceInput) {
      ...PriceBlockInit_ItemPrice
    }
  }
  ${rN}
`,rW=nZ`
  fragment ExperimentsInit_ItemPrice on ItemPrice {
    experiments {
      membershipCarouselPlacement
    }
  }
`,rF=nZ`
  fragment ExperimentsInit_Product on Product {
    price(input: $productPriceInput) {
      ...ExperimentsInit_ItemPrice
    }
  }
  ${rW}
`,rG=nZ`
  fragment TieredOffersTrackingInit_ItemPrice on ItemPrice {
    tieredOffersTracking {
      amountConsideredToNextTier
      amountRemainingToNextTier
      nextTierId
      quantityConsideredToNextTier
      quantityRemainingToNextTier
      savings
      savingsType
      tieredOffersGroupName
      trackingBy
      tiers {
        discountValue
        minPurchaseAmount
        minQuantity
        offerId
        qualified
        tierId
      }
    }
  }
`,rj=nZ`
  fragment TieredOffersTrackingInit_Product on Product {
    price(input: $productPriceInput) {
      ...TieredOffersTrackingInit_ItemPrice
    }
  }
  ${rG}
`,rU=nZ`
  fragment PlusXOffersGateInit_ItemPrice on ItemPrice {
    showPlusOffers
  }
`,rH=nZ`
  fragment PlusXOffersGateInit_Product on Product {
    price(input: $productPriceInput) {
      ...PlusXOffersGateInit_ItemPrice
    }
  }
  ${rU}
`,rz=nZ`
  fragment MembershipUpsellInit_ItemPrice on ItemPrice {
    whatIfPrice {
      planPaidMember2 {
        price
        savings
        savingsPercent
      }
      planPaidMember3 {
        price
        savings
        savingsPercent
      }
    }
  }
`,rV=nZ`
  fragment MembershipUpsellInit_Product on Product {
    price(input: $productPriceInput) {
      ...MembershipUpsellInit_ItemPrice
    }
  }
  ${rz}
`,rK=nZ`
  fragment EcoRebatesInit_ItemPrice on ItemPrice {
    isEcoRebateEligible
  }
`,rY=nZ`
  fragment EcoRebatesInit_Product on Product {
    price(input: $productPriceInput) {
      ...EcoRebatesInit_ItemPrice
    }
  }
  ${rK}
`,rq=nZ`
  fragment PriceExperienceInit_RewardCabos_ItemPrice on ItemPrice {
    __typename
    skuId
    rewardCabosAvailable {
      offerId
      offerName
      type
      subType
      effectiveStartDateTime
      effectiveEndDateTime
    }
  }
`,rX=nZ`
  fragment PriceExperienceInit_RewardCabos_Product on Product {
    price(input: $productPriceInput) {
      ...PriceExperienceInit_RewardCabos_ItemPrice
    }
  }
  ${rq}
`,rZ=nZ`
  fragment SpendAndGetInit_ItemPrice on ItemPrice {
    spendAndGetCabosAvailable {
      offerId
      offerName
      optInCode
      isOfferActivated
      effectiveStartDate
      effectiveEndDate
    }
  }
`,rJ=nZ`
  fragment SpendAndGetInit_Product on Product {
    price(input: $productPriceInput) {
      ...SpendAndGetInit_ItemPrice
    }
  }
  ${rZ}
`,rQ=nZ`
  fragment CaboSucoInit_ItemPrice on ItemPrice {
    skuId
    customerSelectedDiscountsAvailable {
      offerId
      offerName
      type
      couponId
      savingsAdjustment
      effectiveStartDate
      effectiveEndDate
      effectiveEndTime
      isDiscountSelected
      offerPrice
      businessUnit
      customerAttribute
    }
  }
`,r0=nZ`
  fragment CaboSucoInit_Product on Product {
    price(input: $productPriceInput) {
      ...CaboSucoInit_ItemPrice
    }
  }
  ${rQ}
`,r1=nZ`
  fragment GiftWithPurchaseInit_ItemPrice on ItemPrice {
    giftSkus {
      __typename
      brand
      isGiftCard
      isRequiredWithOffer
      offerId
      parentSkus
      quantity
      savings
      skuId
    }
    priceWithCart {
      giftSkus {
        __typename
        brand
        isGiftCard
        isRequiredWithOffer
        offerId
        parentSkus
        quantity
        savings
        skuId
      }
      totalGiftSavings
    }
  }
`,r2=nZ`
  fragment GiftWithPurchaseInit_Product on Product {
    price(input: $productPriceInput) {
      ...GiftWithPurchaseInit_ItemPrice
    }
  }
  ${r1}
`,r3=nZ`
  fragment OffersInit_SkuOffer on SkuOffer {
    __typename
    hotOffer
    offerId
    offerType
    complexMemberOffer
  }
`,r6=nZ`
  fragment OffersInit_SkuOffersConnection on SkuOffersConnection {
    __typename
    offers {
      ...OffersInit_SkuOffer
    }
  }
  ${r3}
`,r5=nZ`
  fragment OffersInit_Product on Product {
    offers(input: $skuOffersInput) {
      ...OffersInit_SkuOffersConnection
    }
  }
  ${r6}
`,r4=nZ`
  fragment FinanceOptionsInit_ItemPrice on ItemPrice {
    totalSavings
    heroRenderPriceOptions
    financeOption {
      financeTerm
      monthlyPayment
      offerId
      planType
      rate
      totalCost
      totalCostIncludingTax
    }
    paymentOptions {
      numberOfInstallments
      installmentAmount
      installmentServiceFee
      vendor
      isDisplayable
      type
    }
    showLeasingOption
    isBbyCardMember
  }
`,r8=nZ`
  fragment PromotionalOptionListInit_Product on Product {
    __typename
    skuId
    buyingOptions {
      __typename
      pdpUrl
      type
    }
    price(input: $productPriceInput) {
      displayableCustomerPrice @include(if: $useDisplayablePriceFields)
      customerPrice @skip(if: $useDisplayablePriceFields)
      displayableRegularPrice @include(if: $useDisplayablePriceFields)
      regularPrice @skip(if: $useDisplayablePriceFields)
      mobileContracts {
        isDefaultContract
      }
      connectionType
      preferredBadging
      puckDisplayMessage
      ...FinanceOptionsInit_ItemPrice
    }
  }
  ${r4}
`,r9=nZ`
  fragment PriceExperienceInit_Product on Product {
    ...PriceBlockInit_Product
    ...ExperimentsInit_Product
    ...TieredOffersTrackingInit_Product
    price(input: $productPriceInput) {
      offerRankings @include(if: $useOfferRankings) {
        groupName
        numberOfGiftCards
        offerId
        path
        rank
        totalGiftCardAmount
        type
      }
    }
    ...PlusXOffersGateInit_Product @include(if: $usePlusXOffersFields)
    ...MembershipUpsellInit_Product @include(if: $useMembershipUpsellFields)
    ...EcoRebatesInit_Product @include(if: $useEcoRebatesFields)
    ...PriceExperienceInit_RewardCabos_Product
      @include(if: $useSpendAndGetFields)
    ...SpendAndGetInit_Product @include(if: $useSpendAndGetFields)
    ...CaboSucoInit_Product @include(if: $useCaboSucoFields)
    ...GiftWithPurchaseInit_Product @include(if: $useGiftWithPurchaseFields)
    ...OffersInit_Product @include(if: $useOffersFields)
    ...PromotionalOptionListInit_Product
      @include(if: $usePromotionalOptionListFields)
  }
  ${r$}
  ${rF}
  ${rj}
  ${rH}
  ${rV}
  ${rY}
  ${rX}
  ${rJ}
  ${r0}
  ${r2}
  ${r5}
  ${r8}
`,r7=nZ`
  fragment PaymentOptions_BundlePrice on BundlePrice {
    __typename
  }
`,ae=nZ`
  fragment PriceBlockInit_BundlePrice on BundlePrice {
    __typename
    ...ConditionalTapForPrice_BundlePrice
    ...Header_BundlePrice
    ...TopPriceMessage_BundlePrice
    ...DealAlert_BundlePrice
    ...CustomerPrice_BundlePrice
    ...Savings_BundlePrice
    ...BottomPriceMessage_BundlePrice
    ...FinanceOptions_BundlePrice
    ...PaymentOptions_BundlePrice
    ...Footer_BundlePrice
  }
  ${n5}
  ${ra}
  ${rO}
  ${n7}
  ${n8}
  ${rT}
  ${n3}
  ${rt}
  ${r7}
  ${rn}
`,at=nZ`
  fragment PriceBlockInit_BundleSkuLine on BundleSkuLine {
    __typename
    id
    skuId
    ...ConditionalTapForPrice_BundleSkuLine
    ...Header_BundleSkuLine
    ...TopPriceMessage_BundleSkuLine
    ...DealAlert_BundleSkuLine
    ...CustomerPrice_BundleSkuLine
    ...Savings_BundleSkuLine
    ...BottomPriceMessage_BundleSkuLine
    ...FinanceOptions_BundleSkuLine
    ...PaymentOptions_BundleSkuLine
    ...Footer_BundleSkuLine
  }
  ${n4}
  ${ro}
  ${rv}
  ${re}
  ${n9}
  ${rS}
  ${n6}
  ${ri}
  ${rl}
  ${rr}
`,ai=nZ`
  fragment PriceBlockInit_BundlePricing on BundlePricing {
    bundlePrice {
      ...PriceBlockInit_BundlePrice
    }
    skus {
      ...PriceBlockInit_BundleSkuLine
    }
  }
  ${ae}
  ${at}
`,an=nZ`
  fragment PriceExperienceInit_BundlePricing on BundlePricing {
    ...PriceBlockInit_BundlePricing
  }
  ${ai}
`,ar=nZ`
  fragment PriceExperienceInit_Medium_Product on Product {
    price(input: $productPriceInput) {
      isEcoRebateEligible @include(if: $useEcoRebatesFields)
      showPlusOffers @include(if: $usePlusXOffersFields)
      ...CaboSucoInit_ItemPrice @include(if: $useCaboSucoFields)
      ...GiftWithPurchaseInit_ItemPrice @include(if: $useGiftWithPurchaseFields)
      ...ExperimentsInit_ItemPrice
      ...MembershipUpsellInit_ItemPrice @include(if: $useMembershipUpsellFields)
      ...PriceBlockInit_Medium_ItemPrice
      ...PriceExperienceInit_RewardCabos_ItemPrice
        @include(if: $useSpendAndGetFields)
      ...SpendAndGetInit_ItemPrice @include(if: $useSpendAndGetFields)
      ...TieredOffersTrackingInit_ItemPrice
    }
    skuId
    ...OffersInit_Product @include(if: $useOffersFields)
  }
  ${rQ}
  ${r1}
  ${rW}
  ${rz}
  ${rm}
  ${rq}
  ${rZ}
  ${rG}
  ${r5}
`,aa=nZ`
  fragment PriceExperienceInit_Compact_Product on Product {
    price(input: $productPriceInput) {
      isEcoRebateEligible @include(if: $useEcoRebatesFields)
      showPlusOffers
      ...CaboSucoInit_ItemPrice
      ...GiftWithPurchaseInit_ItemPrice
      ...ExperimentsInit_ItemPrice
      ...MembershipUpsellInit_ItemPrice
      ...PriceBlockInit_Compact_ItemPrice
      ...PriceExperienceInit_RewardCabos_ItemPrice
      ...SpendAndGetInit_ItemPrice
      ...TieredOffersTrackingInit_ItemPrice
    }
    skuId
    ...OffersInit_Product
  }
  ${rQ}
  ${r1}
  ${rW}
  ${rz}
  ${rc}
  ${rq}
  ${rZ}
  ${rG}
  ${r5}
`,ao=nZ`
  fragment PriceExperienceInit_Large_Product on Product {
    buyingOptions {
      __typename
      pdpUrl
      type
    }
    price(input: $productPriceInput) {
      isEcoRebateEligible @include(if: $useEcoRebatesFields)
      showPriceAssistant
      offerRankings @include(if: $useOfferRankings) {
        groupName
        numberOfGiftCards
        offerId
        path
        rank
        totalGiftCardAmount
        type
      }
      ...CaboSucoInit_ItemPrice @include(if: $useCaboSucoFields)
      ...GiftWithPurchaseInit_ItemPrice @include(if: $useGiftWithPurchaseFields)
      ...ExperimentsInit_ItemPrice
      ...MembershipUpsellInit_ItemPrice @include(if: $useMembershipUpsellFields)
      ...PriceBlockInit_Large_ItemPrice
      ...PriceExperienceInit_RewardCabos_ItemPrice
        @include(if: $useSpendAndGetFields)
      ...SpendAndGetInit_ItemPrice @include(if: $useSpendAndGetFields)
      ...TieredOffersTrackingInit_ItemPrice
    }
    skuId
    ...OffersInit_Product @include(if: $useOffersFields)
    ...PromotionalOptionListInit_Product
      @include(if: $usePromotionalOptionListFields)
  }
  ${rQ}
  ${r1}
  ${rW}
  ${rz}
  ${rf}
  ${rq}
  ${rZ}
  ${rG}
  ${r5}
  ${r8}
`,as=nZ`
  fragment PriceExperienceInit_Small_Product on Product {
    price(input: $productPriceInput) {
      isEcoRebateEligible @include(if: $useEcoRebatesFields)
      showPlusOffers
      ...CaboSucoInit_ItemPrice
      ...GiftWithPurchaseInit_ItemPrice
      ...ExperimentsInit_ItemPrice
      ...MembershipUpsellInit_ItemPrice
      ...PriceBlockInit_Small_ItemPrice
      ...PriceExperienceInit_RewardCabos_ItemPrice
      ...SpendAndGetInit_ItemPrice
      ...TieredOffersTrackingInit_ItemPrice
    }
    skuId
    ...OffersInit_Product
  }
  ${rQ}
  ${r1}
  ${rW}
  ${rz}
  ${rp}
  ${rq}
  ${rZ}
  ${rG}
  ${r5}
`,al=nZ`
  fragment PriceExperienceInit_StandAloneValueProps_Product on Product {
    price(input: $productPriceInput) {
      isEcoRebateEligible @include(if: $useEcoRebatesFields)
      offerRankings @include(if: $useOfferRankings) {
        groupName
        numberOfGiftCards
        offerId
        path
        rank
        totalGiftCardAmount
        type
      }
      ...CaboSucoInit_ItemPrice
      ...GiftWithPurchaseInit_ItemPrice
      ...ExperimentsInit_ItemPrice
      ...MembershipUpsellInit_ItemPrice
      ...PriceExperienceInit_RewardCabos_ItemPrice
      ...SpendAndGetInit_ItemPrice
      ...TieredOffersTrackingInit_ItemPrice
    }
    skuId
    ...OffersInit_Product @include(if: $useOffersFields)
    ...PromotionalOptionListInit_Product
      @include(if: $usePromotionalOptionListFields)
  }
  ${rQ}
  ${r1}
  ${rW}
  ${rz}
  ${rq}
  ${rZ}
  ${rG}
  ${r5}
  ${r8}
`,ad=nZ`
  query CaboSucoInit_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      price(input: $productPriceInput) {
        ...CaboSucoInit_ItemPrice
      }
    }
  }
  ${rQ}
`,ac=nZ`
  query DealAlertInit_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      price(input: $productPriceInput) {
        ...DealAlert_ItemPrice
      }
    }
  }
  ${rx}
`,au=nZ`
  query EcoRebatesExperience_GetIsEcoRebateEligible(
    $skuId: String!
    $openBoxCondition: Int
    $productPriceInput: ProductItemPriceInput!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      price(input: $productPriceInput) {
        ...EcoRebatesExperience_ItemPrice
      }
    }
  }
  ${nJ}
`,ap=nZ`
  query EcoRebatesExperience_GetEcoRebate(
    $skuId: String!
    $zipCode: String!
    $useRetailProductsPlatform: Boolean!
  ) {
    productBySkuId(skuId: $skuId) {
      ecoRebates(
        zipCode: $zipCode
        useRetailProductsPlatform: $useRetailProductsPlatform
      ) {
        ...EcoRebatesExperience__EcoRebate
      }
    }
  }
  ${nQ}
`,am=nZ`
  query FinanceOptionPaymentInit_GetProduct(
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
    $openBoxCondition: Int
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      __typename
      skuId
      price(input: $productPriceInput) {
        openBoxCondition
        connectionType
        mobileContracts {
          isDefaultContract
        }
        preferredBadging
        puckDisplayMessage
        customerPrice @skip(if: $useDisplayablePriceFields)
        regularPrice @skip(if: $useDisplayablePriceFields)
        displayableCustomerPrice @include(if: $useDisplayablePriceFields)
        displayableRegularPrice @include(if: $useDisplayablePriceFields)
        ...FinanceOptionPaymentInit_ItemPrice
      }
    }
  }
  ${n0}
`,af=nZ`
  query FinanceOptionPaymentInit_GetBundlePricing(
    $bundlePriceInput: BundlePriceInput!
  ) {
    bundlePricing(bundlePriceInput: $bundlePriceInput) {
      __typename
      financeOption {
        financeTerm
        monthlyPayment
        offerId
        planType
        rate
        totalCost
        totalCostIncludingTax
      }
    }
  }
`,ag=nZ`
  query GiftWithPurchaseInit_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      price(input: $productPriceInput) {
        ...GiftWithPurchaseInit_ItemPrice
      }
    }
  }
  ${r1}
`,ay=nZ`
  query MembershipUpsellInit_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      price(input: $productPriceInput) {
        ...MembershipUpsellInit_ItemPrice
      }
    }
  }
  ${rz}
`,aP=nZ`
  query AllInSubtotal_GetBundlePricing($bundlePriceInput: BundlePriceInput!) {
    bundlePricing(bundlePriceInput: $bundlePriceInput) {
      __typename
      bundlePrice {
        __typename
        customerPrice
        totalSavings
      }
      skus {
        __typename
        skuId
        icrCode
        isMAP
        strictMapIcr
      }
    }
  }
`,ah=nZ`
  query PriceBlockInit_Warranty_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceBlockInit_Warranty_Product
    }
  }
  ${rb}
`,aI=nZ`
  query PriceBlockInit_SavingsOnly_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceBlockInit_SavingsOnly_Product
    }
  }
  ${rh}
`,aC=nZ`
  query PriceBlockInit_Single_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceBlockInit_Single_Product
    }
  }
  ${rI}
`,a_=nZ`
  query PriceBlockInit_Compact_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceBlockInit_Compact_Product
    }
  }
  ${ru}
`,ab=nZ`
  query PriceBlockInit_Small_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceBlockInit_Small_Product
    }
  }
  ${rC}
`,aT=nZ`
  query PriceBlockInit_Medium_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceBlockInit_Medium_Product
    }
  }
  ${ry}
`,aS=nZ`
  query PriceBlockInit_Large_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceBlockInit_Large_Product
    }
  }
  ${rg}
`,aO=nZ`
  query PriceBlockInit_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $useDisplayablePriceFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceBlockInit_Product
    }
  }
  ${r$}
`,av=nZ`
  query PriceBlockInit_GetBundlePricing($bundlePriceInput: BundlePriceInput!) {
    bundlePricing(bundlePriceInput: $bundlePriceInput) {
      ...PriceBlockInit_BundlePricing
    }
  }
  ${ai}
`,aw=nZ`
  query PriceExperienceInit_StandAloneValueProps_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $skuOffersInput: ProductSkuOffersInput!
    $useDisplayablePriceFields: Boolean!
    $useEcoRebatesFields: Boolean!
    $useOffersFields: Boolean!
    $useOfferRankings: Boolean!
    $usePromotionalOptionListFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceExperienceInit_StandAloneValueProps_Product
    }
  }
  ${al}
`,aA=nZ`
  query PriceExperienceInit_Compact_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $skuOffersInput: ProductSkuOffersInput!
    $useDisplayablePriceFields: Boolean!
    $useEcoRebatesFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceExperienceInit_Compact_Product
    }
  }
  ${aa}
`,aE=nZ`
  query PriceExperienceInit_Small_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $skuOffersInput: ProductSkuOffersInput!
    $useDisplayablePriceFields: Boolean!
    $useEcoRebatesFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceExperienceInit_Small_Product
    }
  }
  ${as}
`,ax=nZ`
  query PriceExperienceInit_Medium_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $skuOffersInput: ProductSkuOffersInput!
    $useDisplayablePriceFields: Boolean!
    $usePlusXOffersFields: Boolean!
    $useMembershipUpsellFields: Boolean!
    $useEcoRebatesFields: Boolean!
    $useSpendAndGetFields: Boolean!
    $useCaboSucoFields: Boolean!
    $useGiftWithPurchaseFields: Boolean!
    $useOffersFields: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceExperienceInit_Medium_Product
    }
  }
  ${ar}
`,aL=nZ`
  query PriceExperienceInit_Large_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $skuOffersInput: ProductSkuOffersInput!
    $useDisplayablePriceFields: Boolean!
    $usePromotionalOptionListFields: Boolean!
    $useMembershipUpsellFields: Boolean!
    $useEcoRebatesFields: Boolean!
    $useSpendAndGetFields: Boolean!
    $useCaboSucoFields: Boolean!
    $useGiftWithPurchaseFields: Boolean!
    $useOffersFields: Boolean!
    $useOfferRankings: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceExperienceInit_Large_Product
    }
  }
  ${ao}
`,ak=nZ`
  query PriceExperienceInit_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
    $skuOffersInput: ProductSkuOffersInput!
    $useDisplayablePriceFields: Boolean!
    $usePromotionalOptionListFields: Boolean!
    $usePlusXOffersFields: Boolean!
    $useMembershipUpsellFields: Boolean!
    $useEcoRebatesFields: Boolean!
    $useSpendAndGetFields: Boolean!
    $useCaboSucoFields: Boolean!
    $useGiftWithPurchaseFields: Boolean!
    $useOffersFields: Boolean!
    $useOfferRankings: Boolean!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      ...PriceExperienceInit_Product
    }
  }
  ${r9}
`,aB=nZ`
  query PriceExperienceInit_GetBundlePricing(
    $bundlePriceInput: BundlePriceInput!
  ) {
    bundlePricing(bundlePriceInput: $bundlePriceInput) {
      ...PriceExperienceInit_BundlePricing
    }
  }
  ${an}
`,aD=nZ`
  query PriceExperienceInit_RewardCabos_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      __typename
      skuId
      openBoxCondition
      price(input: $productPriceInput) {
        ...PriceExperienceInit_RewardCabos_ItemPrice
      }
    }
  }
  ${rq}
`,aR=nZ`
  query SpendAndGetInit_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      __typename
      skuId
      openBoxCondition
      price(input: $productPriceInput) {
        __typename
        skuId
        ...SpendAndGetInit_ItemPrice
      }
    }
  }
  ${rZ}
`,aM=nZ`
  query TieredOffersTrackingInit_GetProduct(
    $openBoxCondition: Int
    $skuId: String!
    $productPriceInput: ProductItemPriceInput!
  ) {
    productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
      __typename
      skuId
      openBoxCondition
      price(input: $productPriceInput) {
        __typename
        skuId
        ...TieredOffersTrackingInit_ItemPrice
      }
    }
  }
  ${rG}
`,aN={removePdpSliders:{CONTROL:"A",TREATMENT:"B"},removePlpPlusOffers:{CONTROL:"A",TREATMENT:"B"}};function a$(e,t){return ef(t)&&Object.values(aN[e]).includes(t)}function aW({feature:e,liveConfig:t,displayLocation:i}){let n=t[`${e}.allowedDisplayLocations`];return!!Array.isArray(n)&&0!==n.length&&!!ef(i)&&n.includes(i)}function aF({displayLocation:e,liveConfig:t,feature:i,experiments:n,recipe:r}){return function({displayLocation:e,feature:t,liveConfig:i,experiments:n}){let r=aN[t].CONTROL;if(!i[`${t}.enabled`]||ef(e)&&`${t}.allowedDisplayLocations`in i&&!aW({feature:t,liveConfig:i,displayLocation:e}))return r;let a=i[`${t}.ABTestEnabled`];return ef(a)?"deo"===a?function(e,t,i){let n=aN[e].CONTROL;if(et(i)){let r=i[t];return a$(e,r)?r:(d.Ay.warn(`Invalid DEO recipe value "${r}" for feature "${e}". Falling back to CONTROL.`),n)}return d.Ay.warn(`DEO feature "${t}" enabled but no matching recipe in experiments: ${JSON.stringify(i)}. Falling back to CONTROL.`),n}(t,i[`${t}.ABTestKey`],n):a$(t,a)?a:(d.Ay.warn(`Invalid config recipe value "${a}" for feature "${t}". Falling back to CONTROL.`),r):aN[t].TREATMENT}({displayLocation:e,feature:i,experiments:n,liveConfig:t})===r}function aG({agentLocId:e,customerToken:t,employeeToken:i,locStoreId:n}){let r={};if(eK(i)){r.isStoreAgent=!0,eK(t)&&(r.ct=t);let i=e??n;eK(i)&&(r.locationId=i)}return r}var aj={LARGE:rg,MEDIUM:ry,SMALL:rC,MINI:ru,PRODUCT_CARD_PRICE:ru,ATTACH:ru,WARRANTY_INTERRUPTOR:rb,WARRANTY_SELECTOR:rb,SINGLE:rI,PRODUCT_CARD_TOTAL_SAVINGS:rh,ALL_IN_SUBTOTAL:ai,ALL_IN_SAVINGS:ai};function aU(e){return et(e)&&ef(e.skuId)}function aH({liveConfig:e,visitorId:t}){return eg(t)&&e["egp.itemPriceInput.visitorId.enabled"]}function az(e){let t=eN(e);return t?{customerAttributes:function(e){if(eu(e.profileLabels))return;let t=e.profileLabels.map(e=>e.label).filter(Boolean);if(t.length>0)return t}(t),planPaidMemberType:function(e){if(eK(e.planPaidMembershipEffectiveType)&&eg(e.planPaidMembershipEffectiveType))return e.planPaidMembershipEffectiveType}(t)}:{}}function aV({liveConfig:e,platform:t,displayLocation:i,customer:n,agentLocId:r,selectedCabo:a,selectedSuco:o,customerToken:s,employeeToken:l,locStoreId:d,cartTimestamp:c,visitorId:u,customerId:p}){let{customerAttributes:m,planPaidMemberType:f}=az(n),g=function({liveConfig:e,displayLocation:t}){if(e["egp.itemPriceInput.context.enabled"]){if(eG(t))return"Product-Page";if(eU(t))return"plp";if(ej(t))return"retail-pdp"}}({liveConfig:e,displayLocation:i});return{customerId:p,planPaidMemberType:f,salesChannel:eZ(t),selectedCabo:a,selectedSuco:o,...e["egp.itemPriceInput.customerAttributes.enabled"]?{customerAttributes:m}:{},...e["egp.itemPriceInput.usePriceWithCart.enabled"]?{usePriceWithCart:!0,cartTimestamp:c}:{},...e["egp.itemPriceInput.useSuco.enabled"]?{useSuco:!0}:{},...e["egp.itemPriceInput.useCabo.enabled"]?{useCabo:!0}:{},...aH({liveConfig:e,visitorId:u})?{visitorId:u}:{},...g?{context:g}:{},...ef(i)&&e["egp.itemPriceInput.displayLocation.allowedDisplayLocations"].includes(i)?{displayLocation:i}:{},...aG({agentLocId:r,customerToken:s,employeeToken:l,locStoreId:d})}}function aK({customer:e,liveConfig:t,platform:i}){let{maxOffers:n,checkmarkMessagingRequired:r,filterFinanceMinPurchaseAmount:a}=t.specialOffersList,{planPaidMemberType:o}=az(e);return{salesChannel:eZ(i),effectivePlanPaidMemberType:o,checkmarkMessagingRequired:r,maxOffers:n,filterFinanceMinPurchaseAmount:a}}function aY({displayLocation:e,liveConfig:t}){return ef(e)&&t["offerContainer.allowedDisplayLocations"].includes(e)}function aq({displayLocation:e,experiments:t,liveConfig:i}){let n=aF({displayLocation:e,liveConfig:i,experiments:t,feature:"removePlpPlusOffers",recipe:aN.removePlpPlusOffers.CONTROL}),r=aF({displayLocation:e,liveConfig:i,experiments:t,feature:"removePdpSliders",recipe:aN.removePdpSliders.CONTROL}),a=function({displayLocation:e,liveConfig:t,usePlusXOffersFields:i,usePromotionalOptionListFields:n}){return aW({feature:"removePdpSliders",liveConfig:t,displayLocation:e})?n:!aW({feature:"removePlpPlusOffers",liveConfig:t,displayLocation:e})||i}({displayLocation:e,liveConfig:i,usePlusXOffersFields:n,usePromotionalOptionListFields:r}),o=aY({displayLocation:e,liveConfig:i});return{useCaboSucoFields:a,useDisplayablePriceFields:i["displayablePriceFields.enabled"],useEcoRebatesFields:a,useGiftWithPurchaseFields:a,useMembershipUpsellFields:a,useOffersFields:!o&&a,usePlusXOffersFields:n,usePromotionalOptionListFields:r,useSpendAndGetFields:a,useOfferRankings:o}}function aX(e){let{skuId:t,openBoxCondition:i}=e;return{skuId:t,openBoxCondition:i,pricexFragmentInclusionVariables:aq(e),productPriceInput:aV(e),skuOffersInput:aK(e)}}function aZ(e){let{cartTimestamp:t,customerId:i,displayLocation:n,customer:r,liveConfig:a,platform:o,visitorId:s,skus:l,isCombo:d,includeFulfillment:c}=e,{planPaidMemberType:u}=az(r),p=eg(t)?Number(t):void 0;return{bundlePriceInput:{catalog:"bby",context:eg(n)?eG(n)?"Product-Page":n:"PriceView",customerId:i,effectivePlanPaidMemberType:u,salesChannel:eZ(o),skus:l.map((e,t)=>({id:e.id??t.toString(),...e})),...a["egp.itemPriceInput.usePriceWithCart.enabled"]&&Number.isFinite(p)?{cartTimestamp:p,usePriceWithCart:!0}:{},...aH({liveConfig:a,visitorId:s})?{visitorId:s}:{},isCombo:d,...void 0===c?{}:{includeFulfillment:c}}}}function aJ(e){let t=aj[e];return{document:t,name:function(e){let t=e.definitions.find(e=>e.kind===L.b.FRAGMENT_DEFINITION);if(!t)throw Error("[price-ui/price-block] Fragment definition not found in document. This usually indicates corrupted generated GraphQL code. To fix: (1) Verify the document contains a fragment definition, (2) Regenerate GraphQL types using `npm run codegen` or equivalent, (3) Check that you are passing the correct fragment document to this function.");return t.name.value}(t)}}function aQ({cartTimestampOverride:e,customer:t,displayLocation:i,experiments:n,platform:r}){let a=tw(),o=tW(),s=tk(),d=e??s,c=tN(),u=t$(),p=tF(),m=tL(),f=tx();return{productPriceInput:(0,l.useMemo)(()=>aV({agentLocId:o,cartTimestamp:d,customer:t,customerId:m,customerToken:c,displayLocation:i,employeeToken:u,liveConfig:a,locStoreId:p,platform:r,visitorId:f}),[o,d,t,m,c,i,u,a,p,r,f]),skuOffersInput:(0,l.useMemo)(()=>aK({customer:t,liveConfig:a,platform:r}),[t,a,r]),pricexFragmentInclusionVariables:(0,l.useMemo)(()=>aq({displayLocation:i,experiments:n,liveConfig:a}),[i,n,a])}}var a0={LARGE:aS,MEDIUM:aT,SMALL:ab,MINI:a_,PRODUCT_CARD_PRICE:a_,ATTACH:a_,WARRANTY_INTERRUPTOR:ah,WARRANTY_SELECTOR:ah,SINGLE:aC,PRODUCT_CARD_TOTAL_SAVINGS:aI,ALL_IN_SUBTOTAL:a_,ALL_IN_SAVINGS:aI},a1={LARGE:aL,MEDIUM:ax,SMALL:aE,PRODUCT_CARD_PRICE:aA,STANDALONE_VALUE_PROPS:aw,WARRANTY_INTERRUPTOR:ah,WARRANTY_SELECTOR:ah,MINI:a_,SINGLE:aC,ATTACH:a_,PRODUCT_CARD_TOTAL_SAVINGS:aI,ALL_IN_SUBTOTAL:a_,ALL_IN_SAVINGS:aI};function a2(e){if(aU(e)){let{profile:t,liveConfig:i,displayLocation:n}=e,{pricexFragmentInclusionVariables:r,...a}=aX(e);return i9("profileBasedFragments",n,i)?{document:tV(t)?a0[t]:a0.LARGE,variables:{...a,...r}}:{document:aO,variables:{...a,...r}}}return{document:av,variables:aZ(e)}}function a3(e){if(aU(e)){let{profile:t,liveConfig:i,displayLocation:n}=e,{pricexFragmentInclusionVariables:r,...a}=aX(e);return i9("profileBasedFragments",n,i)?{document:a1[t??"LARGE"],variables:{...a,...r}}:{document:ak,variables:{...a,...r}}}return{document:aB,variables:aZ(e)}}var a6={document:(0,c.J1)`
    query {
      none
    }
  `,variables:void 0},a5=C.A.create({linkContainer:{marginTop:4},offerDetailsContainer:{marginTop:12,marginBottom:8}}),a4=({link:e,offerDetails:t,parameters:i})=>{let[n,r]=(0,l.useState)(!1),o=t7(t??"",12),s=(0,l.useCallback)(()=>{var t;let n;J({pageName:eh({displayLocation:i.displayLocation}),data:(t=i.displayLocation,n=ts,ts&&(n=eG(t)?`Special offers: Included with Purchase ${ts}`:`+X offers for you: Included with Purchase ${ts}`),{event:{type:"interaction"},interaction:{name:ts},content:[{name:n,type:"drawer",isClick:!0}]})}),e&&window.open(e.trim(),"_blank","noopener,noreferrer")},[e,i.displayLocation]),d=(0,l.useCallback)(()=>{r(!0)},[]);return e?(0,g.jsx)(D.Link,{accessibilityRole:"link",onPress:s,style:a5.linkContainer,testID:a.a.GIFT_WITH_PURCHASE_VIEW_OFFER_PAGE_LINK,children:ts}):t?(0,g.jsxs)(g.Fragment,{children:[(0,g.jsx)(D.Link,{accessibilityRole:"link",onPress:d,style:a5.linkContainer,testID:a.a.GIFT_WITH_PURCHASE_SEE_OFFER_DETAILS_LINK,children:"See offer details"}),!!n&&(0,g.jsx)(m.default,{style:a5.offerDetailsContainer,children:o})]}):null},a8=C.A.create({container:{flex:1,backgroundColor:"white"},header:{paddingTop:16,paddingBottom:16,borderBottomWidth:1,borderBottomColor:"#e0e6ef"},headerTitle:{fontFamily:a.d.font.family.sans,fontSize:a.d.size.font[3],fontWeight:"500"},headerSubTitle:{fontFamily:a.d.font.family.sans,fontSize:a.d.size.font[2],fontWeight:400,marginTop:4},content:{paddingTop:16},itemContainer:{marginBottom:16,borderBottomWidth:1,borderBottomColor:"#e0e6ef"},lastItemContainer:{marginBottom:16,paddingBottom:16,borderBottomWidth:0},item:{marginBottom:16},itemRow:{flexDirection:"row"},imageContainer:{marginRight:32,width:100},bestBuyLogo:{width:100,height:65,borderRadius:4},itemImage:{width:100,height:65,borderRadius:4},itemDetails:{flex:1},itemTitle:{fontSize:a.d.size.font[2],fontWeight:"500",fontFamily:a.d.font.family.sans,lineHeight:22,marginBottom:6},valueText:{fontSize:a.d.size.font[2],fontFamily:a.d.font.family.sans,fontWeight:"500",marginBottom:8},description:{fontSize:a.d.size.font[2],lineHeight:20,color:"#2c2c2c",marginBottom:10},link:{color:a.d.color.blue,fontSize:14,textDecorationLine:"none"},linkContainer:{marginTop:4},termsText:{fontSize:14,color:"#2c2c2c"},termsContainer:{marginTop:8},descriptionContainer:{marginTop:0,marginBottom:10,width:"100%"},disclaimer:{fontSize:12}}),a9=({item:e,isLastItem:t,parameters:i})=>{let n,r=t?a8.lastItemContainer:a8.itemContainer,o=t7(e.longDescription??"",12),s=t7(e.disclaimer??"",12),l=nA({value:e.savings??0,prefix:"A ",suffix:" value!",threshold:n});return(0,g.jsx)(m.default,{style:r,testID:a.a.GIFT_WITH_PURCHASE_MODAL_ITEM,children:(0,g.jsxs)(m.default,{style:a8.item,children:[(0,g.jsxs)(m.default,{style:a8.itemRow,children:[(0,g.jsx)(m.default,{style:a8.imageContainer,children:(0,g.jsx)(A.default,{alt:"",resizeMode:"contain",source:{uri:e.primaryImage},style:a8.itemImage})}),(0,g.jsxs)(m.default,{style:a8.itemDetails,children:[(0,g.jsx)(I.E,{accessibilityRole:"text",style:a8.itemTitle,children:e.shortName}),!!l&&(0,g.jsx)(I.E,{accessibilityRole:"text",style:a8.valueText,children:l}),(0,g.jsx)(m.default,{style:a8.descriptionContainer,children:o})]})]}),!!e.disclaimer&&(0,g.jsx)(m.default,{children:s}),(0,g.jsx)(a4,{link:e.linkTo,offerDetails:e.offerDetails,parameters:i})]})})},a7=({promotionalData:e,params:t,giftSkuType:i})=>{let n,r=(0,l.useMemo)(()=>e?.gwpModalData?.gwpItems??[],[e]),o=r.length,s=nA({value:e.gwpModalData?.totalGiftSavings??0,prefix:"That's a ",suffix:" value!",threshold:n});return(0,g.jsx)(B.default,{accessible:!0,children:(0,g.jsxs)(m.default,{style:a8.container,testID:a.a.GIFT_WITH_PURCHASE_MODAL,children:[!i&&(0,g.jsxs)(m.default,{style:a8.header,testID:a.a.GIFT_WITH_PURCHASE_MODAL_HEADER,children:[(0,g.jsxs)(I.E,{accessibilityRole:"text",style:a8.headerTitle,children:[o," ",1===o?"free item":"free items"," with this purchase"]}),!!s&&(0,g.jsx)(I.E,{accessibilityRole:"text",style:a8.headerSubTitle,children:s})]}),(0,g.jsx)(m.default,{style:a8.content,testID:a.a.GIFT_WITH_PURCHASE_MODAL_CONTENT,children:r.map((e,i)=>(0,g.jsx)(a9,{isLastItem:i===r.length-1,item:e,parameters:t},e.skuId))})]})})};(0,l.forwardRef)((e,t)=>(0,g.jsx)(i4,{hierarchy:e.hierarchy,mobileSnapPoints:[90],platform:e.parameters.platform,ref:t,title:"Included with Purchase",children:!!e.promotionalData&&(0,g.jsx)(a7,{egpData:e.promotionalData.egpData,params:e.parameters,promotionalData:e.promotionalData})})).displayName="GiftWithPurchaseDrawer",C.A.create({container:{flexDirection:"row",display:"flex"},content:{fontFamily:a.d.font.family.sans,fontSize:a.d.size.font[3],fontWeight:"500",lineHeight:a.d.size.lineHeight[3],color:a.d.color.blue,flexDirection:"row",alignItems:"center",flexWrap:"wrap",marginLeft:4}}),C.A.create({itemContainer:{marginBottom:16},itemRow:{display:"flex",flexDirection:"row",marginBottom:16},itemDetails:{flex:1},giftPopover:{fontFamily:a.d.font.family.sans,fontSize:a.d.size.font[3],fontWeight:"400",lineHeight:a.d.size.lineHeight[3]},descriptionContainer:{marginTop:16,marginBottom:10,width:"100%"}}),C.A.create({scrollView:{maxHeight:280},popover:{width:300,maxHeight:300},container:{flexDirection:"row",display:"flex",alignItems:"flex-start",justifyContent:"flex-start"},promoCardContent:{fontSize:a.d.size.font[2],fontWeight:"400",lineHeight:a.d.size.lineHeight[2],color:a.d.color.foregroundDefault,flexDirection:"row",alignItems:"center",flexWrap:"wrap",marginLeft:4},promoCard:{fontSize:a.d.size.font[2],fontWeight:"500",lineHeight:a.d.size.lineHeight[2],color:a.d.color.primaryEmphasisBlue,flexDirection:"row",alignItems:"center",flexWrap:"wrap",marginLeft:4}});var oe={__brand:void 0,data:void 0};function ot(e){let t=eQ(e,{});if(er(t))return t.paymentOptions}function oi(e){return es(e)&&er(e.price)?e.price.financeOption:eo(e)?e.financeOption:void 0}var on=e=>e.find(({type:e,vendor:t,isDisplayable:i,numberOfInstallments:n,installmentAmount:r})=>"BNPL"===e&&"zip"===t&&i&&em(n)&&em(r)),or=()=>{let e=C.A.create({text:{height:12,display:"flex",fontWeight:"500",fontSize:10,fontFamily:a.d.font.family.sans,fontStyle:"normal",textAlign:"right",color:"#014FD3"}});return(0,g.jsxs)(_.default,{role:"paragraph",style:e.text,children:["Learn more ",">"]})},oa=(0,l.lazy)(async()=>await Promise.all([i.e(81120),i.e(47682),i.e(73697)]).then(i.bind(i,60687))),oo=({installmentServiceFee:e,numberOfInstallments:t})=>(0,g.jsx)(l.Suspense,{fallback:(0,g.jsx)(or,{}),children:(0,g.jsx)(oa,{installmentServiceFee:e,numberOfInstallments:t})}),os=({height:e=12,width:t=33})=>(0,g.jsx)("div",{className:"zip",style:{height:e,width:t},children:(0,g.jsxs)("svg",{"aria-label":"Zip",fill:"none",role:"img",style:{height:e,width:t},viewBox:"0 0 70 36",xmlns:"http://www.w3.org/2000/svg",children:[(0,g.jsx)("path",{d:"M1.57138 21.8984L2.18053 26.8613H23.5065L22.8087 21.1777H12.8655L12.7786 20.4734L21.937 14.0736L21.3251 9.10059H0L0.697879 14.7842H10.6575L10.7453 15.4949L1.57138 21.8984Z",fill:"#1A0826"}),(0,g.jsx)("path",{d:"M23.8027 9.10059L25.9842 26.8613H47.3267L45.1452 9.10059H23.8027Z",fill:"#AA8FFF"}),(0,g.jsx)("path",{d:"M69.7072 15.495C69.2151 11.5026 66.0787 9.0833 61.8165 9.10068H47.6211L49.8007 26.8605H56.1868L55.7496 23.3089H62.508C67.8285 23.3089 70.2624 19.9942 69.7072 15.495ZM61.8192 18.3304L55.1423 18.3378L54.6191 14.0755L61.3335 14.081C62.9131 14.0993 63.7208 14.9883 63.8507 16.2057C63.9311 16.9877 63.5726 18.3295 61.8192 18.3295V18.3304Z",fill:"#1A0826"}),(0,g.jsx)("path",{d:"M30.3076 6.81633C31.439 5.61278 31.2519 3.59906 29.8897 2.31855C28.5276 1.03804 26.5061 0.975643 25.3747 2.17919C24.2433 3.38273 24.4304 5.39646 25.7926 6.67697C27.1548 7.95748 29.1762 8.01987 30.3076 6.81633Z",fill:"#1A0826"})]})}),ol=({egpData:e,...t})=>{let{show:i,data:n}=(({egpData:e,layoutConfig:t})=>{let i=ot(e);if(t.buyNowPayLater.show&&Array.isArray(i)){let e=on(i);if(e)return{data:e,show:!0}}return{data:null,show:!1}})({...t,egpData:e}),r=C.A.create({price:{fontSize:20,lineHeight:24,fontWeight:"500",fontFamily:a.d.font.family.sans},small:{fontSize:10,lineHeight:12,fontWeight:"400",fontFamily:a.d.font.family.sans},semiBold:{fontWeight:500,fontFamily:a.d.font.family.sans},med:{fontSize:12,fontFamily:a.d.font.family.sans},bottomMarginSm:{marginBottom:2},bottomMarginLg:{marginBottom:8},flex:{display:"flex",flexDirection:"row",marginBottom:4},link:{color:a.d.color.blue,fontFamily:a.d.font.family.sans},container:{display:"flex",flexDirection:"row",alignItems:"center"}});return i?(0,g.jsxs)(m.default,{testID:a.a.PRICE_BLOCK_BUY_NOW_PAY_LATER,children:[(0,g.jsxs)(I.E,{style:[r.small,r.bottomMarginSm],children:[n.numberOfInstallments," payments starting at"]}),(0,g.jsx)(I.E,{style:[r.price,r.semiBold],children:e6(n.installmentAmount)}),(0,g.jsxs)(m.default,{style:r.flex,children:[(0,g.jsx)(I.E,{style:[r.small,r.bottomMarginSm],children:"with"}),(0,g.jsx)(os,{height:12,width:33})]}),(0,g.jsx)(oo,{installmentServiceFee:n.installmentServiceFee,numberOfInstallments:n.numberOfInstallments})]}):null};function od({egpData:e,parameters:t,layoutConfig:i,allowedProfile:n,profile:r}){let a=is(e,t),o=im({egpData:e,parameters:t,selectedContract:iE(),showStandardPricing:iB()});return n!==r||a||o?oe:function({egpData:e,layoutConfig:t,parameters:i}){let n=function({egpData:e}){let t=eQ(e,{});if(er(t))return t.heroRenderPriceOptions}({egpData:e});return"FINANCE_OPTIONS"===n?function({egpData:e,layoutConfig:t,parameters:i}){if(!t.suggestedMonthlyPayment.show)return oe;let n=eN(i.customer),r=oi(e);return et(r)&&"monthlyPayment"in r&&em(r.monthlyPayment)&&"financeTerm"in r&&em(r.financeTerm)?{__brand:"FinanceOptionPayment",data:{financeOption:r,skuId:nB(e),userType:eq(n)}}:oe}({egpData:e,layoutConfig:t,parameters:i}):"PAYMENT_OPTIONS"===n?function({egpData:e,layoutConfig:t}){if(!t.buyNowPayLater.show)return oe;let i=ot(e);if(Array.isArray(i)){let e=i.find(e=>e.isDisplayable&&"zip"===e.vendor&&"BNPL"===e.type&&em(e.numberOfInstallments)&&em(e.installmentAmount));if(!eu(e))return{__brand:"BuyNowPayLater",data:e}}return oe}({egpData:e,layoutConfig:t}):{__brand:void 0,data:void 0}}({egpData:e,layoutConfig:i,parameters:t})}var oc=eS({});function ou(){return eO(oc,e=>e.navigationGateWay)}oc.displayName="NavigationContext";var op=eS({});function om(){return eO(op,e=>e.notificationGateWay)}op.displayName="NotificationContext";var of=(0,l.createContext)({});of.displayName="PerformanceCallbacksContext";var og=({children:e,...t})=>{let i=(0,l.useContext)(of),n=(0,l.useMemo)(()=>({...i,...t}),[i,t]);return(0,g.jsx)(of.Provider,{value:n,children:e})};function oy(){return(0,l.useContext)(of)}var oP=({liveConfig:e,children:t})=>{let i=(0,l.useMemo)(()=>{let t={customSpansPrefs:{isCustomSpansEnabled:e?.["performanceToolsPreferences.customSpansPrefs.isCustomSpansEnabled"],perSpan:e?.["performanceToolsPreferences.customSpansPrefs.perSpan"]},sentryLib:e?.["performanceToolsPreferences.sentryLib"]},i=P.pQ.safeParse(t);return i.success?i.data:{customSpansPrefs:{isCustomSpansEnabled:tg["performanceToolsPreferences.customSpansPrefs.isCustomSpansEnabled"],perSpan:tg["performanceToolsPreferences.customSpansPrefs.perSpan"]},sentryLib:tg["performanceToolsPreferences.sentryLib"]}},[e]);return(0,g.jsx)(P.DD,{prefs:i,children:t})},oh=[35,140],oI=[24,80],oC=C.A.create({wrap:{paddingTop:4}}),o_=({children:e,isLoading:t,profile:i,onVisibleChange:n})=>{let[r,o]=(0,l.useMemo)(()=>((e="LARGE")=>{switch(e){case"LARGE":case"MEDIUM":case"ALL_IN_SUBTOTAL":return oh;default:return oI}})(i),[i]);return(0,l.useEffect)(()=>{if(n)return n(!0),()=>{n(!1)}},[n]),t?(0,g.jsx)(m.default,{"data-testid":a.a.SKELETON_WRAPPER,style:oC.wrap,children:(0,g.jsx)(M.Ay,{backgroundColor:"#e4e5e8","data-testid":a.a.SKELETON_CONTENT,foregroundColor:"#f6f6f7",height:r,speed:1.5,viewBox:`0 0 ${o} ${r+10}`,width:o,children:(0,g.jsx)("rect",{"data-testid":a.a.SKELETON_RECTANGLE,height:r,rx:"4",ry:"4",width:o,x:"0",y:"5"})})}):e};function ob(e){return"attach"===e}function oT(e){return"attach-delivery-and-install"===e||e===th}function oS(e){let{layoutConfig:t,parameters:i}=e;return!(!t.price.bottomMessage.show||i.priceVariant===tI)&&!!im(e)&&!(ig(e)&&!t.price.bottomMessage.showWith.activatedFullPrice)}function oO({egpData:e,layoutConfig:t,parameters:i}){let n=iE(),r=iB(),a=oS({egpData:e,layoutConfig:t,parameters:i,selectedContract:n,showStandardPricing:r}),{data:o}=iJ("connected-device-carrier-content",{skip:!a||!im({egpData:e,parameters:i,selectedContract:n,showStandardPricing:r})});if(a){let a=eQ(e,i),s=ic(a,n);return{data:{message:function({carrierContent:e,egpData:t,parameters:i,selectedContract:n,showStandardPricing:r}){let a=eQ(t,i);if(im({egpData:t,parameters:i,selectedContract:n,showStandardPricing:r})){let t=ic(a,n),i=il(a)?a.mobileContracts:[];return function({contract:e,isUnlocked:t,carrierContent:i,mobileContracts:n}){if(!i)throw Error(`Expected carrierContent to be object, instead received ${i}`);return[{key:"carrier-template-content",value:iy(ib({content:i,contract:e,isUnlocked:t,section:"HERO_PRICE_BLOCK",mobileContracts:n}).description,e)}]}({contract:t,isUnlocked:ip(a),carrierContent:e,mobileContracts:i})}throw Error("Insufficient data to derive 'bottomPriceMessage'")}({egpData:e,layoutConfig:t,parameters:i,selectedContract:n,showStandardPricing:r,carrierContent:o??to}),showSeeDetails:ip(a)&&!1===s.matchesCurrentPrice},show:!0}}return{data:void 0,show:!1}}var ov={lg:a.d.size.lineHeight[2],md:a.d.size.lineHeight[2],sm:a.d.size.lineHeight[2],xsm:a.d.size.lineHeight[1]},ow={lg:a.d.size.font[2],md:a.d.size.font[2],sm:a.d.size.font[2],xsm:a.d.size.font[1]};function oA(e){return C.A.create({container:{display:"flex",flexDirection:"row",alignItems:"flex-end",gap:4},text:{fontSize:ow[e],lineHeight:ov[e]},seeDetailsText:{color:a.d.color.primaryEmphasisBlue,fontSize:a.d.size.font[3],lineHeight:ov[e]}})}var oE={lg:oA("lg"),md:oA("md"),sm:oA("sm"),xsm:oA("xsm")},ox=({egpData:e,layoutConfig:t,parameters:i})=>{let n,{data:r,show:o}=oO({egpData:e,layoutConfig:t,parameters:i}),d=iE(),c=(n=(0,s.U)(),eO(iA,e=>eu(e.onAddToPackage)?()=>{n.warn("PriceContext.onAddToPackage is undefined")}:e.onAddToPackage)),u=(0,l.useCallback)(()=>{var t;J({pageName:"Product Display Page",data:{event:{type:"interaction"},interaction:{name:"Price Choice Engagement"},content:[{name:"Pricing Offer: See Details",isClick:!0,region:"PriceBlock"}],skus:[{id:(t=ic(eQ(e,i),d)).skuId??"",unitPrice:t.customerPrice??t.currentPrice??void 0}]}}),c()},[e,i,d,c]),p=oE[t.size];return o?(0,g.jsxs)(b.S,{style:p.container,children:[(0,g.jsx)(nf,{body:r.message,containerStyle:p.container,"data-testid":a.a.PRICE_BLOCK_BOTTOM_PRICE_MESSAGE,textStyle:p.text}),!!r.showSeeDetails&&(0,g.jsx)(w.default,{"data-testid":a.a.PRICE_BLOCK_BOTTOM_PRICE_MESSAGE_SEE_DETAILS,onPress:u,children:(0,g.jsx)(I.E,{style:p.seeDetailsText,children:"See details"})})]}):null};ox.displayName="BottomPriceMessage";var oL=({children:e,egpData:t,layoutConfig:i,parameters:n,profile:r})=>{let{hasTapped:o,handleTap:s}=n$(nB(t,n)),d="lv"!==n.platform,c=(0,l.useCallback)(()=>{s()},[s]),u=function({layoutConfig:e,parameters:t,egpData:i,profile:n}){let{restrictedPriceDisplayMessage:r}=nD(i,t);return"SINGLE"===n&&r?"See details":ef(r)?r:"lv"===t.platform?e.restrictedPrice.lvMessage:e.restrictedPrice.svMessage}({layoutConfig:i,parameters:n,egpData:t,profile:r}),p=C.A.create({message:{fontSize:13,fontWeight:"500"}});return nM(t)?null:nR(t,n)&&!o?"See details"===u?(0,g.jsx)(b.S,{"data-testid":a.a.RESTRICTED_PRICE_SEE_DETAIL,children:(0,g.jsx)(I.E,{style:p.message,children:u})}):d?(0,g.jsx)(f.default,{activeOpacity:1,onPress:c,role:"button",children:(0,g.jsx)(b.S,{className:"whitespace-nowrap","data-testid":a.a.RESTRICTED_PRICE_TAP_FOR_PRICE,style:{alignSelf:"flex-start"},children:(0,g.jsx)(I.E,{style:p.message,children:u})})}):(0,g.jsx)(b.S,{className:"whitespace-nowrap","data-testid":a.a.RESTRICTED_PRICE_TAP_FOR_PRICE,children:(0,g.jsx)(I.E,{style:p.message,children:u})}):e};function ok(e){return"warranty"===e}oL.displayName="ConditionalTapForPrice";var oB=/^([^\d,]+)(\d+(?:,\d+)*)(?:\.(\d+))?$/,oD={centsFontSize:a.d.size.font[4],centsLineHeight:a.d.size.lineHeight[5]-2,integerFontSize:a.d.size.font[10],integerLineHeight:a.d.size.lineHeight[10],symbolFontSize:a.d.size.font[5],symbolLineHeight:a.d.size.lineHeight[5],suffixFontSize:a.d.size.font[5],suffixLineHeight:a.d.size.lineHeight[8]},oR={centsFontSize:a.d.size.font[4],centsLineHeight:a.d.size.lineHeight[5],integerFontSize:a.d.size.font[10],integerLineHeight:a.d.size.lineHeight[9],symbolFontSize:a.d.size.font[5],symbolLineHeight:a.d.size.lineHeight[6],suffixFontSize:a.d.size.font[5],suffixLineHeight:a.d.size.lineHeight[6]},oM={centsFontSize:a.d.size.font[2],centsLineHeight:a.d.size.lineHeight[4],integerFontSize:a.d.size.font[6],integerLineHeight:a.d.size.lineHeight[6],symbolFontSize:a.d.size.font[3],symbolLineHeight:a.d.size.lineHeight[4],suffixFontSize:a.d.size.font[2],suffixLineHeight:a.d.size.lineHeight[4]},oN={centsFontSize:a.d.size.font[2],centsLineHeight:a.d.size.lineHeight[3],integerFontSize:a.d.size.font[6],integerLineHeight:a.d.size.lineHeight[7],symbolFontSize:a.d.size.font[3],symbolLineHeight:a.d.size.lineHeight[3],suffixFontSize:a.d.size.font[2],suffixLineHeight:a.d.size.lineHeight[6]},o$={centsFontSize:a.d.size.font[1],centsLineHeight:a.d.size.lineHeight[3],integerFontSize:a.d.size.font[5],integerLineHeight:a.d.size.lineHeight[5],symbolFontSize:a.d.size.font[2],symbolLineHeight:a.d.size.lineHeight[3],suffixFontSize:a.d.size.font[2],suffixLineHeight:a.d.size.lineHeight[4]},oW={centsFontSize:a.d.size.font[1],centsLineHeight:a.d.size.lineHeight[1],integerFontSize:a.d.size.font[3],integerLineHeight:a.d.size.lineHeight[3],symbolFontSize:a.d.size.font[1],symbolLineHeight:a.d.size.lineHeight[1],suffixFontSize:a.d.size.font[2],suffixLineHeight:a.d.size.lineHeight[4]},oF=C.A.create({row:{flexDirection:"row"}}),oG=({accessibilityLabel:e,isLargeView:t,isWeb:i,message:n,shouldShowSeoAttribute:r,size:o,suffix:s})=>{let l=np("font-500",((e,t)=>{switch(e){case"lg":return"text-7";case"md":return t?"text-6":"text-4";case"sm":return"text-4";case"xsm":return"text-3";default:return""}})(o,t),((e,t)=>{switch(e){case"lg":return"leading-7";case"md":return t?"leading-6":"leading-4";case"sm":return"leading-4";case"xsm":return"leading-3";default:return""}})(o,t));return(0,g.jsxs)(b.S,{...!i&&{accessibilityLabel:e,accessible:!0},"data-testid":a.a.PRICE_BLOCK_CUSTOMER_PRICE,style:oF.row,testID:a.a.PRICE_BLOCK_CUSTOMER_PRICE,...r&&{"data-lu-target":"customer_price"},children:[!!i&&(0,g.jsx)(I.E,{className:"sr-only",children:e}),(0,g.jsx)(I.E,{...i&&{"aria-hidden":!0,customProps:{web:{root:{elementtiming:"price_et"}}}},className:l,children:n}),!!s&&(0,g.jsx)(I.E,{...i&&{"aria-hidden":!0},className:s.className,children:s.message})]})};oG.displayName="CustomerPriceControl";var oj="/mo.",oU="/mo.*",oH=C.A.create({superscriptRow:{display:"flex",flexDirection:"row",alignItems:"flex-start"}}),oz=({accessibilityLabel:e,isWeb:t,parsedPrice:i,profile:n,shouldShowSeoAttribute:r,size:o,suffix:s})=>{let{integerFontSize:l,integerLineHeight:d,symbolFontSize:c,symbolLineHeight:p,centsFontSize:m,centsLineHeight:f,suffixFontSize:y,suffixLineHeight:P}=function(e,t){let i="ios"===u.A.OS;switch(e){case"lg":return i?oD:oR;case"md":return"ALL_IN_SUBTOTAL"!==t?oM:{...i?oN:oM,integerFontSize:a.d.size.font[7],symbolFontSize:a.d.size.font[2]};case"sm":return o$;case"xsm":return"PRODUCT_CARD_PRICE"!==t?o$:{...o$,centsLineHeight:a.d.size.lineHeight[2]};default:return oW}}(o,n);return(0,g.jsxs)(b.S,{...!t&&{accessibilityLabel:e,accessible:!0},"data-testid":a.a.PRICE_BLOCK_CUSTOMER_PRICE,style:oH.superscriptRow,testID:a.a.PRICE_BLOCK_CUSTOMER_PRICE,...r&&{"data-lu-target":"customer_price"},children:[!!t&&(0,g.jsx)(I.E,{className:"sr-only",children:e}),(0,g.jsx)(I.E,{...t&&{"aria-hidden":!0},style:{fontSize:c,lineHeight:p,fontWeight:"500"},children:i.currencySymbol}),(0,g.jsx)(I.E,{...t&&{"aria-hidden":!0,customProps:{web:{root:{elementtiming:"price_et"}}}},style:{fontSize:l,lineHeight:d,fontWeight:"500"},children:i.integer}),null!==i.cents&&(0,g.jsx)(I.E,{...t&&{"aria-hidden":!0},style:{fontSize:m,lineHeight:f,fontWeight:"500"},children:i.cents}),!!s&&(0,g.jsx)(I.E,{...t&&{"aria-hidden":!0},className:s.className,style:{fontSize:y,lineHeight:P,fontWeight:"500",alignSelf:"flex-end"},children:s.message})]})};oz.displayName="CustomerPriceSuperscript";var oV=e=>{let{layoutConfig:t,profile:i,parameters:n}=e,{onCustomerPriceShown:r}=oy(),{data:a,show:o,isLargeView:s}=function({egpData:e,layoutConfig:t,parameters:i}){let n=iE(),r=iB();return(0,l.useMemo)(()=>{let a=t.price.show,o="lv"===i.platform,s=(e=>{var t;let{egpData:i,layoutConfig:n,parameters:r,selectedContract:a}=e;if(t=n.variant,es(i)&&el(i.termLength)&&"warranty"===t&&i.termLength.unitOfMeasure?.toLowerCase()==="months"&&(e0(i.price)??0)>0)return!0;let o=eQ(i,r);if(im(e)){if(n.price.seeDetailsText.showWith.activated)return!1;let{currentPrice:e,numberOfPayments:t=0}=ic(o,a);return ep(e)&&ep(t)&&t>1}return!1})({egpData:e,layoutConfig:t,parameters:i,selectedContract:n,showStandardPricing:r});return a?{data:{message:(e=>{let{egpData:t,parameters:i,layoutConfig:n,selectedContract:r}=e,a=eQ(t,i);if(eu(a))throw TypeError(`Expected price to be an object, instead received ${a}`);if(im(e)){let e;return n.price.seeDetailsText.showWith.activated?"See details":e6((e=ic(a,r)).customerPrice??e.currentPrice,{zeroStrategy:"showCurrency"})}if(ok(n.variant)){if(!es(t))throw Error(`Expected egpData to be Product, instead received ${JSON.stringify(t)}`);let e=e0(t.price);return function(e){if(!ep(e))throw Error(`Expected ${(void 0)??"value"} to be a number, instead received ${e}`)}(e),e6(e,{zeroStrategy:"showCurrency"})}return ob(n.variant)?function(e,t){let{priceVariant:i}=t,n=eQ(e,t);if(en(n)){if("attach-delivery"===i)return e6(n.deliveryTotal);if(oT(i))return e6(n.deliveryAndInstallationTotal)}return ea(n)?e6(n.customerSubBundlePrice??n.customerPrice):e6(e0(n))}(t,i):e6(e0(a))})({egpData:e,layoutConfig:t,parameters:i,selectedContract:n,showStandardPricing:r}),showPerMonth:s},show:a,isLargeView:o}:{data:null,show:a,isLargeView:o}},[e,t,i,n,r])}(e),d=function({layoutConfig:e,isLargeView:t,showPerMonth:i}){let n=iE(),r=ix(),a=n&&iO(n,{tradeInAppraisal:r});if(i){let i=np("font-500",((e,t)=>{switch(e){case"lg":return"text-5";case"md":return t?"text-6":"text-4";case"sm":return"text-4";case"xsm":return"text-3";default:return""}})(e.size,t??!1),((e,t)=>{switch(e){case"lg":return"leading-5";case"md":return t?"leading-6":"leading-4";case"sm":return"leading-4";case"xsm":return"leading-3";default:return""}})(e.size,t??!1)),n=a?oU:oj;return{message:n,className:i,accessibleMessage:function(e){switch(e){case oj:return"per month";case oU:return"per month, see details";default:return e}}(n)}}return null}({...e,isLargeView:s,showPerMonth:a?.showPerMonth??!1}),c=!tH(n.platform),u=(0,l.useMemo)(()=>(function(e,t){if(e)return t?[e.message,t.accessibleMessage].filter(Boolean).join(" "):e.message})(a,d),[a,d]);(function(e){let{profile:t,value:i,spanId:n}=e,r=function(e){let{profile:t,spanId:i}=e,n=`pb_${ty[t]}_${i}`;if(n.length>10)throw Error(`Span ID "${n}" exceeds 10 character limit`);let{endSpan:r}=(0,P.Rj)({spanId:n});return r}({spanId:n,profile:t}),a=(0,l.useRef)(i);(0,l.useEffect)(()=>{i!==a.current&&r(),a.current=i},[i,r])})({value:a?.message,profile:i??"SINGLE",spanId:"pmc"}),(0,l.useEffect)(()=>{!o||eu(r)||r()},[r,o]);let p=function({message:e,profile:t}){let i=tw();return(0,l.useMemo)(()=>(function({enabled:e,profile:t,message:i,excludedProfiles:n=[]}){var r;let a;return!e||n.includes(t??"")?null:(r=i??"",(a=oB.exec(r.trim()))?{currencySymbol:a[1],integer:a[2],cents:a[3]??null}:null)})({enabled:i["price.customerPriceSuperscriptAndSize.enabled"],profile:t,message:e,excludedProfiles:i["price.customerPriceSuperscriptAndSize.excludedProfiles"]}),[i,e,t])}({message:a?.message,profile:i});if(!o)return null;let m="LARGE"===i;return p?(0,g.jsx)(oz,{accessibilityLabel:u,isWeb:c,parsedPrice:p,profile:i,shouldShowSeoAttribute:m,size:t.size,suffix:d}):(0,g.jsx)(oG,{accessibilityLabel:u,isLargeView:s,isWeb:c,message:a.message,shouldShowSeoAttribute:m,size:t.size,suffix:d})};oV.displayName="CustomerPrice";var oK=()=>(0,g.jsxs)("svg",{"data-testid":a.a.DEALS_ALERT_BELL_ICON,fill:"none",height:32,viewBox:"0 0 32 32",width:32,children:[(0,g.jsx)("rect",{fill:"white",fillOpacity:.9,height:31,rx:15.5,width:31,x:.5,y:.5}),(0,g.jsx)("rect",{height:31,rx:15.5,stroke:"#E0E6EF",width:31,x:.5,y:.5}),(0,g.jsx)("path",{d:"M16.0002 22.6667C13.9269 22.6667 13.0002 21.0734 13.0002 19.5C13.0002 19.2267 13.2269 19 13.5002 19H18.5002C18.7735 19 19.0002 19.2267 19.0002 19.5C19.0002 21.0734 18.0735 22.6667 16.0002 22.6667ZM14.0469 20C14.1669 20.66 14.5802 21.6667 16.0002 21.6667C17.4202 21.6667 17.8335 20.66 17.9535 20H14.0469Z",fill:"#141D23"}),(0,g.jsx)("path",{d:"M21.5069 20H10.5002C10.0269 20 9.60685 19.72 9.42019 19.28C9.24019 18.8467 9.34019 18.3467 9.66685 18.0134C10.3202 17.3534 10.9935 16.46 11.0002 14.8267C11.0202 10.4934 14.1535 9.33337 16.0002 9.33337C16.3535 9.33337 18.2002 9.40004 19.5669 10.78C20.5269 11.7467 21.0069 13.1134 21.0002 14.84C20.9935 16.4534 21.6669 17.3534 22.3335 18.0134C22.6669 18.3467 22.7669 18.8467 22.5869 19.28C22.4069 19.7134 21.9869 20 21.5069 20ZM16.0002 10.3334C15.5935 10.3334 12.0202 10.46 12.0002 14.8334C11.9935 16.8334 11.1269 17.96 10.3802 18.72C10.3135 18.7867 10.3269 18.8534 10.3469 18.9C10.3602 18.9334 10.4002 19 10.5002 19H21.5135C21.6135 19 21.6535 18.9334 21.6669 18.8934C21.6869 18.8467 21.6935 18.78 21.6335 18.72C20.8669 17.96 19.9935 16.8267 20.0069 14.8334C20.0135 13.38 19.6335 12.26 18.8669 11.4867C17.7469 10.3667 16.1735 10.3334 16.0002 10.3334Z",fill:"#141D23"})]}),oY=C.A.create({container:{alignItems:"center",justifyContent:"center"}}),oq=({value:e,size:t=115})=>(0,g.jsx)(m.default,{"data-testid":a.a.QR_CODE_CONTAINER,style:oY.container,children:(0,g.jsx)(m.default,{children:(0,g.jsx)($.h,{"data-testid":a.a.QR_CODE_SVG,height:t,level:"H",value:e,width:t})})}),oX=C.A.create({modalText:{marginBottom:24,fontSize:20,lineHeight:24,fontWeight:400,letterSpacing:0,fontFamily:"Human BBY Digital"},modalTitleSv:{marginBottom:12,fontSize:20,fontWeight:500,lineHeight:28,fontFamily:"Human BBY Digital"},buttonColumn:{flexDirection:"column",alignItems:"center",justifyContent:"center"},openTheAppButton:{minWidth:96,marginBottom:8,width:"100%",paddingLeft:24,paddingRight:24,marginTop:12},defaultButton:{padding:8},linkButton:{padding:8,color:"#0046be"},linkButtonText:{color:"#030303",fontFamily:"Human BBY Digital",fontWeight:500,fontSize:15,lineHeight:18},modalStyle:{width:328,padding:28,borderRadius:8},leftAlignedText:{textAlign:"left"},lvModalHeaderStyles:{display:"none"},lvModalStyleOverrides:{padding:0,borderWidth:0,borderColor:"none",borderRadius:0,width:899},lvModalContainer:{display:"flex",flexDirection:"row"},imageContainer:{width:"46%"},image:{height:"100%",width:"100%"},rightContainer:{display:"flex",flexDirection:"column",gap:24,width:"54%",backgroundColor:"#fff",padding:24,paddingTop:16},titleContainer:{display:"flex",flexDirection:"row",justifyContent:"space-between"},title:{fontSize:20,lineHeight:24,fontWeight:500},QRCodeContainer:{backgroundColor:"#f3f4f6",paddingTop:8,paddingBottom:8,paddingLeft:16,paddingRight:16,borderRadius:8,justifyContent:"space-between",display:"flex",flexDirection:"row",gap:12,position:"relative"},qrCode:{backgroundColor:"#fff",padding:12,borderRadius:8},textContainer:{display:"flex",flexDirection:"column",justifyContent:"center",width:"60%",gap:12},boldText:{fontWeight:600}}),oZ=({pdpUrl:e,onModalClose:t,isSmallView:i=!1})=>{let n=(0,l.useRef)(null),r=(0,l.useMemo)(()=>{let t,n,r;return t=e.includes("test.ecommerce.com")?"https://bestbuy.test-app.link/":"https://bestbuy.app.link/",n=i?"priceAlerts_SV":"priceAlerts_LV",r=encodeURIComponent(`${e}&ref=${n}`),`${t}?%7Efeature=dotcom&%7Ecampaign=${n}&%7Echannel=${i?"SV":"LV"}&%24deeplink_path=${r}`},[i,e]);(0,l.useEffect)(()=>{n.current&&n.current.openModal()},[]);let o=(0,l.useCallback)(()=>{t&&(t(),J({pageName:"Product Display Page",data:iU(ij,i?"Cancel":"Close")}),n.current?.closeModal())},[t,i]),s=(0,l.useCallback)(()=>{J({pageName:"Product Display Page",data:iU(ij,"Open App")}),window.location.href=r},[r]);return i?(0,g.jsxs)(ni,{"data-testid":a.a.DEALS_ALERT_MODAL,headerStyle:{justifyContent:"space-between"},modalStyleOverrides:oX.modalStyle,onClose:o,ref:n,title:(0,g.jsx)(_.default,{"data-testid":a.a.DEALS_ALERT_MODAL_TITLE,style:oX.modalTitleSv,children:ij}),children:[(0,g.jsx)(_.default,{"data-testid":a.a.DEALS_ALERT_MODAL_TEXT,style:[oX.modalText,oX.leftAlignedText],children:"We'll notify you if there's a price drop. In the Best Buy app set a Deal Alert to get it for less."}),(0,g.jsxs)(m.default,{"data-testid":a.a.DEALS_ALERT_MODAL_BUTTON_ROW,style:oX.buttonColumn,children:[(0,g.jsx)(N.Button,{accessibilityLabel:"Open the app","data-testid":a.a.DEALS_ALERT_MODAL_OPEN_BUTTON,label:"Open the app",onPress:s,style:oX.openTheAppButton,variant:"primary"}),(0,g.jsx)(f.default,{accessibilityLabel:"Cancel","data-testid":a.a.DEALS_ALERT_MODAL_CANCEL_BUTTON,onPress:o,style:oX.defaultButton,children:(0,g.jsx)(_.default,{style:oX.linkButtonText,children:"Cancel"})})]})]}):(0,g.jsx)(ni,{"data-testid":a.a.DEALS_ALERT_MODAL,headerStyle:oX.lvModalHeaderStyles,modalStyleOverrides:oX.lvModalStyleOverrides,ref:n,size:"lg",children:(0,g.jsxs)(m.default,{style:oX.lvModalContainer,children:[(0,g.jsx)(m.default,{style:oX.imageContainer,children:(0,g.jsx)(A.default,{accessibilityLabel:"Deal Alert",alt:"Deal Alert",resizeMode:"contain",source:{uri:"https://pisces.bbystatic.com/image2/BestBuy_US/dam/OptimizedDealGraphicDesktop-8312255f-db92-4a50-992b-569be1a4b781.png"},style:oX.image})}),(0,g.jsxs)(m.default,{style:oX.rightContainer,children:[(0,g.jsxs)(m.default,{style:oX.titleContainer,children:[(0,g.jsx)(_.default,{style:oX.title,children:ij}),(0,g.jsx)(f.default,{accessibilityLabel:"Close",accessibilityRole:"button","data-testid":a.a.MODAL_CLOSE_BUTTON,hitSlop:12,onPress:o,children:(0,g.jsx)(a.m,{})})]}),(0,g.jsxs)(m.default,{style:oX.QRCodeContainer,children:[(0,g.jsx)(m.default,{"data-testid":a.a.DEALS_ALERT_MODAL_QR_CODE_CONTAINER,style:oX.qrCode,children:(0,g.jsx)(oq,{size:120,value:r})}),(0,g.jsxs)(m.default,{style:oX.textContainer,children:[(0,g.jsxs)(_.default,{children:[(0,g.jsx)(_.default,{style:oX.boldText,children:"Scan the code"})," to set a Deal Alert in the Best Buy app to get it for less."]}),(0,g.jsx)(_.default,{children:"We'll notify you if there's a price drop."})]})]})]})]})})},oJ=C.A.create({container:{},button:{padding:4}}),oQ=({onPress:e,parameters:t,profile:i,data:n})=>{let[r,o]=(0,l.useState)(!1),[s,d]=(0,l.useState)(""),{platform:c,skuId:u}=t;(0,l.useEffect)(()=>{let e=window._metaLayer?.env_appServer??window._metaLayer?.env_appAssets??window.metaLayer?.env_appServer??window.metaLayer?.env_appAssets;e&&d(e)},[]);let p=(0,l.useMemo)(()=>u?`${s}/site/p/${u}.p`:void 0,[u,s]),y=(0,l.useMemo)(()=>"sv"===c,[c]),P=(0,l.useCallback)(()=>{u&&J({pageName:"Product Display Page",data:{event:{type:"interaction"},interaction:{name:"Deal Alert: Set alert"},skus:[{id:u}]}}),o(!0),e&&e()},[u,e]),h=(0,l.useCallback)(()=>{o(!1)},[]),I=(0,l.useMemo)(()=>(0,g.jsx)(f.default,{accessibilityLabel:"Deal Alert",accessibilityRole:"button","data-testid":a.a.DEALS_ALERT_BELL_BUTTON,onPress:P,style:oJ.button,children:(0,g.jsx)(oK,{"data-testid":a.a.DEALS_ALERT_BELL_ICON})}),[P]),C=(0,l.useMemo)(()=>r&&p?(0,g.jsx)(oZ,{"data-testid":a.a.DEALS_ALERT_MODAL,isSmallView:y,onModalClose:h,pdpUrl:p}):null,[r,y,h,p]);return!function({data:e,parameters:t,pdpUrl:i,platform:n,profile:r}){return!!i&&!!["LARGE"].includes(r)&&!!["lv","sv"].includes(n)&&!il(eQ(e,t))&&!is(e,t)}({data:n,parameters:t,pdpUrl:p,platform:c,profile:i})?null:(0,g.jsxs)(m.default,{"data-testid":a.a.DEALS_ALERT,style:[oJ.container],children:[I,C]})},o0=C.A.create({container:{paddingTop:5,paddingBottom:5,paddingRight:5},notificationFilled:{width:20,height:20,top:0}}),o1=e=>{let{parameters:t}=e,{skuId:i}=t,n=eq(eN(t.customer)),r=ou(),a=(0,l.useCallback)(()=>{i&&J({data:{event:{type:"interaction"},interaction:{name:"Deal Alert: Modify Alert"},skus:[{id:i}]},pageName:"Product Display Page"}),r?.navigateDealAlert?.()},[r,i]),o=!function({parameters:e,layoutConfig:t,liveConfig:i,egpData:n}){if(!tH(e.platform))return!1;let r=eQ(n,e),a=0===e0(r),o=il(r),s=e.isMembershipSku??!1,l=is(n,e);if(a||o||s||l)return!1;let d=t.dealAlert?.show??!1;return!!iH({isMobilePlatform:tH(e.platform),isUserLoggedIn:e.isUserLoggedIn??!1,liveConfig:i})&&d}(e),{dealAlertSkuStatus:s}=iV(i,o,n),d=s.skuIdInDealAlert??!1;return o||!d?null:(0,g.jsx)(m.default,{style:o0.container,children:(0,g.jsx)(f.default,{"data-testid":"deal-alert-touchable",onPress:a,children:(0,g.jsx)(W.default,{fill:"#318000",style:o0.notificationFilled})})})},o2=(e,{egpData:t,parameters:i})=>{let n=eQ(t,i),r=er(n)?n.puckDisplayMessage??n.preferredBadging:void 0;return r?.toLocaleLowerCase()===ex?r:e},o3=(e,{egpData:t,layoutConfig:i,parameters:n})=>{let r=eQ(t,n),a=er(r)?r.puckDisplayMessage:void 0,o=r?.preferredBadging?.toLowerCase(),s=a??o;return s?(ob(i.variant)||n.priceVariant===tI)&&!eB(s)?e:s:e},o6=(e,{egpData:t,parameters:i,layoutConfig:n})=>io(t,i)&&n.badge.badgingTypeWith?n.badge.badgingTypeWith.lowestOpenBoxPrice:e;function o5(e){var t;if(im(e))return;let{egpData:i,layoutConfig:n,parameters:r}=e;return t={egpData:i,layoutConfig:n,parameters:r},[o3,o6,o2].reduce((e,i)=>i(e,t),void 0)}function o4({badgingType:e,layoutConfig:t,liveConfig:i,parameters:n}){return!!t.badge.show&&(e?.toLowerCase()===ex||!function({liveConfig:e,parameters:t}){var i;let n;return!!t.suppressBadging||(i=t.displayLocation,!!Array.isArray(n=e["suppressBadging.allowedDisplayLocations"])&&0!==n.length&&ef(i)&&n.includes(i))}({liveConfig:i,parameters:n})&&(ok(t.variant)||ob(t.variant)||n.priceVariant===tI?eB(e):(e!==ev.PACKAGE_PRICE||!n.isCombo||!!t.savings.showWith.badging)&&!eu(e)))}var o8=[ev.MY_BBY_LOYALTY,ev.MY_BBY_ELITE_LOYALTY,ev.MY_BBY_ELITE_PLUS_LOYALTY,ev.CABO,ev.SUCO,ev.PAID_MEMBER,ev.PLAN_PAID_MEMBER_2,ev.PLAN_PAID_MEMBER_3,"Clearance","My Best Buy Offer","Total Member Price","Plus Member Price","Offer Pricing"];function o9(e,t){let i=eQ(e,t);return function(e){try{if("string"==typeof e){let t=0,i=e;e.includes("CDT")&&(i=`${i.replace("CDT","").trim()}Z`,t=5),e.includes("CST")&&(i=`${i.replace("CST","").trim()}Z`,t=6);let n=new Date(i);return Number.isNaN(n.getTime())?void 0:(0,F.L)(n,t)}}catch{}}(i?.dealExpirationTimeStamp)}function o7({egpData:e,layoutConfig:t,liveConfig:i,parameters:n}){let r=function({egpData:e,parameters:t,liveConfig:i,layoutConfig:n,selectedContract:r,showStandardPricing:a}){if(!i["dealExpirationTimer.enabled"]||!n.dealExpirationTimer.show||t.priceVariant===tI)return!1;let o=eQ(e,t);if(eu(o)||en(o)||function({egpData:e,layoutConfig:t,parameters:i,selectedContract:n,showStandardPricing:r}){return o8.includes(o5({egpData:e,layoutConfig:t,parameters:i,selectedContract:n,showStandardPricing:r})??"")}({egpData:e,layoutConfig:n,parameters:t,selectedContract:r,showStandardPricing:a}))return!1;let s=o9(e,t);return!eu(s)&&s<(0,F.L)(new Date,i["dealExpirationTimer.showWithinHours"])}({egpData:e,liveConfig:i,layoutConfig:t,parameters:n,selectedContract:iE(),showStandardPricing:iB()}),a=o9(e,n),o=r&&a instanceof Date;return o?{data:{dealExpirationDate:a},show:o}:{data:null,show:o}}var se=({fill:e,...t})=>(0,g.jsxs)("svg",{"data-testid":a.a.ICON_CLOCK,fill:"none",height:"24",viewBox:"0 0 24 24",width:"24",xmlns:"http://www.w3.org/2000/svg",...t,children:[(0,g.jsx)("path",{d:"M12 22.5C6.21 22.5 1.5 17.79 1.5 12C1.5 6.21 6.21 1.5 12 1.5C17.79 1.5 22.5 6.21 22.5 12C22.5 17.79 17.79 22.5 12 22.5ZM12 3C7.04 3 3 7.04 3 12C3 16.96 7.04 21 12 21C16.96 21 21 16.96 21 12C21 7.04 16.96 3 12 3Z",fill:e}),(0,g.jsx)("path",{d:"M15.25 16C15.06 16 14.87 15.93 14.72 15.78L11.47 12.53C11.3293 12.3895 11.2502 12.1988 11.25 12V5.75C11.25 5.34 11.59 5 12 5C12.41 5 12.75 5.34 12.75 5.75V11.69L15.78 14.72C16.07 15.01 16.07 15.49 15.78 15.78C15.63 15.93 15.44 16 15.25 16Z",fill:e})]});function st({dealExpirationDate:e,endsSoonHours:t}){return(0,j.O)(e,Date.now())/3600<=t}function si({dealExpirationDate:e}){let t=new Date;if(e>(0,G.o)())return`Deal ends ${(0,U.GP)(e,"MMM d, yyyy")}`;if((0,H.M)(e,t)>=24)return"Deal ends tomorrow";if(e<=t)return"Deal has ended";let i=(0,j.O)(e,t),n=Math.floor(i/3600).toString(),r=Math.floor(i%3600/60).toLocaleString("en-US",{minimumIntegerDigits:2}),a=Math.floor(i%60).toLocaleString("en-US",{minimumIntegerDigits:2});return`Deal ends in ${n}:${r}:${a}`}function sn(e,t){if(t)return a.d.color.promoRed;switch(e){case"footer":return a.d.color.hintGray;case"header":return a.d.color.pureBlack}}var sr=e=>{let{layoutConfig:{dealExpirationTimer:{location:t}}}=e,{isEndingSoonOrOver:i,message:n}=function({dealExpirationDate:e,liveConfig:t}){let i=t["dealExpirationTimer.endsSoonHours"],[n,r]=(0,l.useState)(si({dealExpirationDate:e})),[a,o]=(0,l.useState)(st({dealExpirationDate:e,endsSoonHours:i})),s=(0,l.useRef)(void 0),d=(0,l.useCallback)(()=>{o(st({dealExpirationDate:e,endsSoonHours:i})),r(si({dealExpirationDate:e}))},[e,i]);return(0,l.useEffect)(()=>(d(),function({dealExpirationDate:e}){return e>new Date&&e<(0,G.o)()}({dealExpirationDate:e})&&(clearInterval(s.current),s.current=setInterval(d,1e3)),()=>{clearInterval(s.current)}),[d,e]),{isEndingSoonOrOver:a,message:n}}(e),r=(0,l.useMemo)(()=>C.A.create({container:{alignItems:"center",backgroundColor:"header"===t?a.d.color.lightRed:a.d.color.transparent,borderRadius:a.d.size.radius.md,display:"flex",flexDirection:"row",gap:4,paddingBottom:4,paddingLeft:4*("header"===t),paddingRight:4*("header"===t),paddingTop:4},icon:{color:sn(t,i),height:12,width:12},text:{color:i?a.d.color.promoRed:a.d.color.pureBlack,fontSize:a.d.size.font[1],fontStyle:"header"===t?"normal":"italic",fontWeight:"header"===t?"500":"400",lineHeight:a.d.size.lineHeight[1]}}),[i,t]),o=(0,l.useMemo)(()=>({color:sn(t,i),size:"header"===t?12:14}),[i,t]);return(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_DEAL_EXPIRATION_TIMER_MESSAGE,style:r.container,children:[(0,g.jsx)(se,{"data-testid":a.a.PRICE_BLOCK_DEAL_EXPIRATION_TIMER_MESSAGE_ICON,fill:o.color,height:o.size,strokeWidth:.5,width:o.size}),(0,g.jsx)(I.E,{"data-testid":a.a.PRICE_BLOCK_DEAL_EXPIRATION_TIMER_MESSAGE_TEXT,style:r.text,children:n})]})},sa=e=>{let{data:t,show:i}=o7(e);if(!i)return null;let{layoutConfig:n,liveConfig:r}=e;return(0,g.jsx)(sr,{"data-testid":a.a.PRICE_BLOCK_DEAL_EXPIRATION_TIMER,dealExpirationDate:t.dealExpirationDate,layoutConfig:n,liveConfig:r})};function so(e){return el(e)&&e.unitOfMeasure?.toLowerCase()==="years"}function ss(e){if(im(e)){let{egpData:t,parameters:i,selectedContract:n}=e,r=ic(eQ(t,i),n);if("FINANCED"===r.purchaseType&&em(r.billCreditAmount)&&em(r.contractTotalSavings)&&em(r.numberOfPayments)){let e=e6(r.contractTotalSavings),t=e6(r.billCreditAmount);return`Total savings of ${e} includes ${t}/mo. carrier bill credit for ${r.numberOfPayments} months. Bill credits end when phone balance is paid off.`}}}var sl={lg:a.d.size.lineHeight[3],md:a.d.size.lineHeight[2],sm:a.d.size.lineHeight[2],xsm:a.d.size.lineHeight[1]},sd={lg:a.d.size.font[3],md:a.d.size.font[2],sm:a.d.size.font[2],xsm:a.d.size.font[1]},sc=({egpData:e,layoutConfig:t,parameters:i})=>{let n=iE(),r=iB(),o=function(e){let{egpData:t,layoutConfig:i,liveConfig:n,parameters:r}=e;return!(!i.footerMessage.show||!i.footerMessage.showWith.badging&&o4({badgingType:o5(e),layoutConfig:i,liveConfig:n,parameters:r}))&&(!!ef(ss(e))||es(t)&&so(t.termLength))}({egpData:e,layoutConfig:t,liveConfig:tw(),parameters:i,selectedContract:n,showStandardPricing:r}),s=ef(ss({egpData:e,parameters:i,selectedContract:n,showStandardPricing:r})),d=(0,l.useMemo)(()=>i.isTextCenterAligned?"center":i.isTextRightAligned?"flex-end":"flex-start",[i]),c=C.A.create({container:{marginTop:20*!!s},text:{display:"flex",flexDirection:"row",fontSize:s?11:sd[t.size],lineHeight:s?14:sl[t.size],justifyContent:d}});if(!o)return null;let u=function({egpData:e,parameters:t,selectedContract:i,showStandardPricing:n}){let r=eQ(e,t),a=ss({egpData:e,parameters:t,selectedContract:i,showStandardPricing:n});if(ef(a))return a;let o=e0(r);if(es(e)&&so(e.termLength)&&em(e.termLength.value)&&em(o)){let t=12*e.termLength.value;return`About ${e6(o/t,{zeroStrategy:"showCurrency"})}/mo.`}}({egpData:e,parameters:i,selectedContract:n,showStandardPricing:r});return(0,g.jsx)(b.S,{"data-testid":a.a.PRICE_BLOCK_FOOTER_MESSAGE_CONTAINER,style:c.container,children:(0,g.jsx)(I.E,{className:s?void 0:"whitespace-nowrap","data-testid":a.a.PRICE_BLOCK_FOOTER_MESSAGE_TEXT,style:c.text,children:u})})};sc.displayName="FooterMessage";var su=C.A.create({footer:{flexDirection:"column",gap:4}}),sp=e=>{let{layoutConfig:t,egpData:i,parameters:n}=e;return(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_FOOTER,style:su.footer,children:["footer"===t.dealExpirationTimer.location&&(0,g.jsx)(sa,{...e}),(0,g.jsx)(sc,{egpData:i,layoutConfig:t,parameters:n})]})};function sm(e,t,i,n,r){let a={event:{type:"interaction"},interaction:{name:e},content:[{type:n,name:t,region:i}]};return r?.id&&(a.skus=[r]),a}function sf(e,t){if(!es(e))return;let i=eQ(e,t);return er(i)?i.puckMessageURL??void 0:void 0}function sg(e,t){if(et(e)){let[i,n]=Object.entries(e).find(([e])=>e.toLowerCase()===t.toLowerCase())??[];return n}}function sy({egpData:e,layoutConfig:t,parameters:i}){let n=iE(),r=iB(),a=tw(),o=o5({egpData:e,layoutConfig:t,parameters:i,selectedContract:n,showStandardPricing:r}),s=o4({badgingType:o,layoutConfig:t,liveConfig:a,parameters:i}),l=sf(e,i),d=o?function(e,t,i){if(eu(i))return"";if(i in ek)return ek[i].text;let n=eQ(e,t);if(er(n)){let e=n.puckDisplayMessage??n.preferredBadging;if(e)return e}return""}(e,i,o):"",c=function(e,t,i){let{data:n,loading:r}=iJ("pricex-holiday-membership-modal",{skip:!e});if(!e)return{data:null,loading:!1};let a=sg(n,e);if(!a&&t&&i){let e=sg(n,"defaultModalContent");return{data:{title:i,link:{href:t,text:e?.link?.text},disclaimers:e?.disclaimers},loading:r}}return{data:a,loading:r}}(o,l,d);return s?{data:{badgingType:o,copy:{text:d},isClickable:function({badgingType:e,layoutConfig:t,holidayBadgeModalContent:i,egpData:n,parameters:r}){if(e?.toLowerCase()===ex)return!1;if(e&&i.data)return t.badge.clickableInWeb||t.badge.clickableInApp;if(!eD(e))return!1;let a=eQ(n,r);return er(a)&&em(a.priceWithCart?.totalOfferSavings)}({badgingType:o,layoutConfig:t,holidayBadgeModalContent:c,egpData:e,parameters:i}),holidayBadgeModalContent:c},show:s}:{data:null,show:s}}function sP(e){if(es(e))return e.skuId??e.price?.skuId}function sh(e,t){let i;return[sP(e)??"",...er(i=eQ(e,t))?i.priceWithCart?.adjustedCartItems?.filter(e=>null!==e).map(e=>e.skuId).filter(Boolean)??[]:[]].filter(Boolean)}sp.displayName="Footer";var sI=({displayLocation:e,skuId:t,customerPrice:i,regularPrice:n})=>{let{data:r}=iJ("bns-disclaimer-2"),[o,s]=(0,l.useState)(!1),d=(0,l.useCallback)(()=>{o||(({displayLocation:e,skuId:t,customerPrice:i,regularPrice:n})=>{let r,a=t?(r={id:t},"number"==typeof i&&(r.unitPrice=i),"number"==typeof n&&(r.regularPrice=n),r):void 0;J({pageName:eh({displayLocation:e}),data:sm(tn,"Offer Disclaimer",tt,"link",a)})})({displayLocation:e,skuId:t,customerPrice:i,regularPrice:n}),s(!o)},[o,e,t,i,n]);if(ec(r))return null;let c=C.A.create({wrapper:{display:"flex",flexDirection:"column",alignItems:"flex-start",gap:8},trigger:{display:"flex",alignItems:"center",flexDirection:"row",gap:4},triggerText:{color:a.d.color.primaryEmphasisBlue,fontFamily:a.d.font.family.sans,fontSize:a.d.size.font[1],fontWeight:"500",lineHeight:a.d.size.lineHeight[1]},paragraph:{color:a.d.color.darkGray,fontFamily:a.d.font.family.sans,fontSize:a.d.size.font[1],lineHeight:a.d.size.lineHeight[1],flexShrink:1}});return(0,g.jsxs)(b.S,{"data-testid":a.a.BUNDLE_AND_SAVE_DISCLAIMER_WRAPPER,style:c.wrapper,children:[(0,g.jsx)(w.default,{"data-testid":a.a.BUNDLE_AND_SAVE_DISCLAIMER_TRIGGER,onPress:d,children:(0,g.jsxs)(b.S,{"data-testid":a.a.BUNDLE_AND_SAVE_DISCLAIMER_TRIGGER,style:c.trigger,children:[(0,g.jsx)(I.E,{"data-testid":a.a.BUNDLE_AND_SAVE_DISCLAIMER_TRIGGER_TEXT,style:c.triggerText,children:r.OfferContent?.DefaultDisclaimer?.header}),(0,g.jsx)(a.l,{color:a.d.color.primaryEmphasisBlue,"data-testid":a.a.BUNDLE_AND_SAVE_DISCLAIMER_TRIGGER_ICON,rotateDegrees:o?-90:90,size:20,strokeWidth:"8"})]})}),!!o&&r.OfferContent?.DefaultDisclaimer?.body?.map(e=>(0,g.jsx)(I.E,{"data-testid":a.a.BUNDLE_AND_SAVE_DISCLAIMER_PARAGRAPH,style:c.paragraph,children:e},e))]})},sC=C.A.create({container:{display:"flex",flexDirection:"row",justifyContent:"space-between"},nameAndImage:{display:"flex",flexDirection:"row",columnGap:8},name:{maxWidth:145},image:{width:48,height:48},purchasePrice:{fontWeight:"500"},previousPrice:{color:a.d.color.defaultSubdued,textDecorationLine:"line-through"}}),s_=e=>{let t=e6(e.purchasePrice),i=e.previousPrice===e.purchasePrice?null:e6(e.previousPrice);return(0,g.jsxs)(b.S,{"data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM_CONTAINER,style:sC.container,children:[(0,g.jsx)(o_,{"data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM_SKELETON,isLoading:e.isLoading??!1,profile:"LARGE",children:(0,g.jsxs)(b.S,{"data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM_NAME_AND_IMAGE,style:sC.nameAndImage,children:[(0,g.jsx)(A.default,{accessibilityLabel:e.name??"Product image",alt:e.name??"Product image","data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM_IMAGE,resizeMode:"contain",source:{uri:e.imageSrc??""},style:sC.image}),(0,g.jsx)(I.E,{"data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM_NAME,style:sC.name,children:e.name})]})}),(0,g.jsxs)(b.S,{className:"flex flex-col items-end",children:[(0,g.jsx)(I.E,{"data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM_PURCHASE_PRICE,style:sC.purchasePrice,children:t}),!!i&&(0,g.jsx)(I.E,{"data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM_PREVIOUS_PRICE,style:sC.previousPrice,children:i})]})]})},sb=C.A.create({container:{display:"flex",flexDirection:"column",gap:20},header:{display:"flex",columnGap:8,flexDirection:"row",alignItems:"center"},header__title:{fontWeight:"500",fontSize:a.d.size.font[4]},summaryText:{fontSize:a.d.size.font[2]},addToCartContainer:{display:"flex",justifyContent:"flex-end",flexDirection:"row"},addToCartButtonWrapper:{maxWidth:400,...u.A.select({web:{},default:{width:"100%"}})}}),sT=({data:e,loading:t,closeModal:i,displayLocation:n,onAddToCartSuccess:r})=>{let o=e?.primaryProduct.skuId,s=(0,l.useCallback)(()=>{(({displayLocation:e,skuId:t,customerPrice:i,regularPrice:n})=>{let r,a=t?(r={id:t},"number"==typeof i&&(r.unitPrice=i),"number"==typeof n&&(r.regularPrice=n),r):void 0;J({pageName:eh({displayLocation:e}),data:sm(tn,"Add to Cart",tt,"button",a)})})({displayLocation:n,skuId:o,customerPrice:e?.primaryProduct.purchasePrice,regularPrice:e?.primaryProduct.previousPrice}),r?.(),i()},[i,e?.primaryProduct.previousPrice,e?.primaryProduct.purchasePrice,n,r,o]);return null===e?null:(0,g.jsxs)(b.S,{"data-testid":a.a.BUNDLE_AND_SAVE_CONTAINER,style:sb.container,children:[(0,g.jsxs)(b.S,{style:{display:"flex",flexDirection:"column",gap:4},children:[(0,g.jsxs)(b.S,{"data-testid":a.a.BUNDLE_AND_SAVE_HEADER,style:sb.header,children:[(0,g.jsx)(a.n,{size:24}),(0,g.jsx)(I.E,{"data-testid":a.a.BUNDLE_AND_SAVE_HEADER_TITLE,style:sb.header__title,children:"Bundle & Save"})]}),(0,g.jsx)(b.S,{children:(0,g.jsxs)(I.E,{"data-testid":a.a.BUNDLE_AND_SAVE_SUMMARY_TEXT,style:sb.summaryText,children:["Save ",e.totalOfferSavings," when you buy these together:"]})})]}),(0,g.jsx)(b.S,{children:(0,g.jsx)(s_,{"data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM,imageSrc:e.primaryProduct.imageSrc,isLoading:t,name:e.primaryProduct.name,previousPrice:e.primaryProduct.previousPrice,purchasePrice:e.primaryProduct.purchasePrice})}),(0,g.jsx)(b.S,{"data-testid":a.a.BUNDLE_AND_SAVE_ADD_TO_CART_CONTAINER,style:sb.addToCartContainer,children:(0,g.jsx)(b.S,{style:sb.addToCartButtonWrapper,children:(0,g.jsx)(e9,{_name:"AddToCartButton",context:"PLP",destinationZipCode:e.addToCartProps.destinationZipCode,isSmallView:e.addToCartProps.isSmallView,onSuccess:s,salesChannel:e.addToCartProps.salesChannel,skuId:e.primaryProduct.skuId})})}),e.adjustedCartItems.length>0&&(0,g.jsxs)(g.Fragment,{children:[(0,g.jsx)(b.S,{children:(0,g.jsx)(I.E,{className:"italic","data-testid":a.a.BUNDLE_AND_SAVE_CURRENTLY_IN_CART_TEXT,children:"Currently in your cart"})}),e.adjustedCartItems.map(({previousPrice:e,purchasePrice:i,imageSrc:n,name:r,key:o})=>(0,g.jsx)(s_,{"data-testid":a.a.BUNDLE_AND_SAVE_MODAL_ITEM,imageSrc:n,isLoading:t,name:r,previousPrice:e,purchasePrice:i},o))]}),(0,g.jsx)(sI,{customerPrice:e.primaryProduct.purchasePrice,displayLocation:n,regularPrice:e.primaryProduct.previousPrice,skuId:o})]})};sT.displayName="BundleAndSave";var sS=C.A.create({link:{fontSize:15,fontWeight:"500",color:a.d.color.blue,marginBottom:16}}),sO=({data:e,loading:t,displayLocation:i,analyticsSku:n,puckMessageURL:r})=>{let o=r??e?.link?.href,s=(0,l.useCallback)(()=>{e?.link?.text&&J({pageName:eh({displayLocation:i}),data:sm(tn,e.link.text,tt,tr,n)})},[n,e,i]);return(0,g.jsxs)(m.default,{children:[!!e?.link&&(0,g.jsx)(o_,{isLoading:t,profile:"LARGE",children:(0,g.jsx)(w.default,{onPress:s,children:(0,g.jsx)(_.default,{"data-testid":a.a.HOLIDAY_BADGE_MODAL_CONTENT_LINK,href:o,style:sS.link,children:e.link.text})})}),!!e?.disclaimers&&(0,g.jsx)(o_,{isLoading:t,profile:"LARGE",children:(0,g.jsx)(_.default,{"data-testid":a.a.HOLIDAY_BADGE_MODAL_CONTENT_DISCLAIMERS,role:"paragraph",children:e.disclaimers.join(`
`)})})]})},sv=(0,c.J1)`
  query getBundleAndSaveModalProducts($skuIds: [String!]!) {
    productsBySkuIds(skuIds: $skuIds) {
      ... on ProductNotFound {
        skuId
      }
      ... on Product {
        skuId
        name {
          short
        }
        primaryImage {
          piscesHref
        }
      }
    }
  }
`,sw=({badgingType:e,copy:t,styles:i,parameters:n,egpData:r,holidayBadgeModalContent:o,onModalClose:s})=>{let{__brand:d,query:c}=function({egpData:e,parameters:t,badgingType:i}){let n=function({egpData:e,parameters:t}){let i,[n,{data:r,loading:a}]=(0,z._)(sv),o=(0,l.useCallback)(()=>{let i=sh(e,t);if(i.length>0)return n({variables:{skuIds:i}})},[e,t,n]),s=function(e,t,i){let n=eQ(e,t);if(er(n)){let a=sP(e);if(a){var r;let o,s=(r=sh(e,t),o=Object.fromEntries(r.map(e=>[e,{skuId:e,name:"",imageSrc:""}])),i?.productsBySkuIds?.reduce((e,t)=>{if(es(t)){let{skuId:i,name:n,primaryImage:r}=t;if(i)return{...e,[i]:{skuId:i,name:n?.short??"",imageSrc:r?.piscesHref??""}}}return e},o)??o);return{primaryProduct:{skuId:a,purchasePrice:e0(n),previousPrice:e1(n),imageSrc:s[a].imageSrc,name:s[a].name},adjustedCartItems:n.priceWithCart?.adjustedCartItems?.reduce((e,t,i)=>t?.skuId?e.concat({purchasePrice:t.newCustomerPrice,previousPrice:t.previousCustomerPrice,imageSrc:s[t.skuId].imageSrc,name:s[t.skuId].name,key:`${t.skuId}_${i}`}):e,[])??[]}}}}(e,t,r);if(ec(s))return{loading:a,loadData:o,data:null};let{primaryProduct:d,adjustedCartItems:c}=s;return{loading:a,loadData:o,data:{totalOfferSavings:er(i=eQ(e,t))&&em(i.priceWithCart?.totalOfferSavings)?e6(i.priceWithCart.totalOfferSavings,{decimalStrategy:"hide-decimals",zeroStrategy:"showCurrency"}):"",primaryProduct:d,adjustedCartItems:c,addToCartProps:{salesChannel:eZ(t.platform),isSmallView:"lv"!==t.platform,destinationZipCode:t.zipCode}}}}({egpData:e,parameters:t});return eD(i)?{__brand:"bundle-and-save-modal",query:n}:{__brand:"noop",query:null}}({egpData:r,parameters:n,badgingType:e}),u=sf(r,n),p=(0,l.useRef)(null),[m,f]=(0,l.useState)(!1),y=eQ(r,n),P=n.skuId,{displayLocation:h}=n,C=(0,l.useMemo)(()=>{if(!P)return;let e={id:P},t=e0(y),i=e1(y);return"number"==typeof t&&(e.unitPrice=t),"number"==typeof i&&(e.regularPrice=i),e},[P,y]),_=(0,l.useCallback)(()=>{if("bundle-and-save-modal"===d){c.loadData();let e=c.data?.primaryProduct.skuId;e&&J({data:{event:{type:"interaction"},interaction:{name:`See your savings: (${e})`},basket:{offers:[{type:"bundle_and_save",amount:0,id:e}]},content:[{name:`See your savings: (${e})`,type:"data-track",isClick:!0}]},pageName:"Product Display Page"})}else J({pageName:eh({displayLocation:h}),data:sm(te,t.text,tt,ti,C)});p.current?.openModal()},[c,d,t.text,h,C]),T=(0,l.useRef)(!1),S=(0,l.useCallback)(()=>{p.current?.closeModal()},[]),O=(0,l.useCallback)(()=>{T.current=!0},[]),v=(0,l.useCallback)(()=>{f(!0)},[]),A=(0,l.useCallback)(()=>{f(!1)},[]),E=(0,l.useCallback)(()=>{if(T.current){T.current=!1,s?.();return}J({pageName:eh({displayLocation:h}),data:sm(tn,"close",tt,tr,C)}),s?.()},[C,h,s]);return(0,g.jsxs)(g.Fragment,{children:[(0,g.jsx)(w.default,{"data-testid":a.a.PRICE_BLOCK_BADGING_PRESSABLE,onHoverIn:v,onHoverOut:A,onPress:_,children:(0,g.jsx)(b.S,{"data-testid":a.a.PRICE_BLOCK_BADGING_WITH_MODAL,style:i.container,children:(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_BADGING_ROW,style:[i.flexRow],children:[(0,g.jsx)(I.E,{className:"text-style-micro-md-500",customProps:{native:{root:{allowFontScaling:!1}}},"data-testid":a.a.PRICE_BLOCK_BADGING_TEXT,style:[m&&{textDecorationLine:"underline"}],children:t.text}),(0,g.jsx)(a.l,{color:"black","data-testid":a.a.PRICE_BLOCK_BADGING_CARET_ICON,size:8})]})})}),(0,g.jsxs)(ni,{"data-testid":a.a.PRICE_BLOCK_BADGING_MODAL,onClose:E,ref:p,title:"bundle-and-save-modal"!==d&&!!o.data&&(0,g.jsx)(o_,{"data-testid":a.a.PRICE_BLOCK_BADGING_MODAL_SKELETON,isLoading:o.loading,profile:"LARGE",children:(0,g.jsx)(I.E,{"aria-level":2,"data-testid":a.a.PRICE_BLOCK_BADGING_MODAL_TITLE,style:i.modalTitle,children:o.data.title})}),children:["bundle-and-save-modal"===d&&(0,g.jsx)(sT,{closeModal:S,data:c.data,"data-testid":a.a.PRICE_BLOCK_BUNDLE_AND_SAVE_MODAL_CONTENT,displayLocation:h,loading:c.loading,onAddToCartSuccess:O}),"bundle-and-save-modal"!==d&&!!o.data&&(0,g.jsx)(sO,{analyticsSku:C,data:o.data,"data-testid":a.a.PRICE_BLOCK_HOLIDAY_BADGE_MODAL_CONTENT,displayLocation:h,loading:o.loading,puckMessageURL:u})]})]})};sw.displayName="BadgingWithModal";var sA=e=>{let{egpData:t,parameters:i}=e,{data:n,show:r}=sy(e);if(!r)return null;let o=(({parameters:e})=>C.A.create({textColor:{color:a.d.color.black},container:{backgroundColor:a.d.color.transparent,borderRadius:a.d.size.radius.md,display:"flex",flexDirection:"row",gap:2,justifyContent:e.isTextRightAligned?"flex-end":"flex-start"},emphasizedText:{fontSize:a.d.size.font[1],fontWeight:"500",lineHeight:a.d.size.lineHeight[1]},flexRow:{alignItems:"center",display:"flex",columnGap:2,flexDirection:"row"},modalTitle:{fontWeight:"500",fontSize:"lv"===e.platform?a.d.size.font[6]:a.d.size.font[5],marginBottom:24,marginTop:0,lineHeight:"lv"===e.platform?a.d.size.lineHeight[6]:a.d.size.lineHeight[5]}}))({badgingType:n.badgingType,parameters:i});return n.isClickable&&n.badgingType?(0,g.jsx)(sw,{badgingType:n.badgingType,copy:n.copy,egpData:t,holidayBadgeModalContent:n.holidayBadgeModalContent,parameters:i,styles:o}):(0,g.jsx)(b.S,{className:"whitespace-nowrap","data-testid":a.a.PRICE_BLOCK_BADGING,style:o.container,children:(0,g.jsx)(I.E,{className:"text-style-micro-md-500",customProps:{native:{root:{allowFontScaling:!1}}},"data-testid":a.a.PRICE_BLOCK_BADGING_TEXT,children:n.copy.text})})};sA.displayName="Badging";var sE=e=>{let{layoutConfig:t,parameters:i}=e,{show:n}=sy(e),{show:r}=o7(e),o="header"===t.dealExpirationTimer.location;if(!n&&!r)return null;let s=C.A.create({header:{display:"flex",alignItems:"center",flexDirection:"row",justifyContent:i.isTextRightAligned?"flex-end":"flex-start",gap:4}});return(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_HEADER,style:s.header,children:[(0,g.jsx)(sA,{...e}),!!o&&!!r&&(0,g.jsx)(sa,{...e})]})};function sx(){let e=tA();if(et(e)&&("planPaidMembershipEffectiveType"in e||"profileLabels"in e||"planPaidMembershipPendingType"in e||"displayName"in e||"isRecognized"in e||"planPaidMembershipActiveType"in e||"primaryShippingAddressZipCode"in e||"memberId"in e))return e}sE.displayName="Header";var sL={buy_new:"Buy New:",comp_value:"Comp. Value:"};function sk(e){let{egpData:t,parameters:i,selectedContract:n}=e,r=eQ(t,i),a=e1(r),o=r?.showTotalSavings,s=r?.totalSavings,l=r?.totalSavingsPercent;if(ea(r)&&!eu(r.regularSubBundlePrice)&&(a=r.regularSubBundlePrice),(oT(i.priceVariant)||i.priceVariant===th)&&en(r)&&(a=r.deliveryAndServices?.regularPrice,o=void 0,s=r.deliveryAndServices?.totalSavings),im(e)){let e=ic(r,n);a=e.regularPrice,o=e.showTotalSavings,s=e.contractTotalSavings,l=e.totalSavingsPercent}return is(t,i)&&(a=(s=r.openBoxSavings??0)+(e0(r)??0)),{showTotalSavings:o,totalSavings:s,regularPrice:a,totalSavingsPercent:l}}function sB(e){let t=sk(e),{liveConfig:{"showTotalSavings.percent.threshold":i,"showTotalSavings.threshold":n},parameters:{showSavingsAsPercentage:r}}=e,a=t.totalSavings??0,o=t.totalSavingsPercent??0,s=a>=n,{showTotalSavings:l}=t;return!1!==l&&(r?o>=i&&s:s)}function sD(e,t){if(!eu(eQ(e,t)))return is(e,t)?"buy_new":"comp_value"}var sR={interaction:{name:"Reference Pricing Info"},content:[{name:"Reference Pricing Info",isClick:!0,type:"data-track"}]},sM=C.A.create({modalContent:{display:"flex",flexDirection:"column",gap:12},modalCopy:{fontFamily:a.d.font.family.sans,fontSize:15}}),sN={native:{linkText:{className:"font-500 text-4 text-primary"}},web:{linkText:{className:"font-500 text-2 text-primary"}}},s$=e=>{let t,i,n,r=(0,l.useRef)(null),{egpData:o,parameters:s}=e,d=eQ(o,s),c=s.skuId,{displayLocation:u}=s,p=c?(t={id:c},i=e0(d),n=e1(d),"number"==typeof i&&(t.unitPrice=i),"number"==typeof n&&(t.regularPrice=n),t):void 0,f=function({egpData:e,parameters:t,layoutConfig:i}){let n=function(e){var t;let i,{layoutConfig:n,egpData:r,parameters:a,selectedContract:o,tradeInAppraisal:s}=e;if(!n.savings.regularPrice.showInfoModal)return!1;let l=eQ(r,a);if(!et(l))return!1;let d=im(e),c=!d||iv({selectedContract:o,tradeInAppraisal:s}),u=d&&"comp_value"===sD(r,a)&&(i=(t=ic(l,o)).customerPrice??t.currentPrice,!eu(t.regularPrice)&&!eu(i)&&t.regularPrice>i);return(c||u)&&!is(r,a)&&!io(r,a)}({egpData:e,parameters:t,layoutConfig:i,selectedContract:iE(),showStandardPricing:iB(),tradeInAppraisal:ix()}),{data:r}=iJ("priceviewregularpricedescriptioncontent",{skip:!n}),{trackClick:a}=function({displayLocation:e,data:t}){return(0,l.useMemo)(()=>({trackClick:()=>{J({data:t,pageName:eh({displayLocation:e})})}}),[t,e])}({displayLocation:t.displayLocation,data:sR});if(n)return{copy:r?.regularPriceDescriptionContent?.content?.WAS??"",learnMoreLink:r?.regularPriceDescriptionContent?.learnMoreLink??"",learnMoreText:r?.regularPriceDescriptionContent?.learnMoreText??"",trackClick:a}}(e),y=(0,l.useCallback)(e=>{let t=e===ta;J({pageName:eh({displayLocation:u}),data:sm(t?te:tn,e,tt,t?ti:tr,p)})},[u,p]),P=(0,l.useCallback)(()=>{y("close")},[y]),h=(0,l.useCallback)(()=>{y("Learn more")},[y]),I=(0,l.useCallback)(()=>{f&&r.current&&(y(ta),r.current.openModal(),f.trackClick())},[f,y]);return f?(0,g.jsxs)(g.Fragment,{children:[(0,g.jsx)(w.default,{accessibilityLabel:"information",accessibilityRole:"button",onPress:I,children:(0,g.jsx)(a.g,{color:a.d.color.defaultSubdued,size:12,strokeWidth:1})}),(0,g.jsx)(ni,{onClose:P,ref:r,children:(0,g.jsxs)(m.default,{"data-testid":a.a.PRICE_BLOCK_REGULAR_PRICE_INFO_MODAL,style:sM.modalContent,children:[(0,g.jsx)(_.default,{"data-testid":a.a.PRICE_BLOCK_REGULAR_PRICE_INFO_MODAL_COPY,role:"paragraph",style:sM.modalCopy,children:f.copy}),(0,g.jsx)(D.Link,{accessibilityRole:"link",customProps:sN,"data-testid":a.a.PRICE_BLOCK_REGULAR_PRICE_INFO_MODAL_LEARN_MORE_LINK,href:f.learnMoreLink,onPress:h,children:f.learnMoreText})]})})]}):null},sW=e=>{var t;let{layoutConfig:i,egpData:n,parameters:r,liveConfig:o,profile:s}=e,{data:d,show:c}=function({egpData:e,layoutConfig:t,parameters:i}){let n=iE(),r=iB(),a={egpData:e,parameters:i,layoutConfig:t,liveConfig:tw(),selectedContract:n,showStandardPricing:r},o=function(e){let{layoutConfig:t}=e;return!(!sB(e)||function(e){let{egpData:t,parameters:i,layoutConfig:n,selectedContract:r,showStandardPricing:a}=e;return!n.savings.showWith.bottomPriceMessage&&oS({egpData:t,layoutConfig:n,parameters:i,selectedContract:r,showStandardPricing:a})}(e)||function(e){let{egpData:t,liveConfig:i,parameters:n,layoutConfig:r,selectedContract:a,showStandardPricing:o}=e;return!r.savings.showWith.badging&&o4({badgingType:o5({egpData:t,layoutConfig:r,parameters:n,selectedContract:a,showStandardPricing:o}),layoutConfig:r,liveConfig:i,parameters:n})}(e)||function(e){let{egpData:t,parameters:i,layoutConfig:n}=e;return!n.savings.showWith.openBoxPrice&&is(t,i)}(e)||function(e){let{egpData:t,parameters:i,layoutConfig:n}=e;return!n.savings.showWith.lowestOpenBoxPrice&&io(t,i)}(e)||function(e){let{layoutConfig:t}=e;return!t.savings.showWith.activated&&im(e)}(e))&&t.savings.regularPrice.show}(a);return o?{data:{prefix:function({egpData:e,parameters:t,layoutConfig:i}){if(i.savings.regularPrice.showStrikeThru)return;let n=sD(e,t);if(!ec(n))return sL[n]}({egpData:e,layoutConfig:t,parameters:i}),regularPriceMessage:function(e){let{egpData:t,parameters:i,selectedContract:n}=e,r=eQ(t,i);if(im(e))return function({price:e,selectedContract:t}){let{numberOfPayments:i,regularPrice:n}=ic(e,t),r=e6(n,{zeroStrategy:"throwError"});return(i??0)>1?`${r}/mo.`:r}({price:r,selectedContract:n});let{regularPrice:a}=sk(e);return e6(a,{zeroStrategy:"throwError"})}(a),buyNewUrl:function(e,t){if(is(e,t))return function(e){if(Array.isArray(e))return e.find(e=>ed(e)&&"New"===e.type)}(e.buyingOptions)?.pdpUrl}(e,i)},show:o}:{data:null,show:o}}(e),{skuId:u}=r,p=(0,l.useRef)({native:{linkText:{className:"font-500 text-2 text-primary"}},web:{linkText:{className:"font-500 text-2 text-primary"}}}),m=i.savings.regularPrice.showStrikeThru,f=m?3:2,y=C.A.create({text:{color:a.d.color.defaultSubdued,fontSize:a.d.size.font[f],lineHeight:a.d.size.lineHeight[f],fontWeight:"400",textDecorationLine:m?"line-through":"none"},linkTextWrapper:{display:"flex",flexDirection:"row",alignItems:"center",gap:2},view:{alignItems:"center",display:"flex",flexDirection:"row",gap:4}}),P=(0,l.useCallback)(()=>{J({pageName:"Product Display Page",data:{event:{type:"interaction"},interaction:{name:"Buy New Selection"},skus:[{id:u??""}]}})},[u]);if(!c)return null;let h="LARGE"===s&&d.prefix===sL.comp_value,_=!!(d.prefix===sL.comp_value||m),T=(t=d.prefix,t===sL.comp_value?"The comparable value is ":m?"The price was ":null),S=d.buyNewUrl?(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_REGULAR_PRICE_LINK_TEXT_WRAPPER,style:y.linkTextWrapper,children:[(0,g.jsx)(I.E,{"data-testid":a.a.PRICE_BLOCK_REGULAR_PRICE_PREFIX_TEXT,style:y.text,children:d.prefix}),(0,g.jsx)(D.Link,{customProps:p.current,"data-testid":a.a.PRICE_BLOCK_REGULAR_PRICE_MESSAGE_LINK,href:d.buyNewUrl,onPress:P,children:d.regularPriceMessage})]}):(({data:e,shouldShowSeoAttribute:t,showAccessibilityText:i,srOnlyPrefix:n,styles:r})=>(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_REGULAR_PRICE_MESSAGE_TEXT,...i&&{customProps:{web:{root:{role:"text"}}}},children:[!!n&&(0,g.jsx)(I.E,{className:"sr-only",children:n}),(0,g.jsxs)(I.E,{className:"whitespace-nowrap",style:r.text,children:[!!e.prefix&&(0,g.jsxs)(I.E,{"aria-hidden":!!n,style:r.text,children:[e.prefix," "]}),(0,g.jsx)(I.E,{style:r.text,...!!t&&{"data-lu-target":"comp_value"},children:e.regularPriceMessage})]})]}))({data:d,shouldShowSeoAttribute:h,showAccessibilityText:_,srOnlyPrefix:T,styles:y});return(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_REGULAR_PRICE,style:y.view,children:[S,!!i.savings.regularPrice.showInfoModal&&(0,g.jsx)(s$,{egpData:n,layoutConfig:i,liveConfig:o,parameters:r})]})};function sF(e){let{egpData:t,layoutConfig:i,parameters:n}=e;return!(!sB(e)||!i.savings.showWith.lowestOpenBoxPrice&&io(t,n)||!i.savings.showWith.openBoxPrice&&is(t,n)||!i.savings.totalSavings.showWith.bundleAndSave&&eD(o5(e)))&&i.savings.totalSavings.show}sW.displayName="RegularPrice";var sG=({egpData:e,layoutConfig:t,parameters:i,profile:n})=>{let r=iE(),o=iB(),s=tw(),l={egpData:e,layoutConfig:t,liveConfig:s,parameters:i,selectedContract:r,showStandardPricing:o};if(!sF(l))return null;let d="ALL_IN_SAVINGS"===n,c=function(e,t){let{layoutConfig:i,parameters:n}=e,{showSavingsAsPercentage:r}=n,{totalSavings:a,totalSavingsPercent:o}=sk(e);if(r)return em(o)?`${String(o)}% off`:"";if(im(e))return function(e){let{layoutConfig:t,egpData:i,parameters:n,selectedContract:r}=e,a=e6(sk(e).totalSavings,{decimalStrategy:t.savings.totalSavings.decimalStrategy,zeroStrategy:"throwError"}),o=eQ(i,n);if(ig(e))return`Save ${a}`;let{instantSavings:s,totalSavingsPerTerm:l}=ic(o,r);if(!em(s)&&!em(l))return`Save ${a}`;let d=e6(l||s,{decimalStrategy:t.savings.totalSavings.decimalStrategy,zeroStrategy:"throwError"});return t.savings.totalSavings.allowMonthlyPrice?`Save ${a} (${d}/mo.)`:`Save ${a}`}(e);let s=e6(a,{decimalStrategy:i.savings.totalSavings.decimalStrategy,zeroStrategy:"throwError"});return"ALL_IN_SAVINGS"===t?`Saving ${s} today`:`Save ${s}`}(l,n),u=(({liveConfig:e,parameters:t,layoutConfig:i,profile:n})=>{let{savingsTextColor:r,showSavingsBackground:o=!0,showSavingsAsPercentage:s,showSavingsAsRectangularBadge:l}=t,d=e["highlightedSavings.greenSavingsBadge.enabled"],c="ALL_IN_SAVINGS"===n,u=d&&!c,p=i.savings.totalSavings.showBackground,m="lg"===i.size,f=d&&m,g=(({hasProfileSavingsBackground:e,isGreenSavingsBadgeEnabled:t,showSavingsBackground:i})=>t||i&&e)({showSavingsBackground:o,hasProfileSavingsBackground:p,isGreenSavingsBadgeEnabled:u}),y=(({hasSavingsBackground:e,isGreenSavingsBadgeEnabled:t,savingsTextColor:i})=>t&&e?a.d.color.foregroundSuccess:i||(e?a.d.color.white:a.d.color.promoRed))({isGreenSavingsBadgeEnabled:u,hasSavingsBackground:g,savingsTextColor:c?a.d.color.foregroundSuccess:r}),P=c||f,h=P?a.d.size.font[3]:a.d.size.font[2],I=P?a.d.size.lineHeight[3]:a.d.size.lineHeight[2],_=(({hasProfileSavingsBackground:e,isGreenSavingsBadgeEnabled:t,showSavingsAsPercentage:i,showSavingsAsRectangularBadge:n})=>n??(t&&!e)?{borderRadius:a.d.size.radius.md}:{borderTopLeftRadius:a.d.size.radius.lg,borderTopRightRadius:i?a.d.size.radius.lg:0,borderBottomLeftRadius:i?a.d.size.radius.lg:0,borderBottomRightRadius:a.d.size.radius.lg})({hasProfileSavingsBackground:p,isGreenSavingsBadgeEnabled:u,showSavingsAsPercentage:s,showSavingsAsRectangularBadge:l,hasSavingsBackground:g});return C.A.create({allInSavingsContainer:{display:"flex",alignItems:"flex-start",flexDirection:"column"},container:(({hasSavingsBackground:e,isGreenSavingsBadgeEnabled:t,hasProfileSavingsBackground:i,borderRadius:n})=>{if(!e)return{};let r=t&&!i,o=r?2:4,s=r?2:8;return{alignSelf:"flex-start",backgroundColor:t?a.d.color.success:a.d.color.promoRed,...n,paddingTop:o,paddingBottom:o,paddingLeft:s,paddingRight:s}})({hasSavingsBackground:g,isGreenSavingsBadgeEnabled:u,hasProfileSavingsBackground:p,borderRadius:_}),subtotalLabel:{color:a.d.color.foregroundDefault,fontSize:a.d.size.font[3],lineHeight:a.d.size.lineHeight[3],fontWeight:"500",marginBottom:2},text:{color:y,fontSize:h,lineHeight:I,fontWeight:"500"}})})({liveConfig:s,layoutConfig:t,parameters:i,profile:n});return(0,g.jsx)(b.S,{"data-testid":a.a.PRICE_BLOCK_TOTAL_SAVINGS,style:[u.container,d&&u.allInSavingsContainer],children:(0,g.jsx)(I.E,{className:"whitespace-nowrap","data-testid":a.a.PRICE_BLOCK_TOTAL_SAVINGS_TEXT,style:u.text,children:c})})};sG.displayName="TotalSavings";var sj=({egpData:e,isPriceAndSavingsWrapped:t,layoutConfig:i,liveConfig:n,parameters:r,profile:o})=>{let s=iE(),d=iB(),c=(0,l.useMemo)(()=>t||"xsm"===i.size?0:8,[i.size,t]);if(!i.savings.show)return null;let u=C.A.create({container:{columnGap:4,display:"flex",paddingBottom:c,paddingTop:c,flexDirection:!function(e){let{layoutConfig:t}=e;if(t.savings.wrapped||im(e))return!0;let i=sk(e),n=i.regularPrice??0;return(i.totalSavings??0)>t.savings.wrappedThreshold||n>t.savings.wrappedThreshold}({egpData:e,layoutConfig:i,parameters:r,selectedContract:s,showStandardPricing:d})?"row":"column"}});return(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_SAVINGS,style:u.container,children:[(0,g.jsx)(sG,{egpData:e,layoutConfig:i,liveConfig:n,parameters:r,profile:o}),(0,g.jsx)(sW,{egpData:e,layoutConfig:i,liveConfig:n,parameters:r,profile:o})]})};function sU(e){if(im(e)){let{egpData:t,parameters:i,selectedContract:n}=e;return!!ic(eQ(t,i),n).hasPriceRange}return!1}function sH({egpData:e,layoutConfig:t,liveConfig:i,parameters:n,selectedContract:r,showStandardPricing:a}){return n.priceVariant===th&&!o4({badgingType:o5({egpData:e,layoutConfig:t,parameters:n,selectedContract:r,showStandardPricing:a}),layoutConfig:t,liveConfig:i,parameters:n})}sj.displayName="Savings";var sz=e=>{let{data:t,show:i}=function({egpData:e,layoutConfig:t,parameters:i}){let n=iE(),r=iB(),a=ix(),o=tw();if(iv({selectedContract:n,tradeInAppraisal:a}))return{data:{message:"Estimated trade-in value applied:"},show:!0};let s=function(e){let{layoutConfig:t,parameters:i}=e;return!(!t.price.topMessage.show||i.priceVariant===tI)&&(sU(e)||sH(e))}({egpData:e,layoutConfig:t,liveConfig:o,parameters:i,selectedContract:n,showStandardPricing:r});return s?{data:{message:function(e){if(sU(e)||sH(e))return"Starting at";throw Error("Insufficient data to derive 'topPriceMessage'")}({egpData:e,layoutConfig:t,liveConfig:o,parameters:i,selectedContract:n,showStandardPricing:r})},show:s}:{data:null,show:s}}(e);if(!i)return null;let n=C.A.create({text:{fontSize:a.d.size.font[1],lineHeight:a.d.size.lineHeight[1]}});return(0,g.jsx)(b.S,{"data-testid":a.a.PRICE_BLOCK_TOP_PRICE_MESSAGE,children:(0,g.jsx)(I.E,{"data-testid":a.a.PRICE_BLOCK_TOP_PRICE_MESSAGE_TEXT,style:n.text,children:t.message})})};sz.displayName="TopPriceMessage";var sV=()=>{let e=C.A.create({line:{height:22,width:1,backgroundColor:a.d.color.defaultSubdued,opacity:.24},text:{fontSize:12,padding:4,color:a.d.color.defaultSubdued},container:{display:"flex",justifyContent:"center",alignItems:"center",flexDirection:"column",marginRight:10}});return(0,g.jsxs)(b.S,{"data-testid":a.a.VERTICAL_RULE_CONTAINER,style:e.container,children:[(0,g.jsx)(b.S,{"data-testid":a.a.VERTICAL_RULE_LINE,style:e.line}),(0,g.jsx)(I.E,{"data-testid":a.a.VERTICAL_RULE_TEXT,style:e.text,children:"or"}),(0,g.jsx)(b.S,{"data-testid":a.a.VERTICAL_RULE_LINE,style:e.line})]})},sK=e=>{let{data:t,__brand:i}=od(e),{profile:n,parameters:r,egpData:o}=e,s=eQ(o,r)??null,l=e1(s),d=e0(s);return t?"LARGE"===n?(0,g.jsxs)(b.S,{className:"flex flex-row items-center","data-testid":a.a.PRICE_BLOCK_FINANCE_OPTIONS,children:[(0,g.jsx)(sV,{}),"BuyNowPayLater"===i&&(0,g.jsx)(ol,{...e}),"FinanceOptionPayment"===i&&(0,g.jsx)(e9,{_name:"FinanceOptionPayment",displayLocation:r.displayLocation,financeOption:t.financeOption,platform:r.platform,profile:n,regularPrice:l,skuId:t.skuId??"",unitPrice:d,userType:t.userType})]}):"MEDIUM"===n&&"FinanceOptionPayment"===i?(0,g.jsx)(i8,{name:"plp.suggestedMonthlyPayment.enabled",children:(0,g.jsx)(b.S,{className:"flex flex-row items-center pt-50","data-testid":a.a.PRICE_BLOCK_FINANCE_OPTIONS,children:(0,g.jsx)(e9,{_name:"FinanceOptionPayment",displayLocation:r.displayLocation,financeOption:t.financeOption,platform:r.platform,profile:n,regularPrice:l,skuId:t.skuId??"",unitPrice:d,userType:t.userType})})}):void 0:null};sK.displayName="FinanceOptions",a.d.size.lineHeight[7],a.d.size.lineHeight[6],a.d.size.lineHeight[4],a.d.size.lineHeight[3];var sY=e=>{let{profile:t}=e,{egpData:i,parameters:n,layoutConfig:r,liveConfig:o}=function(e){let{parameters:t,profile:i,profileOverrides:n}=e,r=tw(),a=sx(),o=eN(t?.customer),s=eN(o)??a,l={...t,skus:t?.skus,customer:s,isUserLoggedIn:t?.isUserLoggedIn??!1,platform:t?.platform??"lv",isSkuIdInDealAlert:t?.isSkuIdInDealAlert??!1,skuId:t?.skuId};return{egpData:function({data:e,parameters:t}){if(eu(e))throw TypeError("`data` must not be null or undefined");if(es(e))return e;if(eo(e)){if(en(e.bundlePrice)||e.skus?.some(e=>ea(e)&&e.skuId===t?.skuId))return e;throw Error("Couldn't find BundleSkuLine object with skuId matching `parameters.skuId`")}throw Error("`data` must satisfy an one of: Egp.Product, Egp.BundlePricing")}(e),layoutConfig:tK(i,n),liveConfig:et(r)?(0,tT.default)(tg,r):tg,parameters:l}}(e),d=iq({feature:tP.PRICE_BLOCK_CONTENT,profile:t});(0,l.useEffect)(()=>{d()},[d]);let c=iE(),u=iB(),{show:p}=oO({egpData:i,layoutConfig:r,parameters:n}),m=sF({egpData:i,layoutConfig:r,liveConfig:o,parameters:n,selectedContract:c,showStandardPricing:u}),{data:f}=od({allowedProfile:"LARGE",egpData:i,layoutConfig:r,parameters:n,profile:t,liveConfig:o}),y=(0,l.useMemo)(()=>r.priceSavingsWrapper.wrapped||V(f),[r.priceSavingsWrapper.wrapped,f]),P=(0,l.useMemo)(()=>{var e;let i;return e=n.displayLocation,i=o?.["layout.horizontalDisplayLocations"]??[],"MINI"===t&&i.includes(e??"")},[n.displayLocation,t,o]),h=(0,l.useMemo)(()=>P?"row":y?"column":"row",[P,y]),I=(0,s.U)(),_=!o["pdp.dealAlertStandalone.enabled"],T=(0,l.useCallback)((e,t)=>{I.warn("[DealAlertErrorBoundary] Uncaught error",e,t.componentStack,{parameters:n,egpData:i})},[i,n,I]),S=((e=!1,t=!1)=>{if(e&&t)throw Error("Both 'isTextCenterAligned' and 'isTextRightAligned' cannot be true at the same time.");return e?"center":t?"flex-end":"flex-start"})(n.isTextCenterAligned,n.isTextRightAligned),O=(0,l.useMemo)(()=>(({contentAlignment:e,hasBottomPriceMessage:t,hasSavings:i,isHorizontalLayout:n,isPriceAndSavingsWrapped:r,isTextCenterAligned:a,isTextRightAligned:o,priceAndSavingsFlexDirection:s,size:l})=>C.A.create({contentContainer:{justifyContent:"space-between"},flexRow:{display:"flex",flexDirection:a?"column":"row",alignItems:"center",gap:4*!!r,zIndex:1},flexColumn:{display:"flex",flexDirection:"column",flexGrow:+!!o,alignItems:e,gap:4},priceContainer:{display:"flex",flexDirection:"row",alignItems:i||t?"center":"flex-start",gap:4,zIndex:1},priceAndSavings:{alignItems:r?e:"center",columnGap:n?4:16,display:"flex",flexDirection:s,rowGap:4*("lg"===l)},price:{display:"flex",flexDirection:"column",alignItems:e}}))({contentAlignment:S,hasBottomPriceMessage:p,hasSavings:m,isHorizontalLayout:P,isPriceAndSavingsWrapped:y,isTextCenterAligned:n.isTextCenterAligned,isTextRightAligned:n.isTextRightAligned,priceAndSavingsFlexDirection:h,size:r.size}),[S,p,m,P,y,n.isTextCenterAligned,n.isTextRightAligned,h,r.size]);return(0,g.jsxs)(oL,{egpData:i,layoutConfig:r,liveConfig:o,parameters:n,profile:t,children:[(0,g.jsxs)(b.S,{className:"lg"===r.size?"flex gap-100":"","data-testid":`${t}_profile`,style:O.contentContainer,children:[(0,g.jsxs)(b.S,{children:[(0,g.jsx)(sE,{egpData:i,layoutConfig:r,liveConfig:o,parameters:n}),(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_CONTENT,style:O.flexRow,children:[(0,g.jsxs)(b.S,{"data-testid":a.a.PRICE_BLOCK_COLUMN,style:O.flexColumn,children:[!!r.price.topMessage.show&&(0,g.jsx)(sz,{egpData:i,layoutConfig:r,liveConfig:o,parameters:n}),(0,g.jsxs)(b.S,{style:O.priceContainer,children:[(({egpData:e,layoutConfig:t,liveConfig:i,parameters:n,shouldShowLegacyDealAlert:r})=>t.dealAlert?.show&&r?(0,g.jsx)(o1,{egpData:e,layoutConfig:t,liveConfig:i,parameters:n}):null)({egpData:i,layoutConfig:r,liveConfig:o,parameters:n,shouldShowLegacyDealAlert:_}),(0,g.jsxs)(b.S,{style:O.price,children:[(0,g.jsxs)(b.S,{style:O.priceAndSavings,children:[!!r.price.show&&(0,g.jsx)(oV,{egpData:i,layoutConfig:r,liveConfig:o,parameters:n,profile:t}),!!r.savings.show&&(0,g.jsx)(sj,{egpData:i,isPriceAndSavingsWrapped:y,layoutConfig:r,liveConfig:o,parameters:n,profile:t})]}),!!r.price.bottomMessage.show&&(0,g.jsx)(ox,{egpData:i,layoutConfig:r,liveConfig:o,parameters:n})]})]})]}),"LARGE"===t&&(0,g.jsx)(sK,{allowedProfile:"LARGE",egpData:i,layoutConfig:r,liveConfig:o,parameters:n,profile:t})]}),(0,g.jsx)(sp,{egpData:i,layoutConfig:r,liveConfig:o,parameters:n})]}),(0,g.jsx)(b.S,{className:"flex items-center",children:(0,g.jsx)(R.tH,{fallback:(0,g.jsx)(b.S,{}),onError:T,children:(({egpData:e,parameters:t,profile:i,shouldShowLegacyDealAlert:n})=>n?(0,g.jsx)(i8,{name:"dealAlert.enabled",children:(0,g.jsx)(oQ,{data:e,parameters:t,profile:i})}):null)({egpData:i,parameters:n,profile:t,shouldShowLegacyDealAlert:_})})})]}),"MEDIUM"===t&&(0,g.jsx)(sK,{allowedProfile:"MEDIUM",egpData:i,layoutConfig:r,liveConfig:o,parameters:n,profile:t})]})};sY.displayName="PriceBlockContent";var sq=e=>{let{data:t,parameters:i,profile:n}=e,r=tw(),a=iq({feature:tP.CUSTOMER_PRICE,profile:n}),{onPriceReady:o}=oy();(0,l.useEffect)(()=>{o?.()},[o]);let{data:s}=function({parameters:e,data:t,profile:i}){let n=tw(),{agentLocId:r,cartTimestamp:a,customerId:o,customerToken:s,employeeToken:l,locStoreId:d,selectionOverrideSpread:u,triggeredTimestamp:p,visitorId:m}=i3(e.skuId,{basketTimestampOverride:e.basketTimestampOverride,userTokenOverride:e.userTokenOverride}),f=eN(e.customer),g={...e,customer:f,...u},y=es(t)||eo(t),P=function(e,t,i=!1){return e&&(i||!t)}(y,p,e.parentManagedRefetch),h=function({agentLocId:e,cartTimestamp:t,customerToken:i,customerId:n,employeeToken:r,liveConfig:a,locStoreId:o,parameters:s,visitorId:l,profile:d}){return i9("profileBasedFragments",s.displayLocation,a)?function({agentLocId:e,cartTimestamp:t,customerToken:i,customerId:n,employeeToken:r,liveConfig:a,locStoreId:o,parameters:s,visitorId:l,profile:d}){return Array.isArray(s.skus)?a2({customer:s.customer,displayLocation:s.displayLocation,includeFulfillment:s.includeFulfillment,isCombo:s.isCombo,liveConfig:a,platform:s.platform,skus:s.skus}):ef(s.skuId)?a2({agentLocId:e,cartTimestamp:t,customerId:n,customerToken:i,customer:s.customer,displayLocation:s.displayLocation,employeeToken:r,liveConfig:a,locStoreId:o,openBoxCondition:s.openBoxCondition??void 0,selectedCabo:s.selectedCabo,selectedSuco:s.selectedSuco,skuId:s.skuId,platform:s.platform,profile:tV(d)?d:"LARGE",visitorId:l}):a6}({agentLocId:e,cartTimestamp:t,customerToken:i,customerId:n,employeeToken:r,liveConfig:a,locStoreId:o,parameters:s,visitorId:l,profile:d}):Array.isArray(s.skus)?function({parameters:e,customerId:t,visitorId:i,liveConfig:n}){if(!Array.isArray(e.skus))throw TypeError("SKU ids required for bundle pricing");if(0===e.skus.length)throw Error("SKU ids required for bundle pricing");let{fragment:r,name:a}=eJ(eH,{parameters:e,liveConfig:n}),{fragment:o,name:s}=eJ(ez,{parameters:e,liveConfig:n}),l=(0,c.J1)`
    query BundlePriceQuery(
      $skus: [BundleSkuInput],
      $salesChannel: String!,
      $effectivePlanPaidMemberType: String,
      $context: String!,
      $catalog: String!,
      $usePriceWithCart: Boolean,
      $isCombo: Boolean,
      $includeFulfillment: Boolean,
      $visitorId: String,
      $customerId: String
    ) {
      bundlePricing(
        bundlePriceInput: {
          skus: $skus,
          salesChannel: $salesChannel,
          effectivePlanPaidMemberType: $effectivePlanPaidMemberType,
          context: $context,
          catalog: $catalog,
          usePriceWithCart: $usePriceWithCart,
          isCombo: $isCombo,
          includeFulfillment: $includeFulfillment,
          visitorId: $visitorId,
          customerId: $customerId
        }
      )  {
        ...${a}
        ...${s}
      }
    }
    ${r}
    ${o}
  `,d=eq(eN(e.customer)),u=eZ(e.platform),p=e.skus.map((e,t)=>({id:e.id??t.toString(),skuId:e.skuId,postalCode:e.postalCode,selectedFulfillmentType:e.selectedFulfillmentType,selectedFulfillmentLOSId:e.selectedFulfillmentLOSId,parentItemRelationship:e.parentItemRelationship,parentItemId:e.parentItemId,subBundleLineIds:e.subBundleLineIds}));return{document:l,variables:{catalog:"bby",context:e.displayLocation?.trim()||"PriceView",effectivePlanPaidMemberType:d,salesChannel:u,skus:p,usePriceWithCart:!0,isCombo:e.isCombo,includeFulfillment:e.includeFulfillment,visitorId:i,customerId:t}}}({parameters:s,visitorId:l,customerId:n,liveConfig:a}):ef(s.skuId)?function({agentLocId:e,cartTimestamp:t,customerToken:i,customerId:n,employeeToken:r,liveConfig:a,locStoreId:o,parameters:s,visitorId:l}){if(!ef(s.skuId))throw Error("skuId is required for product pricing");let{fragment:d,name:u}=eJ(eV,{agentLocId:e,cartTimestamp:t,customerToken:i,customerId:n,employeeToken:r,liveConfig:a,locStoreId:o,parameters:s,visitorId:l});return{document:(0,c.J1)`
    query getProduct($skuId: String!, $openBoxCondition: Int) {
      productBySkuId(skuId: $skuId, openBoxCondition: $openBoxCondition) {
        ...${u}
      }
    }
    ${d}
  `,variables:{openBoxCondition:s.openBoxCondition,skuId:s.skuId}}}({agentLocId:e,cartTimestamp:t,customerToken:i,customerId:n,employeeToken:r,liveConfig:a,locStoreId:o,parameters:s,visitorId:l}):a6}({agentLocId:r,cartTimestamp:a,customerToken:s,customerId:o,employeeToken:l,liveConfig:n,locStoreId:d,parameters:g,visitorId:m,profile:i}),I=iX(h,e.isCachedResponse??!1),{data:C,error:_}=(0,E.U)(I.document,P?x.h:{variables:I.variables,errorPolicy:"all",context:{priceBlockDisplayLocation:e.displayLocation?.trim()??"unknown"}}),b=function(e){if(!eu(e)){if(es(e.productBySkuId))return e.productBySkuId;if(eo(e.bundlePricing))return e.bundlePricing}}(C);if(y||b)return{data:b??t};let T=_?`${_.name}: ${_.message}`:"Unknown error";throw Error(`[usePriceBlockQuery] ${T}, query.variables:${JSON.stringify(h.variables)}, Parameters: ${JSON.stringify(e)}`)}({data:t,parameters:i,profile:n});return(0,g.jsx)(og,{onCustomerPriceShown:a,children:(0,g.jsx)(sY,{...e,data:s,liveConfig:r})})};sq.displayName="PriceBlockLoader";var sX=({children:e,hasData:t,prefix:i,profile:n})=>{let r=iq({feature:t?tP.PRICE_READY:tP.DATA_PRICE_READY,prefix:i,profile:n});return(0,g.jsx)(og,{onPriceReady:r,children:e})},sZ={lg:a.d.size.lineHeight[7],md:a.d.size.lineHeight[6],sm:a.d.size.lineHeight[4],xsm:a.d.size.lineHeight[3]},sJ=e=>{let{parameters:t,data:i,profile:n,profileOverrides:r,visitingComponents:o,liveConfig:d}=e,c=(0,s.U)(),u=(0,l.useCallback)((e,i)=>{c.withFields({componentStack:i.componentStack,displayLocation:t.displayLocation,skuId:t.skuId}).error("[ErrorBoundary] Uncaught error",e)},[c,t.displayLocation,t.skuId]),p=eN(t.customer),f=[t.skuId,t.skus,p?.memberId,t.displayLocation,t.openBoxCondition,n,i],y=t.skus?.map(e=>`${e.id??""}:${e.skuId}`).join("|"),{handleContentLayout:P,wrapperStyle:h,fallbackClampStyle:_,onShimmerVisibilityChange:T}=iZ({heightKey:t.lineId??t.skuId??(y&&y.length>0?y:void 0),openBoxCondition:t.openBoxCondition??void 0}),S=tK(n,r),O=(0,l.useMemo)(()=>C.A.create({errorText:{fontSize:13,fontWeight:"500",lineHeight:sZ[S.size]}}),[S.size]),v=(0,l.useCallback)(()=>(0,g.jsx)(b.S,{className:"brix",children:(0,g.jsx)(I.E,{"data-testid":a.a.PRICE_BLOCK_ERROR,style:O.errorText,children:"See price in cart"})}),[O.errorText]);return(0,g.jsx)(oP,{liveConfig:d,children:(0,g.jsx)(sX,{hasData:!!i,profile:n,children:(0,g.jsx)(m.default,{style:h,children:(0,g.jsx)(b.S,{className:"brix","data-testid":a.a.PRICE_BLOCK,"data-version":"1.2638.9",children:(0,g.jsx)(R.tH,{fallbackRender:v,onError:u,resetKeys:f,children:(0,g.jsx)(e8,{AddToCartButton:o?.AddToCartButton,EmbeddedComponentFacade:o?.EmbeddedComponentFacade,FinanceOptionPayment:o?.FinanceOptionPayment,ModalView:o?.ModalView,PortalWrapper:o?.PortalWrapper,SpendAndGetMembershipBanner:o?.SpendAndGetMembershipBanner,ZipLearnMoreLink:o?.ZipLearnMoreLink,ZipLogo:o?.ZipLogo,ZipModal:o?.ZipModal,children:(0,g.jsx)(l.Suspense,{fallback:(0,g.jsx)(m.default,{style:_,children:(0,g.jsx)(o_,{isLoading:!0,onVisibleChange:T,profile:n,children:(0,g.jsx)(b.S,{})})}),children:(0,g.jsx)(m.default,{onLayout:P,children:(0,g.jsx)(sq,{...e})})})})})})})})})};sJ.displayName="PriceBlock";var sQ=e=>{let t,i,n,{profile:r,liveConfig:o,data:s,profileOverrides:d,visitingComponents:c}=e,u=(t=sx(),i=eN(e.customer)??t,n=tE(),(0,l.useMemo)(()=>({customer:i,displayLocation:e.displayLocation,isCombo:e.isCombo,lowestAvailableOpenBoxCondition:e.lowestAvailableOpenBoxCondition,openBoxCondition:e.openBoxCondition,suppressBadging:e.suppressBadging,platform:n,priceVariant:e.priceVariant,skuId:e.skuId,skus:e.skus,isTextCenterAligned:e.isTextCenterAligned,isTextRightAligned:e.isTextRightAligned,includeFulfillment:e.includeFulfillment,lineId:e.lineId,showSavingsAsRectangularBadge:e.showSavingsAsRectangularBadge}),[i,n,e.displayLocation,e.isCombo,e.lowestAvailableOpenBoxCondition,e.openBoxCondition,e.suppressBadging,e.priceVariant,e.skuId,e.skus,e.isTextCenterAligned,e.isTextRightAligned,e.includeFulfillment,e.lineId,e.showSavingsAsRectangularBadge])),p=`${r}_profile`;return(0,g.jsx)(m.default,{"data-testid":p,children:(0,g.jsx)(sJ,{data:s,"data-testid":a.a.PRICE_BLOCK_CONTENT,liveConfig:o,parameters:u,profile:r,profileOverrides:d,visitingComponents:c})})},s0=({children:e,locationId:t,isLegacyVersion:i=!1})=>{let n=tw();(0,K.A)(t_(n),"There was an issue loading <PriceBlockSoftLauncher/>. No configuration was found.");let r=(({configuration:e,locationId:t,vt:i})=>!!e["migration.validated.placements"].includes(t)||(i?!!e["migration.unvalidated.placements"].includes(t)&&!!e["migration.unvalidated.visitorTokens"].includes(i):(d.Ay.warn(`Unable to determine visibility of the @bestbuy/price-block.
Visitor token is type ${null===i?"null":typeof i}. Expected a string.`),!1)))({configuration:n,locationId:t,vt:tx()});return r&&!i||i&&!r?e:null},s1=({children:e,displayLocation:t,experiments:i,feature:n,recipe:r})=>aF({displayLocation:t,experiments:i,feature:n,liveConfig:tw(),recipe:r})?e:null}}]);
//# sourceMappingURL=84f9ef10-17c3a4e6cdfc400e.js.map