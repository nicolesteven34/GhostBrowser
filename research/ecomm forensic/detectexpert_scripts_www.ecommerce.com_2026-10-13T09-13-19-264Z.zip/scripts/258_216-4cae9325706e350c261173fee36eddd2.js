/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.ecommerce.com/~assets/bby/_com/shop/save-for-later/dist/client/216-4cae9325706e350c261173fee36eddd2.js
 * Detected Engine: Unknown
 * Vectors Invoked: 
 */

(self.webpackChunkgvpc_shop_save_for_later_v1_25_34_144=self.webpackChunkgvpc_shop_save_for_later_v1_25_34_144||[]).push([[216],{459:(e,r,t)=>{"use strict";var n=t(15704);function o(){}function a(){}a.resetWarningCache=o,e.exports=function(){function e(e,r,t,o,a,p){if(p!==n){var s=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw s.name="Invariant Violation",s}}function r(){return e}e.isRequired=e;var t={array:e,bigint:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:r,element:e,elementType:e,instanceOf:r,node:e,objectOf:r,oneOf:r,oneOfType:r,shape:r,exact:r,checkPropTypes:a,resetWarningCache:o};return t.PropTypes=t,t}},60216:(e,r,t)=>{e.exports=t(459)()},15704:e=>{"use strict";e.exports="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"}}]);
//# sourceMappingURL=216-4cae9325706e350c261173fee36eddd2.js.map