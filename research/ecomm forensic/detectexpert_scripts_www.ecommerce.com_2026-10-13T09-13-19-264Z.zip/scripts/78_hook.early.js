/**
 * DetectExpert Pro Extracted Script
 * Target: chrome-extension://obbkkjmpgaajcggbhajpdeeadkkchbeo/hook.early.js
 * Detected Engine: Unknown
 * Vectors Invoked: webgl.getParameter, audio.offlineAudioContext, audio.analyser, canvas.toDataURL, canvas.measureText, webgl.getSupportedExtensions, webgl.getShaderPrecisionFormat, webrtc.createOffer
 */

// Script URL: chrome-extension://obbkkjmpgaajcggbhajpdeeadkkchbeo/hook.early.js
// Detected Anti-Fraud Engine: Unknown
// Calls observed: 157
