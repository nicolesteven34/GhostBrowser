/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.ecommerce.com/~assets/bby/_com/shop/save-for-later/dist/client/91-4cae9325706e350c261173fee36eddd2.js
 * Detected Engine: Unknown
 * Vectors Invoked: 
 */

"use strict";(self.webpackChunkgvpc_shop_save_for_later_v1_25_34_144=self.webpackChunkgvpc_shop_save_for_later_v1_25_34_144||[]).push([[91,487],{62091:(_,e,s)=>{s.r(e),s.d(e,{queryClient:()=>r});var r=new(s(68439).QueryClient)({defaultOptions:{}})}}]);
//# sourceMappingURL=91-4cae9325706e350c261173fee36eddd2.js.map