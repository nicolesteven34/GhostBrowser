/**
 * DetectExpert Pro Extracted Script
 * Target: at Navigator.r [as sendBeacon] (https://nexus.ensighten.com/bestbuy/privacy_prod_cm_copy/Bootstrap.js
 * Detected Engine: Unknown
 * Vectors Invoked: network.sendBeacon
 */

// Script URL: at Navigator.r [as sendBeacon] (https://nexus.ensighten.com/bestbuy/privacy_prod_cm_copy/Bootstrap.js
// Detected Anti-Fraud Engine: Unknown
// Calls observed: 5
