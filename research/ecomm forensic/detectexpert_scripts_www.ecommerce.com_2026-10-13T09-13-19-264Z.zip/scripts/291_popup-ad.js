/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.ecommerce.com/~assets/bby/_com/popup-ad.js
 * Detected Engine: Unknown
 * Vectors Invoked: 
 */

/* eslint-disable */
var e=document.createElement('div');
e.id='cYBiNwCbFGqU';
e.style.display='none';
document.body.appendChild(e);