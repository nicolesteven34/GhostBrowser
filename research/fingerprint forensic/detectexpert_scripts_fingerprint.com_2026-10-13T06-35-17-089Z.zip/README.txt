# DetectExpert Pro - Extracted Script Package
Target Domain: fingerprint.com
Exported: 2026-10-13T06:35:17.104Z

This archive contains all external and inline JavaScript scripts that invoked browser fingerprinting APIs during the observation session.

Check manifest.json for mapping of scripts to identified anti-fraud vendors and vector call counts.
