/**
 * DetectExpert Pro Extracted Script
 * Target: chrome-extension://obbkkjmpgaajcggbhajpdeeadkkchbeo/hook.early.js
 * Detected Engine: Unknown
 * Vectors Invoked: webrtc.createOffer, audio.offlineAudioContext, canvas.toDataURL, webgl.readPixels, canvas.getImageData, webgl.getParameter, webgl.getSupportedExtensions, webgl.getShaderPrecisionFormat
 */

// Script URL: chrome-extension://obbkkjmpgaajcggbhajpdeeadkkchbeo/hook.early.js
// Detected Anti-Fraud Engine: Unknown
// Calls observed: 40
