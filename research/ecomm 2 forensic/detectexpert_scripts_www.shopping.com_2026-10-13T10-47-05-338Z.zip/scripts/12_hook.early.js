/**
 * DetectExpert Pro Extracted Script
 * Target: chrome-extension://obbkkjmpgaajcggbhajpdeeadkkchbeo/hook.early.js
 * Detected Engine: Unknown
 * Vectors Invoked: canvas.toDataURL, canvas.getImageData, webgl.getParameter, webgl.getSupportedExtensions
 */

// Script URL: chrome-extension://obbkkjmpgaajcggbhajpdeeadkkchbeo/hook.early.js
// Detected Anti-Fraud Engine: Unknown
// Calls observed: 13
