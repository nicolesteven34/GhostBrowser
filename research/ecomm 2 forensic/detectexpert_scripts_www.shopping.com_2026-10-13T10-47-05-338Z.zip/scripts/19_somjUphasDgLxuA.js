/**
 * DetectExpert Pro Extracted Script
 * Target: at new e (https://m.media-shopping.com/images/S/sash/somjUphasDgLxuA.js?name=vendors
 * Detected Engine: Unknown
 * Vectors Invoked: device.battery
 */

// Script URL: at new e (https://m.media-shopping.com/images/S/sash/somjUphasDgLxuA.js?name=vendors
// Detected Anti-Fraud Engine: Unknown
// Calls observed: 1
