/**
 * DetectExpert Pro Extracted Script
 * Target: https://www.shopping.com/stores/Razer/page/CDB96030-A7CF-4B56-B70C-67086A740274?lp_asin=B0FDPJZQNY&ref_=ast_bln&store_ref=bl_ast_dp_brandlogo_sto
 * Detected Engine: Unknown
 * Vectors Invoked: device.hardwareConcurrency, device.deviceMemory, bot.webdriver, bot.automationArtifacts, network.sendBeacon, device.speechSynthesis
 */

<!doctype html><html lang="en-us" class="a-no-js" data-19ax5a9jf="dingo"><!-- sp:feature:head-start -->
<head><script>var aPageStart = (new Date()).getTime();</script><meta charset="utf-8"/>
<!-- sp:end-feature:head-start -->
<!-- sp:feature:csm:head-open-part1 -->

<script type='text/javascript'>var ue_t0=ue_t0||+new Date();</script>
<!-- sp:end-feature:csm:head-open-part1 -->
<!-- sp:feature:cs-optimization -->
<meta http-equiv='x-dns-prefetch-control' content='on'>
<link rel="preconnect" href="https://images-na.ssl-images-shopping.com" crossorigin>
<link rel="preconnect" href="https://m.media-shopping.com" crossorigin>
<!-- sp:end-feature:cs-optimization -->
<!-- sp:feature:csm:head-open-part2 -->
<script type='text/javascript'>
window.ue_ihb = (window.ue_ihb || window.ueinit || 0) + 1;
if (window.ue_ihb === 1) {

var ue_csm = window,
    ue_hob = +new Date();
(function(d){var e=d.ue=d.ue||{},f=Date.now||function(){return+new Date};e.d=function(b){return f()-(b?0:d.ue_t0)};e.stub=function(b,a){if(!b[a]){var c=[];b[a]=function(){c.push([c.slice.call(arguments),e.d(),d.ue_id])};b[a].replay=function(b){for(var a;a=c.shift();)b(a[0],a[1],a[2])};b[a].isStub=1}};e.exec=function(b,a){return function(){try{return b.apply(this,arguments)}catch(c){ueLogError(c,{attribution:a||"undefined",logLevel:"WARN"})}}}})(ue_csm);


    var ue_err_chan = 'jserr-rw';
(function(d,e){function h(f,b){if(!(a.ec>a.mxe)&&f){a.ter.push(f);b=b||{};var c=f.logLevel||b.logLevel;c&&c!==k&&c!==m&&c!==n&&c!==p||a.ec++;c&&c!=k||a.ecf++;b.pageURL=""+(e.location?e.location.href:"");b.logLevel=c;b.attribution=f.attribution||b.attribution;a.erl.push({ex:f,info:b})}}function l(a,b,c,e,g){d.ueLogError({m:a,f:b,l:c,c:""+e,err:g,fromOnError:1,args:arguments},g?{attribution:g.attribution,logLevel:g.logLevel}:void 0);return!1}var k="FATAL",m="ERROR",n="WARN",p="DOWNGRADED",a={ec:0,ecf:0,
pec:0,ts:0,erl:[],ter:[],buffer:[],mxe:50,startTimer:function(){a.ts++;setInterval(function(){d.ue&&a.pec<a.ec&&d.uex("at");a.pec=a.ec},1E4)}};l.skipTrace=1;h.skipTrace=1;h.isStub=1;d.ueLogError=h;d.ue_err=a;e.onerror=l})(ue_csm,window);


var ue_id = 'KAS98C370K01G4FPVKFV',
    ue_url = '/rd/uedata',
    ue_navtiming = 1,
    ue_mid = 'ATVPDKIKX0DER',
    ue_sid = '147-0099296-5118245',
    ue_sn = 'www.shopping.com',
    ue_furl = 'fls-na.shopping.com',
    ue_surl = 'https://unagi.shopping.com/1/events/com.amazon.csm.nexusclient.prod',
    ue_int = 0,
    ue_fcsn = 1,
    ue_urt = 3,
    ue_rpl_ns = 'cel-rpl',
    ue_ddq = 1,
    ue_fpf = '//fls-na.shopping.com/1/batch/1/OP/ATVPDKIKX0DER:147-0099296-5118245:KAS98C370K01G4FPVKFV$uedata=s:',
    ue_sbuimp = 1,
    ue_ibft = 0,
    ue_lpsi = 6000,
    ue_lob = '1',
    ue_act = '-1',
    ue_dsbl_cel = 1,

    ue_swi = 1;
var ue_viz=function(){(function(b,f,d){function g(){return(!(p in d)||0<d[p])&&(!(q in d)||0<d[q])}function h(c){if(b.ue.viz.length<w&&!r){var a=c.type;c=c.originalEvent;/^focus./.test(a)&&c&&(c.toElement||c.fromElement||c.relatedTarget)||(a=g()?f[s]||("blur"==a||"focusout"==a?t:u):t,b.ue.viz.push(a+":"+(+new Date-b.ue.t0)),a==u&&(b.ue.isl&&x("at"),r=1))}}for(var r=0,x=b.uex,a,k,l,s,v=["","webkit","o","ms","moz"],e=0,m=1,u="visible",t="hidden",p="innerWidth",q="innerHeight",w=20,n=0;n<v.length&&!e;n++)if(a=
v[n],k=(a?a+"H":"h")+"idden",e="boolean"==typeof f[k])l=a+"visibilitychange",s=(a?a+"V":"v")+"isibilityState";h({});e&&f.addEventListener(l,h,0);m=g()?1:0;d.addEventListener("resize",function(){var a=g()?1:0;m!==a&&(m=a,h({}))},{passive:!0});b.ue&&e&&(b.ue.pageViz={event:l,propHid:k})})(ue_csm,ue_csm.document,ue_csm.window)};window.ue_viz=ue_viz;

(function(d,h,R){function I(a){return a&&a.replace&&a.replace(/^\s+|\s+$/g,"")}function v(a){return"undefined"===typeof a}function M(a){return"function"===typeof a}function G(a,b){for(var c in b)b[w](c)&&(a[c]=b[c])}function N(a){try{var b=R.cookie.match(RegExp("(^| )"+a+"=([^;]+)"));if(b)return b[2].trim()}catch(c){}}function S(m,b,c){var t=(E||{}).type;if("device"!==c||2!==t&&1!==t){if(m){d.ue_id=a.id=a.rid=m;if("device"===c||"pre-fetch"===c)a.oid=I(m);p&&(p=p.replace(/((.*?:){2})(\w+)/,function(a,
b){return b+m}));J&&(e("id",J,m),J=0)}b&&(p&&(p=p.replace(/(.*?:)(\w|-)+/,function(a,c){return c+b})),d.ue_sid=b);c&&a.tag("page-source:"+c);d.ue_fpf=p}}function T(){var a={};return function(b){b&&(a[b]=1);b=[];for(var c in a)a[w](c)&&b.push(c);return b}}function F(d,b,c,t){t=t||+new K;var g,h;if(b||v(c)){if(d)for(h in g=b?e("t",b)||e("t",b,{}):a.t,g[d]=t,c)c[w](h)&&e(h,b,c[h]);return t}}function e(d,b,c){var e=b&&b!=a.id?a.sc[b]:a;e||(e=a.sc[b]={});"id"===d&&c&&(U=1);return e[d]=c||e[d]}function V(d,
b,c,e,g){c="on"+c;var h=b[c];M(h)?d&&(a.h[d]=h):h=function(){};b[c]=function(a){g?(e(a),h(a)):(h(a),e(a))};b[c]&&(b[c].isUeh=1)}function W(m,b,c,t){function r(b,c,d){b=[b];var f=0,g={},t,k;u.latency={};c?(b.push("m=1"),g[c]=1):g=a.sc;for(k in g)if(g[w](k)){var l=e("wb",k),r=e("t",k)||{},q=e("t0",k)||a.t0,x,n;if(c||2==l){x=l?f++:"";b.push("sc"+x+"="+k);var s=A,p=A;2==l&&h.csa?(p=(s=h.csa("Content",{element:{type:"scope",slotId:k,csmRequestId:""+d}}))&&M(s))&&+q&&s("mark","t0",+q):s=p=A;for(n in r)v(r[n])||
null===r[n]||(b.push(n+x+"="+(r[n]-q)),p&&s("mark",X[n]||n,+r[n]));b.push("t"+x+"="+r[m]);u.latency["t"+x]=r[m];if(e("ctb",k)||e("wb",k))t=1}}!D&&t&&b.push("ctb=1");return b.join("&")}function x(b,c,f,e,m){if(b&&!e){e=d.ue_err;if(p){var g=h.encodeURIComponent;g&&b&&(m=new Image,b=""+d.ue_fpf+g(b)+":"+(+new K-d.ue_t0),a.iel.push(m),m.src=b)}else a.log&&(a.log(b,"uedata",{n:1}),a.ielf.push(b));e&&!e.ts&&e.startTimer();a.b&&(b=a.b,a.b="",x(b,c,f,1))}}function n(b){var c=E?E.type:A,d=2==c||a.isBFonMshop,
c=c&&!d,f=a.bfini;if(!U||a.isBFCache)f&&1<f&&(b+="&bfform=1",c||(a.isBFT=f-1)),d&&(b+="&bfnt=1",a.isBFT=a.isBFT||1),a.ssw&&a.isBFT&&(a.isBFonMshop&&(a.isNRBF=0),v(a.isNRBF)&&(d=a.ssw(a.oid),d.e||v(d.val)||(a.isNRBF=1<d.val?0:1)),v(a.isNRBF)||(b+="&nrbf="+a.isNRBF)),a.isBFT&&!a.isNRBF&&(b+="&bft="+a.isBFT);return b}if(!a.paused&&(b||v(c))){for(var k in c)c[w](k)&&e(k,b,c[k]);a.isBFonMshop||F("pc",b,c);k="ld"===m&&b&&e("wb",b);var B=!k,q=e("id",b)||a.id;k||q===a.oid||(J=b,ga(q,(e("t",b)||{}).tc||+e("t0",
b),+e("t0",b),e("pty",b),e("spty",b)));var C=e("id",b)||a.id,s=e("id2",b)||d.ue_id2,f=a.url+"?"+m+"&v="+a.v+"&id="+C,D=e("ctb",b)||e("wb",b),u={eventName:m,version:a.v,id:C,sessionId:d.ue_sid||"",obfuscatedMarketplaceId:d.ue_mid||""},y;D&&(f+="&ctb="+D);s&&(f+="&id2="+s);1<d.ueinit&&(f+="&ic="+d.ueinit);if(!("ld"!=m&&"ul"!=m||b&&b!=C)){if("ld"==m){try{h[O]&&h[O].isUeh&&(h[O]=null)}catch(N){}if(h.chrome)for(s=0;s<P.length;s++)Y(L,P[s]);(s=R.ue_backdetect)&&s.ue_back&&s.ue_back.value++;d._uess&&(y=
d._uess());a.isl=1}B&&a._bf&&(f+="&bf="+a._bf());d.ue_navtiming&&g&&(e("ctb",C,"1"),a.isBFonMshop||F("tc",A,A,Q));B&&H&&!a.isBFonMshop&&!Z&&(g&&G(a.t,{na_:g.navigationStart,ul_:g.unloadEventStart,_ul:g.unloadEventEnd,rd_:g.redirectStart,_rd:g.redirectEnd,fe_:g.fetchStart,lk_:g.domainLookupStart,_lk:g.domainLookupEnd,co_:g.connectStart,_co:g.connectEnd,sc_:g.secureConnectionStart,rq_:g.requestStart,rs_:g.responseStart,_rs:g.responseEnd,dl_:g.domLoading,di_:g.domInteractive,de_:g.domContentLoadedEventStart,
_de:g.domContentLoadedEventEnd,_dc:g.domComplete,ld_:g.loadEventStart,_ld:g.loadEventEnd,ntd:(M(H.now)&&!v(Q)?new K(Q+H.now())-new K:0)+a.t0}),E&&G(a.t,{ty:E.type+a.t0,rc:E.redirectCount+a.t0}),Z=1);a.isBFonMshop||G(a.t,{hob:d.ue_hob,hoe:d.ue_hoe});a.ifr&&(f+="&ifr=1",u.ifr=!0)}F(m,b,c,t);var z,l;k||b&&b!==C||ha(b);c=d.ue_mbl;B&&c&&c.cnt&&!k&&(f+=c.cnt());k?e("wb",b,2):"ld"==m&&(a.lid=I(C));for(z in a.sc)if(1==e("wb",z))break;if(k){if(a.s)return;f=r(f,null,q)}else c=r(f,null,q),c!=f&&(c=n(c),a.b=
c),y&&(f+=y),f=r(f,b||a.id,q);f=n(f);if(a.b||k)for(z in a.sc)2==e("wb",z)&&delete a.sc[z];z=0;B&&a._rt&&(f+="&rt="+a._rt());y=h.csa;if(!k&&y)for(l in q=e("t",b)||{},c=y("PageTiming"),q)q[w](l)&&c("mark",X[l]||l,q[l]);k||(a.s=0,(l=d.ue_err)&&0<l.ec&&l.pec<l.ec&&(l.pec=l.ec,f+="&ec="+l.ec+"&ecf="+l.ecf),z=e("ctb",b),"ld"!==m||b||a.markers?a.markers&&a.isl&&!k&&b&&G(a.markers,e("t",b)):(a.markers={},G(a.markers,e("t",b))),e("t",b,{}));B&&a.tag&&a.tag().length&&(f+="&csmtags="+a.tag().join("|"),u.csmtags=
a.tag(),a.tag=T());l=a.viz||[];q=l.length;B&&q&&(l=l.splice(0,q),f+="&viz="+l.join("|"),u.viz=l);v(d.ue_pty)||(f+="&pty="+d.ue_pty+"&spty="+d.ue_spty+"&pti="+d.ue_pti,u.pty=d.ue_pty,u.spty=d.ue_spty,u.pti=d.ue_pti);a.tabid&&(f+="&tid="+a.tabid);a.aftb&&(f+="&aftb=1");!B||!a._ui||b&&b!=C||(f+=a._ui());f+="&lob="+(d.ue_lob||"0");a.a=f;x(f,m,z,k,b&&"string"===typeof b&&-1!==b.indexOf("csa:"));k||(u.lob=d.ue_lob||"0",u.browserData=f,(b=y&&y("UEData"))&&b("log",u))}}function ha(a){var b=h.ue_csm_markers||
{},c;for(c in b)b[w](c)&&F(c,a,A,b[c])}function D(a,b,c){c=c||h;if(c[$])c[$](a,b,!1);else if(c[aa])c[aa]("on"+a,b)}function Y(a,b,c){c=c||h;if(c[ba])c[ba](a,b,!1);else if(c[ca])c[ca]("on"+a,b)}function da(){function a(){d.onUl()}function b(a){return function(){c[a]||(c[a]=1,W(a))}}var c={},e,g;d.onLd=b("ld");d.onLdEnd=b("ld");d.onUl=b("ul");e={stop:b("os")};h.chrome?(D(L,a),P.push(a)):e[L]=d.onUl;for(g in e)e[w](g)&&V(0,h,g,e[g]);d.ue_viz&&ue_viz();D("load",d.onLd);F("ue")}function ga(e,b,c,g,r){var p=
d.ue_mbl,n=h.csa,k=n&&n("SPA"),n=n&&n("PageTiming");p&&p.ajax&&p.ajax(b,c);k&&n&&(e={requestId:e,transitionType:"soft"},"string"===typeof g&&(e.pageType=g,d.ue_pty=g),"string"===typeof r&&(e.subPageType=r,d.ue_spty=r),k("newPage",e),n("mark","transitionStart",b));a.tag("ajax-transition")}d.ueinit=(d.ueinit||0)+1;var a=d.ue=d.ue||{};a.t0=h.aPageStart||d.ue_t0;a.id=d.ue_id;a.url=d.ue_url;a.rid=d.ue_id;a.a="";a.b="";a.h={};a.s=1;a.t={};a.sc={};a.iel=[];a.ielf=[];a.viz=[];a.v="0.364606.0";a.paused=!1;
var w="hasOwnProperty",L="beforeunload",O="on"+L,$="addEventListener",ba="removeEventListener",aa="attachEvent",ca="detachEvent",X={cf:"criticalFeature",af:"aboveTheFold",fn:"functional",fp:"firstPaint",fcp:"firstContentfulPaint",bb:"bodyBegin",be:"bodyEnd",ld:"loaded"},K=h.Date,H=h.performance||h.webkitPerformance,g=(H||{}).timing,E=(H||{}).navigation,Q=(g||{}).navigationStart,p=d.ue_fpf,U=0,Z=0,P=[],J=0,A;a.oid=I(a.id);a.lid=I(a.id);a._t0=a.t0;a.tag=T();a.ifr=h.top!==h.self||h.frameElement?1:0;
a.markers=null;a.attach=D;a.detach=Y;if("000-0000000-8675309"===d.ue_sid){var ea=N("cdn-rid"),fa=N("session-id");ea&&fa&&S(ea,fa,"cdn")}d.uei=da;d.ueh=V;d.ues=e;d.uet=F;d.uex=W;a.reset=S;a.pause=function(d){a.paused=d};da()})(ue_csm,ue_csm.window,ue_csm.document);


ue.stub(ue,"event");ue.stub(ue,"onSushiUnload");ue.stub(ue,"onSushiFlush");

ue.stub(ue,"log");ue.stub(ue,"onunload");ue.stub(ue,"onflush");
(function(b){var a=b.ue;a.cv={};a.cv.scopes={};a.cv.buffer=[];a.count=function(b,d,c){var e=a.cv;a.d();c&&c.scope&&(e=a.cv.scopes[c.scope]=a.cv.scopes[c.scope]||{});if(void 0===d)return e[b];e[b]=d;a.cv.buffer.push({c:b,v:d})};a.count("baselineCounter2",1);a&&a.event&&(a.event({requestId:b.ue_id||"rid",server:b.ue_sn||"sn",obfuscatedMarketplaceId:b.ue_mid||"mid"},"csm","csm.CSMBaselineEvent.4"),a.count("nexusBaselineCounter",1,{bf:1}))})(ue_csm);


(function(g,h,l){if("function"===typeof h.addEventListener&&"function"===typeof l.querySelectorAll){var e,r=["mouseenter","mouseleave"],t="click dblclick mousedown mouseover mouseout touchstart keydown keypress MSPointerDown pointerdown focusin".split(" ").concat(r),n=!1,p=[];var u=function(a){for(var b=[];a;)b.push(a),a=a.parentNode;return b};var q=function(a,b){var d=-1,c;for(c=0;c<b.length;c++)if(b[c]===a){d=c;break}return d};var v=function(a,b){a=q(a,b);0<=a&&b.splice(a,1)};var x=function(a){a=
u(a);for(var b,d,c=0;c<a.length;c++)if(d=a[c],(b=d.nodeName)&&b!==l.nodeName){b=b.toLowerCase();if(d.id)return b+"#"+d.id+(f?">"+f:"");(d=d.getAttribute("class"))&&(b=b+"."+d.split(" ").join("."));var f=b+(f?">"+f:"")}return f};var y=function(a){return a.replace(/[^\w.:\-]/g,function(a){return"#"===a?"::":">"===a?":-":"_"})};var w=function(a,b){if(g.ue&&g.ue.count&&g.ueLogError){a=x(a);var d=y(a);var c="degraded"===b?"A UX degrading element has entered the viewport: "+a:"A "+b+" was not handled on element: "+
a;g.ueLogError({m:c,fromOnError:1},{logLevel:"ERROR",attribution:a,message:c});b=["TNR","TNR:"+b,"TNR:"+d,"TNR:"+b+":"+d];for(e=0;e<b.length;e++)g.ue.count(b[e],(g.ue.count(b[e])||0)+1)}};var z=function(a){a=a.getBoundingClientRect();return a.top<a.bottom&&a.left<a.right&&0<=a.bottom&&a.top<=h.innerHeight&&0<=a.right&&a.left<=h.innerWidth};var m=function(){n||(n=!0,setTimeout(function(){[].forEach.call(l.querySelectorAll("[data-ux-degraded]"),function(a){z(a)?0>q(a,p)&&(p.push(a),w(a,"degraded")):
v(a,p)});n=!1},250))};h.addEventListener("scroll",m);h.addEventListener("resize",m);m=function(a){var b=!1,d=0>q(a,r);l.addEventListener(a,function(c){if(!b){b=!0;var f=[],e=d?u(c.target):[c.target],g,h;for(g=0;g<e.length;g++){var k=e[g];k.getAttribute&&("mouseover"===a&&k===c.target&&((h=k.getAttribute("data-ux-jq-mouseenter"))||""===h)&&f.push(k),((h=k.getAttribute("data-ux-"+a))||""===h)&&f.push(k))}f.length?(c.ack=c.acknowledge=function(a){a=a||c.currentTarget;v(a,f)},setTimeout(function(){var c;
for(c=0;c<f.length;c++)w(f[c],a);b=!1},250)):b=!1}},!0)};for(e=0;e<t.length;e++)m(t[e])}})(ue_csm,window,document);


var ue_hoe = +new Date();
}
window.ueinit = window.ue_ihb;
</script>

<!-- 2grn2v4kejt8zf8pfw5oxxouieaitkj -->
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 12602)</script>
<!-- sp:end-feature:csm:head-open-part2 -->
<!-- sp:feature:aui-assets -->
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/214aTrUk8lL._RC|51nfWTBkewL.css_.css?AUIClients/AmazonUI" />
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/11WsGYSItxL._RC|01DE6WSvLKL.css,516AF8YtSfL.css,31VyBF3Z4EL.css,01dpRn7s1DL.css,21JMC7OC91L.css,01nO+AnUDyL.css,01oplyhwgTL.css,413Vvv3GONL.css,1170nDgl0uL.css,01Rw4F+QU6L.css,11GW2DCngTL.css,01dwEpLmO4L.css,01IdKcBuAdL.css,01iHqjS7YfL.css,21D3IemrALL.css,11Cv7swYm2L.css,51kR4v4RCcL.css,01yC8kk5kkL.css,11hdEXw-6rL.css,01GAxF7K5tL.css,01ZM-s8Z3xL.css,21gEzBqpmtL.css,11FeoxrgiyL.css,21Yuul0BcnL.css,01rSTIgNJIL.css,21HqyYwP3xL.css,31u+uM+C07L.css,019TAYpKRCL.css,01Lgkx7LWKL.css,31g3RABPKHL.css,11PDZ29p-PL.css,117zDsOznQL.css,215WpAjwzoL.css,11INh4d+2FL.css,114aTS6SjML.css,01Uw64cHNCL.css,21GcfcmbahL.css,21OD8FuBraL.css,11XozyxiH7L.css,210W8HxtP4L.css,11GyUpf9PlL.css,119Cktja74L.css,11PMguLK6gL.css,01890+Vwk8L.css,11TZSntL0oL.css,01qiwJ7qDfL.css,21jZ2Hny6UL.css,01ONg56w3qL.css,0136+UFOtpL.css,31un+UKeIeL.css,21MLYj6O8gL.css,013-xYw+SRL.css_.css?AUIClients/AmazonUI#us.not-trident" />
<script>
(function(b,a,c,d){if((b=b.AmazonUIPageJS||b.P)&&b.when&&b.register){c=[];for(a=a.currentScript;a;a=a.parentElement)a.id&&c.push(a.id);return b.log("A copy of P has already been loaded on this page.","FATAL",c.join(" "))}})(window,document,Date);(function(a,b,c,d){"use strict";a._pSetI=function(){return null}})(window,document,Date);(function(c,e,I,B){"use strict";c._pd=function(){var a,u;return function(C,f,h,k,b,D,v,E,F){function w(d){try{return d()}catch(J){return!1}}function l(){if(m){var d={w:c.innerWidth||b.clientWidth,h:c.innerHeight||b.clientHeight};5<Math.abs(d.w-q.w)||50<d.h-q.h?(q=d,n=4,(d=a.mobile||a.tablet?450<d.w&&d.w>d.h:1250<=d.w)?k(b,"a-ws"):b.className=v(b,"a-ws")):0<n&&(n--,x=setTimeout(l,16))}}function G(d){(m=d===B?!m:!!d)&&l()}function H(){return m}if(!u){u=!0;var r=function(){var d=["O","ms","Moz","Webkit"],
c=e.createElement("div");return{testGradients:function(){return!0},test:function(a){var b=a.charAt(0).toUpperCase()+a.substr(1);a=(d.join(b+" ")+b+" "+a).split(" ");for(b=a.length;b--;)if(""===c.style[a[b]])return!0;return!1},testTransform3d:function(){return!0}}}(),y=b.className,z=/(^| )a-mobile( |$)/.test(y),A=/(^| )a-tablet( |$)/.test(y);a={audio:function(){return!!e.createElement("audio").canPlayType},video:function(){return!!e.createElement("video").canPlayType},canvas:function(){return!!e.createElement("canvas").getContext},
svg:function(){return!!e.createElementNS&&!!e.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},dragDrop:function(){return"draggable"in e.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!c.history||!c.history.pushState)},webworker:function(){return!!c.Worker},autofocus:function(){return"autofocus"in e.createElement("input")},
inputPlaceholder:function(){return"placeholder"in e.createElement("input")},textareaPlaceholder:function(){return"placeholder"in e.createElement("textarea")},localStorage:function(){return"localStorage"in c&&null!==c.localStorage},orientation:function(){return"orientation"in c},touch:function(){return"ontouchend"in e},gradients:function(){return r.testGradients()},hires:function(){var a=c.devicePixelRatio&&1.5<=c.devicePixelRatio||c.matchMedia&&c.matchMedia("(min-resolution:144dpi)").matches;E("hiRes"+
(z?"Mobile":A?"Tablet":"Desktop"),a?1:0);return a},transform3d:function(){return r.testTransform3d()},touchScrolling:function(){return f(/Windowshop|android|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|SOFTWARE=([5-9]|[1-9][0-9]+)(.[0-9]{1,2})+.*DEVICE=iPhone|Chrome|Silk|Firefox|Trident.+?; Touch/i)},ios:function(){return f(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!f(/trident|Edge/i)},android:function(){return f(/android.([1-9]|[L-Z])/i)&&!f(/trident|Edge/i)},mobile:function(){return z},
tablet:function(){return A},rtl:function(){return"rtl"===b.dir}};for(var g in a)a.hasOwnProperty(g)&&(a[g]=w(a[g]));for(var t="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),p=0;p<t.length;p++)a[t[p]]=w(function(){return r.test(t[p])});var m=!0,x=0,q={w:0,h:0},n=4;l();h(c,"resize",function(){clearTimeout(x);n=4;l()});b.className=v(b,"a-no-js");k(b,"a-js");!f(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||c.navigator.standalone||f(/safari/i)||k(b,"a-ember");
h=[];for(g in a)a.hasOwnProperty(g)&&a[g]&&h.push("a-"+g.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));k(b,h.join(" "));b.setAttribute("data-aui-build-date",F);C.register("p-detect",function(){return{capabilities:a,localStorage:a.localStorage&&D,toggleResponsiveGrid:G,responsiveGridEnabled:H}});return a||{}}}}()})(window,document,Date);(function(a,p,q,k){function m(e,b,c,g){a.P.when.apply(a.P,b).register("flow:"+e,function(){var a=g.apply(this,arguments);return c||a})}function l(e){a.P.log(e,"FATAL","AmazonUIPageJS@AUIDefineJS")}function f(a,b,c){Object.defineProperty(a,b,{value:c,writable:!1})}function n(e,b,c){"string"!==typeof e&&a.P.error("Anonymous modules are not supported.");var g=c!==k?c:"function"===typeof b?b:k;g||a.P.error("A callback must be provided");var f,h=[];if(c&&Array.isArray(b)&&(h=b.reduce(function(b,d){if("module"===
d||"require"===d)a.P.error('"module" or "require" injection is not supported.');else if("exports"===d){d=f={};var c="flow:"+e+"-exports";a.P.declare(c,d);b.push(c)}else 0!==d.lastIndexOf("@amzn/",0)?l("Dependency "+d+" does not begin with '@amzn/'"):b.push("flow:"+d);return b},[]),b.length!==h.length))return;m(e,h,f,g)}"use strict";Object.prototype.hasOwnProperty.call(a,"aui")?l("AUIDefineJS is already present globally"):(f(a,"aui",{}),f(a.aui,"amd_define",n))})(window,document,Date);(function(g,h,C,D){function K(a){l&&l.tag&&l.tag(p(":","aui",a))}function q(a,b){l&&l.count&&l.count("aui:"+a,0===b?0:b||(l.count("aui:"+a)||0)+1)}function L(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function x(a,b,c){a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}function p(a,b,c,f){b=b&&c?b+a+c:b||c;return f?p(a,b,f):b}function y(a,b,c){try{Object.defineProperty(a,b,{value:c,writable:!1})}catch(f){a[b]=c}return c}function M(a,b){a.className=
N(a,b)+" "+b}function N(a,b){return(" "+a.className+" ").split(" "+b+" ").join(" ").replace(/^ | $/g,"")}function aa(a,b,c){var f=c=a.length,e=function(){f--||(E.push(b),F||(m?m.set(z):setTimeout(z,0),F=!0))};for(e();c--;)O[a[c]]?e():(u[a[c]]=u[a[c]]||[]).push(e)}function ba(a,b,c,f,e){var d=h.createElement(a?"script":"link");x(d,"error",f);e&&x(d,"load",e);a?(d.type="text/javascript",d.async=!0,c&&/AUIClients|images[/]I/.test(b)&&d.setAttribute("crossorigin","anonymous"),d.src=b):(d.rel="stylesheet",
d.href=b);h.getElementsByTagName("head")[0].appendChild(d)}function P(a,b){return function(c,f){function e(){ba(b,c,d,function(b){G?q("resource_unload"):d?(d=!1,q("resource_retry"),e()):(q("resource_error"),a.log("Asset failed to load: "+c));b&&b.stopPropagation?b.stopPropagation():g.event&&(g.event.cancelBubble=!0)},f)}if(Q[c])return!1;Q[c]=!0;q("resource_count");var d=!0;return!e()}}function ca(a,b,c){for(var f={name:a,guard:function(c){return b.guardFatal(a,c)},guardTime:function(a){return b.guardTime(a)},
logError:function(c,d,e){b.logError(c,d,e,a)}},e=[],d=0;d<c.length;d++)A.hasOwnProperty(c[d])&&(e[d]=H.hasOwnProperty(c[d])?H[c[d]](A[c[d]],f):A[c[d]]);return e}function v(a,b,c,f,e){return function(d,k){function n(){var a=null;f?a=k:"function"===typeof k&&(q.start=r(),a=k.apply(g,ca(d,h,l)),q.end=r());if(b){A[d]=a;a=d;for(O[a]=!0;(u[a]||[]).length;)u[a].shift()();delete u[a]}q.done=!0}var h=e||this;"function"===typeof d&&(k=d,d=D);b&&(d=d?d.replace(R,""):"__NONAME__",I.hasOwnProperty(d)&&h.error(p(", reregistered by ",
p(" by ",d+" already registered",I[d]),h.attribution),d),I[d]=h.attribution);for(var l=[],m=0;m<a.length;m++)l[m]=a[m].replace(R,"");var q=w[d||"anon"+ ++da]={depend:l,registered:r(),namespace:h.namespace};d&&ea.hasOwnProperty(d);c?n():aa(l,h.guardFatal(d,n),d);return{decorate:function(a){H[d]=h.guardFatal(d,a)}}}}function S(a){return function(){var b=Array.prototype.slice.call(arguments);return{execute:v(b,!1,a,!1,this),register:v(b,!0,a,!1,this)}}}function J(a,b){return function(c,f){f||(f=c,c=
D);var e=this.attribution;return function(){n.push(b||{attribution:e,name:c,logLevel:a});var d=f.apply(this,arguments);n.pop();return d}}}function B(a,b){this.load={js:P(this,!0),css:P(this)};y(this,"namespace",b);y(this,"attribution",a)}function T(){h.body?k.trigger("a-bodyBegin"):setTimeout(T,20)}"use strict";var t=C.now=C.now||function(){return+new C},r=function(a){return a&&a.now?a.now.bind(a):t}(g.performance),fa=r(),ea={},l=g.ue;K();K("aui_build_date:3.26.8-2026-10-06");var U={getItem:function(a){try{return g.localStorage.getItem(a)}catch(b){}},
setItem:function(a,b){try{return g.localStorage.setItem(a,b)}catch(c){}}},m=g._pSetI(),E=[],ha=[],F=!1,ia=navigator.scheduling&&"function"===typeof navigator.scheduling.isInputPending;var z=function(){for(var a=m?m.set(z):setTimeout(z,0),b=t();ha.length||E.length;)if(E.shift()(),m&&ia){if(150<t()-b&&!navigator.scheduling.isInputPending()||50<t()-b&&navigator.scheduling.isInputPending())return}else if(50<t()-b)return;m?m.clear(a):clearTimeout(a);F=!1};var O={},u={},Q={},G=!1;x(g,"beforeunload",function(){G=
!0;setTimeout(function(){G=!1},1E4)});var R=/^prv:/,I={},A={},H={},w={},da=0,ja=String.fromCharCode(92),n=[],V=!0,W=g.onerror;g.onerror=function(a,b,c,f,e){e&&"object"===typeof e||(e=Error(a,b,c),e.columnNumber=f,e.stack=b||c||f?p(ja,e.message,"at "+p(":",b,c,f)):D);var d=n.pop()||{};e.attribution=p(":",e.attribution||d.attribution,d.name);e.logLevel=d.logLevel;e.attribution&&console&&console.log&&console.log([e.logLevel||"ERROR",a,"thrown by",e.attribution].join(" "));n=[];W&&(d=[].slice.call(arguments),
d[4]=e,W.apply(g,d))};B.prototype={logError:function(a,b,c,f){b={message:b,logLevel:c||"ERROR",attribution:p(":",this.attribution,f)};if(g.ueLogError)return g.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));return!1},error:function(a,b,c,f){a=Error(p(":",f,a,c));a.attribution=p(":",this.attribution,b);throw a;},guardError:J(),guardFatal:J("FATAL"),guardCurrent:function(a){var b=n[n.length-1];return b?J(b.logLevel,b).call(this,a):a},guardTime:function(a){var b=
n[n.length-1],c=b&&b.name;return c&&c in w?function(){var b=r(),e=a.apply(this,arguments);w[c].async=(w[c].async||0)+r()-b;return e}:a},log:function(a,b,c){return this.logError(null,a,b,c)},declare:v([],!0,!0,!0),register:v([],!0),execute:v([]),AUI_BUILD_DATE:"3.26.8-2026-10-06",when:S(),now:S(!0),trigger:function(a,b,c){var f=t();this.declare(a,{data:b,pageElapsedTime:f-(g.aPageStart||NaN),triggerTime:f});c&&c.instrument&&X.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},
attributeErrors:function(a){return new B(a)},_namespace:function(a,b){return new B(a,b)},setPriority:function(a){V?V=!1:this.log("setPriority only accept the first call.")}};var k=y(g,"AmazonUIPageJS",new B);var X=k._namespace("PageJS","AmazonUI");X.declare("prv:p-debug",w);k.declare("p-recorder-events",[]);k.declare("p-recorder-stop",function(){});y(g,"P",k);T();if(h.addEventListener){var Y;h.addEventListener("DOMContentLoaded",Y=function(){k.trigger("a-domready");h.removeEventListener("DOMContentLoaded",
Y,!1)},!1)}var Z=h.documentElement,ka=g._pd(k,L,x,M,Z,U,N,q,"3.26.8-2026-10-06");L(/UCBrowser/i)||ka.localStorage&&M(Z,U.getItem("a-font-class"));k.declare("a-event-revised-handling",!1);k.declare("a-fix-event-off",!1);q("pagejs:pkgExecTime",r()-fa)})(window,document,Date);
(function(d,G,I,J){function r(h){k&&k.tag&&k.tag(g(":","aui",h))}function e(h,d){k&&k.count&&k.count("aui:"+h,0===d?0:d||(k.count("aui:"+h)||0)+1)}function t(d){try{return d.test(navigator.userAgent)}catch(y){return!1}}function l(d){return"function"===typeof d}function w(d,g,e){d.addEventListener?d.addEventListener(g,e,!1):d.attachEvent&&d.attachEvent("on"+g,e)}function g(d,e,l,k){e=e&&l?e+d+l:e||l;return k?g(d,e,k):e}"use strict";var k=d.ue,A=String.fromCharCode(92),B=["webpack://@import/chromium-server/"];
P.execute("RetailPageServiceWorker",function(){function h(a,b){m.controller&&a?(a={feature:"retail_service_worker_messaging",command:a},b&&(a.data=b),m.controller.postMessage(a)):a&&e("sw:sw_message_no_ctrl",1)}function y(a){var b=a.data;if(b&&"retail_service_worker_messaging"===b.feature&&b.command&&b.data){var c=b.data;a=d.ue;var f=d.ueLogError;switch(b.command){case "log_counter":a&&l(a.count)&&c.name&&a.count(c.name,0===c.value?0:c.value||1);break;case "log_tag":a&&l(a.tag)&&c.tag&&(a.tag(c.tag),
b=d.uex,a.isl&&l(b)&&b("at"));break;case "log_error":f&&l(f)&&c.message&&f({message:c.message,logLevel:c.level||"ERROR",attribution:c.attribution||"RetailServiceWorker"});break;case "log_weblab_trigger":if(!c.weblab||!c.treatment)break;a&&l(a.trigger)?a.trigger(c.weblab,c.treatment):(e("sw:wt:miss"),e("sw:wt:miss:"+c.weblab+":"+c.treatment));break;default:e("sw:unsupported_message_command",1)}}}function v(a,b){return"sw:"+(b||"")+":"+a+":"}function z(a,b){try{m.register("/service-worker.js").then(function(){e(a+
"success")}).catch(function(c){C(c,a,b)})}catch(c){C(c,a,b)}}function C(a,b,c){var f;a:{if(a&&"object"===typeof a&&"string"===typeof a.stack)for(f=0;f<B.length;f++)if(-1!==a.stack.indexOf(B[f])){f=!0;break a}f=!1}f?e(b+"error:suppressed"):(P.logError(a,"[AUI SW] Failed to "+c+" service worker: ","ERROR","RetailPageServiceWorker"),e(b+"failure"))}function D(){n.forEach(function(a){r(a)})}function q(a){return a.capabilities.isAmazonApp&&a.capabilities.android}function E(a,b,c){if(b)if(b.mshop&&q(a))a=
v(c,"mshop_and"),b=b.mshop.action,n.push(a+"supported"),b(a,c);else if(b.browser){a=t(/Chrome/i)&&!t(/Edge/i)&&!t(/OPR/i)&&!a.capabilities.isAmazonApp&&!t(new RegExp(A+"bwv"+A+"b"));var f=b.browser;b=v(c,"browser");a?(a=f.action,n.push(b+"supported"),a(b,c)):n.push(b+"unsupported")}}function F(a,b,c){a&&n.push(v("register",c)+"unsupported");b&&n.push(v("unregister",c)+"unsupported");D()}try{var m=navigator.serviceWorker}catch(a){r("sw:nav_err")}(function(){if(m){var a=function(){h("page_loaded",{rid:d.ue_id,
mid:d.ue_mid,pty:d.ue_pty,sid:d.ue_sid,spty:d.ue_spty,furl:d.ue_furl})};w(m,"message",y);h("client_messaging_ready");P.when("load").execute(a);w(m,"controllerchange",function(){h("client_messaging_ready");"complete"===G.readyState&&a()})}})();var n=[],p=function(a,b){var c=d.uex,f=d.uet;a=g(":","aui","sw",a);"ld"===b&&l(c)?c("ld",a,{wb:1}):l(f)&&f(b,a,{wb:1})},H=function(a,b,c){function f(a){b&&l(b.failure)&&b.failure(a)}function k(){n=setTimeout(function(){r(g(":","sw:"+h,u.TIMED_OUT));f({ok:!1,
statusCode:u.TIMED_OUT,done:!1});p(h,"ld")},c||4E3)}var u={NO_CONTROLLER:"no_ctrl",TIMED_OUT:"timed_out",UNSUPPORTED_BROWSER:"unsupported_browser",UNEXPECTED_RESPONSE:"unexpected_response"},h=g(":",a.feature,a.command),n,q=!0;if("MessageChannel"in d&&m&&"controller"in m)if(m.controller){var t=new MessageChannel;t.port1.onmessage=function(c){(c=c.data)&&c.feature===a.feature&&c.command===a.command?(q&&(p(h,"cf"),q=!1),p(h,"af"),clearTimeout(n),c.done||k(),c.ok?b&&l(b.success)&&b.success(c):f(c),c.done&&
p(h,"ld")):e(g(":","sw:"+h,u.UNEXPECTED_RESPONSE),1)};k();p(h,"bb");m.controller.postMessage(a,[t.port2])}else r(g(":","sw:"+a.feature,u.NO_CONTROLLER)),f({ok:!1,statusCode:u.NO_CONTROLLER,done:!0});else r(g(":","sw:"+a.feature,u.UNSUPPORTED_BROWSER)),f({ok:!1,statusCode:u.UNSUPPORTED_BROWSER,done:!0})};(function(){m?(p("ctrl_changed","bb"),m.addEventListener("controllerchange",function(){r("sw:ctrl_changed");p("ctrl_changed","ld")})):e(g(":","sw:ctrl_changed","sw_unsupp"),1)})();(function(){var a=
function(){p(b,"ld");var a=d.uex;H({feature:"page_proxy",command:"request_feature_tags"},{success:function(b){b=b.data;Array.isArray(b)&&b.forEach(function(a){"string"===typeof a?r(g(":","sw:ppft",a)):e(g(":","sw:ppft","invalid_tag"),1)});e(g(":","sw:ppft","success"),1);k&&k.isl&&l(a)&&a("at")},failure:function(a){e(g(":","sw:ppft","error:"+(a.statusCode||"ppft_error")),1)}})};if("requestIdleCallback"in d){var b=g(":","ppft","callback_ricb");d.requestIdleCallback(a,{timeout:1E3})}else b=g(":","ppft",
"callback_timeout"),setTimeout(a,0);p(b,"bb")})();var x={reg:{},unreg:{}};x.reg.mshop={action:z};x.reg.browser={action:z};(function(a){var b=a.reg,c=a.unreg;m&&m.getRegistrations?(P.when("A").execute(function(b){if((a.reg.mshop||a.unreg.mshop)&&"function"===typeof q&&q(b)){var f=a.reg.mshop?"T1":"C",g=d.ue;g&&g.trigger?g.trigger("MSHOP_SW_CLIENT_446196",f):e("sw:mshop:wt:failed")}E(b,c,"unregister")}),w(d,"load",function(){P.when("A").execute(function(a){E(a,b,"register");D()})})):(F(b&&b.browser,
c&&c.browser,"browser"),P.when("A").execute(function(a){"function"===typeof q&&q(a)&&F(b&&b.mshop,c&&c.mshop,"mshop_and")}))})(x)})})(window,document,Date);
'use strict';(function(b){function t(a,e,d){function h(a,b,c){var f=Array(e.length);~m&&(f[m]={});~n&&(f[n]=c);for(c=0;c<q.length;c++){var h=q[c],g=a[c];f[h]=g}for(c=0;c<p.length;c++)h=p[c],g=b[c],f[h]=g;a=d.apply(null,f);return~m?f[m]:a}"string"!==typeof a&&b.P.error("C001");var c=-1<a.indexOf("/")&&(-1<a.indexOf("es3")||-1<a.indexOf("evergreen")),r=c&&-1<a.indexOf("@");c&&!r&&(a=a.substring(0,a.lastIndexOf("/")));if(!w[a]){w[a]=!0;d||(d=e,e=[]);a=a.split(":",2);c=a[1]?a[0]:void 0;var g=(a[1]||a[0]).replace(/@capability\//,
"@c/"),x=-1<g.indexOf("/")?g.split("/")[0]:g,l=c?b.P._namespace(c):b.P;a=!g.lastIndexOf("@c/",0);c=!g.lastIndexOf("@m/",0);for(var q=[],u=[],p=[],v=[],n=-1,m=-1,k=0;k<e.length;k++){var f=e[k];"module"===f&&l.error("C002");"exports"===f?m=k:"require"===f?n=k:f.lastIndexOf("@p/",0)?f.lastIndexOf("@c/",0)&&f.lastIndexOf("@m/",0)?f.lastIndexOf("./",0)?(q.push(k),u.push("mix:"+f)):(f=x+"/"+f.substr(2),p.push(k),v.push(f)):(p.push(k),v.push(f)):(q.push(k),u.push(f.substr(3)))}var y=a||c||r||~n||p.length;
l.when.apply(l,u).register("mix:"+g,function(){var a=[].slice.call(arguments);return y?{capabilities:v,cardModuleFactory:function(b,c){b=h(a,b,c);b.P=l;return b},require:~n?t:void 0}:h(a,[],function(){})});y&&l.when("mix:@amzn/mix.client-runtime","mix:"+g).execute(function(a,b){a.registerCapabilityModule(g,b)});l.when("mix:"+g).register("xcp:"+g,function(a){return a});var t=function(a,b,c){try{var e=a[0],d=e.lastIndexOf("./",0)?e:x+"/"+e.substr(2),f=d.lastIndexOf("@p/",0)?"mix:"+d:d.substr(3);l.when(f).execute(function(a){try{b(a)}catch(A){c(A)}})}catch(z){c(z)}}}}
"use strict";var w={};b.mix_d||((b.Promise?P:P.when("3p-promise")).register("@p/promise-is-ready",function(a){b.Promise=b.Promise||a}),(Array.prototype.includes?P:P.when("a-polyfill")).register("@p/polyfill-is-ready",function(){}),b.mix_d=function(a,b,d){P.when("@p/promise-is-ready","@p/polyfill-is-ready").execute("@p/mix-d-deps",function(){t(a,b,d)})},b.xcp_d=b.mix_d,P.when("mix:@amzn/mix.client-runtime").execute(function(a){P.declare("xcp:@xcp/runtime",a)}));b.mixTimeout||(b.mixTimeout=function(a,
e,d){b.mixCardInitTimeouts||(b.mixCardInitTimeouts={});b.mixCardInitTimeouts[e]&&clearTimeout(b.mixCardInitTimeouts[e]);b.mixCardInitTimeouts[e]=setTimeout(function(){P.log("Client-side initialization timeout","WARN",a)},d)});b.mix_csa_map=b.mix_csa_map||{};b.mix_csa_internal=b.mix_csa_internal||function(a,e,d){return b.mix_csa_map[e]=b.mix_csa_map[e]||b.csa(a,d)};b.mix_csa_internal_key=b.mix_csa_internal_key||function(a,b){for(var d="",e=0;e<b.length;e++){var c=b[e];void 0!==a[c]&&"object"!==typeof a[c]&&
(d+=c+":"+a[c]+",")}if(!d)throw Error("bad mix-csa key gen.");return d};b.mix_csa_event=b.mix_csa_event||function(a){try{var e=b.mix_csa_internal_key(a,["producerId"])}catch(d){return P.logError(d,"MIX C005","WARN",void 0),function(){}}try{return b.mix_csa_internal("Events",e,a)}catch(d){return P.logError(d,"MIX C004","WARN",e),function(){}}};b.mix_csa=b.mix_csa||function(a,e){try{e=e||"";var d=document.querySelectorAll(a);if(1<d.length)for(var h=0;h<d.length;h++){if(d[h].querySelector(e)){var c=
d[h];break}}else 1===d.length&&(c=d[0]);if(!c)throw Error(" ");return b.mix_csa_internal("Content",a,{element:c})}catch(r){return P.logError(r,"MIX C004","WARN",a),function(){}}}})(window);
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.js').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/61xJcNKKLXL.js?AUIClients/AmazonUIjQuery');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/11I0WXrZVoL._RC|11Y+5x+kkTL.js,51IrWwn6GEL.js,115zbyk371L.js,11GgN1+C7hL.js,01+z+uIeJ-L.js,01Aie6L4uGL.js,21NadQlXUWL.js,01vRf9id2EL.js,31on-La90vL.js,11a7qqY8xXL.js,11PZSUl3FLL.js,51C4kaFbiAL.js,11FhdH2HZwL.js,11wb9K3sw0L.js,11BrgrMAHUL.js,11dKU9zhD1L.js,21F6z4HaEVL.js,01Svfxfy8OL.js,61lbT4bHNWL.js,01ikBbTAneL.js,31xywoXPfpL.js,01qXJuwGmxL.js,01WlsjNmqIL.js,11F929pmpYL.js,31dUhXzzjYL.js,01rpauTep4L.js,314M2Oak7hL.js,011FfPwYqHL.js,21P5VvHf-XL.js,01pTq+jF06L.js,21kN0q4IA-L.js,0105nvqLd4L.js,11vb6P5C5AL.js,01ZNzO-VJuL.js_.js?AUIClients/AmazonUI');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/516npEhK50L.js?AUIClients/CardJsRuntimeBuzzCopyBuild');
});
</script>
<!-- sp:end-feature:aui-assets -->
<!-- sp:feature:nav-agent-metadata -->
      <style id="agent-styles">
      /* CRITICAL FIX: Opacity > 0 for technical clickability. */
      #nav-search-submit-text-agent, #nav-search-submit-button-agent {
        opacity: 0.001 !important;
        pointer-events: auto !important;
        cursor: default !important;
        background: transparent !important;
        border: none !important;
        outline: none !important;
        z-index: 9999 !important;
      }

      #nav-search-submit-button-agent:hover, #nav-search-submit-button-agent:focus {
        background: transparent !important;
      }

      /* *** FIX 2: Force PERMANENT transparency on the parent containers. *** */
      #nav-search, #nav-search-bar-form {
        background-color: transparent !important;
        background: transparent !important;
        border: none !important;
        box-shadow: none !important;
      }

      /* *** FIX 3: Keep the focus transparency rule (using :has is safer) *** */
      #nav-search:has(#twotabsearchtextbox:focus), #nav-search-bar-form:has(#twotabsearchtextbox:focus) {
        background-color: transparent !important;
        background: transparent !important;
        border: none !important;
        box-shadow: none !important;
      }

      #nav-search:hover, #nav-search.nav-active, #nav-search-bar-form:hover, #nav-search-bar-form:focus-within {
        border-color: transparent !important;
        box-shadow: none !important;
      }
      </style>
      <script id="agent-semantic-map" type="application/agent+json">
      {
        "@context": "https://agent.schema.org",
        "@type": "AgentInterfaceMap",
        "pageType": "product-listing",
        "primaryActions": [
          {
            "id": "search_agent",
            "action": "search",
            "selector": "#nav-search-submit-button-agent",
            "description": "AI-optimized search submission",
            "inputSelector": "#twotabsearchtextbox",
            "priority": "primary",
            "recommended": true,
            "visibility": "visually-hidden"
          }
        ],
        "suggestions": {
          "preferredSearchMode": "agent",
          "agentButton": "#nav-search-submit-button-agent"
        }
      }
      </script>
<!-- sp:end-feature:nav-agent-metadata -->
<!-- sp:feature:nav-inline-css -->
<!-- NAVYAAN CSS -->

<style type="text/css">
.nav-sprite-v1 .nav-sprite, .nav-sprite-v1 .nav-icon {
  background-image: url(https://m.media-shopping.com/images/G/01/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB779528203_.png);
  background-position: 0 1000px;
  background-repeat: repeat-x;
}
.nav-spinner {
  background-image: url(https://m.media-shopping.com/images/G/01/javascripts/lib/popover/images/snake._CB485935611_.gif);
  background-position: center center;
  background-repeat: no-repeat;
}
.nav-timeline-icon, .nav-access-image, .nav-timeline-prime-icon {
  background-image: url(https://m.media-shopping.com/images/G/01/gno/sprites/timeline_sprite_1x._CB485945973_.png);
  background-repeat: no-repeat;
}
</style>
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/51waPb-h-9L._RC|71vEeKvawSL.css,41WcY5PbsbL.css,612evE2JRhL.css,61Y0ThXQrKL.css,41sOnlSfhtL.css,01FcI3FsaiL.css,21y6uRBcF9L.css,01-Mnqi69mL.css,31YZpDCYJPL.css,21DwGGPS1eL.css,41vWFCvFunL.css,21CB9R4dxNL.css,111Bp55OByL.css,01f-B++9uCL.css,21KQnzhmfTL.css,41bqNBi+QSL.css,61f0dQ2ffRL.css,01NLp3ZKNoL.css_.css?AUIClients/NavDesktopUberAsset#desktop.us.1173010-T1.1421755-T1.1381529-T1.1253326-T1.1236111-T1.1346270-T1" />
<!-- sp:end-feature:nav-inline-css -->
<!-- sp:feature:host-assets -->
<script>
      (function(n,i,v,r,s,c,x,z){x=window.AwsRumClient={q:[],n:n,i:i,v:v,r:r,c:c};window[n]=function(c,p){x.q.push({c:c,p:p});};z=document.createElement('script');z.async=true;z.src=s;document.head.insertBefore(z,document.head.getElementsByTagName('script')[0]);})(
        'cwr',
        '2a81ece3-57da-461c-b0a6-0a885b879baf',
        '1.0.0',
        'us-east-1',
        'https://client.rum.us-east-1.amazonaws.com/1.x/cwr.js',
        {
          sessionSampleRate: 1,
          guestRoleArn: "arn:aws:iam::480078786773:role/AmazonStoresContentRendering-Prod-NA-RUM-UnauthenticatedRole",
          identityPoolId: "us-east-1:b57f3f6e-ad88-4ec8-bb75-f1aee448c9a4",
          endpoint: "https://dataplane.rum.us-east-1.amazonaws.com",
          telemetries: [['errors', { ignore: function() {return true;}}]],
          allowCookies: false,
          enableXRay: false
        }
      );
    </script>
<script type="text/javascript">
  var navigationType =
    (window.performance &&
      window.performance.navigation &&
      window.performance.navigation.type) ||
    0;
  var visibilityState = document.visibilityState || "";
  var xhr = new XMLHttpRequest();
  var jsonRequest = {
    requestId: "KAS98C370K01G4FPVKFV",
    sessionId: "147-0099296-5118245",
    marketplaceId: "ATVPDKIKX0DER",
    pageId: "CDB96030-A7CF-4B56-B70C-67086A740274",
    storeId: "CDB96030-A7CF-4B56-B70C-67086A740274",
    isRobot: "false",
    customerId: "",
    token: "aJnGDd0b1RVaTHskivLZ0y3BxBm3kitr9MfwACCEAaokqWL0+74cErs23SwZfpl3oKfeOI1Y1r1toBPDKmDi0Q==",
    navigationType: navigationType,
    visibilityState: visibilityState,
  };

  xhr.open(
    "POST",
    "/stores/page/" +
      "CDB96030-A7CF-4B56-B70C-67086A740274" +
      "?pageViewLogging=1" +
      "&brandStoreId=CDB96030-A7CF-4B56-B70C-67086A740274"
  );
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.send(JSON.stringify(jsonRequest));
</script>
<script type="text/javascript">
    !function(){
        var originalOnError = window.onerror;
        window.onerror = function StoresOnError(message, file, line, col, error) {
            // if error message is 'script error', report as ERROR instead of FATAL.
            if (window.ueLogError && message === 'Script error.') {
                var exception = {
                    m : message,
                    f : file,
                    l : line,
                    c : "" + col,
                    err : error,
                    fromOnError : 1,
                    args : arguments
                };

                var additionalInfo = {
                    logLevel: 'ERROR',
                    attribution: 'AmazonStoresLivePage:UnsupportedScriptError',
                };

                window.ueLogError(exception, additionalInfo);
                return;
            }

            // otherwise, report to parent onError
            if (originalOnError) {
                originalOnError.apply(window, arguments);
            }
        }
    }();
</script>
<title>Shopping.com: Razer</title>
<meta property="og:title" content="Razer">
<meta name="twitter:title" content="Razer">

<link rel="canonical" href="https://www.shopping.com/stores/Razer/page/CDB96030-A7CF-4B56-B70C-67086A740274"/>
<meta property="og:url" content="https://www.shopping.com/stores/Razer/page/CDB96030-A7CF-4B56-B70C-67086A740274">
<meta name="twitter:url" content="https://www.shopping.com/stores/Razer/page/CDB96030-A7CF-4B56-B70C-67086A740274">

<meta name="description" content="Home Page">
<meta property="og:description" content="Home Page">
<meta name="twitter:description" content="Home Page">

<meta property="og:image" content="https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg">
<meta name="twitter:image" content="https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg">

<meta property="og:site_name" content="Shopping.com">
<meta name="twitter:site" content="Shopping.com">

<meta name="twitter:card" content="summary_large_image">

<script type="a-state" data-a-state="{&quot;key&quot;:&quot;visitInfo&quot;}">{"customerId":"","visitId":"8755ff19-67e4-4972-9990-e583cf886542","pageId":"CDB96030-A7CF-4B56-B70C-67086A740274","pageVersion":"0muzvd941"}</script><script type="a-state" data-a-state="{&quot;key&quot;:&quot;nexusLoggingInfo&quot;}">{"revisionId":"0muzvd941","customerId":"","sessionId":"147-0099296-5118245","pageId":"CDB96030-A7CF-4B56-B70C-67086A740274","storeId":"CDB96030-A7CF-4B56-B70C-67086A740274"}</script><!-- sp:csrf --><meta name="anti-csrftoken-a2z" content="hDcdGivz3zuEIYoyKDWqyGz5DlXnsPamdZ1di+KlmjhAAAAAAGrOCyg2NDQyZGE4NS01OTZkLTQzODQtYjE0Yy1kZWNiZDc2MDJkZjM=" id="kindle-reader-api" ><!-- sp:end-csrf -->

<!-- sp:csrf --><meta name="anti-csrftoken-a2z" content="hA3/6mrwaGh64RxvZ18LYCwbxWRedEiYirzaN2OP6Ll6AAAAAGrOCyg2NDQyZGE4NS01OTZkLTQzODQtYjE0Yy1kZWNiZDc2MDJkZjM=" id="brand-store-add-to-cart-api" ><!-- sp:end-csrf -->

<!-- sp:csrf --><meta name="anti-csrftoken-a2z" content="hGpuzSh9Vc07Zg5PszWF/LsQ0VnQi4TzA2osZN0wVyNhAAAAAGrOCyg2NDQyZGE4NS01OTZkLTQzODQtYjE0Yy1kZWNiZDc2MDJkZjM=" id="bgw-csrf" ><!-- sp:end-csrf -->




<script type="a-state" data-a-state="{&quot;key&quot;:&quot;widgetInstrumentationData&quot;}">{"isWidgetInstrumentationEnabled":true}</script><link rel="stylesheet" href="https://m.media-shopping.com/images/I/214zMj2KQRL.css?AUIClients/AmazonStoresCnubaAssets" />
<script>
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/21QTE5zfWuL.js?AUIClients/AmazonStoresCnubaAssets');
</script>




<link rel="stylesheet" href="https://m.media-shopping.com/images/I/01ixfc-7StL.css?AUIClients/BrandFollowKataComponentAssets" />
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/11OgEfILTEL.css?AUIClients/InContextDetailPageAssets#1442063-T1.1463686-T1.1423113-T1" />
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/51WJcF0axXL.css?AUIClients/FollowButtonWidgetAssets" />

<script>
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/41fFmJrK7zL._RC|01N0G7oHRlL.js_.js?AUIClients/BrandFollowKataComponentAssets');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/61-AxLNpw1L._RC|01zCndFsf4L.js,019K6hE9zSL.js,01edGJjT5SL.js_.js?AUIClients/InContextDetailPageAssets#1442063-T1.1459118-T1.1354819-T1.1463686-T1.1439981-T1.1423113-T1.1313601-T1');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/51+aVv60wyL.js?AUIClients/FollowButtonWidgetAssets');
</script>

<style>@font-face{font-family:"Amazon Ember";font-weight:300;src:url("https://m.media-shopping.com/images/G/01/AmazonStores/Fonts/AmazonEmber_W_Lt.eot");src:url("https://m.media-shopping.com/images/G/01/AmazonStores/Fonts/AmazonEmber_W_Lt.eot#iefix") format("embedded-opentype"),url("https://m.media-shopping.com/images/G/01/AmazonStores/Fonts/AmazonEmber_W_Lt.woff2") format("woff2"),url("https://m.media-shopping.com/images/G/01/AmazonStores/Fonts/AmazonEmber_W_Lt.woff") format("woff")}.stores-page{background:#fff;padding:0 0 40px 0}@media screen and (max-width: 840px){.stores-page{padding:0 0 40px 0}}.stores-page a{text-decoration:none}.stores-page a:focus{outline:3px solid #007185;outline-offset:initial;border-radius:1px}.stores-page a:hover,.stores-page a:active{text-decoration:none;outline:0}.stores-page:has([data-nav-layout=desktop-v3]){overflow-x:clip}</style><script type="text/javascript">
        window["global_Stores_ThemeName"]="diamond";
        document.documentElement.classList.add("stores-theme-elegant","stores-theme-diamond")
        window["webpackManifest_Stores_CDN_AssetsMap"]={"stores_core_rendering.js":"https://m.media-shopping.com/images/I/51eiBVHOJBL.js?stores_core_rendering.js","Translations-translation-ar-json.js":"https://m.media-shopping.com/images/I/51FHDSVqNHL.js?Translations-translation-ar-json.js","Translations-translation-bn-json.js":"https://m.media-shopping.com/images/I/51eXvgPajXL.js?Translations-translation-bn-json.js","Translations-translation-cs-json.js":"https://m.media-shopping.com/images/I/41JATS+nAEL.js?Translations-translation-cs-json.js","Translations-translation-da-json.js":"https://m.media-shopping.com/images/I/41QBU0To6ML.js?Translations-translation-da-json.js","Translations-translation-de-json.js":"https://m.media-shopping.com/images/I/41crbJ7054L.js?Translations-translation-de-json.js","Translations-translation-en-json.js":"https://m.media-shopping.com/images/I/51HpHnIEENL.js?Translations-translation-en-json.js","Translations-translation-es-json.js":"https://m.media-shopping.com/images/I/517iOu73H+L.js?Translations-translation-es-json.js","Translations-translation-fr-json.js":"https://m.media-shopping.com/images/I/51qaGIq5rwL.js?Translations-translation-fr-json.js","Translations-translation-he-json.js":"https://m.media-shopping.com/images/I/51EAzjGUBoL.js?Translations-translation-he-json.js","Translations-translation-hi-json.js":"https://m.media-shopping.com/images/I/51At8RxncAL.js?Translations-translation-hi-json.js","Translations-translation-it-json.js":"https://m.media-shopping.com/images/I/4191mw7tnxL.js?Translations-translation-it-json.js","Translations-translation-ja-json.js":"https://m.media-shopping.com/images/I/51eLbEGn0DL.js?Translations-translation-ja-json.js","Translations-translation-kn-json.js":"https://m.media-shopping.com/images/I/61sj79jO6lL.js?Translations-translation-kn-json.js","Translations-translation-ko-json.js":"https://m.media-shopping.com/images/I/51K-fu4vAwL.js?Translations-translation-ko-json.js","Translations-translation-ml-json.js":"https://m.media-shopping.com/images/I/61GTGBiKTFL.js?Translations-translation-ml-json.js","Translations-translation-mr-json.js":"https://m.media-shopping.com/images/I/51FUqHsfQeL.js?Translations-translation-mr-json.js","Translations-translation-nb-json.js":"https://m.media-shopping.com/images/I/41KzlGKEPBL.js?Translations-translation-nb-json.js","Translations-translation-nl-json.js":"https://m.media-shopping.com/images/I/41cNm+cT6SL.js?Translations-translation-nl-json.js","Translations-translation-pl-json.js":"https://m.media-shopping.com/images/I/41THwTXrKFL.js?Translations-translation-pl-json.js","Translations-translation-pt-json.js":"https://m.media-shopping.com/images/I/51c7WOxe3ZL.js?Translations-translation-pt-json.js","Translations-translation-sv-json.js":"https://m.media-shopping.com/images/I/41Y9gODnlLL.js?Translations-translation-sv-json.js","Translations-translation-ta-json.js":"https://m.media-shopping.com/images/I/61R1joW1P3L.js?Translations-translation-ta-json.js","Translations-translation-te-json.js":"https://m.media-shopping.com/images/I/61JZFToqRvL.js?Translations-translation-te-json.js","Translations-translation-tr-json.js":"https://m.media-shopping.com/images/I/41IToOAnHuL.js?Translations-translation-tr-json.js","Translations-translation-zh-json.js":"https://m.media-shopping.com/images/I/51RrZ1Z+-7L.js?Translations-translation-zh-json.js","Translations-translation-json.js":"https://m.media-shopping.com/images/I/41hySY6YDvL.js?Translations-translation-json.js","Widgets-ASLPAdProductList.js":"https://m.media-shopping.com/images/I/91nvTTvaLbL.js?Widgets-ASLPAdProductList.js","Widgets-ASLPBrandHeader.js":"https://m.media-shopping.com/images/I/411Ip1pK1RL.js?Widgets-ASLPBrandHeader.js","Widgets-AplusContent.js":"https://m.media-shopping.com/images/I/117yvhPXLGL.js?Widgets-AplusContent.js","Widgets-AuthorBio.js":"https://m.media-shopping.com/images/I/311eu9TTb2L.js?Widgets-AuthorBio.js","Widgets-AuthorCards.js":"https://m.media-shopping.com/images/I/21pGxw4uA8L.js?Widgets-AuthorCards.js","Widgets-AuthorFooter.js":"https://m.media-shopping.com/images/I/51wsnDJk3rL.js?Widgets-AuthorFooter.js","Widgets-AuthorSubHeader.js":"https://m.media-shopping.com/images/I/014m09GRexL.js?Widgets-AuthorSubHeader.js","Widgets-Banner.js":"https://m.media-shopping.com/images/I/31gPrQlBUOL.js?Widgets-Banner.js","Widgets-BeaconOverviewBanner.js":"https://m.media-shopping.com/images/I/115S9fzSAgL.js?Widgets-BeaconOverviewBanner.js","Widgets-Brand.js":"https://m.media-shopping.com/images/I/51TGj1NSyNL.js?Widgets-Brand.js","Widgets-BrandAgentChatBottomsheet.js":"https://m.media-shopping.com/images/I/81KUVe1TjsL.js?Widgets-BrandAgentChatBottomsheet.js","Widgets-BrandAgentChatIngress.js":"https://m.media-shopping.com/images/I/51m7CNMAvoL.js?Widgets-BrandAgentChatIngress.js","Widgets-BrandCatalogProductGrid.js":"https://m.media-shopping.com/images/I/91QUq7-mJyL.js?Widgets-BrandCatalogProductGrid.js","Widgets-BrandCategoryCarousel.js":"https://m.media-shopping.com/images/I/71GwskI0Q8L.js?Widgets-BrandCategoryCarousel.js","Widgets-BrandCategoryStack.js":"https://m.media-shopping.com/images/I/61lJvT61d8L.js?Widgets-BrandCategoryStack.js","Widgets-BrandCollectionCarousel.js":"https://m.media-shopping.com/images/I/61H-F2slb8L.js?Widgets-BrandCollectionCarousel.js","Widgets-BrandFollowProductHighlight.js":"https://m.media-shopping.com/images/I/81HLFJ4RtqL.js?Widgets-BrandFollowProductHighlight.js","Widgets-BrandGrid.js":"https://m.media-shopping.com/images/I/51nEFKqDxwL.js?Widgets-BrandGrid.js","Widgets-BrandInfoHeader.js":"https://m.media-shopping.com/images/I/119uBz4eeML.js?Widgets-BrandInfoHeader.js","Widgets-BrandIngressFooter.js":"https://m.media-shopping.com/images/I/41Ttlj1u70L.js?Widgets-BrandIngressFooter.js","Widgets-BrandMosaicCarousel.js":"https://m.media-shopping.com/images/I/81iSvLOpPeL.js?Widgets-BrandMosaicCarousel.js","Widgets-BrandPostStack.js":"https://m.media-shopping.com/images/I/817NvFZtwNL.js?Widgets-BrandPostStack.js","Widgets-BrandProfilePreviewCard.js":"https://m.media-shopping.com/images/I/21kKXO-qhfL.js?Widgets-BrandProfilePreviewCard.js","Widgets-BrandSelectorWithCategory.js":"https://m.media-shopping.com/images/I/61cQyIBANJL.js?Widgets-BrandSelectorWithCategory.js","Widgets-CampaignProductList.js":"https://m.media-shopping.com/images/I/81ZcJeYGikL.js?Widgets-CampaignProductList.js","Widgets-CategorySelectorWithProductGrid.js":"https://m.media-shopping.com/images/I/91gWkxviB9L.js?Widgets-CategorySelectorWithProductGrid.js","Widgets-DepartmentBrandCarousel.js":"https://m.media-shopping.com/images/I/31xLGZWETLL.js?Widgets-DepartmentBrandCarousel.js","Widgets-DynamicPageProductList.js":"https://m.media-shopping.com/images/I/81vlPqP9w+L.js?Widgets-DynamicPageProductList.js","Widgets-EditorialRow.js":"https://m.media-shopping.com/images/I/81TCNAiCJHL.js?Widgets-EditorialRow.js","Widgets-ExploreNavigationBar.js":"https://m.media-shopping.com/images/I/21gWDGOZCOL.js?Widgets-ExploreNavigationBar.js","Widgets-ExploreProductGrid.js":"https://m.media-shopping.com/images/I/9180yW2KzeL.js?Widgets-ExploreProductGrid.js","Widgets-Gallery.js":"https://m.media-shopping.com/images/I/41utf+gyaUL.js?Widgets-Gallery.js","Widgets-Header.js":"https://m.media-shopping.com/images/I/71e8-lUIe-L.js?Widgets-Header.js","Widgets-InlineConversationalShopping.js":"https://m.media-shopping.com/images/I/813h73vKejL.js?Widgets-InlineConversationalShopping.js","Widgets-LiveVideo.js":"https://m.media-shopping.com/images/I/01YnoZnE18L.js?Widgets-LiveVideo.js","Widgets-LiveVideoBanner.js":"https://m.media-shopping.com/images/I/21f1VbA+9-L.js?Widgets-LiveVideoBanner.js","Widgets-MultiMediaCarousel.js":"https://m.media-shopping.com/images/I/812nuCT9bcL.js?Widgets-MultiMediaCarousel.js","Widgets-MultiSelectorProductGrid.js":"https://m.media-shopping.com/images/I/91edoX6raML.js?Widgets-MultiSelectorProductGrid.js","Widgets-OasHeader.js":"https://m.media-shopping.com/images/I/51kscUN8ZHL.js?Widgets-OasHeader.js","Widgets-ProductCarousel.js":"https://m.media-shopping.com/images/I/4108VE6r+vL.js?Widgets-ProductCarousel.js","Widgets-ProductCollection.js":"https://m.media-shopping.com/images/I/91KVFGN9yfL.js?Widgets-ProductCollection.js","Widgets-ProductDetailsShowcase.js":"https://m.media-shopping.com/images/I/81Ke6JWvEwL.js?Widgets-ProductDetailsShowcase.js","Widgets-ProductGrid.js":"https://m.media-shopping.com/images/I/917baFtOwaL.js?Widgets-ProductGrid.js","Widgets-ProductGridFilters.js":"https://m.media-shopping.com/images/I/41TI8X7bP5L.js?Widgets-ProductGridFilters.js","Widgets-ProductSelector.js":"https://m.media-shopping.com/images/I/213ifKT2plL.js?Widgets-ProductSelector.js","Widgets-PuisItemCarousel.js":"https://m.media-shopping.com/images/I/81xnflHzgRL.js?Widgets-PuisItemCarousel.js","Widgets-SLPFooterIngress.js":"https://m.media-shopping.com/images/I/51UApuaOicL.js?Widgets-SLPFooterIngress.js","Widgets-SeeMoreBottomSheet.js":"https://m.media-shopping.com/images/I/31bwr4pHvOL.js?Widgets-SeeMoreBottomSheet.js","Widgets-Share.js":"https://m.media-shopping.com/images/I/319m2IYl+wL.js?Widgets-Share.js","Widgets-SimilarAuthors.js":"https://m.media-shopping.com/images/I/51+gK-2LAIL.js?Widgets-SimilarAuthors.js","Widgets-TopFollowedBrands.js":"https://m.media-shopping.com/images/I/81rpeqTG8bL.js?Widgets-TopFollowedBrands.js","Federation-shared.js":"https://m.media-shopping.com/images/I/01BDLPTgtsL.js?Federation-shared.js","Federation-selectors.js":"https://m.media-shopping.com/images/I/01StibAZk8L.js?Federation-selectors.js","Federation-widgets.js":"https://m.media-shopping.com/images/I/912eVtJqLeL.js?Federation-widgets.js","Federation-components.js":"https://m.media-shopping.com/images/I/91fTOuqU2TL.js?Federation-components.js","Federation-utils.js":"https://m.media-shopping.com/images/I/61shaYI9i+L.js?Federation-utils.js","videojs-lang.js":"https://m.media-shopping.com/images/I/715GZEE-gSL.js?videojs-lang.js","Common-config.js":"https://m.media-shopping.com/images/I/31I-LVrnnBL.js?Common-config.js","Common-NexusLoggerWrapper.js":"https://m.media-shopping.com/images/I/31xdPgZ6RhL.js?Common-NexusLoggerWrapper.js","Common-styles.js":"https://m.media-shopping.com/images/I/4118kHqBaxL.js?Common-styles.js","Common-Product.js":"https://m.media-shopping.com/images/I/31vUfHrRgGL.js?Common-Product.js","Common-ProductInfo.js":"https://m.media-shopping.com/images/I/314hsbuMSDL.js?Common-ProductInfo.js","Common-utils.js":"https://m.media-shopping.com/images/I/21-5kiQAEDL.js?Common-utils.js","Common-BottomSheet.js":"https://m.media-shopping.com/images/I/21-cO-oJLjL.js?Common-BottomSheet.js","videojs.js":"https://m.media-shopping.com/images/I/81uiyrM2ElL.js?videojs.js","Common-Video.js":"https://m.media-shopping.com/images/I/31ZZrAIZDML.js?Common-Video.js","Common-Metrics.js":"https://m.media-shopping.com/images/I/31+MoVCocsL.js?Common-Metrics.js","Common-ProductGridItem.js":"https://m.media-shopping.com/images/I/41CaC+ZVb8L.js?Common-ProductGridItem.js","Common-ProductShowcase.tsx.js":"https://m.media-shopping.com/images/I/31fFAlZYkaL.js?Common-ProductShowcase.tsx.js","Common-AddToCart.js":"https://m.media-shopping.com/images/I/31yaZyDaZxL.js?Common-AddToCart.js","Common-ImageVideoCarousel.js":"https://m.media-shopping.com/images/I/31t2BfLhshL.js?Common-ImageVideoCarousel.js","Common-TopBar.js":"https://m.media-shopping.com/images/I/31G3+hEvksL.js?Common-TopBar.js","Common-VariationHandler.js":"https://m.media-shopping.com/images/I/31M4ZajVlAL.js?Common-VariationHandler.js","Common-Variations.js":"https://m.media-shopping.com/images/I/31Y52sUHDyL.js?Common-Variations.js","Common-ProductShowcaseActions.js":"https://m.media-shopping.com/images/I/21LuR9-ij6L.js?Common-ProductShowcaseActions.js","reactmarkdown.js":"https://m.media-shopping.com/images/I/21pxPVs1x7L.js?reactmarkdown.js","Common-OAMProductUIRender.tsx.js":"https://m.media-shopping.com/images/I/31YITSH0D0L.js?Common-OAMProductUIRender.tsx.js","Common-ProductUIAssets.tsx.js":"https://m.media-shopping.com/images/I/21pFfVZd2-L.js?Common-ProductUIAssets.tsx.js","Common-useAddToCart.ts.js":"https://m.media-shopping.com/images/I/21Z2GMdRjvL.js?Common-useAddToCart.ts.js","Common-ProductGridItemT1.js":"https://m.media-shopping.com/images/I/41OHxcGraxL.js?Common-ProductGridItemT1.js","Common-ProductGrid.js":"https://m.media-shopping.com/images/I/31whgJwUi1L.js?Common-ProductGrid.js","Common-AuthorSearchFiltersMobile.js":"https://m.media-shopping.com/images/I/21wT93N4R4L.js?Common-AuthorSearchFiltersMobile.js","Common-AuthorProductGrid.js":"https://m.media-shopping.com/images/I/21kCw5v+OqL.js?Common-AuthorProductGrid.js","Common-FollowButton.js":"https://m.media-shopping.com/images/I/21gU5AnUjIL.js?Common-FollowButton.js","Common-ProductCard.js":"https://m.media-shopping.com/images/I/31wGEG3ZJjL.js?Common-ProductCard.js","Common-StreamClient.ts.js":"https://m.media-shopping.com/images/I/314-iHeH9KL.js?Common-StreamClient.ts.js","Common-FeedbackSection.js":"https://m.media-shopping.com/images/I/31TnE62dAAL.js?Common-FeedbackSection.js","Common-useSSEChat.js":"https://m.media-shopping.com/images/I/21hseovi6BL.js?Common-useSSEChat.js","Common-InlineAsinFaceoutCard.js":"https://m.media-shopping.com/images/I/21xZA22AZAL.js?Common-InlineAsinFaceoutCard.js","Common-EditorialTile.js":"https://m.media-shopping.com/images/I/41FNFfWK2WL.js?Common-EditorialTile.js","Common-EditorialTileInteractiveImage.js":"https://m.media-shopping.com/images/I/31wQ0v8KRHL.js?Common-EditorialTileInteractiveImage.js","Common-EditorialRow.js":"https://m.media-shopping.com/images/I/312mrsmLbAL.js?Common-EditorialRow.js","Common-EditorialTileImage.js":"https://m.media-shopping.com/images/I/31OKhSQcTAL.js?Common-EditorialTileImage.js","Common-EditorialTileProduct.js":"https://m.media-shopping.com/images/I/31apsuLr5VL.js?Common-EditorialTileProduct.js","Common-MultiMediaCarousel.js":"https://m.media-shopping.com/images/I/31ZnxbmG84L.js?Common-MultiMediaCarousel.js","Common-TextTileLayer.js":"https://m.media-shopping.com/images/I/31K9CW-DKtL.js?Common-TextTileLayer.js","Common-ProductCarousel.js":"https://m.media-shopping.com/images/I/31VemeO4b5L.js?Common-ProductCarousel.js","Common-InlineConversationalShopping.js":"https://m.media-shopping.com/images/I/21Okl+O+8YL.js?Common-InlineConversationalShopping.js","Common-widgetContext.js":"https://m.media-shopping.com/images/I/21PWA25NrvL.js?Common-widgetContext.js","Common-NavAccordionMenu.tsx.js":"https://m.media-shopping.com/images/I/21Qy+Dvg1SL.js?Common-NavAccordionMenu.tsx.js","Common-MobileHeader.tsx.js":"https://m.media-shopping.com/images/I/21js6g2i9nL.js?Common-MobileHeader.tsx.js","Common-SideMenu.tsx.js":"https://m.media-shopping.com/images/I/21FtY4GdivL.js?Common-SideMenu.tsx.js","Common-HeaderV1.js":"https://m.media-shopping.com/images/I/31M4+b8WGlL.js?Common-HeaderV1.js","Common-BrandCatalogProductGrid.tsx.js":"https://m.media-shopping.com/images/I/21Mv292-cFL.js?Common-BrandCatalogProductGrid.tsx.js","Common-BrandMosaicProduct.js":"https://m.media-shopping.com/images/I/21ChB8oUVRL.js?Common-BrandMosaicProduct.js","Common-BrandCategoryProduct.js":"https://m.media-shopping.com/images/I/21eelEdDV8L.js?Common-BrandCategoryProduct.js","Common-NavItem.js":"https://m.media-shopping.com/images/I/217V9jD4itL.js?Common-NavItem.js","Common-NavBar.js":"https://m.media-shopping.com/images/I/21JfgZswdFL.js?Common-NavBar.js","Common-LinkUtils.js":"https://m.media-shopping.com/images/I/21dTg+712CL.js?Common-LinkUtils.js","styles-689dd663.css":"https://m.media-shopping.com/images/I/01jnzWU8xUL.css?styles-689dd663.css","styles-31743c5a.css":"https://m.media-shopping.com/images/I/A1qyLF2DSNL.css?styles-31743c5a.css","styles-4ae14c31.css":"https://m.media-shopping.com/images/I/81jaxCBGl4L.css?styles-4ae14c31.css","styles-05ae064d.css":"https://m.media-shopping.com/images/I/01jnzWU8xUL.css?styles-05ae064d.css"};
        window.renderStoresWidgetsPluginList=[{"widgetId":"awls_cb4f34657f877973f57d2cb11b53f581f","widgetName":{"ar-AE":"التسوّق المباشر","de-DE":"Live Shopping","en-AU":"Live Shopping","en-CA":"Live Shopping","en-GB":"Live Shopping","en-IN":"Live Shopping","en-SG":"Live Shopping","en-US":"Live Shopping","es-CO":"Compras en vivo","es-ES":"Compras en Live","es-MX":"Compras en vivo","fr-CA":"Achats en direct","fr-FR":"Live Shopping","hi-IN":"लाइव शॉपिंग","it-IT":"Acquisti Live","ja-JP":"ライブショッピング","ko-KR":"라이브 쇼핑","nl-NL":"Live winkelen","pl-PL":"Zakupy na żywo","pt-BR":"Compras ao vivo","sv-SE":"Live Shopping","ta-IN":"லைவ் ஷாப்பிங்","th-TH":"การช้อปปิ้งผ่านไลฟ์","tr-TR":"Live Alışveriş","vi-VN":"Mua sắm trực tiếp","zh-CN":"直播购物","zh-TW":"直播購物"},"baseUrl":"https://d3r0qwykulb30y.cloudfront.net/awls_cb4f34657f877973f57d2cb11b53f581f/45","url":"https://d3r0qwykulb30y.cloudfront.net/awls_cb4f34657f877973f57d2cb11b53f581f/45/client/awls_cb4f34657f877973f57d2cb11b53f581f.js","contactDetails":"Website/AmazonLiveCreator/Creator Tools","widgetPosition":"EMBEDDED"},{"widgetId":"awls_881ebdc8240d21931f70aedc74df96997","widgetName":"Brand Home Social Share Widget","baseUrl":"https://d3r0qwykulb30y.cloudfront.net/awls_881ebdc8240d21931f70aedc74df96997/221","url":"https://d3r0qwykulb30y.cloudfront.net/awls_881ebdc8240d21931f70aedc74df96997/221/client/awls_881ebdc8240d21931f70aedc74df96997.js","contactDetails":"Performance Advertising/Operations/Stores","widgetPosition":"EMBEDDED"}];
    </script><link rel="stylesheet" href="https://m.media-shopping.com/images/I/01jnzWU8xUL.css?styles-689dd663.css" /><link rel="stylesheet" href="https://m.media-shopping.com/images/I/A1qyLF2DSNL.css?styles-31743c5a.css" /><link rel="stylesheet" href="https://m.media-shopping.com/images/I/81jaxCBGl4L.css?styles-4ae14c31.css" /><link rel="stylesheet" href="https://m.media-shopping.com/images/I/01jnzWU8xUL.css?styles-05ae064d.css" /><script async type="text/javascript" src="https://m.media-shopping.com/images/I/81ZH0g5h6nL.js?main.js"></script><script async type="text/javascript" src="https://m.media-shopping.com/images/I/41wqhrnDiqL.js?runtime.js"></script><script async type="text/javascript" src="https://m.media-shopping.com/images/I/61CFWASTZAL.js?AAPI-client.js"></script><script async type="text/javascript" src="https://m.media-shopping.com/images/I/B1R0Vj7gQeL.js?vendor.js"></script><script async type="text/javascript" src="https://m.media-shopping.com/images/I/61vNAXvkqzL.js?Redux-sagas.js"></script>
<script>window.stores_iframe_aui_assets="PGxpbmsgcmVsPSJzdHlsZXNoZWV0IiBocmVmPSJodHRwczovL20ubWVkaWEtYW1hem9uLmNvbS9pbWFnZXMvSS8yMTRhVHJVazhsTC5fUkN8NTFuZldUQmtld0wuY3NzXy5jc3M/QVVJQ2xpZW50cy9BbWF6b25VSSIgLz4KPGxpbmsgcmVsPSJzdHlsZXNoZWV0IiBocmVmPSJodHRwczovL20ubWVkaWEtYW1hem9uLmNvbS9pbWFnZXMvSS8xMVdzR1lTSXR4TC5fUkN8MDFERTZXU3ZMS0wuY3NzLDUxTkNHcFlIWExMLmNzcywzMVZ5QkYzWjRFTC5jc3MsMDFkcFJuN3MxREwuY3NzLDIxSk1DN09DOTFMLmNzcywwMW5PK0FuVUR5TC5jc3MsMDFvcGx5aHdnVEwuY3NzLDQxM1Z2djNHT05MLmNzcywxMTcwbkRnbDB1TC5jc3MsMDFSdzRGK1FVNkwuY3NzLDExR1cyRENuZ1RMLmNzcywwMWR3RXBMbU80TC5jc3MsMDFJZEtjQnVBZEwuY3NzLDAxaUhxalM3WWZMLmNzcywyMUQzSWVtckFMTC5jc3MsMTFDdjdzd1ltMkwuY3NzLDUxa1I0djRSQ2NMLmNzcywwMXlDOGtrNWtrTC5jc3MsMTFoZEVYdy02ckwuY3NzLDAxR0F4RjdLNXRMLmNzcywwMVpNLXM4WjN4TC5jc3MsMjFnRXpCcXBtdEwuY3NzLDExRmVveHJnaXlMLmNzcywyMVl1dWwwQmNuTC5jc3MsMDFyU1RJZ05KSUwuY3NzLDIxSHF5WXdQM3hMLmNzcywzMXUrdU0rQzA3TC5jc3MsMDE5VEFZcEtSQ0wuY3NzLDAxTGdreDdMV0tMLmNzcywzMWczUkFCUEtITC5jc3MsMTFQRFoyOXAtUEwuY3NzLDExN3pEc096blFMLmNzcywyMTVXcEFqd3pvTC5jc3MsMTFJTmg0ZCsyRkwuY3NzLDExNGFUUzZTak1MLmNzcywwMVV3NjRjSE5DTC5jc3MsMjFHY2ZjbWJhaEwuY3NzLDIxT0Q4RnVCcmFMLmNzcywxMVhvenl4aUg3TC5jc3MsMjEwVzhIeHRQNEwuY3NzLDExR3lVcGY5UGxMLmNzcywxMTlDa3RqYTc0TC5jc3MsMTFQTWd1TEs2Z0wuY3NzLDAxODkwK1Z3azhMLmNzcywxMVRaU250TDBvTC5jc3MsMDFxaXdKN3FEZkwuY3NzLDIxaloySG55NlVMLmNzcywwMU9OZzU2dzNxTC5jc3MsMDEzNitVRk90cEwuY3NzLDMxdW4rVUtlSWVMLmNzcywyMU1MWWo2TzhnTC5jc3MsMDEzLXhZdytTUkwuY3NzXy5jc3M/QVVJQ2xpZW50cy9BbWF6b25VSSN1cy5ub3QtdHJpZGVudCIgLz4KPHNjcmlwdD4KKGZ1bmN0aW9uKGIsYSxjLGQpe2lmKChiPWIuQW1hem9uVUlQYWdlSlN8fGIuUCkmJmIud2hlbiYmYi5yZWdpc3Rlcil7Yz1bXTtmb3IoYT1hLmN1cnJlbnRTY3JpcHQ7YTthPWEucGFyZW50RWxlbWVudClhLmlkJiZjLnB1c2goYS5pZCk7cmV0dXJuIGIubG9nKCJBIGNvcHkgb2YgUCBoYXMgYWxyZWFkeSBiZWVuIGxvYWRlZCBvbiB0aGlzIHBhZ2UuIiwiRkFUQUwiLGMuam9pbigiICIpKX19KSh3aW5kb3csZG9jdW1lbnQsRGF0ZSk7KGZ1bmN0aW9uKGEsYixjLGQpeyJ1c2Ugc3RyaWN0IjthLl9wU2V0ST1mdW5jdGlvbigpe3JldHVybiBudWxsfX0pKHdpbmRvdyxkb2N1bWVudCxEYXRlKTsoZnVuY3Rpb24oYyxlLEksQil7InVzZSBzdHJpY3QiO2MuX3BkPWZ1bmN0aW9uKCl7dmFyIGEsdTtyZXR1cm4gZnVuY3Rpb24oQyxmLGgsayxiLEQsdixFLEYpe2Z1bmN0aW9uIHcoZCl7dHJ5e3JldHVybiBkKCl9Y2F0Y2goSil7cmV0dXJuITF9fWZ1bmN0aW9uIGwoKXtpZihtKXt2YXIgZD17dzpjLmlubmVyV2lkdGh8fGIuY2xpZW50V2lkdGgsaDpjLmlubmVySGVpZ2h0fHxiLmNsaWVudEhlaWdodH07NTxNYXRoLmFicyhkLnctcS53KXx8NTA8ZC5oLXEuaD8ocT1kLG49NCwoZD1hLm1vYmlsZXx8YS50YWJsZXQ/NDUwPGQudyYmZC53PmQuaDoxMjUwPD1kLncpP2soYiwiYS13cyIpOmIuY2xhc3NOYW1lPXYoYiwiYS13cyIpKTowPG4mJihuLS0seD1zZXRUaW1lb3V0KGwsMTYpKX19ZnVuY3Rpb24gRyhkKXsobT1kPT09Qj8hbTohIWQpJiZsKCl9ZnVuY3Rpb24gSCgpe3JldHVybiBtfWlmKCF1KXt1PSEwO3ZhciByPWZ1bmN0aW9uKCl7dmFyIGQ9WyJPIiwibXMiLCJNb3oiLCJXZWJraXQiXSwKYz1lLmNyZWF0ZUVsZW1lbnQoImRpdiIpO3JldHVybnt0ZXN0R3JhZGllbnRzOmZ1bmN0aW9uKCl7cmV0dXJuITB9LHRlc3Q6ZnVuY3Rpb24oYSl7dmFyIGI9YS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSthLnN1YnN0cigxKTthPShkLmpvaW4oYisiICIpK2IrIiAiK2EpLnNwbGl0KCIgIik7Zm9yKGI9YS5sZW5ndGg7Yi0tOylpZigiIj09PWMuc3R5bGVbYVtiXV0pcmV0dXJuITA7cmV0dXJuITF9LHRlc3RUcmFuc2Zvcm0zZDpmdW5jdGlvbigpe3JldHVybiEwfX19KCkseT1iLmNsYXNzTmFtZSx6PS8oXnwgKWEtbW9iaWxlKCB8JCkvLnRlc3QoeSksQT0vKF58IClhLXRhYmxldCggfCQpLy50ZXN0KHkpO2E9e2F1ZGlvOmZ1bmN0aW9uKCl7cmV0dXJuISFlLmNyZWF0ZUVsZW1lbnQoImF1ZGlvIikuY2FuUGxheVR5cGV9LHZpZGVvOmZ1bmN0aW9uKCl7cmV0dXJuISFlLmNyZWF0ZUVsZW1lbnQoInZpZGVvIikuY2FuUGxheVR5cGV9LGNhbnZhczpmdW5jdGlvbigpe3JldHVybiEhZS5jcmVhdGVFbGVtZW50KCJjYW52YXMiKS5nZXRDb250ZXh0fSwKc3ZnOmZ1bmN0aW9uKCl7cmV0dXJuISFlLmNyZWF0ZUVsZW1lbnROUyYmISFlLmNyZWF0ZUVsZW1lbnROUygiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLCJzdmciKS5jcmVhdGVTVkdSZWN0fSxvZmZsaW5lOmZ1bmN0aW9uKCl7cmV0dXJuIG5hdmlnYXRvci5oYXNPd25Qcm9wZXJ0eSYmbmF2aWdhdG9yLmhhc093blByb3BlcnR5KCJvbkxpbmUiKSYmbmF2aWdhdG9yLm9uTGluZX0sZHJhZ0Ryb3A6ZnVuY3Rpb24oKXtyZXR1cm4iZHJhZ2dhYmxlImluIGUuY3JlYXRlRWxlbWVudCgic3BhbiIpfSxnZW9sb2NhdGlvbjpmdW5jdGlvbigpe3JldHVybiEhbmF2aWdhdG9yLmdlb2xvY2F0aW9ufSxoaXN0b3J5OmZ1bmN0aW9uKCl7cmV0dXJuISghYy5oaXN0b3J5fHwhYy5oaXN0b3J5LnB1c2hTdGF0ZSl9LHdlYndvcmtlcjpmdW5jdGlvbigpe3JldHVybiEhYy5Xb3JrZXJ9LGF1dG9mb2N1czpmdW5jdGlvbigpe3JldHVybiJhdXRvZm9jdXMiaW4gZS5jcmVhdGVFbGVtZW50KCJpbnB1dCIpfSwKaW5wdXRQbGFjZWhvbGRlcjpmdW5jdGlvbigpe3JldHVybiJwbGFjZWhvbGRlciJpbiBlLmNyZWF0ZUVsZW1lbnQoImlucHV0Iil9LHRleHRhcmVhUGxhY2Vob2xkZXI6ZnVuY3Rpb24oKXtyZXR1cm4icGxhY2Vob2xkZXIiaW4gZS5jcmVhdGVFbGVtZW50KCJ0ZXh0YXJlYSIpfSxsb2NhbFN0b3JhZ2U6ZnVuY3Rpb24oKXtyZXR1cm4ibG9jYWxTdG9yYWdlImluIGMmJm51bGwhPT1jLmxvY2FsU3RvcmFnZX0sb3JpZW50YXRpb246ZnVuY3Rpb24oKXtyZXR1cm4ib3JpZW50YXRpb24iaW4gY30sdG91Y2g6ZnVuY3Rpb24oKXtyZXR1cm4ib250b3VjaGVuZCJpbiBlfSxncmFkaWVudHM6ZnVuY3Rpb24oKXtyZXR1cm4gci50ZXN0R3JhZGllbnRzKCl9LGhpcmVzOmZ1bmN0aW9uKCl7dmFyIGE9Yy5kZXZpY2VQaXhlbFJhdGlvJiYxLjU8PWMuZGV2aWNlUGl4ZWxSYXRpb3x8Yy5tYXRjaE1lZGlhJiZjLm1hdGNoTWVkaWEoIihtaW4tcmVzb2x1dGlvbjoxNDRkcGkpIikubWF0Y2hlcztFKCJoaVJlcyIrCih6PyJNb2JpbGUiOkE/IlRhYmxldCI6IkRlc2t0b3AiKSxhPzE6MCk7cmV0dXJuIGF9LHRyYW5zZm9ybTNkOmZ1bmN0aW9uKCl7cmV0dXJuIHIudGVzdFRyYW5zZm9ybTNkKCl9LHRvdWNoU2Nyb2xsaW5nOmZ1bmN0aW9uKCl7cmV0dXJuIGYoL1dpbmRvd3Nob3B8YW5kcm9pZHxPUyAoWzUtOV18WzEtOV1bMC05XSspKF9bMC05XXsxLDJ9KSsgbGlrZSBNYWMgT1MgWHxTT0ZUV0FSRT0oWzUtOV18WzEtOV1bMC05XSspKC5bMC05XXsxLDJ9KSsuKkRFVklDRT1pUGhvbmV8Q2hyb21lfFNpbGt8RmlyZWZveHxUcmlkZW50Lis/OyBUb3VjaC9pKX0saW9zOmZ1bmN0aW9uKCl7cmV0dXJuIGYoL09TIFsxLTldWzAtOV0qKF9bMC05XSopKyBsaWtlIE1hYyBPUyBYL2kpJiYhZigvdHJpZGVudHxFZGdlL2kpfSxhbmRyb2lkOmZ1bmN0aW9uKCl7cmV0dXJuIGYoL2FuZHJvaWQuKFsxLTldfFtMLVpdKS9pKSYmIWYoL3RyaWRlbnR8RWRnZS9pKX0sbW9iaWxlOmZ1bmN0aW9uKCl7cmV0dXJuIHp9LAp0YWJsZXQ6ZnVuY3Rpb24oKXtyZXR1cm4gQX0scnRsOmZ1bmN0aW9uKCl7cmV0dXJuInJ0bCI9PT1iLmRpcn19O2Zvcih2YXIgZyBpbiBhKWEuaGFzT3duUHJvcGVydHkoZykmJihhW2ddPXcoYVtnXSkpO2Zvcih2YXIgdD0idGV4dFNoYWRvdyB0ZXh0U3Ryb2tlIGJveFNoYWRvdyBib3JkZXJSYWRpdXMgYm9yZGVySW1hZ2Ugb3BhY2l0eSB0cmFuc2Zvcm0gdHJhbnNpdGlvbiIuc3BsaXQoIiAiKSxwPTA7cDx0Lmxlbmd0aDtwKyspYVt0W3BdXT13KGZ1bmN0aW9uKCl7cmV0dXJuIHIudGVzdCh0W3BdKX0pO3ZhciBtPSEwLHg9MCxxPXt3OjAsaDowfSxuPTQ7bCgpO2goYywicmVzaXplIixmdW5jdGlvbigpe2NsZWFyVGltZW91dCh4KTtuPTQ7bCgpfSk7Yi5jbGFzc05hbWU9dihiLCJhLW5vLWpzIik7ayhiLCJhLWpzIik7IWYoL09TIFsxLThdKF9bMC05XSopKyBsaWtlIE1hYyBPUyBYL2kpfHxjLm5hdmlnYXRvci5zdGFuZGFsb25lfHxmKC9zYWZhcmkvaSl8fGsoYiwiYS1lbWJlciIpOwpoPVtdO2ZvcihnIGluIGEpYS5oYXNPd25Qcm9wZXJ0eShnKSYmYVtnXSYmaC5wdXNoKCJhLSIrZy5yZXBsYWNlKC8oW0EtWl0pL2csZnVuY3Rpb24oYSl7cmV0dXJuIi0iK2EudG9Mb3dlckNhc2UoKX0pKTtrKGIsaC5qb2luKCIgIikpO2Iuc2V0QXR0cmlidXRlKCJkYXRhLWF1aS1idWlsZC1kYXRlIixGKTtDLnJlZ2lzdGVyKCJwLWRldGVjdCIsZnVuY3Rpb24oKXtyZXR1cm57Y2FwYWJpbGl0aWVzOmEsbG9jYWxTdG9yYWdlOmEubG9jYWxTdG9yYWdlJiZELHRvZ2dsZVJlc3BvbnNpdmVHcmlkOkcscmVzcG9uc2l2ZUdyaWRFbmFibGVkOkh9fSk7cmV0dXJuIGF8fHt9fX19KCl9KSh3aW5kb3csZG9jdW1lbnQsRGF0ZSk7KGZ1bmN0aW9uKGEscCxxLGspe2Z1bmN0aW9uIG0oZSxiLGMsZyl7YS5QLndoZW4uYXBwbHkoYS5QLGIpLnJlZ2lzdGVyKCJmbG93OiIrZSxmdW5jdGlvbigpe3ZhciBhPWcuYXBwbHkodGhpcyxhcmd1bWVudHMpO3JldHVybiBjfHxhfSl9ZnVuY3Rpb24gbChlKXthLlAubG9nKGUsIkZBVEFMIiwiQW1hem9uVUlQYWdlSlNAQVVJRGVmaW5lSlMiKX1mdW5jdGlvbiBmKGEsYixjKXtPYmplY3QuZGVmaW5lUHJvcGVydHkoYSxiLHt2YWx1ZTpjLHdyaXRhYmxlOiExfSl9ZnVuY3Rpb24gbihlLGIsYyl7InN0cmluZyIhPT10eXBlb2YgZSYmYS5QLmVycm9yKCJBbm9ueW1vdXMgbW9kdWxlcyBhcmUgbm90IHN1cHBvcnRlZC4iKTt2YXIgZz1jIT09az9jOiJmdW5jdGlvbiI9PT10eXBlb2YgYj9iOms7Z3x8YS5QLmVycm9yKCJBIGNhbGxiYWNrIG11c3QgYmUgcHJvdmlkZWQiKTt2YXIgZixoPVtdO2lmKGMmJkFycmF5LmlzQXJyYXkoYikmJihoPWIucmVkdWNlKGZ1bmN0aW9uKGIsZCl7aWYoIm1vZHVsZSI9PT0KZHx8InJlcXVpcmUiPT09ZClhLlAuZXJyb3IoJyJtb2R1bGUiIG9yICJyZXF1aXJlIiBpbmplY3Rpb24gaXMgbm90IHN1cHBvcnRlZC4nKTtlbHNlIGlmKCJleHBvcnRzIj09PWQpe2Q9Zj17fTt2YXIgYz0iZmxvdzoiK2UrIi1leHBvcnRzIjthLlAuZGVjbGFyZShjLGQpO2IucHVzaChjKX1lbHNlIDAhPT1kLmxhc3RJbmRleE9mKCJAYW16bi8iLDApP2woIkRlcGVuZGVuY3kgIitkKyIgZG9lcyBub3QgYmVnaW4gd2l0aCAnQGFtem4vJyIpOmIucHVzaCgiZmxvdzoiK2QpO3JldHVybiBifSxbXSksYi5sZW5ndGghPT1oLmxlbmd0aCkpcmV0dXJuO20oZSxoLGYsZyl9InVzZSBzdHJpY3QiO09iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChhLCJhdWkiKT9sKCJBVUlEZWZpbmVKUyBpcyBhbHJlYWR5IHByZXNlbnQgZ2xvYmFsbHkiKTooZihhLCJhdWkiLHt9KSxmKGEuYXVpLCJhbWRfZGVmaW5lIixuKSl9KSh3aW5kb3csZG9jdW1lbnQsRGF0ZSk7KGZ1bmN0aW9uKGcsaCxDLEQpe2Z1bmN0aW9uIEsoYSl7bCYmbC50YWcmJmwudGFnKHAoIjoiLCJhdWkiLGEpKX1mdW5jdGlvbiBxKGEsYil7bCYmbC5jb3VudCYmbC5jb3VudCgiYXVpOiIrYSwwPT09Yj8wOmJ8fChsLmNvdW50KCJhdWk6IithKXx8MCkrMSl9ZnVuY3Rpb24gTChhKXt0cnl7cmV0dXJuIGEudGVzdChuYXZpZ2F0b3IudXNlckFnZW50KX1jYXRjaChiKXtyZXR1cm4hMX19ZnVuY3Rpb24geChhLGIsYyl7YS5hZGRFdmVudExpc3RlbmVyP2EuYWRkRXZlbnRMaXN0ZW5lcihiLGMsITEpOmEuYXR0YWNoRXZlbnQmJmEuYXR0YWNoRXZlbnQoIm9uIitiLGMpfWZ1bmN0aW9uIHAoYSxiLGMsZil7Yj1iJiZjP2IrYStjOmJ8fGM7cmV0dXJuIGY/cChhLGIsZik6Yn1mdW5jdGlvbiB5KGEsYixjKXt0cnl7T2JqZWN0LmRlZmluZVByb3BlcnR5KGEsYix7dmFsdWU6Yyx3cml0YWJsZTohMX0pfWNhdGNoKGYpe2FbYl09Y31yZXR1cm4gY31mdW5jdGlvbiBNKGEsYil7YS5jbGFzc05hbWU9Ck4oYSxiKSsiICIrYn1mdW5jdGlvbiBOKGEsYil7cmV0dXJuKCIgIithLmNsYXNzTmFtZSsiICIpLnNwbGl0KCIgIitiKyIgIikuam9pbigiICIpLnJlcGxhY2UoL14gfCAkL2csIiIpfWZ1bmN0aW9uIGFhKGEsYixjKXt2YXIgZj1jPWEubGVuZ3RoLGU9ZnVuY3Rpb24oKXtmLS18fChFLnB1c2goYiksRnx8KG0/bS5zZXQoeik6c2V0VGltZW91dCh6LDApLEY9ITApKX07Zm9yKGUoKTtjLS07KU9bYVtjXV0/ZSgpOih1W2FbY11dPXVbYVtjXV18fFtdKS5wdXNoKGUpfWZ1bmN0aW9uIGJhKGEsYixjLGYsZSl7dmFyIGQ9aC5jcmVhdGVFbGVtZW50KGE/InNjcmlwdCI6ImxpbmsiKTt4KGQsImVycm9yIixmKTtlJiZ4KGQsImxvYWQiLGUpO2E/KGQudHlwZT0idGV4dC9qYXZhc2NyaXB0IixkLmFzeW5jPSEwLGMmJi9BVUlDbGllbnRzfGltYWdlc1svXUkvLnRlc3QoYikmJmQuc2V0QXR0cmlidXRlKCJjcm9zc29yaWdpbiIsImFub255bW91cyIpLGQuc3JjPWIpOihkLnJlbD0ic3R5bGVzaGVldCIsCmQuaHJlZj1iKTtoLmdldEVsZW1lbnRzQnlUYWdOYW1lKCJoZWFkIilbMF0uYXBwZW5kQ2hpbGQoZCl9ZnVuY3Rpb24gUChhLGIpe3JldHVybiBmdW5jdGlvbihjLGYpe2Z1bmN0aW9uIGUoKXtiYShiLGMsZCxmdW5jdGlvbihiKXtHP3EoInJlc291cmNlX3VubG9hZCIpOmQ/KGQ9ITEscSgicmVzb3VyY2VfcmV0cnkiKSxlKCkpOihxKCJyZXNvdXJjZV9lcnJvciIpLGEubG9nKCJBc3NldCBmYWlsZWQgdG8gbG9hZDogIitjKSk7YiYmYi5zdG9wUHJvcGFnYXRpb24/Yi5zdG9wUHJvcGFnYXRpb24oKTpnLmV2ZW50JiYoZy5ldmVudC5jYW5jZWxCdWJibGU9ITApfSxmKX1pZihRW2NdKXJldHVybiExO1FbY109ITA7cSgicmVzb3VyY2VfY291bnQiKTt2YXIgZD0hMDtyZXR1cm4hZSgpfX1mdW5jdGlvbiBjYShhLGIsYyl7Zm9yKHZhciBmPXtuYW1lOmEsZ3VhcmQ6ZnVuY3Rpb24oYyl7cmV0dXJuIGIuZ3VhcmRGYXRhbChhLGMpfSxndWFyZFRpbWU6ZnVuY3Rpb24oYSl7cmV0dXJuIGIuZ3VhcmRUaW1lKGEpfSwKbG9nRXJyb3I6ZnVuY3Rpb24oYyxkLGUpe2IubG9nRXJyb3IoYyxkLGUsYSl9fSxlPVtdLGQ9MDtkPGMubGVuZ3RoO2QrKylBLmhhc093blByb3BlcnR5KGNbZF0pJiYoZVtkXT1ILmhhc093blByb3BlcnR5KGNbZF0pP0hbY1tkXV0oQVtjW2RdXSxmKTpBW2NbZF1dKTtyZXR1cm4gZX1mdW5jdGlvbiB2KGEsYixjLGYsZSl7cmV0dXJuIGZ1bmN0aW9uKGQsayl7ZnVuY3Rpb24gbigpe3ZhciBhPW51bGw7Zj9hPWs6ImZ1bmN0aW9uIj09PXR5cGVvZiBrJiYocS5zdGFydD1yKCksYT1rLmFwcGx5KGcsY2EoZCxoLGwpKSxxLmVuZD1yKCkpO2lmKGIpe0FbZF09YTthPWQ7Zm9yKE9bYV09ITA7KHVbYV18fFtdKS5sZW5ndGg7KXVbYV0uc2hpZnQoKSgpO2RlbGV0ZSB1W2FdfXEuZG9uZT0hMH12YXIgaD1lfHx0aGlzOyJmdW5jdGlvbiI9PT10eXBlb2YgZCYmKGs9ZCxkPUQpO2ImJihkPWQ/ZC5yZXBsYWNlKFIsIiIpOiJfX05PTkFNRV9fIixJLmhhc093blByb3BlcnR5KGQpJiZoLmVycm9yKHAoIiwgcmVyZWdpc3RlcmVkIGJ5ICIsCnAoIiBieSAiLGQrIiBhbHJlYWR5IHJlZ2lzdGVyZWQiLElbZF0pLGguYXR0cmlidXRpb24pLGQpLElbZF09aC5hdHRyaWJ1dGlvbik7Zm9yKHZhciBsPVtdLG09MDttPGEubGVuZ3RoO20rKylsW21dPWFbbV0ucmVwbGFjZShSLCIiKTt2YXIgcT13W2R8fCJhbm9uIisgKytkYV09e2RlcGVuZDpsLHJlZ2lzdGVyZWQ6cigpLG5hbWVzcGFjZTpoLm5hbWVzcGFjZX07ZCYmZWEuaGFzT3duUHJvcGVydHkoZCk7Yz9uKCk6YWEobCxoLmd1YXJkRmF0YWwoZCxuKSxkKTtyZXR1cm57ZGVjb3JhdGU6ZnVuY3Rpb24oYSl7SFtkXT1oLmd1YXJkRmF0YWwoZCxhKX19fX1mdW5jdGlvbiBTKGEpe3JldHVybiBmdW5jdGlvbigpe3ZhciBiPUFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cyk7cmV0dXJue2V4ZWN1dGU6dihiLCExLGEsITEsdGhpcykscmVnaXN0ZXI6dihiLCEwLGEsITEsdGhpcyl9fX1mdW5jdGlvbiBKKGEsYil7cmV0dXJuIGZ1bmN0aW9uKGMsZil7Znx8KGY9YyxjPQpEKTt2YXIgZT10aGlzLmF0dHJpYnV0aW9uO3JldHVybiBmdW5jdGlvbigpe24ucHVzaChifHx7YXR0cmlidXRpb246ZSxuYW1lOmMsbG9nTGV2ZWw6YX0pO3ZhciBkPWYuYXBwbHkodGhpcyxhcmd1bWVudHMpO24ucG9wKCk7cmV0dXJuIGR9fX1mdW5jdGlvbiBCKGEsYil7dGhpcy5sb2FkPXtqczpQKHRoaXMsITApLGNzczpQKHRoaXMpfTt5KHRoaXMsIm5hbWVzcGFjZSIsYik7eSh0aGlzLCJhdHRyaWJ1dGlvbiIsYSl9ZnVuY3Rpb24gVCgpe2guYm9keT9rLnRyaWdnZXIoImEtYm9keUJlZ2luIik6c2V0VGltZW91dChULDIwKX0idXNlIHN0cmljdCI7dmFyIHQ9Qy5ub3c9Qy5ub3d8fGZ1bmN0aW9uKCl7cmV0dXJuK25ldyBDfSxyPWZ1bmN0aW9uKGEpe3JldHVybiBhJiZhLm5vdz9hLm5vdy5iaW5kKGEpOnR9KGcucGVyZm9ybWFuY2UpLGZhPXIoKSxlYT17fSxsPWcudWU7SygpO0soImF1aV9idWlsZF9kYXRlOjMuMjYuOC0yMDI2LTEwLTAzIik7dmFyIFU9e2dldEl0ZW06ZnVuY3Rpb24oYSl7dHJ5e3JldHVybiBnLmxvY2FsU3RvcmFnZS5nZXRJdGVtKGEpfWNhdGNoKGIpe319LApzZXRJdGVtOmZ1bmN0aW9uKGEsYil7dHJ5e3JldHVybiBnLmxvY2FsU3RvcmFnZS5zZXRJdGVtKGEsYil9Y2F0Y2goYyl7fX19LG09Zy5fcFNldEkoKSxFPVtdLGhhPVtdLEY9ITEsaWE9bmF2aWdhdG9yLnNjaGVkdWxpbmcmJiJmdW5jdGlvbiI9PT10eXBlb2YgbmF2aWdhdG9yLnNjaGVkdWxpbmcuaXNJbnB1dFBlbmRpbmc7dmFyIHo9ZnVuY3Rpb24oKXtmb3IodmFyIGE9bT9tLnNldCh6KTpzZXRUaW1lb3V0KHosMCksYj10KCk7aGEubGVuZ3RofHxFLmxlbmd0aDspaWYoRS5zaGlmdCgpKCksbSYmaWEpe2lmKDE1MDx0KCktYiYmIW5hdmlnYXRvci5zY2hlZHVsaW5nLmlzSW5wdXRQZW5kaW5nKCl8fDUwPHQoKS1iJiZuYXZpZ2F0b3Iuc2NoZWR1bGluZy5pc0lucHV0UGVuZGluZygpKXJldHVybn1lbHNlIGlmKDUwPHQoKS1iKXJldHVybjttP20uY2xlYXIoYSk6Y2xlYXJUaW1lb3V0KGEpO0Y9ITF9O3ZhciBPPXt9LHU9e30sUT17fSxHPSExO3goZywiYmVmb3JldW5sb2FkIixmdW5jdGlvbigpe0c9CiEwO3NldFRpbWVvdXQoZnVuY3Rpb24oKXtHPSExfSwxRTQpfSk7dmFyIFI9L15wcnY6LyxJPXt9LEE9e30sSD17fSx3PXt9LGRhPTAsamE9U3RyaW5nLmZyb21DaGFyQ29kZSg5Miksbj1bXSxWPSEwLFc9Zy5vbmVycm9yO2cub25lcnJvcj1mdW5jdGlvbihhLGIsYyxmLGUpe2UmJiJvYmplY3QiPT09dHlwZW9mIGV8fChlPUVycm9yKGEsYixjKSxlLmNvbHVtbk51bWJlcj1mLGUuc3RhY2s9Ynx8Y3x8Zj9wKGphLGUubWVzc2FnZSwiYXQgIitwKCI6IixiLGMsZikpOkQpO3ZhciBkPW4ucG9wKCl8fHt9O2UuYXR0cmlidXRpb249cCgiOiIsZS5hdHRyaWJ1dGlvbnx8ZC5hdHRyaWJ1dGlvbixkLm5hbWUpO2UubG9nTGV2ZWw9ZC5sb2dMZXZlbDtlLmF0dHJpYnV0aW9uJiZjb25zb2xlJiZjb25zb2xlLmxvZyYmY29uc29sZS5sb2coW2UubG9nTGV2ZWx8fCJFUlJPUiIsYSwidGhyb3duIGJ5IixlLmF0dHJpYnV0aW9uXS5qb2luKCIgIikpO249W107VyYmKGQ9W10uc2xpY2UuY2FsbChhcmd1bWVudHMpLApkWzRdPWUsVy5hcHBseShnLGQpKX07Qi5wcm90b3R5cGU9e2xvZ0Vycm9yOmZ1bmN0aW9uKGEsYixjLGYpe2I9e21lc3NhZ2U6Yixsb2dMZXZlbDpjfHwiRVJST1IiLGF0dHJpYnV0aW9uOnAoIjoiLHRoaXMuYXR0cmlidXRpb24sZil9O2lmKGcudWVMb2dFcnJvcilyZXR1cm4gZy51ZUxvZ0Vycm9yKGF8fGIsYT9iOm51bGwpLCEwO2NvbnNvbGUmJmNvbnNvbGUuZXJyb3ImJihjb25zb2xlLmxvZyhiKSxjb25zb2xlLmVycm9yKGEpKTtyZXR1cm4hMX0sZXJyb3I6ZnVuY3Rpb24oYSxiLGMsZil7YT1FcnJvcihwKCI6IixmLGEsYykpO2EuYXR0cmlidXRpb249cCgiOiIsdGhpcy5hdHRyaWJ1dGlvbixiKTt0aHJvdyBhO30sZ3VhcmRFcnJvcjpKKCksZ3VhcmRGYXRhbDpKKCJGQVRBTCIpLGd1YXJkQ3VycmVudDpmdW5jdGlvbihhKXt2YXIgYj1uW24ubGVuZ3RoLTFdO3JldHVybiBiP0ooYi5sb2dMZXZlbCxiKS5jYWxsKHRoaXMsYSk6YX0sZ3VhcmRUaW1lOmZ1bmN0aW9uKGEpe3ZhciBiPQpuW24ubGVuZ3RoLTFdLGM9YiYmYi5uYW1lO3JldHVybiBjJiZjIGluIHc/ZnVuY3Rpb24oKXt2YXIgYj1yKCksZT1hLmFwcGx5KHRoaXMsYXJndW1lbnRzKTt3W2NdLmFzeW5jPSh3W2NdLmFzeW5jfHwwKStyKCktYjtyZXR1cm4gZX06YX0sbG9nOmZ1bmN0aW9uKGEsYixjKXtyZXR1cm4gdGhpcy5sb2dFcnJvcihudWxsLGEsYixjKX0sZGVjbGFyZTp2KFtdLCEwLCEwLCEwKSxyZWdpc3Rlcjp2KFtdLCEwKSxleGVjdXRlOnYoW10pLEFVSV9CVUlMRF9EQVRFOiIzLjI2LjgtMjAyNi0xMC0wMyIsd2hlbjpTKCksbm93OlMoITApLHRyaWdnZXI6ZnVuY3Rpb24oYSxiLGMpe3ZhciBmPXQoKTt0aGlzLmRlY2xhcmUoYSx7ZGF0YTpiLHBhZ2VFbGFwc2VkVGltZTpmLShnLmFQYWdlU3RhcnR8fE5hTiksdHJpZ2dlclRpbWU6Zn0pO2MmJmMuaW5zdHJ1bWVudCYmWC53aGVuKCJwcnY6YS1sb2dUcmlnZ2VyIikuZXhlY3V0ZShmdW5jdGlvbihiKXtiKGEpfSl9LGhhbmRsZVRyaWdnZXJzOmZ1bmN0aW9uKCl7dGhpcy5sb2coImhhbmRsZVRyaWdnZXJzIGRlcHJlY2F0ZWQiKX0sCmF0dHJpYnV0ZUVycm9yczpmdW5jdGlvbihhKXtyZXR1cm4gbmV3IEIoYSl9LF9uYW1lc3BhY2U6ZnVuY3Rpb24oYSxiKXtyZXR1cm4gbmV3IEIoYSxiKX0sc2V0UHJpb3JpdHk6ZnVuY3Rpb24oYSl7Vj9WPSExOnRoaXMubG9nKCJzZXRQcmlvcml0eSBvbmx5IGFjY2VwdCB0aGUgZmlyc3QgY2FsbC4iKX19O3ZhciBrPXkoZywiQW1hem9uVUlQYWdlSlMiLG5ldyBCKTt2YXIgWD1rLl9uYW1lc3BhY2UoIlBhZ2VKUyIsIkFtYXpvblVJIik7WC5kZWNsYXJlKCJwcnY6cC1kZWJ1ZyIsdyk7ay5kZWNsYXJlKCJwLXJlY29yZGVyLWV2ZW50cyIsW10pO2suZGVjbGFyZSgicC1yZWNvcmRlci1zdG9wIixmdW5jdGlvbigpe30pO3koZywiUCIsayk7VCgpO2lmKGguYWRkRXZlbnRMaXN0ZW5lcil7dmFyIFk7aC5hZGRFdmVudExpc3RlbmVyKCJET01Db250ZW50TG9hZGVkIixZPWZ1bmN0aW9uKCl7ay50cmlnZ2VyKCJhLWRvbXJlYWR5Iik7aC5yZW1vdmVFdmVudExpc3RlbmVyKCJET01Db250ZW50TG9hZGVkIiwKWSwhMSl9LCExKX12YXIgWj1oLmRvY3VtZW50RWxlbWVudCxrYT1nLl9wZChrLEwseCxNLFosVSxOLHEsIjMuMjYuOC0yMDI2LTEwLTAzIik7TCgvVUNCcm93c2VyL2kpfHxrYS5sb2NhbFN0b3JhZ2UmJk0oWixVLmdldEl0ZW0oImEtZm9udC1jbGFzcyIpKTtrLmRlY2xhcmUoImEtZXZlbnQtcmV2aXNlZC1oYW5kbGluZyIsITEpO2suZGVjbGFyZSgiYS1maXgtZXZlbnQtb2ZmIiwhMSk7cSgicGFnZWpzOnBrZ0V4ZWNUaW1lIixyKCktZmEpfSkod2luZG93LGRvY3VtZW50LERhdGUpOwogICh3aW5kb3cuQW1hem9uVUlQYWdlSlMgPyBBbWF6b25VSVBhZ2VKUyA6IFApLmxvYWQuanMoJ2h0dHBzOi8vbS5tZWRpYS1hbWF6b24uY29tL2ltYWdlcy9JLzExSTBXWHJaVm9MLl9SQ3w2MXhKY05LS0xYTC5qcywxMVkrNXgra2tUTC5qcyw1MUlyV3duNkdFTC5qcywxMTV6YnlrMzcxTC5qcywxMUdnTjErQzdoTC5qcywwMSt6K3VJZUotTC5qcywwMUFpZTZMNHVHTC5qcywyMU5hZFFsWFVXTC5qcywwMXZSZjlpZDJFTC5qcywzMW9uLUxhOTB2TC5qcywxMWE3cXFZOHhYTC5qcywxMVBaU1VsM0ZMTC5qcyw1MUM0a2FGYmlBTC5qcywxMUZoZEgySFp3TC5qcywxMXdiOUszc3cwTC5qcywxMUJyZ3JNQUhVTC5qcywxMWRLVTl6aEQxTC5qcywyMUY2ejRIYUVWTC5qcywwMVN2ZnhmeThPTC5qcyw2MWxiVDRiSE5XTC5qcywwMWlrQmJUQW5lTC5qcywzMXh5d29YUGZwTC5qcywwMXFYSnV3R214TC5qcywwMVdsc2pObXFJTC5qcywxMUY5MjlwbXBZTC5qcywzMWRVaFh6empZTC5qcywwMXJwYXVUZXA0TC5qcywzMTRNMk9hazdoTC5qcywwMTFGZlB3WXFITC5qcywyMVA1VnZIZi1YTC5qcywwMXBUcStqRjA2TC5qcywyMWtOMHE0SUEtTC5qcywwMTA1bnZxTGQ0TC5qcywxMXZiNlA1QzVBTC5qcywwMUxkMlRuSlV1TC5qc18uanM/QVVJQ2xpZW50cy9BbWF6b25VSScpOwo8L3NjcmlwdD4K";</script>
<!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-assets -->
<!-- sp:feature:encrypted-slate-token -->
<meta name='encrypted-slate-token' content='AnYxAMJYhjzYYY+xSfvdH8D/e65fr3G4rwuaiDTKQ1QLNMR3YLZpJEa5yr2zIKkBXGDKn4wPRSk7hU5Kqu6ECxoshpqZvUMwHAzQnda0yVpHPZwdGHd+scESh82Ndft0tnFKKQk6GMoQhSRDbXZrd2ntHCjrr+LW3tRpkQPbcCCupbTSGMhEGOam68omRxnnRXL26dxcdoYEJXqHxZS914WkZrCfa+vBYpDucqzLW3dFILytHGwksmu8tos75I/1giBWdp5b1mvxygAOgZKDtuTR1B7BvQzNIcRZa3zIqkGg6YS5EvWvuOpaY3TTJYRyqe0wL3oFXq1+s5U='>
<!-- sp:end-feature:encrypted-slate-token -->
<!-- sp:feature:bidi-endpoint -->
<meta name='bidi-endpoint' content='ws.ep-e908141b0.bidi.amazon.dev'>
<!-- sp:end-feature:bidi-endpoint -->
<!-- sp:feature:flow-closure-id -->
<meta name='flow-closure-id' content='1791887947'>
<!-- sp:end-feature:flow-closure-id -->
<!-- sp:feature:csm:head-close -->
<script type='text/javascript'>
window.ue_ihe = (window.ue_ihe || 0) + 1;
if (window.ue_ihe === 1) {
(function(k,l,g){function m(a){c||(c=b[a.type].id,"undefined"===typeof a.clientX?(e=a.pageX,f=a.pageY):(e=a.clientX,f=a.clientY),2!=c||h&&(h!=e||n!=f)?(r(),d.isl&&l.setTimeout(function(){p("at",d.id)},0)):(h=e,n=f,c=0))}function r(){for(var a in b)b.hasOwnProperty(a)&&d.detach(a,m,b[a].parent)}function s(){for(var a in b)b.hasOwnProperty(a)&&d.attach(a,m,b[a].parent)}function t(){var a="";!q&&c&&(q=1,a+="&ui="+c);return a}var d=k.ue,p=k.uex,q=0,c=0,h,n,e,f,b={click:{id:1,parent:g},mousemove:{id:2,
parent:g},scroll:{id:3,parent:l},keydown:{id:4,parent:g}};d&&p&&(s(),d._ui=t)})(ue_csm,window,document);


(function(s,l){function m(b,e,c){c=c||new Date(+new Date+t);c="expires="+c.toUTCString();n.cookie=b+"="+e+";"+c+";path=/"}function p(b){b+="=";for(var e=n.cookie.split(";"),c=0;c<e.length;c++){for(var a=e[c];" "==a.charAt(0);)a=a.substring(1);if(0===a.indexOf(b))return decodeURIComponent(a.substring(b.length,a.length))}return""}function q(b,e,c){if(!e)return b;-1<b.indexOf("{")&&(b="");for(var a=b.split("&"),f,d=!1,h=!1,g=0;g<a.length;g++)f=a[g].split(":"),f[0]==e?(!c||d?a.splice(g,1):(f[1]=c,a[g]=
f.join(":")),h=d=!0):2>f.length&&(a.splice(g,1),h=!0);h&&(b=a.join("&"));!d&&c&&(0<b.length&&(b+="&"),b+=e+":"+c);return b}var k=s.ue||{},t=3024E7,n=ue_csm.document||l.document,r=null,d;a:{try{d=l.localStorage;break a}catch(u){}d=void 0}k.count&&k.count("csm.cookieSize",document.cookie.length);k.cookie={get:p,set:m,updateCsmHit:function(b,e,c){try{var a;if(!(a=r)){var f;a:{try{if(d&&d.getItem){f=d.getItem("csm-hit");break a}}catch(k){}f=void 0}a=f||p("csm-hit")||"{}"}a=q(a,b,e);r=a=q(a,"t",+new Date);
try{d&&d.setItem&&d.setItem("csm-hit",a)}catch(h){}m("csm-hit",a,c)}catch(g){"function"==typeof l.ueLogError&&ueLogError(Error("Cookie manager: "+g.message),{logLevel:"WARN"})}}}})(ue_csm,window);


(function(l,e){function c(b){b="";var c=a.isBFT?"b":"s",d=""+a.oid,g=""+a.lid,h=d;d!=g&&20==g.length&&(c+="a",h+="-"+g);a.tabid&&(b=a.tabid+"+");b+=c+"-"+h;b!=f&&100>b.length&&(f=b,a.cookie?a.cookie.updateCsmHit(m,b+("|"+ +new Date)):e.cookie="csm-hit="+b+("|"+ +new Date)+n+"; path=/")}function p(){f=0}function d(b){!0===e[a.pageViz.propHid]?f=0:!1===e[a.pageViz.propHid]&&c({type:"visible"})}var n="; expires="+(new Date(+new Date+6048E5)).toGMTString(),m="tb",f,a=l.ue||{},k=a.pageViz&&a.pageViz.event&&
a.pageViz.propHid;a.attach&&(a.attach("click",c),a.attach("keyup",c),k||(a.attach("focus",c),a.attach("blur",p)),k&&(a.attach(a.pageViz.event,d,e),d({})));a.aftb=1})(ue_csm,ue_csm.document);


ue_csm.ue.stub(ue,"impression");


ue.stub(ue,"trigger");


if(window.ue&&uet) { uet('bb'); }

}
</script>
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 2728)</script>
<!-- sp:end-feature:csm:head-close -->
<!-- sp:feature:head-close -->
<script>
window.P && P.register('bb');
if (typeof ues === 'function') {
  ues('t0', 'portal-bb', new Date());
  ues('ctb', 'portal-bb', 1);
}
</script>
</head><!-- sp:end-feature:head-close -->
<!-- sp:feature:start-body -->
<body class="a-m-us a-aui_72554-c a-aui_template_weblab_cache_333406-c a-bw_aui_dark_mode_mshop_ios_1390013-t2"><div id="a-page"><script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{"AUI_72554":"C","AUI_TEMPLATE_WEBLAB_CACHE_333406":"C","BW_AUI_DARK_MODE_MSHOP_IOS_1390013":"T2"}</script><script>typeof uex === 'function' && uex('ld', 'portal-bb', {wb: 1})</script><!-- sp:end-feature:start-body -->
<!-- sp:feature:csm:body-open -->


<script>
!function(){function n(n,t){var r=i(n);return t&&(r=r("instance",t)),r}var r=[],c=0,i=function(t){return function(){var n=c++;return r.push([t,[].slice.call(arguments,0),n,{time:Date.now()}]),i(n)}};n._s=r,this.csa=n}();;
csa('Config', {});
if (window.csa) {
    csa("Config", {
        'Application': 'Retail:Prod:www.shopping.com',
        'Events.Namespace': 'csa',
        'ObfuscatedMarketplaceId': 'ATVPDKIKX0DER',
        'Events.SushiEndpoint': 'https://unagi.shopping.com/1/events/com.amazon.csm.csa.prod',
        'Events.SushiCsaVIP': 'unagi.shopping.com',
        'Events.SushiCsaSourceGroup': 'com.amazon.csm.csa.prod',
        'Events.SushiCsaCustomSourceGroup': 'com.amazon.csm.customsg.prod',
        'Events.SushiEndpointPattern': 'https://%s/1/events/%s',
        'CacheDetection.RequestID': "KAS98C370K01G4FPVKFV",
        'CacheDetection.Callback': window.ue && ue.reset,
        'Transport.nonBatchSchema': "csa.UEData.4",
        'LCP.elementDedup': 1,
        'lob': '1'
    });

    csa("Events")("setEntity", {
        page: {requestId: "KAS98C370K01G4FPVKFV", meaningful: "interactive"},
        session: {id: "147-0099296-5118245"}
    });
}
!function(e){var i,o="splice",r=e.csa,u={},f={},c=e.csa._s,a=0,n=0,l=0,s=-1,g={},h={},p={},d=Object.keys,v=function(){};function t(n,t){return r(n,t)}function m(n,t){var e=f[n]||{};M(e,t),f[n]=e,l++,I()}function y(n,t,e){var r=!0;return t=U(t),e&&e.buffered&&(r=(p[n]||[]).every(function(n){return!1!==t(n)})),r?(g[n]||(g[n]=[]),g[n].push(t),function(){!function(n,t){var e=g[n];if(e){var r=e.indexOf(t);-1!=r&&e[o](r,1)}}(n,t)}):v}function b(n,t){if(t=U(t),n in h)return t(h[n]),v;return y(n,function(n){return t(n),!1})}function w(n,t){if(r("Errors")("logError",n),u.DEBUG)throw t||n}function S(){return[E(),E(),E(),E()].join("-")}function E(){return Math.abs(4294967295*Math.random()|0).toString(36)}function U(n,t){return function(){try{return n.apply(this,arguments)}catch(n){w(n.message||n,n)}}}function D(n,t){return e.setTimeout(U(n),t)}function I(){n||(n=1,D(function(){n=0,O()},0))}function O(){try{a=1;for(var n=0;n<c.length;){var t=c[n];t[0]in f?(c[o](n,1),C(t)):n++}s=l}finally{a=0}}function C(n){var t=f[n[0]],e=n[1],r=e[0];if(!t||!t[r])return w("Undefined function: "+t+"/"+r);i=n[3];try{f[n[2]]=t[r].apply(t,e.slice(1))||{}}catch(n){w("Stub call replay failure: "+(n&&n.message?n.message:n),n)}finally{i=0}}function k(){O()}function M(t,e){d(e).forEach(function(n){t[n]=e[n]})}b("$beforeunload",k),m("Config",{instance:function(n){M(u,n)}}),r.plugin=U(function(n){n(t)}),t.config=u,t.register=m,t.on=y,t.once=b,t.blank=v,t.emit=function(n,t,e){for(var r=g[n]||[],i=0;i<r.length;)!1===r[i](t)?r[o](i,1):i++;h[n]=t||{},e&&e.buffered&&(p[n]||(p[n]=[]),100<=p[n].length&&p[n].shift(),p[n].push(t||{}))},t.UUID=S,t.generateNewRequestId=function(){return S().toUpperCase().replace(/-/g,"").slice(0,20)},t.time=function(n){var t=i?new Date(i.time):new Date;return"ISO"===n?t.toISOString():t.getTime()},t.error=w,t.warn=function(n,t){if(r("Errors")("logWarn",n),u.DEBUG)throw t||n},t.exec=U,t.timeout=D,t.interval=function(n,t){return e.setInterval(U(n),t)},(t.global=e).csa._s.push=function(n){if(n[0]in f){if(!a&&s!==l)return c[o](c.length,0,n),void I();C(n)}else c[o](c.length,0,n)},O(),u["StubCalls.Cleanup.Onload"]&&b("$load",k),D(function(){D(k,u.SkipMissingPluginsTimeout||5e3)},1)}("undefined"!=typeof window?window:global);csa.plugin(function(o){var f="addEventListener",e="requestAnimationFrame",t=o.exec,r=o.global,u=o.on;o.raf=function(n){if(r[e])return r[e](t(n))},o.on=function(n,e,t,r){if(n&&"function"==typeof n[f]){var i=o.exec(t);return n[f](e,i,r),function(){n.removeEventListener(e,i,r)}}return"string"==typeof n?u(n,e,t,r):o.blank}});csa.plugin(function(o){var t,n,r={},e="localStorage",c="sessionStorage",a="local",i="session",u=o.exec;function s(e,t){var n;try{r[t]=!!(n=o.global[e]),n=n||{}}catch(e){r[t]=!(n={})}return n}function f(){t=t||s(e,a),n=n||s(c,i)}function l(e){return e&&e[i]?n:t}o.store=u(function(e,t,n){f();var o=l(n);return e?t?void(o[e]=t):o[e]:Object.keys(o)}),o.storageSupport=u(function(){return f(),r}),o.deleteStored=u(function(e,t){f();var n=l(t);if("function"==typeof e)for(var o in n)n.hasOwnProperty(o)&&e(o,n[o])&&delete n[o];else delete n[e]})});csa.plugin(function(n){n.types={ovl:function(n){var r=[];if(n)for(var i in n)n.hasOwnProperty(i)&&r.push(n[i]);return r}}});csa.plugin(function(a){var e=a.config,t=a.global,r=t.location||{},n=r.host,o=t.document||{},l=e.Application||"Other"+(n?":"+n:""),s="UEData",i=e["KillSwitch."+s],c=e["Transport.AnonymizeRequests"]||!1,f=e.RedactPath||!1,p="csa.UEData.4",u="csa",g="ld",d=a("Transport");i||a.register(s,{log:function(e){if(function(e){return!e||"object"==typeof e&&0===Object.keys(e).length}(e))a.warn("Received empty or null uedata input");else{var t=function(t){var n={schemaId:p,timestamp:a.time("ISO"),producerId:u,messageId:a.UUID(),application:l,url:f?r.protocol+"//"+r.hostname:c?r.href.split("?")[0]:r.href,referrer:f?"":c?o.referrer.split("?")[0]:o.referrer};if(["eventName","lob","ifr","id","csmtags","viz","sessionId","obfuscatedMarketplaceId"].forEach(function(e){null!=t[e]&&(n[e]=t[e])}),["pty","spty","pti"].forEach(function(e){null!=t[e]&&(n.pageInfo=n.pageInfo||{},n.pageInfo[e]=t[e])}),t.latency&&t.latency.t&&(n.t=t.latency.t+""),null!=t.browserData){var e=t.browserData.indexOf("?");-1!=e&&(n.browserData=t.browserData.substring(1+e))}return n.clientRequestId=a.generateNewRequestId(),n}(e);!function(e){return e.eventName===g||e.pageInfo&&null!=e.pageInfo.pty&&null!=e.pageInfo.spty&&null!=e.pageInfo.pti&&(e.viz&&0<e.viz.length||e.csmtags&&0<e.csmtags.length)}(t)?d("log",t):d("log",t,{forceSend:!0})}}})});csa.plugin(function(a){var e=a.config,n="Errors",c="fcsmln",s=e["KillSwitch."+n];function r(n){return function(e){a("Metrics",{producerId:"csa",dimensions:{message:e}})("recordMetric",n,1)}}function t(r){var t,o,l=a("Events",{producerId:r.producerId,lob:e.lob||"0"}),i=["name","type","csm","adb"],u={url:"pageURL",file:"f",line:"l",column:"c"};this.log=function(e){if(!s&&!function(e){if(!e)return!0;for(var n in e)return!1;return!0}(e)){var n=r.logOptions||{ent:{page:["pageType","subPageType","requestId"]}};l("log",function(n){return t=a.UUID(),o={messageId:t,schemaId:r.schemaId||"<ns>.Error.6",errorMessage:n.m||null,attribution:n.attribution||null,logLevel:"FATAL",url:null,file:null,line:null,column:null,stack:n.s||[],context:n.cinfo||{},metadata:{}},n.logLevel&&(o.logLevel=""+n.logLevel),i.forEach(function(e){n[e]&&(o.metadata[e]=n[e])}),c in n&&(o.metadata[c]=n[c]+""),"INFO"===n.logLevel||Object.keys(u).forEach(function(e){"number"!=typeof n[u[e]]&&"string"!=typeof n[u[e]]||(o[e]=""+n[u[e]])}),o}(e),n)}}}a.register(n,{instance:function(e){return new t(e||{})},logError:r("jsError"),logWarn:r("jsWarn")})});csa.plugin(function(o){var r,e,n,t,a,i="function",u="willDisappear",c="$app.",f="$document.",p="focus",s="blur",d="active",l="resign",$=o.global,m=o.exec,b=o.config,h=b["Transport.AnonymizeRequests"]||!1,g=b.RedactPath||!1,v=o("Events"),y=$.location,P=$.document||{},w=$.P||{},k=(($.performance||{}).navigation||{}).type,E=o.on,T=o.emit,I=P.hidden,A={};y&&P&&(E($,"beforeunload",S),E($,"pagehide",S),E(P,"visibilitychange",j(f,function(){return P.visibilityState||"unknown"})),E(P,p,j(f+p)),E(P,s,j(f+s)),w.when&&w.when("mash").execute(function(e){e&&(E(e,"appPause",j(c+"pause")),E(e,"appResume",j(c+"resume")),j(c+"deviceready")(),$.cordova&&$.cordova.platformId&&j(c+cordova.platformId)(),E(P,d,j(c+d)),E(P,l,j(c+l)))}),e=$.app||{},n=m(function(){T(c+"willDisappear"),S()}),a=typeof(t=e[u])==i,e[u]=m(function(){n(),a&&t()}),$.app||($.app=e),"complete"===P.readyState?R():E($,"load",R),I?x():U(),o.on("$app.blur",x),o.on("$app.focus",U),o.on("$document.blur",x),o.on("$document.focus",U),o.on("$document.hidden",x),o.on("$document.visible",U),o.register("SPA",{newPage:D}),D({transitionType:{0:"hard",1:"refresh",2:"back-button"}[k]||"unknown"}));function D(n,e){var t=!!r,a=(e=e||{}).keepPageAttributes;t&&(T("$beforePageTransition"),T("$pageTransition")),t&&!a&&v("removeEntity","page"),r=o.UUID(),a?A.id=r:A={schemaId:"<ns>.PageEntity.2",id:r,url:g?y.protocol+"//"+y.hostname:h?y.href.split("?")[0]:y.href,server:y.hostname,path:g?"":y.pathname,referrer:g?"":h?P.referrer.split("?")[0]:P.referrer,title:P.title},Object.keys(n||{}).forEach(function(e){A[e]=n[e]}),v("setEntity",{page:A}),T("$pageChange",A,{buffered:1}),t&&T("$afterPageTransition")}function R(){T("$load"),T("$ready"),T("$afterload")}function S(){T("$ready"),T("$beforeunload"),T("$unload"),T("$afterunload")}function x(){I||(T("$visible",!1,{buffered:1}),I=!0)}function U(){I&&(T("$visible",!0,{buffered:1}),I=!1)}function j(n,t){return m(function(){var e=typeof t==i?n+t():n;T(e)})}});csa.plugin(function(f){var e="Events",n="UNKNOWN",s="id",o="all",l="sushiSourceGroup",i="copyBaseMetadata",r="copyEntities",c="messageId",a="timestamp",d="producerId",u="application",p="obfuscatedMarketplaceId",g="entities",y="page",h="requestId",v="pageType",b="subPageType",O="schemaId",m="version",I="attributes",E="<ns>",S="lob",k=f.config["Events.SushiCsaSourceGroup"],A="session",T=f.config,t=f.global,U=t.Object.keys,j=(t.location||{}).host,w=T["KillSwitch.PageEntity"],x=T[e+".Namespace"]||"csa_other",N=x+".",q=T.Application||"Other"+(j?":"+j:""),D=T["Transport.AnonymizeRequests"]||!1,K=f("Transport"),M={},P=function(e,t){Object.keys(e).forEach(t)};function _(n,i,r){P(i,function(e){var t=r===o||(r||{})[e];e in n||(n[e]={version:1,id:i[e][s]||f.UUID()}),G(n[e],i[e],t)})}function G(t,n,i){P(n,function(e){!function(e,t,n){return"string"!=typeof t&&e!==m?f.error("Attribute is not of type string: "+e):!0===n||1===n||(e===s||!!~(n||[]).indexOf(e))}(e,n[e],i)||(t[e]=n[e])})}function z(r,e,o){P(e,function(t){var e=r[t];if(!(e[O]&&~e[O].indexOf("PageEntity")&&w)&&e[O]){var n={},i={};n[s]=e[s],n[d]=e[d]||o[d],n[O]=e[O],n[m]=e[m]++,n[I]=i,B(n,o),G(i,e,1),C(i),t===y&&(n.__backfill=function(e){!function(e,t,n,i){if(e&&e[O]&&e[O]!==n&&!e[O].indexOf(N)){var r=e[g];if(r&&r[i]&&r[i][s]===t[s]){var o=r[i],c=U(o);c.push(h),c.push(v),c.push(b),G(o,t,c)}}}(e,i,n[O],t)}),K("log",n)}})}function B(e,t){e[a]=function(e){return"number"==typeof e&&(e=new Date(e).toISOString()),e||f.time("ISO")}(e[a]),e[c]=e[c]||f.UUID(),e[u]=q,e[p]=T.ObfuscatedMarketplaceId||n,O in e&&(e[O]=e[O].replace(E,x)),t&&t[S]&&(e[S]=t[S])}function C(e){delete e[m],delete e[O],delete e[d]}function R(t){var c={},s=!!t[l]&&t[l]!==k,a=!!t[i],u=!!t[r];this.log=function(i,e){var n={},r=(e||{}).ent;if(!i)return f.error("The event cannot be undefined");var o=i[g];if(s)a&&B(i,t),u&&(_(n,M,r),_(n,c,r));else{if("string"!=typeof i[O])return f.error("A valid schema id is required for the event");B(i,t),_(n,M,r),_(n,c,r)}i[d]=t[d],s?(o||u&&0<Object.keys(n).length)&&(i[g]={},o&&P(o,function(t){var n=r&&r[t];i[g][t]={},P(o[t],function(e){(!n||!0===n||Array.isArray(n)&&~n.indexOf(e))&&(i[g][t][e]=o[t][e])})}),u&&0<Object.keys(n).length&&P(n,function(t){i[g][t]||(i[g][t]={}),P(n[t],function(e){e in i[g][t]||(i[g][t][e]=n[t][e])}),C(i[g][t])})):s||(_(n,o||{},r),P(n,function(e){C(n[e])}),i[g]=n),e&&e[S]&&(i[S]=e[S]),(e=e||{})[l]||(e[l]=t[l]||k),K("log",i,e)},this.setEntity=function(e){D&&delete e[A],_(c,e,o),z(c,e,t)}}!T["KillSwitch."+e]&&U&&f.register(e,{setEntity:function(e){D&&delete e[A],f.emit("$entities.set",e,{buffered:1}),_(M,e,o),z(M,e,{producerId:"csa",lob:T[S]||"0"})},removeEntity:function(e){delete M[e]},instance:function(e){return new R(e)}})});csa.plugin(function(p){var a,h="Transport",l="post",f="preflight",c="csa.cajun.",i="store",u="deleteStored",s="sendBeacon",n="__merge",t="__backfill",e=".FlushInterval",g="sushiSourceGroup",v=p.config["Events.SushiCsaSourceGroup"],y="function",d=0,m=p.config[h+".BufferSize"]||2e3,E=p.config[h+".RetryDelay"]||1500,S=p.config[h+".AnonymizeRequests"]||!1,b=p.config[h+".nonBatchSchema"]||"",k={},G=0,I=[],R=p.global,o=R.document,w=p.timeout,A=p.emit,B=R.Object.keys,r=p.config[h+e]||5e3,O=r,j=p.config[h+e+".BackoffFactor"]||1,D=p.config[h+e+".BackoffLimit"]||3e4,T=0,U=0,$=0;function _(o,r){if(864e5<p.time()-+new Date(o.timestamp))return p.warn("Event is too old: "+o);if((r=r||{}).forceSend&&b&&b===o.schemaId)I.forEach(function(e){if(e.accepts(o,r)){var n=e.post?e:null;n&&C(n,[o],r[g]||v)}});else if(G<m){typeof o[t]==y&&(U||$||B(k).forEach(function(e){o[t](k[e].event)}),delete o[t]);var e=o.messageId||p.UUID();e in k||(k[e]={event:o,options:r},G++),typeof o[n]==y&&(r[g]||v)===(((k[e]||{}).options||{})[g]||v)&&o[n](k[e].event),!T&&d&&(T=w(q,function(){var e=O;return O=Math.min(e*j,D),e}()))}}function q(){var r={};B(k).forEach(function(e){var n=k[e],o=n.options&&n.options[g]||v;r[o]||(r[o]=[]),r[o].push(n.event)}),B(r).forEach(function(e){!function(o,r){I.forEach(function(n){var e=r.filter(function(e){return n.accepts(e,{sushiSourceGroup:o})});0<e.length&&(n.chunks?n.chunks(e,o):[e]).forEach(function(e){n[l]&&C(n,e,o)})})}(e,r[e])}),k={},T=0,U+=1,A("$transport.flushed")}function C(n,o,r){function t(){p[u](c+e)}var e=p.UUID();p[i](c+e,JSON.stringify({events:o,sourceGroup:r})),[function(e,n,o,r){var t=R.navigator||{},c=R.cordova||{};if(S)return 0;if(!t[s]||!e[l])return 0;e[f]&&c&&"ios"===c.platformId&&!a&&((new Image).src=e[f]().url,a=1);var i=e[l](n,o);if(!i.type&&t[s](i.url,i.body))return r(),1},function(e,n,o,r){var t=e[l](n,o),c=t.url,i=t.body,a=t.type,f=new XMLHttpRequest,u=0;function s(e,n,o){f.open("POST",e),f.withCredentials=!S,o&&f.setRequestHeader("Content-Type",o),f.send(n)}return f.onload=function(){f.status<299?r():p.config[h+".XHRRetries"]&&u<3&&w(function(){s(c,i,a)},++u*E)},s(c,i,a),1}].some(function(e){try{return e(n,o,r,t)}catch(e){}})}B&&(p.once("$afterload",function(){$=d=1,function(t){(p[i]()||[]).forEach(function(e){if(!e.indexOf(c))try{var n=p[i](e);p[u](e);var o=JSON.parse(n);if(o&&"object"==typeof o&&!Array.isArray(o))try{if(o.events&&o.sourceGroup){var r=o.sourceGroup;o.events.forEach(function(e){t(e,{sushiSourceGroup:r})})}}catch(e){p.error("Error processing backup object format: "+e.message)}else if(Array.isArray(o))try{o.forEach(t)}catch(e){p.error("Error processing array format backup: "+e.message)}}catch(e){p.error(e)}})}(_),p.on(o,"visibilitychange",q,!1),q()}),p.once("$afterunload",function(){d=1,q()}),p.on("$afterPageTransition",function(){G=0,O=r}),p.register(h,{log:_,register:function(e){I.push(e)}}))});csa.plugin(function(n){var u=n.config["Events.SushiEndpoint"],t=n.config["Events.SushiCsaSourceGroup"];n("Transport")("register",{accepts:function(n,r){return!(!n||!r)&&(n.schemaId&&(!r.sushiSourceGroup||r.sushiSourceGroup===t))},post:function(n){var r=n.map(function(n){return{data:n}});return{url:u,body:JSON.stringify({events:r})}},preflight:function(){var n,r=/\/\/(.*?)\//.exec(u);return r&&r[1]&&(n="https://"+r[1]+"/ping"),{url:n}},chunks:function(n){for(var r=[];500<n.length;)r.push(n.splice(0,500));return r.push(n),r}})});csa.plugin(function(u){var e=u.config["Events.SushiEndpoint"],t=u.config["Events.SushiCsaSourceGroup"],s=u.config["Events.SushiCsaVIP"],i=u.config["Events.SushiEndpointPattern"];u("Transport")("register",{accepts:function(n,r){return!(!n||!r)&&(!!r.sushiSourceGroup&&r.sushiSourceGroup!==t)},post:function(n,r){var t=n.map(function(n){return{data:n}});return{url:function(n){var r=e;n&&(r=function(n){var r=Array.prototype.slice.call(arguments,1),t=(n.match(/%s/g)||[]).length;r.length<t&&u.warn("Warning: More placeholders ("+t+") than arguments ("+r.length+")");var e=0;return n.replace(/%s/g,function(){return e<r.length?r[e++]:""})}(i,s,n));return r}(r),body:JSON.stringify({events:t})}},preflight:function(){var n,r=/\/\/(.*?)\//.exec(e);return r&&r[1]&&(n="https://"+r[1]+"/ping"),{url:n}},chunks:function(n){for(var r=[];500<n.length;)r.push(n.splice(0,500));return r.push(n),r}})});csa.plugin(function(n){var t,a,o,r,e=n.config,i="PageViews",d=e[i+".ImpressionMinimumTime"]||1e3,s="hidden",c="innerHeight",l="innerWidth",g="renderedTo",f=g+"Viewed",m=g+"Meaningful",u=g+"Impressed",p=1,h=2,v=3,w=4,P=5,y="loaded",I=7,b=8,T=n.global,S=n.on,E=n("Events",{producerId:"csa",lob:e.lob||"0"}),K=T.document,V={},$={},M=P,R=e["KillSwitch."+i],H=e["KillSwitch.PageRender"],W=e["KillSwitch.PageImpressed"];function j(e){if(!V[I]){if(V[e]=n.time(),e!==v&&e!==y||(t=t||V[e]),t&&M===w){if(a=a||V[e],!R)(i={})[m]=t-o,i[f]=a-o,k("PageView.5",i);r=r||n.timeout(x,d)}var i;if(e!==P&&e!==p&&e!==h||(clearTimeout(r),r=0),e!==p&&e!==h||H||k("PageRender.4",{transitionType:e===p?"hard":"soft"}),e===I&&!W)(i={})[m]=t-o,i[f]=a-o,i[u]=V[e]-o,k("PageImpressed.3",i)}}function k(e,i){$[e]||(i.schemaId="<ns>."+e,E("log",i,{ent:"all"}),$[e]=1)}function q(){0===T[c]&&0===T[l]?(M=b,n("Events")("setEntity",{page:{viewport:"hidden-iframe"}})):M=K[s]?P:w,j(M)}function x(){j(I),r=0}function z(){var e=o?h:p;V={},$={},a=t=0,o=n.time(),j(e),q()}function A(){var e=K.readyState;"interactive"===e&&j(v),"complete"===e&&j(y)}K&&void 0!==K[s]?(z(),S(K,"visibilitychange",q,!1),S(K,"readystatechange",A,!1),S("$afterPageTransition",z),S("$timing:loaded",A),n.once("$load",A)):n.warn("Page visibility not supported")});csa.plugin(function(c){var s=c.config["Interactions.ParentChainLength"]||35,n="click",r="touches",f="timeStamp",o="length",u="pageX",g="pageY",p="pageXOffset",h="pageYOffset",l=250,m=5,v=200,d=.5,t={capture:!0,passive:!0},X=c.config["KillSwitch.ContentInteractions"],Y=c.global,x=c.emit,e=c.on,y=Y.Math.abs,a=(Y.document||{}).documentElement||{},N={x:0,y:0,t:0,sX:0,sY:0},b={x:0,y:0,t:0,sX:0,sY:0};function I(t){if(t.id)return"//*[@id='"+t.id+"']";var n=function(t){var n,e=1;for(n=t.previousSibling;n;n=n.previousSibling)n.nodeName===t.nodeName&&(e+=1);return e}(t),e=t.nodeName;return 1!==n&&(e+="["+n+"]"),t.parentNode&&(e=I(t.parentNode)+"/"+e),e}function C(t,n,e){if(!X){var a=c("Content",{target:e}),i={schemaId:"<ns>.ContentInteraction.2",interaction:t,interactionData:n,messageId:c.UUID()};if(e){var r=I(e);r&&(i.attribution=r);var o=function(t){for(var n=t,e=n.tagName,a=!1,i=t?t.href:null,r=0;r<s;r++){if(!n||!n.parentElement){a=!0;break}e=(n=n.parentElement).tagName+"/"+e,i=i||n.href}return a||(e=".../"+e),{pc:e,hr:i}}(e);o.pc&&(i.interactionData.parentChain=o.pc),o.hr&&(i.interactionData.href=o.hr)}a("log",i),x("$content.interaction",{e:i,w:a})}}function i(t){C(n,{interactionX:""+t.pageX,interactionY:""+t.pageY},t.target)}function D(t){if(t&&t[r]&&1===t[r][o]){var n=t[r][0];b=N={e:t.target,x:n[u],y:n[g],t:t[f],sX:Y[p],sY:Y[h]}}}function S(t){if(t&&t[r]&&1===t[r][o]&&N&&b){var n=t[r][0],e=t[f],a=e-b.t,i={e:t.target,x:n[u],y:n[g],t:e,sX:Y[p],sY:Y[h]};b=i,v<=a&&(N=i)}}function w(t){if(t){var n=y(N.x-b.x),e=y(N.y-b.y),a=y(N.sX-b.sX),i=y(N.sY-b.sY),r=t[f]-N.t;if(l<1e3*n/r&&m<n||l<1e3*e/r&&m<e){var o=e<n;o&&a&&n*d<=a||!o&&i&&e*d<=i||C((o?"horizontal":"vertical")+"-swipe",{interactionX:""+N.x,interactionY:""+N.y,endX:""+b.x,endY:""+b.y},N.e)}}}e(a,n,i,t),e(a,"touchstart",D,t),e(a,"touchmove",S,t),e(a,"touchend",w,t)});csa.plugin(function(a){var c,l,s,e,t="MutationObserver",f="observe",n="disconnect",m="_csa_flt",d="_csa_llt",v="_csa_mr",h="_csa_mi",p="lastChild",_="lastElementChild",b="length",g={childList:!0,subtree:!0},I=13,L=50,i=1e3,y=7,C=4,E={"#text":1,"#comment":1,SCRIPT:1,STYLE:1,NOSCRIPT:1,LINK:1,META:1},r=a.global,u=r.document,S=u.body||u.documentElement,T=Date.now,o=[],x=[],M=0,N=1,k=[],w=[],B=0;T&&r[t]&&(M=0,l=new r[t](O),a.once("$ready",A),N&&(R(),e=a.interval(P,i)),a.register("SpeedIndexBuffers",{getBuffers:D,registerListener:function(e){c=e},replayModuleIsLive:function(e){a.timeout(A,0),e&&e(D)}}));function O(e){o.push({t:T(),m:e}),c&&c()}function P(){var e=T();(!s||i<e-s)&&R()}function R(){for(var e=S,t=T(),n=[],i=[],r=0,u=0,o=0;e&&r<y;)e[m]?++u:(e[m]=t,n.push(e),o=1),i[b]<C&&i.push(e),e[h]=B,e[d]=t,e=e[_]||e[p],r+=1;o&&(u<w[b]&&function(e){for(var t=e,n=w[b];t<n;t++){var i=w[t];if(i){if(i[v])break;if(i[h]<B){if(i[v]=1,!E[i.nodeName||""]){var r=i,u=l;a.raf(function(){u&&r&&u[f](r,g),u=r=null})}break}}}}(u),w=i,k.push({t:t,m:n}),++B,c&&c()),N&&a.timeout(R,o?I:L),s=t}function A(){N&&(N=0,e&&r.clearInterval(e),e=null,R(),l[f](S,g))}function D(e){e&&(A(),x[b]||x.push({t:T(),x:0,y:0}),e(M,k,o,x),l&&l[n]())}});
csa.plugin(function(b){var a=b.global,c=a.uet,e=a.uex,f=a.ue,a=a.Object,g=0,h={largestContentfulPaint:"lcp",visuallyLoaded50:"vl50",visuallyLoaded90:"vl90",visuallyLoaded100:"vl100"};b&&c&&e&&a.keys&&f&&(b.once("$ditched.beforemitigation",function(){g=1}),a.keys(h).forEach(function(a){b.on("$timing:"+a,function(b){var d=h[a];if(f.isl||g){var k="csa:"+d;c(d,k,void 0,b);e("at",k)}else c(d,void 0,void 0,b)})}))});


window.rx = { 'rid':'KAS98C370K01G4FPVKFV', 'sid':'147-0099296-5118245', 'c':{  'rxp':'/rd/uedata',  'ml_dl':false }};
</script>
<script>window.ue && ue.count && ue.count('CSMLibrarySize', 20749)</script>
<!-- sp:end-feature:csm:body-open -->
<!-- sp:feature:nav-inline-js -->
<!-- NAVYAAN JS -->

<script type="text/javascript">!function(n){function e(n,e){return{m:n,a:function(n){return[].slice.call(n)}(e)}}document.createElement("header");var r=function(n){function u(n,r,u){n[u]=function(){a._replay.push(r.concat(e(u,arguments)))}}var a={};return a._sourceName=n,a._replay=[],a.getNow=function(n,e){return e},a.when=function(){var n=[e("when",arguments)],r={};return u(r,n,"run"),u(r,n,"declare"),u(r,n,"publish"),u(r,n,"build"),r.depends=n,r.iff=function(){var r=n.concat([e("iff",arguments)]),a={};return u(a,r,"run"),u(a,r,"declare"),u(a,r,"publish"),u(a,r,"build"),a},r},u(a,[],"declare"),u(a,[],"build"),u(a,[],"publish"),u(a,[],"importEvent"),r._shims.push(a),a};r._shims=[],n.$Nav||(n.$Nav=r("rcx-nav")),n.$Nav.make||(n.$Nav.make=r)}(window)</script><script type="text/javascript">
$Nav.importEvent('navbarJS-beaconbelt');
$Nav.declare('img.sprite', {
  'png32': 'https://m.media-shopping.com/images/G/01/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB779528203_.png',
  'png32-2x': 'https://m.media-shopping.com/images/G/01/gno/sprites/nav-sprite-global-2x-reorg-privacy._CB779528203_.png'
});
$Nav.declare('img.timeline', {
  'timeline-icon-2x': 'https://m.media-shopping.com/images/G/01/gno/sprites/timeline_sprite_2x._CB443581191_.png'
});
window._navbarSpriteUrl = 'https://m.media-shopping.com/images/G/01/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB779528203_.png';
$Nav.declare('img.pixel', 'https://m.media-shopping.com/images/G/01/x-locale/common/transparent-pixel._CB485935036_.gif');
</script>

<img src="https://m.media-shopping.com/images/G/01/gno/sprites/nav-sprite-global-1x-reorg-privacy._CB779528203_.png" style="display:none" alt=""/>
<script type="text/javascript">var nav_t_after_preload_sprite = + new Date();</script>
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('navCF').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/51rG04VN8cL._RC|711xEihqxGL.js,41VWJ7fRjuL.js,01QvReFeJyL.js,01kC46b9vjL.js,817-k-6kdXL.js,11C6Xs6tLuL.js,41jBieyCvYL.js,01wXnKULArL.js,01+pnQJuQ0L.js,311S4pZ3B4L.js,51GC3iCVEKL.js,41GvVRH6GqL.js,41LquXcMYDL.js,11lw6J7z8iL.js,31COIUU385L.js,01VYGE8lGhL.js_.js?AUIClients/NavDesktopUberAsset#desktop.language-en.us.1200978-T1.1354727-T1.1354728-T1.1381529-T1.1354730-T1.1354729-T1.1444135-T1.1253326-T1.1463553-T1.1346270-T1');
});
</script>
<!-- sp:end-feature:nav-inline-js -->
<!-- sp:feature:nav-skeleton -->
<!-- sp:end-feature:nav-skeleton -->
<!-- sp:feature:navbar -->

<!--Pilu -->


  <!-- NAVYAAN -->











<!-- navmet initial definition -->



<script type='text/javascript'>
    if(window.navmet===undefined) {
      window.navmet=[];
      if (window.performance && window.performance.timing && window.ue_t0) {
        var t = window.performance.timing;
        var now = + new Date();
        window.navmet.basic = {
          'networkLatency': (t.responseStart - t.fetchStart),
          'navFirstPaint': (now - t.responseStart),
          'NavStart': (now - window.ue_t0)
        };
        window.navmet.push({key:"NavFirstPaintStart",end:+new Date(),begin:window.ue_t0});
      }
    }
    if (window.ue_t0) {
      window.navmet.push({key:"NavMainStart",end:+new Date(),begin:window.ue_t0});
    }
</script>






<script type='text/javascript'>window.navmet.tmp=+new Date();</script>
  <script type='text/javascript'>
    // Nav start should be logged at this place only if request is NOT progressively loaded.
    // For progressive loading case this metric is logged as part of skeleton.
    // Presence of skeleton signals that request is progressively loaded.
    if(!document.getElementById("navbar-skeleton")) {
      window.uet && uet('ns');
    }
    window._navbar = (function (o) {
      o.componentLoaded = o.loading = function(){};
      o.browsepromos = {};
      o.issPromos = [];
      return o;
    }(window._navbar || {}));
    window._navbar.declareOnLoad = function () { window.$Nav && $Nav.declare('page.load'); };
    if (window.addEventListener) {
      window.addEventListener("load", window._navbar.declareOnLoad, false);
    } else if (window.attachEvent) {
      window.attachEvent("onload", window._navbar.declareOnLoad);
    } else if (window.$Nav) {
      $Nav.when('page.domReady').run("OnloadFallbackSetup", function () {
        window._navbar.declareOnLoad();
      });
    }
    window.$Nav && $Nav.declare('config.lightningDeals', {});
  </script>

    <style mark="aboveNavInjectionCSS" type="text/css">
       #nav-flyout-ewc .nav-flyout-buffer-left { display: none; } #nav-flyout-ewc .nav-flyout-buffer-right { display: none; } div#navSwmHoliday.nav-focus {border: none;margin: 0;}
    </style>
    <script mark="aboveNavInjectionJS" type="text/javascript">
      try {
        if(window.navmet===undefined)window.navmet=[]; if(window.$Nav) { $Nav.when('$', 'config', 'flyout.accountList', 'SignInRedirect', 'dataPanel').run('accountListRedirectFix', function ($, config, flyout, SignInRedirect, dataPanel) { if (!config.accountList) { return; } flyout.getPanel().onData(function (data) { if (SignInRedirect) { var $anchors = $('[data-nav-role=signin]', flyout.elem()); $.each($anchors, function(i, anchorEl) {SignInRedirect.setRedirectUrl($(anchorEl), null, null);});}});}); $Nav.when('$').run('defineIsArray', function(jQuery) { if(jQuery.isArray===undefined) { jQuery.isArray=function(param) { if(param.length===undefined) { return false; } return true; }; } }); $Nav.declare('config.cartFlyoutDisabled', 'true'); $Nav.when('$','$F','config','logEvent','panels','phoneHome','dataPanel','flyouts.renderPromo','flyouts.sloppyTrigger','flyouts.accessibility','util.mouseOut','util.onKey','debug.param').build('flyouts.buildSubPanels',function($,$F,config,logEvent,panels,phoneHome,dataPanel,renderPromo,createSloppyTrigger,a11yHandler,mouseOutUtility,onKey,debugParam){var flyoutDebug=debugParam('navFlyoutClick');return function(flyout,event){var linkKeys=[];$('.nav-item',flyout.elem()).each(function(){var $item=$(this);linkKeys.push({link:$item,panelKey:$item.attr('data-nav-panelkey')});});if(linkKeys.length===0){return;} var visible=false;var $parent=$('<div class=\'nav-subcats\'></div>').appendTo(flyout.elem());var panelGroup=flyout.getName()+'SubCats';var hideTimeout=null;var sloppyTrigger=createSloppyTrigger($parent);var showParent=function(){if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;} if(visible){return;} var height=$('#nav-flyout-shopAll').height(); $parent.css({'height': height});$parent.animate({width:'show'},{duration:200,complete:function(){$parent.css({overflow:'visible'});}});visible=true;};var hideParentNow=function(){$parent.stop().css({overflow:'hidden',display:'none',width:'auto',height:'auto'});panels.hideAll({group:panelGroup});visible=false;if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;}};var hideParent=function(){if(!visible){return;} if(hideTimeout){clearTimeout(hideTimeout);hideTimeout=null;} hideTimeout=setTimeout(hideParentNow,10);};flyout.onHide(function(){sloppyTrigger.disable();hideParentNow();this.elem().hide();});var addPanel=function($link,panelKey){var panel=dataPanel({className:'nav-subcat',dataKey:panelKey,groups:[panelGroup],spinner:false,visible:false});if(!flyoutDebug){var mouseout=mouseOutUtility();mouseout.add(flyout.elem());mouseout.action(function(){panel.hide();});mouseout.enable();} var a11y=a11yHandler({link:$link,onEscape:function(){panel.hide();$link.focus();}});var logPanelInteraction=function(promoID,wlTriggers){var logNow=$F.once().on(function(){var panelEvent=$.extend({},event,{id:promoID});if(config.browsePromos&&!!config.browsePromos[promoID]){panelEvent.bp=1;} logEvent(panelEvent);phoneHome.trigger(wlTriggers);});if(panel.isVisible()&&panel.hasInteracted()){logNow();}else{panel.onInteract(logNow);}};panel.onData(function(data){renderPromo(data.promoID,panel.elem());logPanelInteraction(data.promoID,data.wlTriggers);});panel.onShow(function(){var columnCount=$('.nav-column',panel.elem()).length;panel.elem().addClass('nav-colcount-'+columnCount);showParent();var $subCatLinks=$('.nav-subcat-links > a',panel.elem());var length=$subCatLinks.length;if(length>0){var firstElementLeftPos=$subCatLinks.eq(0).offset().left;for(var i=1;i<length;i++){if(firstElementLeftPos===$subCatLinks.eq(i).offset().left){$subCatLinks.eq(i).addClass('nav_linestart');}} if($('span.nav-title.nav-item',panel.elem()).length===0){var catTitle=$.trim($link.html());catTitle=catTitle.replace(/ref=sa_menu_top/g,'ref=sa_menu');var $subPanelTitle=$('<span class=\'nav-title nav-item\'>'+ catTitle+'</span>');panel.elem().prepend($subPanelTitle);}} $link.addClass('nav-active');});panel.onHide(function(){$link.removeClass('nav-active');hideParent();a11y.disable();sloppyTrigger.disable();});panel.onShow(function(){a11y.elems($('a, area',panel.elem()));});sloppyTrigger.register($link,panel);if(flyoutDebug){$link.click(function(){if(panel.isVisible()){panel.hide();}else{panel.show();}});} var panelKeyHandler=onKey($link,function(){if(this.isEnter()||this.isSpace()){panel.show();}},'keydown',false);$link.focus(function(){panelKeyHandler.bind();}).blur(function(){panelKeyHandler.unbind();});panel.elem().appendTo($parent);};var hideParentAndResetTrigger=function(){hideParent();sloppyTrigger.disable();};for(var i=0;i<linkKeys.length;i++){var item=linkKeys[i];if(item.panelKey){addPanel(item.link,item.panelKey);}else{item.link.mouseover(hideParentAndResetTrigger);}}};});};
      } catch ( err ) {
        if ( window.$Nav ) {
          window.$Nav.when('metrics', 'logUeError').run(function(metrics, log) {
            metrics.increment('NavJS:AboveNavInjection:error');
            log(err.toString(), {
              'attribution': 'rcx-nav',
              'logLevel': 'FATAL'
            });
          });
        }
      }
    </script>

  <noscript>
    <style type="text/css"><!--
      #navbar #nav-shop .nav-a:hover {
        color: #ff9900;
        text-decoration: underline;
      }
      #navbar #nav-search .nav-search-facade,
      #navbar #nav-tools .nav-icon,
      #navbar #nav-shop .nav-icon,
      #navbar #nav-subnav .nav-hasArrow .nav-arrow {
        display: none;
      }
      #navbar #nav-search .nav-search-submit,
      #navbar #nav-search .nav-search-scope {
        display: block;
      }
      #nav-search .nav-search-scope {
        padding: 0 5px;
      }
      #navbar #nav-search .nav-search-dropdown {
        position: relative;
        top: 5px;
        height: 23px;
        font-size: 14px;
        opacity: 1;
        filter: alpha(opacity = 100);
      }
    --></style>
 </noscript>
<script type='text/javascript'>window.navmet.push({key:'PreNav',end:+new Date(),begin:window.navmet.tmp});</script>

<a id='nav-top'></a>





  
<nav
  id="shortcut-menu"
  class="nav-assistant"
  aria-label="Shortcuts menu"
  tabindex="-1"
  role="navigation" 
  
  data-skip-link-target-text="Main content start"
  data-hashed-id=""
data-raw-id=""
>
  <h2 id="nav-assistant-links-heading" class="nav-assistant-heading nav-assistant-headers-font">Skip to</h2>
  <ul aria-labelledby="nav-assistant-links-heading" class="nav-assistant-links-container">
    <li class="nav-assistant-list-item ">
      <a
        href="#skippedLink"
        id="nav-assist-skip-to-main-content"
        aria-label="main content"
        aria-describedby="nav-assist-shortcut-help"
        tabindex="0"
        data-target="#skippedLink"
        data-scrolltarget=""
        data-behavior="navigate"
        
        
        data-nav-assist-menu-item-index="0"
        class="nav-assistant-link nav-assistant-menu-item nav-assistant-link-item a-color-base a-color-link "
      >
        Main content
      </a>
    </li>
  </ul>
  <hr class="nav-assistant-separator" aria-hidden="true" />
  <h2 id="nav-assist-shortcuts-heading" class="nav-assistant-heading nav-assistant-headers-font font-color aok-hidden">
      Keyboard shortcuts
  </h2>
  <ul class="keyboard-shortcuts-list-container aok-hidden" id="nav-assist-shortcuts-container" aria-labelledby="nav-assist-shortcuts-heading">
    <li class="nav-assistant-list-item">
      <a
        href="javascript:void(0)"
        id="nav-assist-search"
        role="link"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link "
        data-nav-assist-menu-item-index="1"
        data-behavior="navigate"
        
        data-actuators="[{&quot;eventCode&quot;:&quot;Slash&quot;,&quot;eventKey&quot;:&quot;÷&quot;,&quot;isShiftRequired&quot;:false},{&quot;eventCode&quot;:&quot;Digit7&quot;,&quot;eventKey&quot;:&quot;\\&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventCode&quot;:&quot;Period&quot;,&quot;eventKey&quot;:&quot;\\&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventCode&quot;:&quot;Slash&quot;,&quot;eventKey&quot;:&quot;/&quot;,&quot;isShiftRequired&quot;:false},{&quot;eventCode&quot;:&quot;Digit7&quot;,&quot;eventKey&quot;:&quot;/&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventCode&quot;:&quot;Period&quot;,&quot;eventKey&quot;:&quot;/&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;/&quot;,&quot;isShiftRequired&quot;:false}]"
        data-target="#twotabsearchtextbox"
        data-modal-ignore=""
        aria-label="Search, alt, forward slash"
        aria-describedby="nav-assist-shortcut-help"
      >
        <div class="keyboard-shortcut-container" aria-hidden="true">
          <span class="shortcut-name nav-assistant-card-font">Search</span>
          <div class="shortcut-keys-container" dir="ltr">
              <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">/</span>
              
          </div>
        </div>
      </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="javascript:void(0)"
        id="nav-assist-cart"
        role="link"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link "
        data-nav-assist-menu-item-index="2"
        data-behavior="navigate"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;Ç&quot;,&quot;eventCode&quot;:&quot;KeyC&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;¢&quot;,&quot;eventCode&quot;:&quot;KeyC&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;C&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="/gp/cart/view.html/?ref_&#x3D;nav_assist"
        data-modal-ignore=""
        aria-label="Cart, shift, alt, c"
        aria-describedby="nav-assist-shortcut-help"
      >
        <div class="keyboard-shortcut-container" aria-hidden="true">
          <span class="shortcut-name nav-assistant-card-font">Cart</span>
          <div class="shortcut-keys-container" dir="ltr">
              <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">C</span>
              
          </div>
        </div>
      </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="javascript:void(0)"
        id="nav-assist-home"
        role="link"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link "
        data-nav-assist-menu-item-index="3"
        data-behavior="navigate"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;Ó&quot;,&quot;eventCode&quot;:&quot;KeyH&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Î&quot;,&quot;eventCode&quot;:&quot;KeyH&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;˘&quot;,&quot;eventCode&quot;:&quot;KeyH&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;H&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="/?ref_&#x3D;nav_assist"
        data-modal-ignore=""
        aria-label="Home, shift, alt, h"
        aria-describedby="nav-assist-shortcut-help"
      >
        <div class="keyboard-shortcut-container" aria-hidden="true">
          <span class="shortcut-name nav-assistant-card-font">Home</span>
          <div class="shortcut-keys-container" dir="ltr">
              <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">H</span>
              
          </div>
        </div>
      </a>
    </li>
    <li class="nav-assistant-list-item">
      <a
        href="javascript:void(0)"
        id="nav-assist-your-orders"
        role="link"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link "
        data-nav-assist-menu-item-index="4"
        data-behavior="navigate"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;Ø&quot;,&quot;eventCode&quot;:&quot;KeyO&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Œ&quot;,&quot;eventCode&quot;:&quot;KeyO&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;O&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="/gp/css/order-history/?ref_&#x3D;nav_assist"
        data-modal-ignore=""
        aria-label="Your orders, shift, alt, o"
        aria-describedby="nav-assist-shortcut-help"
      >
        <div class="keyboard-shortcut-container" aria-hidden="true">
          <span class="shortcut-name nav-assistant-card-font">Orders</span>
          <div class="shortcut-keys-container" dir="ltr">
              <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">O</span>
              
          </div>
        </div>
      </a>
    </li>
    <li class="nav-assistant-list-item">
      <button
        id="nav-assist-show-shortcuts"
        role="button"
        tabindex="-1"
        class="nav-assistant-menu-item nav-assistant-link-item nav-assistant-keyboard-shortcut-item keyboard-shortcut-menu-container a-color-base a-color-link nav-assistant-link-button"
        data-nav-assist-menu-item-index="5"
        data-behavior="show-hide"
        
        data-actuators="[{&quot;eventKey&quot;:&quot;¸&quot;,&quot;eventCode&quot;:&quot;KeyZ&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;ˇ&quot;,&quot;eventCode&quot;:&quot;KeyY&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Å&quot;,&quot;eventCode&quot;:&quot;KeyW&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;⁄&quot;,&quot;eventCode&quot;:&quot;KeyZ&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Z&quot;,&quot;eventCode&quot;:&quot;KeyZ&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Z&quot;,&quot;eventCode&quot;:&quot;KeyY&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Z&quot;,&quot;eventCode&quot;:&quot;KeyW&quot;,&quot;isShiftRequired&quot;:true},{&quot;eventKey&quot;:&quot;Z&quot;,&quot;isShiftRequired&quot;:true}]"
        data-target="a[data-nav-assist-menu-item-index&#x3D;&quot;0&quot;]"
        data-modal-ignore=""
        aria-label="Show/hide shortcuts, shift, alt, z"
        aria-describedby="nav-assist-shortcut-help"
      >
        <div class="keyboard-shortcut-container" aria-hidden="true">
          <span class="shortcut-name nav-assistant-card-font">Show/Hide shortcuts</span>
          <div class="shortcut-keys-container" dir="ltr">
              <span class="shortcut-key nav-assistant-card-font font-color">shift</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">alt</span>
              <span class="plus-sign-color">+</span>
              <span class="shortcut-key nav-assistant-card-font font-color">Z</span>
              
          </div>
        </div>
      </button>
    </li>
  </ul>
  <div
    id="nav-assist-shortcut-help"
    class="aok-hidden"
  >
    <div class="shortcut-help-container">
      <div class="shortcut-help-item-container">
        <div class="icon-container"><i class="a-icon a-icon-info a-icon-mini shortcut-help-icon"></i></div>
        <div class="help-text-container">
          <span class="shortcut-help-text font-color">To move between items, use your keyboard&#x27;s up or down arrows.</span>
        </div>
      </div>
    </div>
  </div>
</nav>





<script type='text/javascript'>window.navmet.main=+new Date();</script>


<style type="text/css">:root { --nav-desktop-header-tbg: #131921; --nav-desktop-header-bbg: #232f3e; --nav-go-button-bg: #febd69; --nav-go-button-hbg: #f3a847; --nav-search-border-shadow: #ff9900; --nav-search-scope: #e6e6e6; --nav-search-scope-hover: #d4d4d4; --nav-x-shop-links: #fff; --nav-x-shop-links-active: #ccc; --nav-cart-count: #f08804; --nav-dropdown-arrows: #a7acb2; --nav-search-labels: #fff; }</style><style type="text/css">#navbar-main #navbar #nav-belt { background: #131921; } #navbar-main #navbar #nav-main { background: #232f3e; } #navbar-main #navbar .nav-a-2 .nav-line-1, .nav-a-2 .nav-line-2, #nav-search-label { color: #fff; } #navbar-main #navbar #nav-cart-count, #nav-ewc-cart-count { color: #f08804; top: 7px; } #navbar-main #navbar #nav-search { .nav-search-scope { background-color: #e6e6e6; border-left: 1px solid #e6e6e6; border-top: 1px solid #e6e6e6; border-bottom: 1px solid #e6e6e6; } .nav-search-scope:hover, .nav-search-scope:focus, .nav-search-scope.nav-focus { background-color: #d4d4d4; border-left-color: #d4d4d4; border-top-color: #d4d4d4; border-bottom-color: #d4d4d4; } .nav-searchbar.nav-active, .nav-searchbar.nav-focus { box-shadow: 0 0 0 2px #ff9900, 0 0 0 3px rgba(255, 153, 0, 0.5); z-index: 1; } .nav-searchbar.nav-active .nav-search-scope, .nav-searchbar.nav-focus .nav-search-scope, .nav-searchbar.nav-active .nav-search-field, .nav-searchbar.nav-focus .nav-search-field { border-top: 1px solid #febd69; border-bottom: 1px solid #febd69; } .nav-searchbar.nav-active .nav-search-scope, .nav-searchbar.nav-focus .nav-search-scope { border-left: 1px solid #febd69; } .nav-search-submit { background-color: #febd69; } .nav-search-submit:hover, .nav-search-submit:focus, .nav-search-submit.nav-focus { background-color: #f3a847; } } #navbar-main #navbar .nav-icon.nav-arrow { border-top-color: #a7acb2; } #navbar-main #navbar .nav-icon-flipped.nav-arrow { border-bottom-color: #a7acb2; } #navbar-main #navbar #nav-flyout-ewc .nav-flyout-head { background-color: #232f3e; } #navbar-main #navbar #nav-logo-borderfade .nav-fade-mask { background-color: #232f3e; width: 195px; }</style>
<header id="navbar-main" class = "nav-opt-sprite nav-flex nav-locale-us nav-lang-en nav-ssl nav-unrec nav-progressive-attribute">

   
  <div id='navbar' cel_widget_id='Navigation-desktop-navbar'
  role='navigation' class="nav-sprite-v1 celwidget nav-bluebeacon bold-focus-hover layout2 nav-flex layout3 layout3-alt nav-packard-glow hamburger nav-progressive-attribute" aria-label="Primary">
    <div id='nav-belt'>
      <div class='nav-left'>
        <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
  <div id="nav-logo" >
    <a href="/ref=nav_logo" id="nav-logo-sprites" class="nav-logo-link nav-progressive-attribute" aria-label="Amazon" lang="en" >
      <span class="nav-sprite nav-logo-base"></span>
      <span id="logo-ext" class="nav-sprite nav-logo-ext nav-progressive-content"></span>
      <span class="nav-logo-locale">.us</span>
    </a>
  </div>
<script type='text/javascript'>window.navmet.push({key:'Logo',end:+new Date(),begin:window.navmet.tmp});</script>
        
<div id="nav-global-location-slot" data-csa-c-type="widget" data-csa-c-slot-id="GLOW-desktop-nav" data-csa-c-content-id="nav-glow">
    <span id="nav-global-location-data-modal-action" class="a-declarative nav-progressive-attribute" data-a-modal='{&quot;width&quot;:375, &quot;closeButton&quot;:&quot;true&quot;,&quot;popoverLabel&quot;:&quot;Choose your location&quot;, &quot;ajaxHeaders&quot;:{&quot;anti-csrftoken-a2z&quot;:&quot;hDlcXcqZh/Y3PK7Gqg3Fz/SBhEUYZyVB4+xiw96rRilWAAAAAGrOCygAAAAB&quot;}, &quot;name&quot;:&quot;glow-modal&quot;, &quot;url&quot;:&quot;/portal-migration/hz/glow/get-rendered-address-selections?deviceType&#x3D;desktop&amp;pageType&#x3D;AmazonStores&amp;storeContext&#x3D;NoStoreName&amp;actionSource&#x3D;desktop-modal&quot;, &quot;footer&quot;:&quot;&lt;span class&#x3D;\&quot;a-declarative\&quot; data-action&#x3D;\&quot;a-popover-close\&quot; data-a-popover-close&#x3D;\&quot;{}\&quot;&gt;&lt;span class&#x3D;\&quot;a-button a-button-primary\&quot;&gt;&lt;span class&#x3D;\&quot;a-button-inner\&quot;&gt;&lt;button name&#x3D;\&quot;glowDoneButton\&quot; class&#x3D;\&quot;a-button-text\&quot; type&#x3D;\&quot;button\&quot;&gt;Done&lt;/button&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;&quot;,&quot;header&quot;:&quot;Choose your location&quot;}' data-action="a-modal">
        <a id="nav-global-location-popover-link" role="button" tabindex="0" class="nav-a nav-a-2 a-popover-trigger a-declarative nav-progressive-attribute" href="">
            <div class="nav-sprite nav-progressive-attribute" id="nav-packard-glow-loc-icon"></div>
            <div id="glow-ingress-block">
                <span class="nav-line-1 nav-progressive-content" id="glow-ingress-line1">
                   Deliver to
                </span>
                <span class="nav-line-2 nav-progressive-content" id="glow-ingress-line2">
                   Ghana
                </span>
            </div>
        </a>
        </span>
        <input data-addnewaddress="add-new" id="unifiedLocation1ClickAddress" name="dropdown-selection" type="hidden" value="add-new" class="nav-progressive-attribute" />
        <input data-addnewaddress="add-new" id="ubbShipTo" name="dropdown-selection-ubb" type="hidden" value="add-new" class="nav-progressive-attribute"/>
        <input id="glowValidationToken" name="glow-validation-token" type="hidden" value="hDlcXcqZh/Y3PK7Gqg3Fz/SBhEUYZyVB4+xiw96rRilWAAAAAGrOCygAAAAB" class="nav-progressive-attribute"/>
        <input id="glowDestinationType" name="glow-destination-type" type="hidden" value="COUNTRY" class="nav-progressive-attribute"/>
</div>

<div id="nav-global-location-toaster-script-container" class="nav-progressive-content">
    <!-- NAVYAAN-GLOW-NAV-TOASTER -->
          <script>
              P.when('glow-toaster-strings').execute(function(S) {
                S.load({"glow-toaster-address-change-error":"An error has occurred and the address has not been updated. Please try again.","glow-toaster-unknown-error":"An error has occurred. Please try again."});
             });
          </script>
          <script>
              P.when('glow-toaster-manager').execute(function(M) {
                M.create({"pageType":"AmazonStores","aisTransitionState":null,"rancorLocationSource":"IP_GEOLOCATION","isB2B":false})
              });
          </script>
</div>

      </div>
          <div class='nav-fill' id='nav-fill-search'>
            <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
<div id="nav-search">
  <div id="nav-bar-left"></div> 
  <form
    id="nav-search-bar-form"
    accept-charset="utf-8"
    action="/s/ref=nb_sb_noss"
    class="nav-searchbar nav-progressive-attribute"
    method="GET"
    name="site-search"
    role="search"
  >

    <div class="nav-left">
      <div id="nav-search-dropdown-card">
        
  <div class="nav-search-scope nav-sprite">
    <div class="nav-search-facade" data-value="search-alias=aps">
      <span id="nav-search-label-id" class="nav-search-label nav-progressive-content">All</span>
      <i class="nav-icon"></i>
    </div>
    <label id="searchDropdownDescription" for="searchDropdownBox" class="nav-progressive-attribute" style="display:none">Select the department you want to search in</label>
    <select
      aria-describedby="searchDropdownDescription"
      class="nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown"
      data-nav-digest="k+fyIAyB82R9jVEmroQ0OWwSW3A="
      data-nav-selected="0"
      id="searchDropdownBox"
      name="url"
      style="display: block;"
      tabindex="0"
      title="Search in"
    >
        <option selected="selected" value="search-alias=aps">All Departments</option>
        <option value="search-alias=arts-crafts-intl-ship">Arts & Crafts</option>
        <option value="search-alias=automotive-intl-ship">Automotive</option>
        <option value="search-alias=baby-products-intl-ship">Baby</option>
        <option value="search-alias=beauty-intl-ship">Beauty & Personal Care</option>
        <option value="search-alias=stripbooks-intl-ship">Books</option>
        <option value="search-alias=fashion-boys-intl-ship">Boys' Fashion</option>
        <option value="search-alias=computers-intl-ship">Computers</option>
        <option value="search-alias=deals-intl-ship">Deals</option>
        <option value="search-alias=digital-music">Digital Music</option>
        <option value="search-alias=electronics-intl-ship">Electronics</option>
        <option value="search-alias=fashion-girls-intl-ship">Girls' Fashion</option>
        <option value="search-alias=hpc-intl-ship">Health & Household</option>
        <option value="search-alias=kitchen-intl-ship">Home & Kitchen</option>
        <option value="search-alias=industrial-intl-ship">Industrial & Scientific</option>
        <option value="search-alias=digital-text">Kindle Store</option>
        <option value="search-alias=luggage-intl-ship">Luggage</option>
        <option value="search-alias=fashion-mens-intl-ship">Men's Fashion</option>
        <option value="search-alias=movies-tv-intl-ship">Movies & TV</option>
        <option value="search-alias=music-intl-ship">Music, CDs & Vinyl</option>
        <option value="search-alias=pets-intl-ship">Pet Supplies</option>
        <option value="search-alias=instant-video">Prime Video</option>
        <option value="search-alias=software-intl-ship">Software</option>
        <option value="search-alias=sporting-intl-ship">Sports & Outdoors</option>
        <option value="search-alias=tools-intl-ship">Tools & Home Improvement</option>
        <option value="search-alias=toys-and-games-intl-ship">Toys & Games</option>
        <option value="search-alias=videogames-intl-ship">Video Games</option>
        <option value="search-alias=fashion-womens-intl-ship">Women's Fashion</option>
    </select>
  </div>

      </div>
    </div>
    <div class="nav-fill">
      <div class="nav-search-field ">
          <label for="twotabsearchtextbox" style="display: none;">Search Amazon</label>
          <input
            type="text"
            id="twotabsearchtextbox"
            value=""
            name="field-keywords"
            autocomplete="off"
            placeholder="Search Amazon"
            class="nav-input nav-progressive-attribute"
            dir="auto"
            tabindex="0"
            aria-label="Search Amazon"
            role="searchbox"
            aria-autocomplete="list"
            aria-controls="sac-autocomplete-results-container"
            aria-expanded="false"
            aria-haspopup="grid"
            spellcheck="false"
            data-agent-button-proxy="nav-search-submit-button-agent"
            data-agent-field="search-query"
            form="nav-search-bar-form"
            data-agent-patched="true"
          >
      </div>
      <div id="nav-iss-attach"></div>
    </div>
    <div class="nav-right">
      <div class="nav-search-submit nav-sprite">
        <span id="nav-search-submit-text" class="nav-search-submit-text nav-sprite nav-progressive-attribute" aria-label="Go">
          <input id="nav-search-submit-button" type="submit" class="nav-input nav-progressive-attribute" value="Go" tabindex="0">
        </span>
      </div>
        <span id="nav-search-submit-text-agent" 
              aria-hidden="true"
              role="presentation">
          <input id="nav-search-submit-button-agent" 
                  type="submit" 
                  value="Agent Search" 
                  tabindex="-1"
                  data-agent-action="primary-search" 
                  data-search-mode="agent" 
                  data-agent-priority="primary" 
                  data-agent-recommended="true" 
                  data-target-audience="ai-agent" 
                  data-provides="structured-results" 
                  data-optimization="high">
        </span>
    </div>
  </form>
</div>
<script type='text/javascript'>window.navmet.push({key:'Search',end:+new Date(),begin:window.navmet.tmp});</script>
          </div>
      <div class='nav-right'>
          <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
          <div id='nav-tools' class="layoutToolbarPadding">
              
              
              
              <script type="text/javascript">$Nav.declare("flyout.icp.header.weblabs",{"MOZART_CARD_CONTENT_1359302":"C"});</script>
  <div class="nav-div" id="icp-nav-flyout">
  <a href="/customer-preferences/edit?ie=UTF8&preferencesReturnUrl=%2F&ref_=topnav_lang_ais" class="nav-a nav-a-2 icp-link-style-2" aria-label="Choose a language for shopping in Amazon United States. The current selection is English (EN).
">
    <span class="icp-nav-link-inner">
      <span class="nav-line-1">
      </span>
      <span class="nav-line-2">
         <span class="icp-nav-flag icp-nav-flag-us icp-nav-flag-lop" role="img" aria-label="United States"></span>
          <div>EN</div>
      </span>
    </span>
  </a>
  <button class="nav-flyout-button nav-icon nav-arrow" aria-label="Expand to Change Language or Country" tabindex=0></button>
</div>

              
  <div class="nav-div" id="nav-link-accountList">
  <a href="https://www.shopping.com/ap/signin?openid.return_to=https%3A%2F%2Fwww.shopping.com%2Fstores%2FRazer%2Fpage%2FCDB96030-A7CF-4B56-B70C-67086A740274%2F%3F_encoding%3DUTF8%26lp_asin%3DB0FDPJZQNY%26store_ref%3Dbl_ast_dp_brandlogo_sto%26ref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0" class="nav-a nav-a-2   nav-progressive-attribute" data-nav-ref="nav_ya_signin"  data-nav-role="signin" data-ux-jq-mouseenter="true" tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav-link-accountList" data-csa-c-content-id="nav_ya_signin"  aria-controls="nav-flyout-accountList" >
  <div class="nav-line-1-container"><span id="nav-link-accountList-nav-line-1" class="nav-line-1 nav-progressive-content">Hello, sign in</span></div>
  <span class="nav-line-2 ">Account & Lists
  </span>
  </a>
  <button class="nav-flyout-button nav-icon nav-arrow" aria-label="Expand Account and Lists" tabindex=0></button>
  </div>

              
<a href="/gp/css/order-history?ref_=nav_orders_first" class="nav-a nav-a-2   nav-progressive-attribute" id="nav-orders" tabindex="0">
  <span class="nav-line-1">Returns</span>
  <span class="nav-line-2">& Orders<span class="nav-icon nav-arrow"></span></span>
</a>

              
              
  <a href="/gp/cart/view.html?ref_=nav_cart" aria-label="4 items in cart" class="nav-a nav-a-2 nav-progressive-attribute" id="nav-cart">
    <div id="nav-cart-count-container">
      <span id="nav-cart-count" aria-hidden="true" class="nav-cart-count nav-cart-1 nav-progressive-attribute nav-progressive-content">4</span>
      <span class="nav-cart-icon nav-sprite"></span>
    </div>
    <div id="nav-cart-text-container" class=" nav-progressive-attribute">
      <span aria-hidden="true" class="nav-line-1">
        
      </span>
      <span aria-hidden="true" class="nav-line-2">
        Cart
        <span class="nav-icon nav-arrow"></span>
      </span>
    </div>
  </a>

          </div>
          <script type='text/javascript'>window.navmet.push({key:'Tools',end:+new Date(),begin:window.navmet.tmp});</script>

      </div>
    </div>
    <div id='nav-belt-search' class='nav-fill'></div>
    <div id='nav-main' class='nav-sprite'>
      <div class='nav-left'>
        <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
  <a href="/gp/site-directory?ref_=nav_em_js_disabled" id="nav-hamburger-menu" role="button" aria-label="Open All Categories Menu" aria-expanded="false" data-csa-c-type="widget" data-csa-c-slot-id="HamburgerMenuDesktop"
  data-csa-c-interaction-events="click" >
    <i class="hm-icon nav-sprite"></i>
    <span class="hm-icon-label">All</span>
  </a>
  
<script type="text/javascript">
  var hmenu = document.getElementById("nav-hamburger-menu");
  hmenu.setAttribute("href", "javascript: void(0)");
  window.navHamburgerMetricLogger = function() {
    if (window.ue && window.ue.count) {
      var metricName = "Nav:Hmenu:IconClickActionPending";
      window.ue.count(metricName, (ue.count(metricName) || 0) + 1);
    }
    window.$Nav && $Nav.declare("navHMenuIconClicked",!0);
    window.$Nav && $Nav.declare("navHMenuIconClickedNotReadyTimeStamp", Date.now());
  };
  hmenu.addEventListener("click", window.navHamburgerMetricLogger);
  window.$Nav && $Nav.declare('hamburgerMenuIconAvailableOnLoad', false);
</script>  
<script type='text/javascript'>window.navmet.push({key:'HamburgerMenuIcon',end:+new Date(),begin:window.navmet.tmp});</script>
        
            
        
        
      </div>
      <div class='nav-fill'>
        
 <div id="nav-shop">
 </div>
        <div id='nav-xshop-container'>
          <div id='nav-xshop' class="nav-progressive-content">
            <script type='text/javascript'>window.navmet.tmp=+new Date();</script>
  <ul class="nav-ul">
      
<li class="nav-li">
<div class="nav-div">
<a href="/Amazon-Video/b/?ie=UTF8&node=2858778011&ref_=nav_cs_prime_video" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_0" data-csa-c-content-id="nav_cs_prime_video">Prime Video</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/coupons?ref_=nav_cs_coupons" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_1" data-csa-c-content-id="nav_cs_coupons">Coupons</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/gp/help/customer/display.html?nodeId=508510&ref_=nav_cs_customerservice" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_2" data-csa-c-content-id="nav_cs_customerservice">Customer Service</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/gp/goldbox?ref_=nav_cs_gb" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_3" data-csa-c-content-id="nav_cs_gb">Today's Deals</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/gp/browse.html?node=16115931011&ref_=nav_cs_registry" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_4" data-csa-c-content-id="nav_cs_registry">Registry</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/gift-cards/b/?ie=UTF8&node=2238192011&ref_=nav_cs_gc" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_5" data-csa-c-content-id="nav_cs_gc">Gift Cards</a>
</div>
</li>


<li class="nav-li">
<div class="nav-div">
<a href="/b/?_encoding=UTF8&ld=AZUSSOA-sell&node=12766669011&ref_=nav_cs_sell" class="nav-a  " tabindex="0" data-csa-c-type="link" data-csa-c-slot-id="nav_cs_6" data-csa-c-content-id="nav_cs_sell">Sell</a>
</div>
</li>


<a href="/gp/help/customer/accessibility" aria-label="Click to call our Disability Customer Support line, or reach us directly at 1-888-283-1678" class="nav-hidden-aria  " tabindex="0"  data-csa-c-type="link" data-csa-c-slot-id="nav_cs_7" >Disability Customer Support</a>

  </ul>
  <script type='text/javascript'>window.navmet.push({key:'CrossShop',end:+new Date(),begin:window.navmet.tmp});</script>
          </div>
        </div>
      </div>
      <div class='nav-right'>
        <script type='text/javascript'>window.navmet.tmp=+new Date();</script><!-- Navyaan SWM -->
<div id="nav-swmslot">
  <!-- Scheduled SWM widget failed to render -->
</div><script type='text/javascript'>window.navmet.push({key:'SWM',end:+new Date(),begin:window.navmet.tmp});</script>
        
      </div>
    </div>

    <div id='nav-subnav-toaster'></div>

    
    <div id="nav-progressive-subnav">
      
    </div>

    
  </div>

  
  

</header>


<script type='text/javascript'>window.navmet.push({key:'NavBar',end:+new Date(),begin:window.navmet.main});</script>


<script type="text/javascript">
  if (window.ue_t0) {
    window.navmet.push({key:"NavMainPaintEnd",end:+new Date(),begin:window.ue_t0});
    window.navmet.push({key:"NavFirstPaintEnd",end:+new Date(),begin:window.ue_t0});
  }
</script>


<script type='text/javascript'>
    <!--
    window.$Nav && $Nav.declare('config.fixedBarBeacon',false);
    window.$Nav && $Nav.when("data").run(function(data) { data({"freshTimeout":{"template":{"name":"flyoutError","data":{"error":{"title":"<style>#nav-flyout-fresh{width:269px;padding:0;}#nav-flyout-fresh .nav-flyout-content{padding:0;}</style><a href='/amazonfresh'><img src='https://images-na.ssl-images-shopping.com/images/G/01/omaha/images/yoda/flyout_72dpi._V270255989_.png' /></a>"}}}},"cartTimeout":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Cart","url":"/gp/cart/view.html?ref_=nav_err_cart_timeout"},"title":"Oops!","paragraph":"Unable to retrieve your cart."}}}},"primeTimeout":{"template":{"name":"flyoutError","data":{"error":{"title":"<a href='/gp/prime'><img src='https://images-na.ssl-images-shopping.com/images/G/01/prime/piv/YourPrimePIV_fallback_CTA._V327346943_.jpg' /></a>"}}}},"ewcTimeout":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Cart","url":"/gp/cart/view.html?ref_=nav_err_ewc_timeout"},"title":"Oops!","paragraph":"There's a problem loading your cart right now."}}}},"errorWishlist":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Wishlist","url":"/gp/registry/wishlist/?ref_=nav_err_wishlist"},"title":"Oops!","paragraph":"Unable to retrieve your wishlist"}}}},"emptyWishlist":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Wishlist","url":"/gp/registry/wishlist/?ref_=nav_err_empty_wishlist"},"title":"Oops!","paragraph":"Your list is empty"}}}},"yourAccountContent":{"template":{"name":"flyoutError","data":{"error":{"button":{"text":"Your Account","url":"/gp/css/homepage.html?ref_=nav_err_youraccount"},"title":"Oops!","paragraph":"Unable to retrieve your account"}}}},"shopAllTimeout":{"template":{"name":"flyoutError","data":{"error":{"paragraph":"Unable to retrieve departments, please try again later"}}}},"kindleTimeout":{"template":{"name":"flyoutError","data":{"error":{"paragraph":"Unable to retrieve list, please try again later"}}}}}); });
window.$Nav && $Nav.when("util.templates").run("FlyoutErrorTemplate", function(templates) {
      templates.add("flyoutError", "<# if(error.title) { #><span class='nav-title'><#=error.title #></span><# } #><# if(error.paragraph) { #><p class='nav-paragraph'><#=error.paragraph #></p><# } #><# if(error.button) { #><a href='<#=error.button.url #>' class='nav-action-button' ><span class='nav-action-inner'><#=error.button.text #></span></a><# } #>");
    });

    if (typeof uet == 'function') {
    uet('bb', 'iss-init-pc', {wb: 1});
  }
  if (!window.$SearchJS && window.$Nav) {
    window.$SearchJS = $Nav.make('sx');
  }

  var opts = {
    host: "completion.shopping.com/search/complete"
  , marketId: "1"
  , obfuscatedMarketId: "ATVPDKIKX0DER"
  , searchAliases: []
  , filterAliases: []
  , pageType: "AmazonStores"
  , requestId: "KAS98C370K01G4FPVKFV"
  , sessionId: "147-0099296-5118245"
  , language: "en_US"
  , customerId: ""
  , asin: ""
  , b2b: 0
  , fresh: 0
  , isJpOrCn: 0
  , isUseAuiIss: 1
};

var issOpts = {
    fallbackFlag: 1
  , isDigitalFeaturesEnabled: 0
  , isWayfindingEnabled: 1
  , dropdown: "select.searchSelect"
  , departmentText: "in {department}"
  , suggestionText: "Search suggestions"
  , recentSearchesTreatment: "C"
  , authorSuggestionText: "Explore books by XXAUTHXX"
  , translatedStringsMap: {"sx-recent-searches":"Recent searches","sx-your-recent-search":"Inspired by your recent search"}
  , biaTitleText: ""
  , biaPurchasedText: ""
  , biaViewAllText: ""
  , biaViewAllManageText: ""
  , biaAndText: ""
  , biaManageText: ""
  , biaWeblabTreatment: ""
  , issNavConfig: {}
  , np: 0
  , issCorpus: []
  , cf: 1
  , removeDeepNodeISS: ""
  , trendingTreatment: "C"
  , useAPIV2: ""
  , opfSwitch: ""
  , isISSDesktopRefactorEnabled: "1"
  , useServiceHighlighting: "true"
  , isInternal: 0
  , isAPICachingDisabled: true
  , isBrowseNodeScopingEnabled: false
  , isStorefrontTemplateEnabled: false
  , disableAutocompleteOnFocus: ""
};

  if (opts.isUseAuiIss === 1 && window.$Nav) {
  window.$Nav.when('sx.iss').run('iss-mason-init', function(iss){
    var issInitObj = buildIssInitObject(opts, issOpts, true);
    new iss.IssParentCoordinator(issInitObj);

    $SearchJS.declare('canCreateAutocomplete', issInitObj);
  });
} else if (window.$SearchJS) {
  var iss;

  // BEGIN Deprecated globals
  var issHost = opts.host
    , issMktid = opts.marketId
    , issSearchAliases = opts.searchAliases
    , updateISSCompletion = function() { iss.updateAutoCompletion(); };
  // END deprecated globals


  $SearchJS.when('jQuery', 'search-js-autocomplete-lib').run('autocomplete-init', initializeAutocomplete);
  $SearchJS.when('canCreateAutocomplete').run('createAutocomplete', createAutocomplete);

} // END conditional for window.$SearchJS
  function initializeAutocomplete(jQuery) {
  var issInitObj = buildIssInitObject(opts, issOpts);
  $SearchJS.declare("canCreateAutocomplete", issInitObj);
} // END initializeAutocomplete
  function initSearchCsl(searchCSL, issInitObject) {
  searchCSL.init(
    opts.pageType,
    (window.ue && window.ue.rid) || opts.requestId
  );
  $SearchJS.declare("canCreateAutocomplete", issInitObject);
} // END initSearchCsl
  function createAutocomplete(issObject) {
  iss = new AutoComplete(issObject);

  $SearchJS.publish("search-js-autocomplete", iss);

  logMetrics();
} // END createAutocomplete
  function buildIssInitObject(opts, issOpts, isNewIss) {
    var issInitObj = {
        src: opts.host
      , sessionId: opts.sessionId
      , requestId: opts.requestId
      , mkt: opts.marketId
      , obfMkt: opts.obfuscatedMarketId
      , pageType: opts.pageType
      , language: opts.language
      , customerId: opts.customerId
      , fresh: opts.fresh
      , b2b: opts.b2b
      , aliases: opts.searchAliases
      , fb: issOpts.fallbackFlag
      , isDigitalFeaturesEnabled: issOpts.isDigitalFeaturesEnabled
      , isWayfindingEnabled: issOpts.isWayfindingEnabled
      , issPrimeEligible: issOpts.issPrimeEligible
      , deptText: issOpts.departmentText
      , sugText: issOpts.suggestionText
      , filterAliases: opts.filterAliases
      , biaWidgetUrl: opts.biaWidgetUrl
      , recentSearchesTreatment: issOpts.recentSearchesTreatment
      , authorSuggestionText: issOpts.authorSuggestionText
      , translatedStringsMap: issOpts.translatedStringsMap
      , biaTitleText: ""
      , biaPurchasedText: ""
      , biaViewAllText: ""
      , biaViewAllManageText: ""
      , biaAndText: ""
      , biaManageText: ""
      , biaWeblabTreatment: ""
      , issNavConfig: issOpts.issNavConfig
      , cf: issOpts.cf
      , ime: opts.isJpOrCn
      , mktid: opts.marketId
      , qs: opts.isJpOrCn
      , issCorpus: issOpts.issCorpus
      , deepNodeISS: {
          searchAliasAccessor: function($) {
            return (window.SearchPageAccess && window.SearchPageAccess.searchAlias()) ||
                   $('select.searchSelect').children().attr('data-root-alias');
          },
          searchAliasDisplayNameAccessor: function() {
            return (window.SearchPageAccess && window.SearchPageAccess.searchAliasDisplayName());
          }
        }
      , removeDeepNodeISS: issOpts.removeDeepNodeISS
      , trendingTreatment: issOpts.trendingTreatment
      , useAPIV2: issOpts.useAPIV2
      , opfSwitch: issOpts.opfSwitch
      , isISSDesktopRefactorEnabled: issOpts.isISSDesktopRefactorEnabled
      , useServiceHighlighting: issOpts.useServiceHighlighting
      , isInternal: issOpts.isInternal
      , isAPICachingDisabled: issOpts.isAPICachingDisabled
      , isBrowseNodeScopingEnabled: issOpts.isBrowseNodeScopingEnabled
      , isStorefrontTemplateEnabled: issOpts.isStorefrontTemplateEnabled
      , disableAutocompleteOnFocus: issOpts.disableAutocompleteOnFocus
      , asin: opts.asin
    };
  
    // If we aren't using the new ISS then we need to add these properties
    
    if (!isNewIss) {
      issInitObj.dd = issOpts.dropdown; // The element with id searchDropdownBox doesn't exist in C.
      issInitObj.imeSpacing = issOpts.imeSpacing;
      issInitObj.isNavInline = 1;
      issInitObj.triggerISSOnClick = 0;
      issInitObj.sc = 1;
      issInitObj.np = issOpts.np;
    }
  
    return issInitObj;
  } // END buildIssInitObject
  function logMetrics() {
  if (typeof uet == 'function' && typeof uex == 'function') {
      uet('be', 'iss-init-pc',
          {
              wb: 1
          });
      uex('ld', 'iss-init-pc',
          {
              wb: 1
          });
  }
} // END logMetrics
  
    
window.$Nav && $Nav.declare('config.navDeviceType','desktop');

window.$Nav && $Nav.declare('config.navDebugHighres',false);

window.$Nav && $Nav.declare('config.pageType','AmazonStores');
window.$Nav && $Nav.declare('config.subPageType','LivePage');

window.$Nav && $Nav.declare('config.dynamicMenuUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Fdynamic\x2Dmenu.html');

window.$Nav && $Nav.declare('config.dismissNotificationUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Fdismissnotification.html');

window.$Nav && $Nav.declare('config.enableDynamicMenus',true);

window.$Nav && $Nav.declare('config.isInternal',false);

window.$Nav && $Nav.declare('config.isBackup',false);

window.$Nav && $Nav.declare('config.isRecognized',false);

window.$Nav && $Nav.declare('config.transientFlyoutTrigger','\x23nav\x2Dtransient\x2Dflyout\x2Dtrigger');

window.$Nav && $Nav.declare('config.subnavFlyoutUrl','\x2Fnav\x2Fajax\x2FsubnavFlyout');
window.$Nav && $Nav.declare('config.isSubnavFlyoutMigrationEnabled',true);

window.$Nav && $Nav.declare('config.recordEvUrl','\x2Fgp\x2Fnavigation\x2Fajax\x2Frecordevent.html');
window.$Nav && $Nav.declare('config.recordEvInterval',15000);
window.$Nav && $Nav.declare('config.sessionId','147\x2D0099296\x2D5118245');
window.$Nav && $Nav.declare('config.requestId','KAS98C370K01G4FPVKFV');

window.$Nav && $Nav.declare('config.alexaListEnabled',true);

window.$Nav && $Nav.declare('config.readyOnATF',false);

window.$Nav && $Nav.declare('config.dynamicMenuArgs',{"rid":"KAS98C370K01G4FPVKFV","isFullWidthPrime":0,"isPrime":0,"dynamicRequest":1,"weblabs":"","isFreshRegionAndCustomer":"","primeMenuWidth":310});

window.$Nav && $Nav.declare('config.customerName',false);

window.$Nav && $Nav.declare('config.customerCountryCode','GH');

window.$Nav && $Nav.declare('config.yourAccountPrimeURL',null);

window.$Nav && $Nav.declare('config.yourAccountPrimeHover',true);

window.$Nav && $Nav.declare('config.searchBackState',{});

window.$Nav && $Nav.declare('nav.inline');

(function (i) {
  if(window._navbarSpriteUrl) {
    i.onload = function() {window.uet && uet('ne')};
    i.src = window._navbarSpriteUrl;
  }
}(new Image()));

window.$Nav && $Nav.declare('config.autoFocus',false);

window.$Nav && $Nav.declare('config.responsiveTouchAgents',["ieTouch"]);

window.$Nav && $Nav.declare('config.responsiveGW',false);

window.$Nav && $Nav.declare('config.pageHideEnabled',false);

window.$Nav && $Nav.declare('config.sslTriggerType','flyoutProximityLarge');
window.$Nav && $Nav.declare('config.sslTriggerRetry',0);

window.$Nav && $Nav.declare('config.doubleCart',false);

window.$Nav && $Nav.declare('config.signInOverride',true);

window.$Nav && $Nav.declare('config.signInTooltip',true);

window.$Nav && $Nav.declare('config.isPrimeMember',false);

window.$Nav && $Nav.declare('config.packardGlowTooltip',false);

window.$Nav && $Nav.declare('config.packardGlowFlyout',false);

window.$Nav && $Nav.declare('config.rightMarginAlignEnabled',true);

window.$Nav && $Nav.declare('config.flyoutAnimation',false);

window.$Nav && $Nav.declare('config.primeTooltip',false);

window.$Nav && $Nav.declare('config.primeDay',false);

window.$Nav && $Nav.declare('config.disableBuyItAgain',false);

window.$Nav && $Nav.declare('config.enableCrossShopBiaFlyout',false);

window.$Nav && $Nav.declare('config.pseudoPrimeFirstBrowse',null);

window.$Nav && $Nav.declare('config.csYourAccount',false);

window.$Nav && $Nav.declare('config.cartFlyoutDisabled',true);

window.$Nav && $Nav.declare('config.isTabletBrowser',false);

window.$Nav && $Nav.declare('config.HmenuProximityArea',[200,200,200,200]);

window.$Nav && $Nav.declare('config.HMenuIsProximity',true);

window.$Nav && $Nav.declare('config.isPureAjaxALF',false);

window.$Nav && $Nav.declare('config.accountListFlyoutRedesign',false);

window.$Nav && $Nav.declare('config.navfresh',false);

window.$Nav && $Nav.declare('config.isFreshRegion',false);

if (window.ue && ue.tag) { ue.tag('navbar'); };

window.$Nav && $Nav.declare('config.blackbelt',true);

window.$Nav && $Nav.declare('config.beaconbelt',true);

window.$Nav && $Nav.declare('config.accountList',true);

window.$Nav && $Nav.declare('config.iPadTablet',false);

window.$Nav && $Nav.declare('config.searchapiEndpoint',false);

window.$Nav && $Nav.declare('config.timeline',false);

window.$Nav && $Nav.declare('config.timelineAsinPriceEnabled',false);

window.$Nav && $Nav.declare('config.timelineDeleteEnabled',false);



window.$Nav && $Nav.declare('config.extendedFlyout',false);

window.$Nav && $Nav.declare('config.flyoutCloseDelay',600);

window.$Nav && $Nav.declare('config.pssFlag',0);

window.$Nav && $Nav.declare('config.isPrimeTooltipMigrated',false);

window.$Nav && $Nav.declare('config.hashCustomerAndSessionId','a7526c105dec053509c4f2350a2c7f1b8da338bf');

window.$Nav && $Nav.declare('config.isExportMode',true);

window.$Nav && $Nav.declare('config.languageCode','en_US');

window.$Nav && $Nav.declare('config.environmentVFI','AmazonNavigationOrchestrator\x2Fdevelopment\x40B6520266869\x2DAL2023_aarch64');

window.$Nav && $Nav.declare('config.isHMenuBrowserCacheDisable',false);

window.$Nav && $Nav.declare('config.signInUrlWithRefTag','https\x3A\x2F\x2Fwww.shopping.com\x2Fap\x2Fsignin\x3Fopenid.return_to\x3Dhttps\x253A\x252F\x252Fwww.shopping.com\x252Fstores\x252FRazer\x252Fpage\x252FCDB96030\x2DA7CF\x2D4B56\x2DB70C\x2D67086A740274\x252F\x253F_encoding\x253DUTF8\x2526lp_asin\x253DB0FDPJZQNY\x2526store_ref\x253Dbl_ast_dp_brandlogo_sto\x2526ref_\x253DnavSignInUrlRefTagPlaceHolder\x26openid.identity\x3Dhttp\x253A\x252F\x252Fspecs.openid.net\x252Fauth\x252F2.0\x252Fidentifier_select\x26openid.assoc_handle\x3Dusflex\x26openid.mode\x3Dcheckid_setup\x26openid.claimed_id\x3Dhttp\x253A\x252F\x252Fspecs.openid.net\x252Fauth\x252F2.0\x252Fidentifier_select\x26openid.ns\x3Dhttp\x253A\x252F\x252Fspecs.openid.net\x252Fauth\x252F2.0');

window.$Nav && $Nav.declare('config.regionalStores',[]);

window.$Nav && $Nav.declare('config.isALFRedesignPT2',true);

window.$Nav && $Nav.declare('config.isNavALFRegistryGiftList',false);

window.$Nav && $Nav.declare('config.marketplaceId','ATVPDKIKX0DER');

window.$Nav && $Nav.declare('config.exportTransitionState',null);

window.$Nav && $Nav.declare('config.enableAeeXopFlyout',false);

window.$Nav && $Nav.declare('config.isPrimeFlyoutMigrationEnabled',false);



window.$Nav && $Nav.declare('config.isAjaxPaymentNotificationMigrated',false);

window.$Nav && $Nav.declare('config.isAjaxPaymentSuppressNotificationMigrated',false);

if (window.P && typeof window.P.declare === "function" && typeof window.P.now === "function") {
  window.P.now('packardGlowIngressJsEnabled').execute(function(glowEnabled) {
    if (!glowEnabled) {
      window.P.declare('packardGlowIngressJsEnabled', true);
    }
  });
  window.P.now('packardGlowStoreName').execute(function(storeName) {
    if (!storeName) {
      window.P.declare('packardGlowStoreName','generic');
    }
  });
}

window.$Nav && $Nav.declare('configComplete');

    -->
</script>


<a id="skippedLink" tabindex="-1"></a>

<script type='text/javascript'>window.navmet.MainEnd = new Date();</script>
<script type="text/javascript">
    if (window.ue_t0) {
      window.navmet.push({key:"NavMainEnd",end:+new Date(),begin:window.ue_t0});
    }
</script>
<!-- sp:end-feature:navbar -->
<!-- sp:feature:configured-sitewide-before-host-atf-assets -->
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/71iX9WkDgxL.css?AUIClients/QuickViewBundles" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.qv.assets.js').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/B1Pf+CGYHAL._RC|01ygvTagJML.js,01E9PGi00iL.js,01J4UfgKxjL.js,01vSfHbPoPL.js,01T-bfgr+6L.js,01UNfTs6y3L.js,01qb0hYMFuL.js_.js?AUIClients/QuickViewBundles#1412440-T1');
});
</script>
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/11QGzS1bPmL.css?AUIClients/BooksCardsReactAssetsBuzz-client-dynamic-loading" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.books.assets.js').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/913zDqayxML.js?AUIClients/BooksCardsReactAssetsBuzz-client-dynamic-loading');
});
</script>
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/61khrxVPBWL.css?AUIClients/BooksDesignSystemWebBuzzAssets" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('sp.load.books.assets.js').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/91a8RROniML._RC|01AADYONJ4L.js,01GznEWrFfL.js,01QVQbySIVL.js,01IP4x65DLL.js_.js?AUIClients/BooksDesignSystemWebBuzzAssets#1236037-C.1408963-C.1401984-C');
});
</script>
<!-- sp:end-feature:configured-sitewide-before-host-atf-assets -->
<!-- sp:feature:host-atf -->


<div class="stores-page ">
    <div class="a-container stores-container stores-desktop"><div class="a-row"></div><div id="header" class="a-row stores-row stores-widget-cf">




  
    
      <div data-csa-c-content-id="widget:x1upuvn53m" data-csa-c-painter="AmazonStoresHeader" data-csa-c-slot-id="brand-stores-Header-Desktop" data-csa-c-type="widget" data-csa-op-log-render="" data-widgetid="x1upuvn53m" data-widgettype="Header" class="a-column a-span12 stores-column">
          






<div id="Header-x1upuvn53m"><div data-testid="observer"><div class="Header__header__g41Bi Header__left__WRNV4 search"><div data-csa-c-action="HERO"><div class="Hero__hero__Oz7Jk" data-testid="hero-image"><img alt="" class="Hero__heroImage__rxHb5 Image__cover__CuIOR" src="https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4._CR0%2C0%2C3000%2C600_SX1500_.jpg" srcSet="https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4._CR0%2C0%2C3000%2C600_SX840_.jpg 840w, https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4._CR0%2C0%2C3000%2C600_SX1280_.jpg 1280w, https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4._CR0%2C0%2C3000%2C600_SX1500_.jpg 1500w, https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4._CR0%2C0%2C3000%2C600_SX1920_.jpg 1920w, https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4._CR0%2C0%2C3000%2C600_SX3000_.jpg 3000w" sizes="(max-width: 840px) 100vw,(max-width: 1500px) 100vw,1500px" data-feature="cf" data-testid="image"/></div></div><div class="Header__placeholder__vziZp"></div><div class="Header__navArea__wjUus" id="nav-area"><div class="Header__navAreaHorizontalLayout__dO20q" data-testid="header-nav-area"><div class="Header__rightColumn__KDRfQ"><div class="Header__navigationArea__V6uZ7"><div data-csa-c-action="MENU"><nav aria-label="breadcrumbs" class="Breadcrumbs__breadcrumbs__hZYYm Breadcrumbs__v2__rp5yN Header__breadcrumbsWithFollowButton__KKBxo Breadcrumbs__noLogo__yrsA9" itemscope="" itemType="http://schema.org/BreadcrumbList" data-testid="breadcrumb"><ol class="Breadcrumbs__breadcrumbListItem__A2w9q"><li class="Breadcrumbs__breadcrumb__M5DAz" itemProp="itemListElement" itemscope="" aria-label="Razer breadcrumb" itemType="http://schema.org/ListItem" data-testid="breadcrumb-item"><a href="#" itemProp="item" aria-label="Razer" aria-current="location"><span itemProp="name">Razer</span></a><meta itemProp="position" content="1"/></li></ol></nav></div><div class="Header__menuArea__ejLNf"><div data-csa-c-action="FOLLOW_BUTTON"><div class="FollowButton__followButton__G40Ba followButton-diamond Header__followButton__dBTS9"><span class="brand-follow-button-container"><span class="a-button a-button-base rio brand-follow-button"><span class="a-button-inner"><button class="a-button-text" type="button" aria-label="Follow Razer" aria-describedby="follow-button-sr-hint-undefined" data-arialabelfollow="Follow Razer" data-arialabelfollowing="Following Razer" data-followtext="Follow" data-followingtext="Following" data-showtooltip="true" data-bfid="BFqhRQw73NSSmdeUGB4qBTpQ==" data-componentid="x1upuvn53m" data-componenttype="header" data-elementid="" data-elementtype="" data-followstatus="false" data-placementid="CDB96030-A7CF-4B56-B70C-67086A740274" data-placementsubtype="stores" data-placementtype="stores" data-requestid="" data-testid="follow-button" data-ref="bft_ast">Follow</button></span></span></span></div></div><div data-csa-c-action="SOCIAL_SHARE"></div><div data-csa-c-action="NAV"><div class="Navigation__navigation__zUrTC Header__navigationWithFollowButton__nEvpR Navigation__hasFollowButton__LIgOF" data-testid="navigation"><div class="Navigation__overlay__KUYT_" role="presentation"></div><div class=""><nav class="Navigation__navBar__tdJ0T" aria-label="Razer Navigation Bar"><ul class="Navigation__navList__HrEra"><li class="Navigation__navItem__bakjf Navigation__isCurrent__Sv_Xw Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/CDB96030-A7CF-4B56-B70C-67086A740274" aria-current="page" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ"><span>Home</span></span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/03508F9D-3610-49AC-9E57-C476A4E7B219" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Deals</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/26843F5A-5134-485D-99D8-8B8827DDF0B1" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">New Releases</span></a></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/7FA70731-D20B-4390-BB01-C3329AC830D1" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mice</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/7FA70731-D20B-4390-BB01-C3329AC830D1" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mice</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/E0E046DD-CED4-418F-8F0E-5B1E66A2B6A3" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Cobra</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/2223E13C-225C-448A-A345-E6F43EE4004E" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Viper </span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/B1CCF8F1-B32D-4DBA-B130-9C4246018BAE" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">DeathAdder</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/4677A451-BFE7-43A2-94B5-D33CE2FC0807" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Basilisk </span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/6C6805ED-C1DD-4DE0-85A0-E41F1E8971A7" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Naga</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/3B015EFB-D9A3-4F4F-A844-FC29624F6F44" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Orochi</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/4319E058-EBE2-4E54-B186-89C9F6F2DBA3" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Headsets</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/4319E058-EBE2-4E54-B186-89C9F6F2DBA3" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Headsets</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/928D659E-E4A5-478E-8A59-77BCF3B0F2ED" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">BlackShark</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/DFF86D43-34FA-4414-8588-0F58EAFD929C" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Kraken</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/AA6A086E-FA17-4BE7-B544-688DE2125D46" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Kraken Kitty</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/1C37A5F9-0DC7-4A60-BEF3-041B507B7560" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Barracuda</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/767B96B8-E316-4C4D-91BA-E637ADB743F7" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Keyboards</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/767B96B8-E316-4C4D-91BA-E637ADB743F7" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Keyboards</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/D9984C65-812C-4C55-9B3F-04A67CB4AA3B" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Huntsman</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/92A2648B-1C39-45E5-A348-51B44888B857" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">BlackWidow </span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/0B231616-85FD-4FA4-9748-9C999A6BB196" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Reclusa</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/CE112A9C-1A41-4535-BB6F-2038145A0A60" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Ornata</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/C4E6F3C7-1D42-4805-946A-CF00EC9F7D4D" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">DeathStalker</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/FAAD26E1-E48A-473C-B8D8-DD3E65162A65" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Joro</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/0D877553-6DCE-4C6B-BE6D-67155E69447A" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Tartarus</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/E2E253F5-087C-476C-8944-77B88D19B274" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Console</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/E2E253F5-087C-476C-8944-77B88D19B274" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Console</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/18A1929E-2386-4B43-A130-58A41C88CE24" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Xbox</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/6D3AAFF1-ED24-464B-898D-6096546A4B60" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">PlayStation</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/D3071CFE-1CC4-427E-8829-765A3E73D1FA" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Switch 2</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/D196CC52-5538-43E9-B8D0-BD45883826CB" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Headsets</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/8F095BDC-9EB5-4E6E-BB6A-AA5209D89582" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Controllers</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/8827A69C-1086-47AD-96CF-87C9DD01493B" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Console Skins</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/0B27581E-45A8-4851-999D-3582C7FA1FA1" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Console Charging</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/3155493D-9CF5-4E79-88B6-780135241B86" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Kitsune</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/9923FDF3-E24F-4072-8230-5493B97BB776" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Controllers</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/D10DEFB8-3DFF-4B9E-B67B-C7168B7279F3" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Productivity</span></a></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/C219EE55-73D3-4846-B607-91C13622F411" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Laptops</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/C219EE55-73D3-4846-B607-91C13622F411" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Laptops</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/0592414B-E2AF-49D5-B7B5-769A1C141F8A" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Blade 16</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/00D32277-E786-4FDE-AAAA-8FAED187E17C" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Blade 18</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/9F7FCB09-D8ED-4E49-A220-CA41CE829CF3" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Laptop Accessories</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/964D2240-9028-403D-8400-B8A9168C07A9" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Laptop Skins</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/CCB421CC-2DA1-41BD-AA05-A8572E409EFB" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Speakers</span></a></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/AEEC3162-B48C-4955-9E4A-468E7F7F9287" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mobile</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/AEEC3162-B48C-4955-9E4A-468E7F7F9287" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mobile</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/635E2DD6-4E3C-4C90-8CD8-6071B689BA5A" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Kishi</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/6747C3F6-0984-4F2D-BB59-F82CA965911F" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Hammerhead</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/E35B9EF7-0DBF-4941-932E-B027979217CD" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Edge</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/534DE2E8-ABF1-4AA6-90E1-1C4616628F22" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mobile Skins</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/77FA7216-D4E7-4ABA-8CE6-73F35867DB46" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mats</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/77FA7216-D4E7-4ABA-8CE6-73F35867DB46" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mats</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/BD06F5A9-8E6B-4ABE-B1F4-1F3A63703F58" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Goliathus</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/1AA8619D-1180-49DF-A620-A2FFEE58D8A5" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gigantus</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/36C095AB-F473-432A-B587-46A210205828" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Atlas</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/44580A73-34C1-4F26-AA4F-BF16D72B53BE" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Firefly</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/B6D02186-FBCB-45C2-88D9-C2EF474C5090" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Content Creation</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/B6D02186-FBCB-45C2-88D9-C2EF474C5090" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Content Creation</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/45950E11-9C9A-4BBC-9DED-D3C41AC6F581" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Seiren</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/36E3BDB3-E5A6-4545-BC6A-56F0F7221F08" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Kiyo</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/D17E96F5-1491-48A8-9E7C-0CBF711F86C6" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Stream Controller</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/233CF814-86C2-47A1-935F-36A735E6D262" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gaming Peripheral Accessories</span></a></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/75DD1756-F264-493D-A7A2-4946D8A15A09" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Chairs</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/75DD1756-F264-493D-A7A2-4946D8A15A09" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Chairs</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/9FE18585-A8A5-4B2E-85F5-05C282FE9405" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Enki</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/905473EF-C5C3-43E1-AC39-3B81124A020C" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Iskur</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/2DFAE1E9-421E-46ED-89AF-02E2EACEDF0C" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Soma Chroma</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/8ABD05E2-19AA-4300-B436-D620A489BDDE" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Fujin</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/B1C6EFBC-3A3D-45F5-85E2-ADAA904895CC" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Licensed Products</span></a></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/6C0E7370-29E6-47A0-94B6-9ECE3F3A7F04" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gear &amp; Lifestyle</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/6C0E7370-29E6-47A0-94B6-9ECE3F3A7F04" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gear &amp; Lifestyle</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/61AB3E15-3561-469F-999C-0FC8BD5D6D99" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Backpacks</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/FE6A8EDA-C274-4BEC-8127-022889D15380" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mercury/Quartz Collection</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/FE6A8EDA-C274-4BEC-8127-022889D15380" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mercury/Quartz Collection</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/15AA038A-27CE-4641-883D-84A390F0DA70" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Quartz Collection</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/629309B8-04DF-4FF8-901E-413A88D572F2" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Mercury Collection</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf Navigation__hasChildren__jSUsH" data-testid="nav-item"><a href="/stores/page/F3A663BB-AA40-46DE-8671-CF6519F0CCF2" aria-haspopup="true" role="button" tabindex="0" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Featured Products</span></a><div class="Navigation__navList__HrEra level2 Navigation__subnav__CkMUI" aria-label="Navigation List" role="dialog"><ul><li class="Navigation__navItem__bakjf Navigation__back__IqAlh" data-click-type="OTHER"><button type="button" tabindex="0"><span>Back</span></button></li><li class="Navigation__navItem__bakjf Navigation__isHeading__ArXQd" data-testid="nav-item"><a href="/stores/page/F3A663BB-AA40-46DE-8671-CF6519F0CCF2" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Featured Products</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/E3A68465-DE7A-4079-8FFA-C6CAB35E622E" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Huntsman - Analog Optical</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/88718101-1754-43AC-B182-CFE18819F832" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">New &amp; Notable: Razer Huntsman V3 HE Magnetic</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/4CF9CC25-12CE-4E9E-963E-CBC9F1B82A14" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">New &amp; Notable: Razer Viper V4 Pro</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/166B218E-0644-4721-A1D4-7C5F3611577A" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gaming Laptops</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/37DB0965-4D7E-45B7-9E63-7A3F10A9B274" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gaming Mice</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/E3806543-5EDD-442C-9496-6C533CB3D721" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gaming Keyboards</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/4FD84B07-A966-4FA7-9171-5648CE4C1ADA" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gaming Headsets</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/58A2BAA2-8C44-45CB-A6FC-C5BEAB2343BE" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">For The Pro</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/9EFC89B5-7360-4565-BCC1-1DAED157106B" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Chroma</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/8F3B2BD3-2448-4A8C-A963-99E3F47C99CF" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Sustainability</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/4925CBF1-DFFA-4689-B424-5DDFF85BC3AE" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Razer Sensa HD Haptics</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/D5F8C3B8-20C5-4689-B0F2-7DCC00798CAE" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Faker Edition -  Viper</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/1BB832C5-F979-4950-AC8A-93BD0EF9524F" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Niko Collection</span></a></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/700EA385-B19E-484E-B403-32B65BA4EDBF" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">New &amp; Notable: Razer Naga V3 Pro</span></a></li></ul></div></li><li class="Navigation__navItem__bakjf" data-testid="nav-item"><a href="/stores/page/A2BB6555-7D49-4B41-B898-99361CC2CF5A" tabindex="0" data-click-type=""><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ">Gift Guide</span></a></li><li class="Navigation__navItem__bakjf Navigation__more__jp3zs Navigation__isInvisible__boabX" aria-hidden="true"><button type="button" tabindex="-1" data-click-type="OTHER"><span class="Navigation__linkText__LoQD4 Navigation__en-US__YUfTQ"><span>More</span></span></button></li></ul></nav></div><div class=""><nav class="Navigation__navMenu__vqaU2"></nav></div></div></div><div class="Header__searchArea__yVqw6" data-csa-c-action="SEARCH_BAR"><div class="SearchInput__container__hhZ_B" data-testid="search-input-container"><div class="SearchInput__before__qXtkx"><button type="button" class="SearchInput__search-icon__em6r2" aria-label="Search" data-testid="search-icon-button"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" data-testid="magnifying-glass-icon"><path d="M20.71 19.29L17.31 15.9C18.4084 14.5032 19.0038 12.7769 19 11C19 9.41775 18.5308 7.87103 17.6518 6.55544C16.7727 5.23985 15.5233 4.21447 14.0615 3.60897C12.5997 3.00347 10.9911 2.84504 9.43928 3.15372C7.88743 3.4624 6.46197 4.22433 5.34315 5.34315C4.22433 6.46197 3.4624 7.88743 3.15372 9.43928C2.84504 10.9911 3.00347 12.5997 3.60897 14.0615C4.21447 15.5233 5.23985 16.7727 6.55544 17.6518C7.87103 18.5308 9.41775 19 11 19C12.7769 19.0038 14.5032 18.4084 15.9 17.31L19.29 20.71C19.383 20.8037 19.4936 20.8781 19.6154 20.9289C19.7373 20.9797 19.868 21.0058 20 21.0058C20.132 21.0058 20.2627 20.9797 20.3846 20.9289C20.5064 20.8781 20.617 20.8037 20.71 20.71C20.8037 20.617 20.8781 20.5064 20.9289 20.3846C20.9797 20.2627 21.0058 20.132 21.0058 20C21.0058 19.868 20.9797 19.7373 20.9289 19.6154C20.8781 19.4936 20.8037 19.383 20.71 19.29ZM5 11C5 9.81332 5.3519 8.65328 6.01119 7.66658C6.67047 6.67989 7.60755 5.91085 8.7039 5.45673C9.80026 5.0026 11.0067 4.88378 12.1705 5.11529C13.3344 5.3468 14.4035 5.91825 15.2426 6.75736C16.0818 7.59648 16.6532 8.66558 16.8847 9.82946C17.1162 10.9933 16.9974 12.1997 16.5433 13.2961C16.0892 14.3925 15.3201 15.3295 14.3334 15.9888C13.3467 16.6481 12.1867 17 11 17C9.4087 17 7.88258 16.3679 6.75736 15.2426C5.63214 14.1174 5 12.5913 5 11Z" fill="#0F1111"></path></svg></button></div><form action="#" data-testid="search-form" class="SearchInput__search-form__aOL5j SearchInput__search-form--show__pRaA6"><input type="search" class="SearchInput__input__IGt2m" data-testid="search-form-input" name="search" spellcheck="false" value="" placeholder="Search all Razer" aria-hidden="false"/></form><div class="SearchInput__after__f3afC"><button type="button" class="SearchInput__x-icon__qHE2F" aria-label="Clear"><svg width="12" height="12" stroke="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 12"><path d="M10.33 0L6 4.329 1.67 0 0 1.67 4.33 6 0 10.33 1.67 12 6 7.67 10.33 12 12 10.33 7.671 6 12 1.67z" fill="#879596" fill-rule="evenodd"></path></svg></button><div class="SearchInput__divider__oS51e"></div><button type="button" class="SearchInput__cancel__Z9Ewl" aria-label="Cancel">Cancel</button></div></div></div></div></div></div></div></div></div></div></div>
<script>
    !(function() {
        var config = {"device":"desktop","version":"1.0","caller":"Cnuba","cssJsMode":"AUI","debug":false,"endpoint":"stores-react","translations":{"STORES_WIDGET_AllDeals":"All Deals","STORES_WIDGET_Follow":"Follow","STORES_WIDGET_Follow_Deals_And_More":"deals and more","STORES_WIDGET_Follow_Value":"Be the first to hear about {0} from {1}","STORES_WIDGET_Following":"Following","STORES_WIDGET_Close":"Close","STORES_WIDGET_SendMessage":"Message","STORES_WIDGET_Home":"Home","STORES_WIDGET_BrandStoreHomePage":"{0} home page","STORES_WIDGET_About":"About","STORES_WIDGET_AllBooks":"All Books","STORES_WIDGET_Posts":"Posts","STORES_WIDGET_More":"More","STORES_WIDGET_Back":"Back","STORES_WIDGET_Menu":"Menu","STORES_WIDGET_Categories":"Categories","STORES_WIDGET_BackToStores":"Back to Store","STORES_WIDGET_BackToSubPage":"Back to {0}","STORES_WIDGET_ShopByCategory":"Shop by category","STORES_WIDGET_Skip":"Skip","STORES_WIDGET_BlackLivesMatterHeadline":"Black lives matter.","STORES_WIDGET_BlackLivesMatterMessage":"{0} stands in solidarity with the Black community.","STORES_WIDGET_SearchResults":"Search Results","STORES_WIDGET_DYNAMIC_MOBILE_NAV_SECTION_TITLE":"Explore Categories","STORES_WIDGET_Cancel":"Cancel","STORES_WIDGET_Clear":"Clear","STORES_WIDGET_Search":"Search","STORES_WIDGET_SearchAll":"Search all {0}","STORES_WIDGET_HEADER_Deals":"Deals","BRAND_FOLLOW_BUTTON_FOLLOW":"+ Follow","BRAND_FOLLOW_BUTTON_FOLLOWING":"✓ Following","STORES_FOLLOW_BUTTON_ARIA_FOLLOW":"Follow {0}","STORES_FOLLOW_BUTTON_ARIA_FOLLOWING":"Following {0}","AUTHOR_FOLLOW_BUTTON_ARIA_FOLLOW_NEW":"Follow {0}","AUTHOR_STORES_FollowToGetNewUpdates_NEW":"Follow to get new release updates, special offers (including promotional offers) and improved recommendations.","AUTHOR_FOLLOW_BUTTON_ARIA_FOLLOWING_NEW":"Following {0}","AUTHOR_STORES_profileImage":"{0} profile image","STORES_WIDGET_ShareTitle":"Share","STORES_WIDGET_ShareText":"Share this page with your friends.","taf_email_name":"Email","taf_facebook_name":"Facebook","taf_x_name":"X","taf_pinterest_name":"Pinterest","taf_copy_tooltip":"Copy Link","taf_copy_url_changeover":"Link copied!","STORES_WIDGET_Share_Email_Subject":"Check out {0} on Amazon","STORES_WIDGET_Share_Email_Content":"I've shared a Brand Store on Amazon with you."},"componentType":"AmazonStoresJuvec","widgetId":"x1upuvn53m","sectionType":"Hero","widgetType":"Header","content":{"textOverlay":"","imageWidth":"3000","nav":{"45950E11-9C9A-4BBC-9DED-D3C41AC6F581":{"parent":"B6D02186-FBCB-45C2-88D9-C2EF474C5090","level":3,"children":[],"pageId":"45950E11-9C9A-4BBC-9DED-D3C41AC6F581","title":"Seiren","href":"/stores/page/45950E11-9C9A-4BBC-9DED-D3C41AC6F581"},"8ABD05E2-19AA-4300-B436-D620A489BDDE":{"parent":"75DD1756-F264-493D-A7A2-4946D8A15A09","level":3,"children":[],"pageId":"8ABD05E2-19AA-4300-B436-D620A489BDDE","title":"Fujin","href":"/stores/page/8ABD05E2-19AA-4300-B436-D620A489BDDE"},"36E3BDB3-E5A6-4545-BC6A-56F0F7221F08":{"parent":"B6D02186-FBCB-45C2-88D9-C2EF474C5090","level":3,"children":[],"pageId":"36E3BDB3-E5A6-4545-BC6A-56F0F7221F08","title":"Kiyo","href":"/stores/page/36E3BDB3-E5A6-4545-BC6A-56F0F7221F08"},"4925CBF1-DFFA-4689-B424-5DDFF85BC3AE":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"4925CBF1-DFFA-4689-B424-5DDFF85BC3AE","title":"Razer Sensa HD Haptics","href":"/stores/page/4925CBF1-DFFA-4689-B424-5DDFF85BC3AE"},"0B27581E-45A8-4851-999D-3582C7FA1FA1":{"parent":"E2E253F5-087C-476C-8944-77B88D19B274","level":3,"children":[],"pageId":"0B27581E-45A8-4851-999D-3582C7FA1FA1","title":"Console Charging","href":"/stores/page/0B27581E-45A8-4851-999D-3582C7FA1FA1"},"8827A69C-1086-47AD-96CF-87C9DD01493B":{"parent":"E2E253F5-087C-476C-8944-77B88D19B274","level":3,"children":[],"pageId":"8827A69C-1086-47AD-96CF-87C9DD01493B","title":"Console Skins","href":"/stores/page/8827A69C-1086-47AD-96CF-87C9DD01493B"},"37DB0965-4D7E-45B7-9E63-7A3F10A9B274":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","children":[],"level":3,"pageId":"37DB0965-4D7E-45B7-9E63-7A3F10A9B274","title":"Gaming Mice","href":"/stores/page/37DB0965-4D7E-45B7-9E63-7A3F10A9B274"},"D196CC52-5538-43E9-B8D0-BD45883826CB":{"parent":"E2E253F5-087C-476C-8944-77B88D19B274","level":3,"children":[],"pageId":"D196CC52-5538-43E9-B8D0-BD45883826CB","title":"Headsets","href":"/stores/page/D196CC52-5538-43E9-B8D0-BD45883826CB"},"C4E6F3C7-1D42-4805-946A-CF00EC9F7D4D":{"parent":"767B96B8-E316-4C4D-91BA-E637ADB743F7","level":3,"children":[],"pageId":"C4E6F3C7-1D42-4805-946A-CF00EC9F7D4D","title":"DeathStalker","href":"/stores/page/C4E6F3C7-1D42-4805-946A-CF00EC9F7D4D"},"166B218E-0644-4721-A1D4-7C5F3611577A":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","children":[],"level":3,"pageId":"166B218E-0644-4721-A1D4-7C5F3611577A","title":"Gaming Laptops","href":"/stores/page/166B218E-0644-4721-A1D4-7C5F3611577A"},"AEEC3162-B48C-4955-9E4A-468E7F7F9287":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["635E2DD6-4E3C-4C90-8CD8-6071B689BA5A","6747C3F6-0984-4F2D-BB59-F82CA965911F","E35B9EF7-0DBF-4941-932E-B027979217CD","534DE2E8-ABF1-4AA6-90E1-1C4616628F22"],"level":2,"pageId":"AEEC3162-B48C-4955-9E4A-468E7F7F9287","title":"Mobile","href":"/stores/page/AEEC3162-B48C-4955-9E4A-468E7F7F9287"},"4677A451-BFE7-43A2-94B5-D33CE2FC0807":{"parent":"7FA70731-D20B-4390-BB01-C3329AC830D1","children":[],"level":3,"pageId":"4677A451-BFE7-43A2-94B5-D33CE2FC0807","title":"Basilisk ","href":"/stores/page/4677A451-BFE7-43A2-94B5-D33CE2FC0807"},"2DFAE1E9-421E-46ED-89AF-02E2EACEDF0C":{"parent":"75DD1756-F264-493D-A7A2-4946D8A15A09","level":3,"children":[],"pageId":"2DFAE1E9-421E-46ED-89AF-02E2EACEDF0C","title":"Soma Chroma","href":"/stores/page/2DFAE1E9-421E-46ED-89AF-02E2EACEDF0C"},"92A2648B-1C39-45E5-A348-51B44888B857":{"parent":"767B96B8-E316-4C4D-91BA-E637ADB743F7","children":[],"level":3,"pageId":"92A2648B-1C39-45E5-A348-51B44888B857","title":"BlackWidow ","href":"/stores/page/92A2648B-1C39-45E5-A348-51B44888B857"},"D17E96F5-1491-48A8-9E7C-0CBF711F86C6":{"parent":"B6D02186-FBCB-45C2-88D9-C2EF474C5090","level":3,"children":[],"pageId":"D17E96F5-1491-48A8-9E7C-0CBF711F86C6","title":"Stream Controller","href":"/stores/page/D17E96F5-1491-48A8-9E7C-0CBF711F86C6"},"928D659E-E4A5-478E-8A59-77BCF3B0F2ED":{"parent":"4319E058-EBE2-4E54-B186-89C9F6F2DBA3","children":[],"level":3,"pageId":"928D659E-E4A5-478E-8A59-77BCF3B0F2ED","title":"BlackShark","href":"/stores/page/928D659E-E4A5-478E-8A59-77BCF3B0F2ED"},"8F3B2BD3-2448-4A8C-A963-99E3F47C99CF":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"8F3B2BD3-2448-4A8C-A963-99E3F47C99CF","title":"Sustainability","href":"/stores/page/8F3B2BD3-2448-4A8C-A963-99E3F47C99CF"},"FAAD26E1-E48A-473C-B8D8-DD3E65162A65":{"parent":"767B96B8-E316-4C4D-91BA-E637ADB743F7","level":3,"children":[],"pageId":"FAAD26E1-E48A-473C-B8D8-DD3E65162A65","title":"Joro","href":"/stores/page/FAAD26E1-E48A-473C-B8D8-DD3E65162A65"},"61AB3E15-3561-469F-999C-0FC8BD5D6D99":{"parent":"6C0E7370-29E6-47A0-94B6-9ECE3F3A7F04","level":3,"children":[],"pageId":"61AB3E15-3561-469F-999C-0FC8BD5D6D99","title":"Backpacks","href":"/stores/page/61AB3E15-3561-469F-999C-0FC8BD5D6D99"},"4319E058-EBE2-4E54-B186-89C9F6F2DBA3":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["928D659E-E4A5-478E-8A59-77BCF3B0F2ED","DFF86D43-34FA-4414-8588-0F58EAFD929C","AA6A086E-FA17-4BE7-B544-688DE2125D46","1C37A5F9-0DC7-4A60-BEF3-041B507B7560"],"level":2,"pageId":"4319E058-EBE2-4E54-B186-89C9F6F2DBA3","title":"Headsets","href":"/stores/page/4319E058-EBE2-4E54-B186-89C9F6F2DBA3"},"0B231616-85FD-4FA4-9748-9C999A6BB196":{"parent":"767B96B8-E316-4C4D-91BA-E637ADB743F7","level":3,"children":[],"pageId":"0B231616-85FD-4FA4-9748-9C999A6BB196","title":"Reclusa","href":"/stores/page/0B231616-85FD-4FA4-9748-9C999A6BB196"},"629309B8-04DF-4FF8-901E-413A88D572F2":{"parent":"FE6A8EDA-C274-4BEC-8127-022889D15380","children":[],"level":3,"pageId":"629309B8-04DF-4FF8-901E-413A88D572F2","title":"Mercury Collection","href":"/stores/page/629309B8-04DF-4FF8-901E-413A88D572F2"},"9EFC89B5-7360-4565-BCC1-1DAED157106B":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"9EFC89B5-7360-4565-BCC1-1DAED157106B","title":"Chroma","href":"/stores/page/9EFC89B5-7360-4565-BCC1-1DAED157106B"},"15AA038A-27CE-4641-883D-84A390F0DA70":{"parent":"FE6A8EDA-C274-4BEC-8127-022889D15380","children":[],"level":3,"pageId":"15AA038A-27CE-4641-883D-84A390F0DA70","title":"Quartz Collection","href":"/stores/page/15AA038A-27CE-4641-883D-84A390F0DA70"},"AA6A086E-FA17-4BE7-B544-688DE2125D46":{"parent":"4319E058-EBE2-4E54-B186-89C9F6F2DBA3","level":3,"children":[],"pageId":"AA6A086E-FA17-4BE7-B544-688DE2125D46","title":"Kraken Kitty","href":"/stores/page/AA6A086E-FA17-4BE7-B544-688DE2125D46"},"6C6805ED-C1DD-4DE0-85A0-E41F1E8971A7":{"parent":"7FA70731-D20B-4390-BB01-C3329AC830D1","children":[],"level":3,"pageId":"6C6805ED-C1DD-4DE0-85A0-E41F1E8971A7","title":"Naga","href":"/stores/page/6C6805ED-C1DD-4DE0-85A0-E41F1E8971A7"},"0D877553-6DCE-4C6B-BE6D-67155E69447A":{"parent":"767B96B8-E316-4C4D-91BA-E637ADB743F7","level":3,"children":[],"pageId":"0D877553-6DCE-4C6B-BE6D-67155E69447A","title":"Tartarus","href":"/stores/page/0D877553-6DCE-4C6B-BE6D-67155E69447A"},"635E2DD6-4E3C-4C90-8CD8-6071B689BA5A":{"parent":"AEEC3162-B48C-4955-9E4A-468E7F7F9287","children":[],"level":3,"pageId":"635E2DD6-4E3C-4C90-8CD8-6071B689BA5A","title":"Kishi","href":"/stores/page/635E2DD6-4E3C-4C90-8CD8-6071B689BA5A"},"03508F9D-3610-49AC-9E57-C476A4E7B219":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":[],"level":2,"pageId":"03508F9D-3610-49AC-9E57-C476A4E7B219","title":"Deals","href":"/stores/page/03508F9D-3610-49AC-9E57-C476A4E7B219"},"CDB96030-A7CF-4B56-B70C-67086A740274":{"parent":null,"children":["03508F9D-3610-49AC-9E57-C476A4E7B219","26843F5A-5134-485D-99D8-8B8827DDF0B1","7FA70731-D20B-4390-BB01-C3329AC830D1","4319E058-EBE2-4E54-B186-89C9F6F2DBA3","767B96B8-E316-4C4D-91BA-E637ADB743F7","E2E253F5-087C-476C-8944-77B88D19B274","9923FDF3-E24F-4072-8230-5493B97BB776","D10DEFB8-3DFF-4B9E-B67B-C7168B7279F3","C219EE55-73D3-4846-B607-91C13622F411","CCB421CC-2DA1-41BD-AA05-A8572E409EFB","AEEC3162-B48C-4955-9E4A-468E7F7F9287","77FA7216-D4E7-4ABA-8CE6-73F35867DB46","B6D02186-FBCB-45C2-88D9-C2EF474C5090","233CF814-86C2-47A1-935F-36A735E6D262","75DD1756-F264-493D-A7A2-4946D8A15A09","B1C6EFBC-3A3D-45F5-85E2-ADAA904895CC","6C0E7370-29E6-47A0-94B6-9ECE3F3A7F04","FE6A8EDA-C274-4BEC-8127-022889D15380","F3A663BB-AA40-46DE-8671-CF6519F0CCF2","A2BB6555-7D49-4B41-B898-99361CC2CF5A"],"level":1,"pageId":"CDB96030-A7CF-4B56-B70C-67086A740274","title":"Razer","href":"/stores/page/CDB96030-A7CF-4B56-B70C-67086A740274"},"BD06F5A9-8E6B-4ABE-B1F4-1F3A63703F58":{"parent":"77FA7216-D4E7-4ABA-8CE6-73F35867DB46","children":[],"level":3,"pageId":"BD06F5A9-8E6B-4ABE-B1F4-1F3A63703F58","title":"Goliathus","href":"/stores/page/BD06F5A9-8E6B-4ABE-B1F4-1F3A63703F58"},"534DE2E8-ABF1-4AA6-90E1-1C4616628F22":{"parent":"AEEC3162-B48C-4955-9E4A-468E7F7F9287","level":3,"children":[],"pageId":"534DE2E8-ABF1-4AA6-90E1-1C4616628F22","title":"Mobile Skins","href":"/stores/page/534DE2E8-ABF1-4AA6-90E1-1C4616628F22"},"700EA385-B19E-484E-B403-32B65BA4EDBF":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"700EA385-B19E-484E-B403-32B65BA4EDBF","title":"New & Notable: Razer Naga V3 Pro","href":"/stores/page/700EA385-B19E-484E-B403-32B65BA4EDBF"},"905473EF-C5C3-43E1-AC39-3B81124A020C":{"parent":"75DD1756-F264-493D-A7A2-4946D8A15A09","level":3,"children":[],"pageId":"905473EF-C5C3-43E1-AC39-3B81124A020C","title":"Iskur","href":"/stores/page/905473EF-C5C3-43E1-AC39-3B81124A020C"},"E0E046DD-CED4-418F-8F0E-5B1E66A2B6A3":{"parent":"7FA70731-D20B-4390-BB01-C3329AC830D1","level":3,"children":[],"pageId":"E0E046DD-CED4-418F-8F0E-5B1E66A2B6A3","title":"Cobra","href":"/stores/page/E0E046DD-CED4-418F-8F0E-5B1E66A2B6A3"},"58A2BAA2-8C44-45CB-A6FC-C5BEAB2343BE":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"58A2BAA2-8C44-45CB-A6FC-C5BEAB2343BE","title":"For The Pro","href":"/stores/page/58A2BAA2-8C44-45CB-A6FC-C5BEAB2343BE"},"1AA8619D-1180-49DF-A620-A2FFEE58D8A5":{"parent":"77FA7216-D4E7-4ABA-8CE6-73F35867DB46","children":[],"level":3,"pageId":"1AA8619D-1180-49DF-A620-A2FFEE58D8A5","title":"Gigantus","href":"/stores/page/1AA8619D-1180-49DF-A620-A2FFEE58D8A5"},"964D2240-9028-403D-8400-B8A9168C07A9":{"parent":"C219EE55-73D3-4846-B607-91C13622F411","level":3,"children":[],"pageId":"964D2240-9028-403D-8400-B8A9168C07A9","title":"Laptop Skins","href":"/stores/page/964D2240-9028-403D-8400-B8A9168C07A9"},"B1CCF8F1-B32D-4DBA-B130-9C4246018BAE":{"parent":"7FA70731-D20B-4390-BB01-C3329AC830D1","children":[],"level":3,"pageId":"B1CCF8F1-B32D-4DBA-B130-9C4246018BAE","title":"DeathAdder","href":"/stores/page/B1CCF8F1-B32D-4DBA-B130-9C4246018BAE"},"88718101-1754-43AC-B182-CFE18819F832":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"88718101-1754-43AC-B182-CFE18819F832","title":"New & Notable: Razer Huntsman V3 HE Magnetic","href":"/stores/page/88718101-1754-43AC-B182-CFE18819F832"},"36C095AB-F473-432A-B587-46A210205828":{"parent":"77FA7216-D4E7-4ABA-8CE6-73F35867DB46","level":3,"children":[],"pageId":"36C095AB-F473-432A-B587-46A210205828","title":"Atlas","href":"/stores/page/36C095AB-F473-432A-B587-46A210205828"},"CE112A9C-1A41-4535-BB6F-2038145A0A60":{"parent":"767B96B8-E316-4C4D-91BA-E637ADB743F7","children":[],"level":3,"pageId":"CE112A9C-1A41-4535-BB6F-2038145A0A60","title":"Ornata","href":"/stores/page/CE112A9C-1A41-4535-BB6F-2038145A0A60"},"26843F5A-5134-485D-99D8-8B8827DDF0B1":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","level":2,"children":[],"pageId":"26843F5A-5134-485D-99D8-8B8827DDF0B1","title":"New Releases","href":"/stores/page/26843F5A-5134-485D-99D8-8B8827DDF0B1"},"767B96B8-E316-4C4D-91BA-E637ADB743F7":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["D9984C65-812C-4C55-9B3F-04A67CB4AA3B","92A2648B-1C39-45E5-A348-51B44888B857","0B231616-85FD-4FA4-9748-9C999A6BB196","CE112A9C-1A41-4535-BB6F-2038145A0A60","C4E6F3C7-1D42-4805-946A-CF00EC9F7D4D","FAAD26E1-E48A-473C-B8D8-DD3E65162A65","0D877553-6DCE-4C6B-BE6D-67155E69447A"],"level":2,"pageId":"767B96B8-E316-4C4D-91BA-E637ADB743F7","title":"Keyboards","href":"/stores/page/767B96B8-E316-4C4D-91BA-E637ADB743F7"},"8F095BDC-9EB5-4E6E-BB6A-AA5209D89582":{"parent":"E2E253F5-087C-476C-8944-77B88D19B274","level":3,"children":[],"pageId":"8F095BDC-9EB5-4E6E-BB6A-AA5209D89582","title":"Controllers","href":"/stores/page/8F095BDC-9EB5-4E6E-BB6A-AA5209D89582"},"E35B9EF7-0DBF-4941-932E-B027979217CD":{"parent":"AEEC3162-B48C-4955-9E4A-468E7F7F9287","level":3,"children":[],"pageId":"E35B9EF7-0DBF-4941-932E-B027979217CD","title":"Edge","href":"/stores/page/E35B9EF7-0DBF-4941-932E-B027979217CD"},"FE6A8EDA-C274-4BEC-8127-022889D15380":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["15AA038A-27CE-4641-883D-84A390F0DA70","629309B8-04DF-4FF8-901E-413A88D572F2"],"level":2,"pageId":"FE6A8EDA-C274-4BEC-8127-022889D15380","title":"Mercury/Quartz Collection","href":"/stores/page/FE6A8EDA-C274-4BEC-8127-022889D15380"},"7FA70731-D20B-4390-BB01-C3329AC830D1":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["E0E046DD-CED4-418F-8F0E-5B1E66A2B6A3","2223E13C-225C-448A-A345-E6F43EE4004E","B1CCF8F1-B32D-4DBA-B130-9C4246018BAE","4677A451-BFE7-43A2-94B5-D33CE2FC0807","6C6805ED-C1DD-4DE0-85A0-E41F1E8971A7","3B015EFB-D9A3-4F4F-A844-FC29624F6F44"],"level":2,"pageId":"7FA70731-D20B-4390-BB01-C3329AC830D1","title":"Mice","href":"/stores/page/7FA70731-D20B-4390-BB01-C3329AC830D1"},"77FA7216-D4E7-4ABA-8CE6-73F35867DB46":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["BD06F5A9-8E6B-4ABE-B1F4-1F3A63703F58","1AA8619D-1180-49DF-A620-A2FFEE58D8A5","36C095AB-F473-432A-B587-46A210205828","44580A73-34C1-4F26-AA4F-BF16D72B53BE"],"level":2,"pageId":"77FA7216-D4E7-4ABA-8CE6-73F35867DB46","title":"Mats","href":"/stores/page/77FA7216-D4E7-4ABA-8CE6-73F35867DB46"},"44580A73-34C1-4F26-AA4F-BF16D72B53BE":{"parent":"77FA7216-D4E7-4ABA-8CE6-73F35867DB46","level":3,"children":[],"pageId":"44580A73-34C1-4F26-AA4F-BF16D72B53BE","title":"Firefly","href":"/stores/page/44580A73-34C1-4F26-AA4F-BF16D72B53BE"},"9923FDF3-E24F-4072-8230-5493B97BB776":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","level":2,"children":[],"pageId":"9923FDF3-E24F-4072-8230-5493B97BB776","title":"Controllers","href":"/stores/page/9923FDF3-E24F-4072-8230-5493B97BB776"},"B1C6EFBC-3A3D-45F5-85E2-ADAA904895CC":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":[],"level":2,"pageId":"B1C6EFBC-3A3D-45F5-85E2-ADAA904895CC","title":"Licensed Products","href":"/stores/page/B1C6EFBC-3A3D-45F5-85E2-ADAA904895CC"},"4CF9CC25-12CE-4E9E-963E-CBC9F1B82A14":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"4CF9CC25-12CE-4E9E-963E-CBC9F1B82A14","title":"New & Notable: Razer Viper V4 Pro","href":"/stores/page/4CF9CC25-12CE-4E9E-963E-CBC9F1B82A14"},"D10DEFB8-3DFF-4B9E-B67B-C7168B7279F3":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":[],"level":2,"pageId":"D10DEFB8-3DFF-4B9E-B67B-C7168B7279F3","title":"Productivity","href":"/stores/page/D10DEFB8-3DFF-4B9E-B67B-C7168B7279F3"},"4FD84B07-A966-4FA7-9171-5648CE4C1ADA":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","children":[],"level":3,"pageId":"4FD84B07-A966-4FA7-9171-5648CE4C1ADA","title":"Gaming Headsets","href":"/stores/page/4FD84B07-A966-4FA7-9171-5648CE4C1ADA"},"9FE18585-A8A5-4B2E-85F5-05C282FE9405":{"parent":"75DD1756-F264-493D-A7A2-4946D8A15A09","level":3,"children":[],"pageId":"9FE18585-A8A5-4B2E-85F5-05C282FE9405","title":"Enki","href":"/stores/page/9FE18585-A8A5-4B2E-85F5-05C282FE9405"},"D9984C65-812C-4C55-9B3F-04A67CB4AA3B":{"parent":"767B96B8-E316-4C4D-91BA-E637ADB743F7","level":3,"children":[],"pageId":"D9984C65-812C-4C55-9B3F-04A67CB4AA3B","title":"Huntsman","href":"/stores/page/D9984C65-812C-4C55-9B3F-04A67CB4AA3B"},"C219EE55-73D3-4846-B607-91C13622F411":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["0592414B-E2AF-49D5-B7B5-769A1C141F8A","00D32277-E786-4FDE-AAAA-8FAED187E17C","9F7FCB09-D8ED-4E49-A220-CA41CE829CF3","964D2240-9028-403D-8400-B8A9168C07A9"],"level":2,"pageId":"C219EE55-73D3-4846-B607-91C13622F411","title":"Laptops","href":"/stores/page/C219EE55-73D3-4846-B607-91C13622F411"},"D5F8C3B8-20C5-4689-B0F2-7DCC00798CAE":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"D5F8C3B8-20C5-4689-B0F2-7DCC00798CAE","title":"Faker Edition -  Viper","href":"/stores/page/D5F8C3B8-20C5-4689-B0F2-7DCC00798CAE"},"F3A663BB-AA40-46DE-8671-CF6519F0CCF2":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","level":2,"children":["E3A68465-DE7A-4079-8FFA-C6CAB35E622E","88718101-1754-43AC-B182-CFE18819F832","4CF9CC25-12CE-4E9E-963E-CBC9F1B82A14","166B218E-0644-4721-A1D4-7C5F3611577A","37DB0965-4D7E-45B7-9E63-7A3F10A9B274","E3806543-5EDD-442C-9496-6C533CB3D721","4FD84B07-A966-4FA7-9171-5648CE4C1ADA","58A2BAA2-8C44-45CB-A6FC-C5BEAB2343BE","9EFC89B5-7360-4565-BCC1-1DAED157106B","8F3B2BD3-2448-4A8C-A963-99E3F47C99CF","4925CBF1-DFFA-4689-B424-5DDFF85BC3AE","D5F8C3B8-20C5-4689-B0F2-7DCC00798CAE","1BB832C5-F979-4950-AC8A-93BD0EF9524F","700EA385-B19E-484E-B403-32B65BA4EDBF"],"pageId":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","title":"Featured Products","href":"/stores/page/F3A663BB-AA40-46DE-8671-CF6519F0CCF2"},"1BB832C5-F979-4950-AC8A-93BD0EF9524F":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","level":3,"children":[],"pageId":"1BB832C5-F979-4950-AC8A-93BD0EF9524F","title":"Niko Collection","href":"/stores/page/1BB832C5-F979-4950-AC8A-93BD0EF9524F"},"18A1929E-2386-4B43-A130-58A41C88CE24":{"parent":"E2E253F5-087C-476C-8944-77B88D19B274","level":3,"children":[],"pageId":"18A1929E-2386-4B43-A130-58A41C88CE24","title":"Xbox","href":"/stores/page/18A1929E-2386-4B43-A130-58A41C88CE24"},"9F7FCB09-D8ED-4E49-A220-CA41CE829CF3":{"parent":"C219EE55-73D3-4846-B607-91C13622F411","level":3,"children":[],"pageId":"9F7FCB09-D8ED-4E49-A220-CA41CE829CF3","title":"Laptop Accessories","href":"/stores/page/9F7FCB09-D8ED-4E49-A220-CA41CE829CF3"},"0592414B-E2AF-49D5-B7B5-769A1C141F8A":{"parent":"C219EE55-73D3-4846-B607-91C13622F411","level":3,"children":[],"pageId":"0592414B-E2AF-49D5-B7B5-769A1C141F8A","title":"Blade 16","href":"/stores/page/0592414B-E2AF-49D5-B7B5-769A1C141F8A"},"2223E13C-225C-448A-A345-E6F43EE4004E":{"parent":"7FA70731-D20B-4390-BB01-C3329AC830D1","children":[],"level":3,"pageId":"2223E13C-225C-448A-A345-E6F43EE4004E","title":"Viper ","href":"/stores/page/2223E13C-225C-448A-A345-E6F43EE4004E"},"DFF86D43-34FA-4414-8588-0F58EAFD929C":{"parent":"4319E058-EBE2-4E54-B186-89C9F6F2DBA3","level":3,"children":[],"pageId":"DFF86D43-34FA-4414-8588-0F58EAFD929C","title":"Kraken","href":"/stores/page/DFF86D43-34FA-4414-8588-0F58EAFD929C"},"E2E253F5-087C-476C-8944-77B88D19B274":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["18A1929E-2386-4B43-A130-58A41C88CE24","6D3AAFF1-ED24-464B-898D-6096546A4B60","D3071CFE-1CC4-427E-8829-765A3E73D1FA","D196CC52-5538-43E9-B8D0-BD45883826CB","8F095BDC-9EB5-4E6E-BB6A-AA5209D89582","8827A69C-1086-47AD-96CF-87C9DD01493B","0B27581E-45A8-4851-999D-3582C7FA1FA1","3155493D-9CF5-4E79-88B6-780135241B86"],"level":2,"pageId":"E2E253F5-087C-476C-8944-77B88D19B274","title":"Console","href":"/stores/page/E2E253F5-087C-476C-8944-77B88D19B274"},"3155493D-9CF5-4E79-88B6-780135241B86":{"parent":"E2E253F5-087C-476C-8944-77B88D19B274","level":3,"children":[],"pageId":"3155493D-9CF5-4E79-88B6-780135241B86","title":"Kitsune","href":"/stores/page/3155493D-9CF5-4E79-88B6-780135241B86"},"00D32277-E786-4FDE-AAAA-8FAED187E17C":{"parent":"C219EE55-73D3-4846-B607-91C13622F411","level":3,"children":[],"pageId":"00D32277-E786-4FDE-AAAA-8FAED187E17C","title":"Blade 18","href":"/stores/page/00D32277-E786-4FDE-AAAA-8FAED187E17C"},"B6D02186-FBCB-45C2-88D9-C2EF474C5090":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["45950E11-9C9A-4BBC-9DED-D3C41AC6F581","36E3BDB3-E5A6-4545-BC6A-56F0F7221F08","D17E96F5-1491-48A8-9E7C-0CBF711F86C6"],"level":2,"pageId":"B6D02186-FBCB-45C2-88D9-C2EF474C5090","title":"Content Creation","href":"/stores/page/B6D02186-FBCB-45C2-88D9-C2EF474C5090"},"3B015EFB-D9A3-4F4F-A844-FC29624F6F44":{"parent":"7FA70731-D20B-4390-BB01-C3329AC830D1","level":3,"children":[],"pageId":"3B015EFB-D9A3-4F4F-A844-FC29624F6F44","title":"Orochi","href":"/stores/page/3B015EFB-D9A3-4F4F-A844-FC29624F6F44"},"75DD1756-F264-493D-A7A2-4946D8A15A09":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","level":2,"children":["9FE18585-A8A5-4B2E-85F5-05C282FE9405","905473EF-C5C3-43E1-AC39-3B81124A020C","2DFAE1E9-421E-46ED-89AF-02E2EACEDF0C","8ABD05E2-19AA-4300-B436-D620A489BDDE"],"pageId":"75DD1756-F264-493D-A7A2-4946D8A15A09","title":"Chairs","href":"/stores/page/75DD1756-F264-493D-A7A2-4946D8A15A09"},"CCB421CC-2DA1-41BD-AA05-A8572E409EFB":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","level":2,"children":[],"pageId":"CCB421CC-2DA1-41BD-AA05-A8572E409EFB","title":"Speakers","href":"/stores/page/CCB421CC-2DA1-41BD-AA05-A8572E409EFB"},"A2BB6555-7D49-4B41-B898-99361CC2CF5A":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","level":2,"children":[],"pageId":"A2BB6555-7D49-4B41-B898-99361CC2CF5A","title":"Gift Guide","href":"/stores/page/A2BB6555-7D49-4B41-B898-99361CC2CF5A"},"1C37A5F9-0DC7-4A60-BEF3-041B507B7560":{"parent":"4319E058-EBE2-4E54-B186-89C9F6F2DBA3","level":3,"children":[],"pageId":"1C37A5F9-0DC7-4A60-BEF3-041B507B7560","title":"Barracuda","href":"/stores/page/1C37A5F9-0DC7-4A60-BEF3-041B507B7560"},"6747C3F6-0984-4F2D-BB59-F82CA965911F":{"parent":"AEEC3162-B48C-4955-9E4A-468E7F7F9287","children":[],"level":3,"pageId":"6747C3F6-0984-4F2D-BB59-F82CA965911F","title":"Hammerhead","href":"/stores/page/6747C3F6-0984-4F2D-BB59-F82CA965911F"},"D3071CFE-1CC4-427E-8829-765A3E73D1FA":{"parent":"E2E253F5-087C-476C-8944-77B88D19B274","level":3,"children":[],"pageId":"D3071CFE-1CC4-427E-8829-765A3E73D1FA","title":"Switch 2","href":"/stores/page/D3071CFE-1CC4-427E-8829-765A3E73D1FA"},"233CF814-86C2-47A1-935F-36A735E6D262":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":[],"level":2,"pageId":"233CF814-86C2-47A1-935F-36A735E6D262","title":"Gaming Peripheral Accessories","href":"/stores/page/233CF814-86C2-47A1-935F-36A735E6D262"},"E3A68465-DE7A-4079-8FFA-C6CAB35E622E":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","children":[],"level":3,"pageId":"E3A68465-DE7A-4079-8FFA-C6CAB35E622E","title":"Huntsman - Analog Optical","href":"/stores/page/E3A68465-DE7A-4079-8FFA-C6CAB35E622E"},"6C0E7370-29E6-47A0-94B6-9ECE3F3A7F04":{"parent":"CDB96030-A7CF-4B56-B70C-67086A740274","children":["61AB3E15-3561-469F-999C-0FC8BD5D6D99"],"level":2,"pageId":"6C0E7370-29E6-47A0-94B6-9ECE3F3A7F04","title":"Gear & Lifestyle","href":"/stores/page/6C0E7370-29E6-47A0-94B6-9ECE3F3A7F04"},"6D3AAFF1-ED24-464B-898D-6096546A4B60":{"parent":"E2E253F5-087C-476C-8944-77B88D19B274","level":3,"children":[],"pageId":"6D3AAFF1-ED24-464B-898D-6096546A4B60","title":"PlayStation","href":"/stores/page/6D3AAFF1-ED24-464B-898D-6096546A4B60"},"E3806543-5EDD-442C-9496-6C533CB3D721":{"parent":"F3A663BB-AA40-46DE-8671-CF6519F0CCF2","children":[],"level":3,"pageId":"E3806543-5EDD-442C-9496-6C533CB3D721","title":"Gaming Keyboards","href":"/stores/page/E3806543-5EDD-442C-9496-6C533CB3D721"}},"imageOffsetTop":0,"imageKey":"al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg","description":"","type":"Hero","assetTags":"","imageOffsetLeft":0,"imageHeight":"600","assetId":"amzn1.assetlibrary.asset1.170df33e4cb80d40c4ffe7f944692110","mobileContent":{"imageWidth":3000,"canvasData":{"top":21.8,"left":0,"width":282,"naturalHeight":600,"naturalWidth":3000,"height":56.4},"imageOffsetTop":0,"assetId":"amzn1.assetlibrary.asset1.170df33e4cb80d40c4ffe7f944692110","imageKey":"al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg","imageUrl":"https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg","assetTags":"","imageOffsetLeft":0,"version":"v2","imageHeight":600,"image":"https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg","a11yImageAltText":""},"imageUrl":"https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg","id":"ispxe65wa3","image":"https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg","a11yImageAltText":""},"pageContext":{"template":"Blank","pageUrlStatus":"StoreBrandName","brandColor":"","program":"default","useBrandIdFlag":true,"introSplashVideo":{"hideIntroSplashVideo":true},"title":"Razer","widgetLayout":["Navigation","Hero","EditorialRow","EditorialRow","EditorialRow","EditorialRow","EditorialRow","EditorialRow","EditorialRow","ProductGrid","EditorialRow"],"isFollowMarketplaceSupported":true,"pageDescription":"Home Page","lastSubmittedTime":1598545160183,"productGridType":"standard","theme":"diamond","id":"CDB96030-A7CF-4B56-B70C-67086A740274","browseNode":2530293011,"brandLogo":{"imageWidth":"400","imageOffsetTop":0,"shape":"square","imageKey":"abs-image-upload-na/1/AmazonStores/ATVPDKIKX0DER/5e9eb9663a1d179d51b04f82e7f81253.w400.h400.png","imageUrl":"https://images-na.ssl-images-shopping.com/images/S/abs-image-upload-na/1/AmazonStores/ATVPDKIKX0DER/5e9eb9663a1d179d51b04f82e7f81253.w400.h400.png","hideBrandLogo":true,"imageOffsetLeft":0,"assetTags":"","imageHeight":"400","image":"https://m.media-shopping.com/images/S/abs-image-upload-na/1/AmazonStores/ATVPDKIKX0DER/5e9eb9663a1d179d51b04f82e7f81253.w400.h400.png","a11yImageAltText":""},"editionKey":"default","brandName":"Razer","storeType":"NAV","isAWLSLiveWidgetAddedOnce":true,"isFollowing":false,"entityType":"VENDOR","isSearchEnabled":true,"rootPageId":"CDB96030-A7CF-4B56-B70C-67086A740274","storeId":"CDB96030-A7CF-4B56-B70C-67086A740274","pagePath":"/stores/Razer/page/CDB96030-A7CF-4B56-B70C-67086A740274","brsEntityId":"220854","version":"0muzvd941","bfid":"BFqhRQw73NSSmdeUGB4qBTpQ==","brandId":"220854","pageImage":"https://m.media-shopping.com/images/S/al-na-9d5791cf-3faf/eefa39c6-aeb9-43d3-b0b0-50d3b9760df4.jpg","externalWidgetIds":["awls_cb4f34657f877973f57d2cb11b53f581f","awls_881ebdc8240d21931f70aedc74df96997"]},"requestContext":{"obfuscatedMarketplaceId":"ATVPDKIKX0DER","obfuscatedMerchantId":"ATVPDKIKX0DER","language":"en-US","sessionId":"147-0099296-5118245","customerIP":"170.75.255.122","currency":"GHS","almThresholdsMap":{},"queryParameterMap":{"slashargs":[""],"ref_":["ast_bln"],"lp_asin":["B0FDPJZQNY"],"store_ref":["bl_ast_dp_brandlogo_sto"],"brandname":["Razer"],"pageId":["CDB96030-A7CF-4B56-B70C-67086A740274"]},"weblabMap":{"ADPT_BSX_STORES_REMOVE_UNUSED_PRODUCT_VIDEOS_1387274":"T1","ADPT_SE_STORES_AAPI_PRODUCT_V2_PAST_INTERACTIONS_1082546":"T1","ADPT_SE_PREMIUM_BEAUTY_THEME_702020":"C","ADPT_BSX_STORES_1116842":"T1","ADPT_BSX_STORES_BYLINE_WIDGET_INJECTION_DESKTOP_1375753":"T1","ADPT_SE_STORES_CX_ATC_AND_QL_ON_SEARCH_RESULTS_597002":"T1","ADPT_SE_STORES_LIGHTNING_DEAL_ATC_1091731":"T1","ADPT_BSX_STORES_WIDGET_INSTRUMENTATION_1283213":"T1","ADPT_BSX_STORES_FOLLOW_ASSET_MARKETPLACE_GATE_1427858":"T1","LIVE_VIDEO_MAX_AGE_940615":"T1","STORES_386110":"C","ADPT_SE_STORES_BTPBADGEANDCLIPPING_808127":"T1","STORES_TEST_TRAFFIC_446265":"C","ADPT_SE_STORES_CX_OUT_OF_STOCK_FILTER_621421":"T1","ADPT_SE_STORES_CX_SOCIAL_SHARE_ON_HEADER_844025":"T1","BSX_CX_PANTHER_MIGRATION_1284400":"T3","SE_STORES_CX_SHOW_OOS_PARENT_572684":"T1","ADPT_BSX_STORES_AAPI_PRODUCT_VIDEO_V3_MIGRATION_1441202":"T1","CM_CR_OMNIBUS_426621":"T1","ASV_CNUBA_DRAM_MIGRATION_1185404":"T1","ADPT_SE_STORES_CX_SLIDER_MAGNIFIER_614391":"T1","ADPT_BSX_STORES_BYLINE_YMAL_MOBILE_MIGRATION_1393094":"T1","ADPT_BSX_STORES_CX_ATC_1312509":"T1","ADPT_SE_STORES_CX_SOCIAL_SHARE_849493":"T1","ADPT_BSX_STORES_DYNAMIC_PRODUCT_GRID_CX_GATING_1190230":"T1","ADPT_SE_STORES_CX_CNUBA_CACHE_1203035":"T1","ADPT_BSX_STORES_CPL_ARRIVAL_GATE_1386481":"T3","SE_STORES_CX_SHOW_OOS_569695":"T1"},"appendedParameters":{"ingress":"2","lp_context_asin":"B0FDPJZQNY","visitId":"8755ff19-67e4-4972-9990-e583cf886542","store_ref":"bl_ast_dp_brandlogo_sto"},"isPreviewCampaign":false,"deviceType":"desktop","deviceMode":"Desktop","appVersion":"","osName":"","ubId":"135-1922100-0406903","pageSubType":"LivePage","previewWidgetGroup":null,"slateToken":"AwcACwGhNNuUaU4tAQEFAABMRzBFAiAJA6TnO0sKXRCbAmEttZhH2LJ2SQbLlIUJWkp4eC2eBAIhAJBMXRb5J4/1T8WEmMPmvzB0HZyWXHc3mtXf1FANtimcAnYxAAUAdQAAIwJ2MW3LS3vlpFsyHugah4QxdsgLHD6/3iC5m92nDvC/Wu9VAQESBnJldGFpbAphbWF6b24uY29tAgAEAAAACAQCBWVuLVVTBQMDR0hTBwAEAAAAAAgEAaEJAAIAPwoAAQEMAAQAAAAADQUADgAEas4KSwMAAAYAAA==","freshCartCsrfToken":"g3LXIxNWXSkaolfaa64qIouCfM8Vy+QSNyjfin3C74WWAAAAAQAAAABqzgsocmF3AAAAAPxEJ5HRQInxPcX7Afa6ow==","painterContentId":"","internal":false,"profile":false,"mshop":false,"previewCampaignId":null,"debug":false,"inBlacklist":false,"customerId":"","amazonApiAjaxEndpoint":"data.shopping.com","amazonApiCsrfToken":"1@g8kZY+zryqId82PE+Vt7f523S6UzW0vlnWaHeDWId4p5AAAAAQAAAABqzgsocmF3AAAAAGfA1H5nd8xGEcC392DFmQ==@6LBVN4"}};
        var widgetDOM = document.getElementById("Header-x1upuvn53m");
        window.renderStoresWidgetsPendingList = window.renderStoresWidgetsPendingList || [];
        window.renderStoresWidgetsPendingList.push([widgetDOM, "Header", config, true]);
    })();
</script>

      </div>
    
    
  

</div><script type="text/javascript">
          if (window.P && window.P.AUI_BUILD_DATE) {
            window.P.register('cf');
          }
          if (ue) {
            uet('cf');
          }
        </script>

        <div id="LiveVideoBanner" class="a-row stores-row stores-widget-atf">




  
    
      <div data-csa-c-content-id="widget:LiveVideoBanner" data-csa-c-painter="AmazonStoresLiveVideoBanner" data-csa-c-slot-id="LiveVideoBanner" data-csa-c-type="widget" data-csa-op-log-render="" data-widgetid="LiveVideoBanner" data-widgettype="LiveVideoBanner" class="a-column a-span12 stores-column">
          <div class="celwidget" cel_widget_id="desktop-brandstore-btf" data-csa-op-log-render="" data-csa-c-content-id="DsUnknown" data-csa-c-slot-id="DsUnknown-1" data-csa-c-type="widget" data-csa-c-painter="AmazonLiveDramV2">






    
    <link rel="stylesheet" href="https://m.media-shopping.com/images/I/010rvoEcCnL.css?AUIClients/ShareWidgetTriggerAssets" />
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/51WZqXp7z7L.css?AUIClients/FollowButtonWidgetAssets" />



<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('amazonlive-need-share').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/21pj1OVABnL.js?AUIClients/ShareWidgetTriggerAssets');
});
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('amazonlive-need-follow').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/51+aVv60wyL.js?AUIClients/FollowButtonWidgetAssets');
});
</script>










<script type="text/javascript">(function(f) {var _np=(window.P._namespace("AmazonLivePortalJavaScript"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
    if (window.ue) {
        window.ues && window.ues('ctb', 'AmazonLiveReact', '1');
        window.uet && window.uet('bb', 'AmazonLiveReact', { wb: 1 });
    }
    window.AmazonLiveHTMLPrintDateTime = new Date().getTime();
}));</script>



    
    
    
        <div id="live-flagship-root" class="amazonlive-widget-padding"></div>
    


<script id= "amazonlive-pd19flagship">
    if (window.ue && window.ue.count) {
        window.ue.count("pd19flagship", 1);
    }
</script>

<script type="text/javascript">(function(f) {var _np=(window.P._namespace("AmazonLivePortalJavaScript"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
window.al_ltnc_m = {}
window.al_ltnc_m.al_st = new Date().getTime();
window.uet && window.uet('bb', 'AmazonLiveFlagshipAssetsLoadLatency', { wb: 1 });
window.ue && window.ue.tag && window.ue.tag("AmazonLiveFlagshipAssets");
}));</script>

<script type="text/javascript" src="https://m.media-shopping.com/images/S/sash/cApzMxYQxXChwEk.js?name=vendors" crossorigin="anonymous" defer></script>
<script type="text/javascript" src="https://m.media-shopping.com/images/S/sash/nLTOsV7d-hjfgR1.js?name=app" crossorigin="anonymous" defer></script>
<link rel="stylesheet" type="text/css" href="https://m.media-shopping.com/images/S/sash/huT8KbbNXnZecoL.css?type=asset&name=vendors" crossorigin="anonymous" />
<link rel="stylesheet" type="text/css" href="https://m.media-shopping.com/images/S/sash/t3YgBEbywBe39-Z.css?type=asset&name=app" crossorigin="anonymous" />


<script type="text/javascript">(function(f) {var _np=(window.P._namespace("AmazonLivePortalJavaScript"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
window.al_ltnc_m.al_end = new Date().getTime();
window.uex && window.uex('ld', 'AmazonLiveFlagshipAssetsLoadLatency', { wb: 1 });
}));</script>



<script type="text/javascript">(function(f) {var _np=(window.P._namespace("AmazonLivePortalJavaScript"));if(_np.guardFatal){_np.guardFatal(f)(_np);}else{f(_np);}}(function(P) {
    var auiEventsToWait = [];
    var waitedP = auiEventsToWait.length === 0 ? P : P.when.apply(P, auiEventsToWait);
    waitedP.execute('amazonlive-flagship-init', function() {
        const rootElement = document.getElementById("live-flagship-root");
        var liveFlagshipStates = {
            "amazonlive-react-component-id": "desktopFlexBanner",
            "aapi-csrf-token": "1@g4mKBqqiRUzmceZ/WJby/tn3HuPyZcfnwcdcte/C7VzHAAAAAQAAAABqzgsocmF3AAAAAGfA1H5nd8xGEcC356nsaQ==@X5X6DJ",
            "source": "",
            "content-id": "1480b661-b3ac-4e0a-9a63-fa6f34e87275",
            "locale": "en_US",
        };
        
        
            liveFlagshipStates["amazonlive-react-widget-options-data"] = JSON.parse("{\"autoplay\":true,\"muted\":true,\"showBackground\":false,\"enableDestinationIngress\":false,\"enableExpandablePlayer\":true,\"disableMobileMute\":false,\"reactionsEnabled\":true,\"autoFocus\":false,\"enableSpecialEventBadge\":true,\"disableFeeDisclosure\":true,\"enableDesktopImmersiveView\":true,\"enableMobileImmersiveView\":true,\"enableChannelPageLink\":false,\"livebadge\":\"live_badge\",\"catamaranBrandStores\":true,\"enableClosedCaptionByDefault\":true,\"enableContentLevelInstrumentationOSA\":true,\"enableProductCarouselAddToCart\":true,\"enableLiveTitleBarLogo\":true,\"enableLiveTitleBarText\":true,\"title\":\"Shop our Live Events\",\"isChatEnabled\":true,\"isShareEnabled\":true,\"isUpNextEnabled\":true,\"ispVerticalRedesign\":false,\"upNextBroadcastIds\":[\"eb4e5ab2-8e78-4bec-baf7-5a010895f412\",\"5880efb7-eb46-4eea-afa5-8acc5eb764ac\",\"559f105c-d601-420c-bd05-6c8dd5511aef\",\"94fde3db-7c13-422a-9797-b5db2b414470\",\"c2cb377f-8763-4e0f-b5be-78d584433083\",\"be4e5a3e-0d12-470c-ae67-2c2c2c6a8668\",\"cc99ac59-c03c-4511-a0e2-4171dbe66916\",\"58b363cc-0854-4646-834e-220a43b7b409\"]}");
        
            liveFlagshipStates["amazonlive-react-aui-page-context"] = JSON.parse("{\"marketplaceId\":\"ATVPDKIKX0DER\",\"deviceType\":\"desktop\",\"appVersion\":\"NA\",\"sessionId\":\"147-0099296-5118245\"}");
        
            liveFlagshipStates["amazonlive-react-weblab-data"] = JSON.parse("{\"BFCMBadgeGating\":\"C\",\"PEASBadgeGating\":\"C\",\"BFCMBadgeTreatments\":\"C\",\"PDBadgeGating\":\"C\",\"PBDDBadgeGating\":\"C\",\"communityModeration\":\"C\"}");
        
            liveFlagshipStates["amazonlive-react-endpoints-data"] = JSON.parse("{\"amazonlive-react-string-translations\":\"https:\/\/d2in0p32vp1pij.cloudfront.net\/v2\/string-translations\",\"amazonlive-react-mediaclient-data\":\"https:\/\/d2in0p32vp1pij.cloudfront.net\/v2\/mediaclient\",\"amazonlive-react-poller-data\":\"https:\/\/d2in0p32vp1pij.cloudfront.net\/v2\/poller?portalOptions=%7B%22enableFlagship%22%3Atrue%2C%22enableVod%22%3Atrue%2C%22vodTimeFrame%22%3A%22365d%22%2C%22preLiveTimeFrame%22%3A%220%22%7D\",\"amazonlive-react-playlist-data\":\"https:\/\/amazonlive-portal.shopping.com\/v2\/playlist?broadcast=1480b661-b3ac-4e0a-9a63-fa6f34e87275&portalOptions=%7B%22enableFlagship%22%3Atrue%2C%22enableVod%22%3Atrue%2C%22vodTimeFrame%22%3A%22365d%22%2C%22preLiveTimeFrame%22%3A%220%22%7D\",\"upNextBroadcasts\":\"https:\/\/d2in0p32vp1pij.cloudfront.net\/v2\/up-next?broadcastId=%7BbroadcastId%7D\",\"amazonlive-react-follow-data\":\"https:\/\/amazonlive-portal.shopping.com\/v2\/follow?broadcastId=%7BbroadcastId%7D\",\"amazonlive-react-hydrate-broadcast-metadata-data\":\"https:\/\/d2in0p32vp1pij.cloudfront.net\/v2\/hydrate-broadcast-metadata?broadcastIds=%7BbroadcastIds%7D\"}");
        
            liveFlagshipStates["amazonlive-react-metrics-data"] = JSON.parse("{\"marketplaceId\":\"ATVPDKIKX0DER\",\"refMarker\":\"\",\"linkParameters\":{},\"pageType\":\"AmazonStores\",\"placementId\":\"\",\"requestId\":\"KAS98C370K01G4FPVKFV\",\"customerId\":\"\",\"trafficType\":\"external\",\"sessionId\":\"147-0099296-5118245\",\"stageFlag\":\"prod\",\"adSlotName\":\"AWLSWidget-1\",\"trafficPolicy\":[]}");
        
            liveFlagshipStates["amazonlive-react-appsync-config-data"] = JSON.parse("{\"endpoint\":\"https:\/\/p3epspumangb5dvijf52er7wdi.appsync-api.us-east-1.amazonaws.com\/graphql\",\"authenticationType\":\"API_KEY\",\"region\":\"us-east-1\",\"apiKey\":\"da2-gpqhkgzhyvclpeuc4ywabkn5ty\"}");
        
            liveFlagshipStates["amazonlive-react-show-data"] = JSON.parse("{\"show\":{\"id\":\"6ba2783b-4897-4b8d-bd22-b7f654800f9e\",\"title\":\"Razer\",\"description\":null,\"slateImageId\":\"https:\/\/images-na.ssl-images-shopping.com\/images\/S\/amazonlive-media-prod\/show\/default\/default_slate.jpeg\",\"logoImageId\":\"https:\/\/m.media-shopping.com\/images\/S\/stores-image-uploads-na-prod\/c\/AmazonStores\/ATVPDKIKX0DER\/383e69c4db4796cc06b80ed8780c55a8.w640.h640._RO319,1,0,0,0,0,0,0,0,0,15_FMpng_.jpg\",\"pageUrl\":\"https:\/\/www.shopping.com\/stores\/page\/CDB96030-A7CF-4B56-B70C-67086A740274\",\"marketplaceId\":null,\"categoryIds\":null,\"type\":null,\"streamKey\":null,\"followEntityId\":\"BFqhRQw73NSSmdeUGB4qBTpQ==\",\"followEntityType\":\"brand\",\"associateLinkCode\":null,\"associateTag\":null,\"associateOffSiteTag\":null,\"featureGroup\":\"3P\",\"customerId\":null}}");
        
            liveFlagshipStates["amazonlive-react-mediaclient-data"] = JSON.parse("{\"backButtonIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/Player\/back-button._CB485933500_.png\",\"shareTwitterIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/social_share_logo\/icon_twitter._CB464284770_.png\",\"shareMailIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/social_share_logo\/icon_mail._CB464284770_.png\",\"shareIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/social_share_logo\/icon_share._CB464284770_.png\",\"mutedIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/Player\/mute._CB485933980_.png\",\"playerViewIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/Player\/Views-Icon._CB485946856_.png\",\"moreOptionsIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/Player\/more-options._CB485935838_.png\",\"sharePinterestIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/social_share_logo\/icon_pinterest._CB464284770_.png\",\"shareFacebookIcon\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/social_share_logo\/icon_fb._CB464284770_.png\",\"navbannerLogo\":\"https:\/\/m.media-shopping.com\/images\/G\/01\/poppin\/Portal\/live-logo._CB485936389_.png\"}");
        
            liveFlagshipStates["amazonlive-react-string-translations"] = JSON.parse("{\"amazon-live-watchmore-streams\":\"Watch more livestreams\",\"amazonlive-portal-enable-closed-caption-text\":\"Enable Closed Captions\",\"asv-lns-all-notifications-label\":\"Click\/Tap to recieve all live notifications for this creator\",\"amazon-live-post-ingress-message\":\"Livestream has ended\",\"amazon-live-accessibility-chat-tab-announcement\":\"Chat tab. Do you want to mute the livestream to hear chat messages?\",\"amazon-live-carousel-product-title\":\"This product is titled ${title}\",\"asv-lns-live-notifications-label\":\"Click\/Tap the button to open dropdown list to change live notification settings\",\"gb_added_to_cart\":\"Added\",\"view-in-browser\":\"View in Browser\",\"amazon-live-deals-timer-label-bottom\":\"on select products\",\"amazon-live-promo-code-eligible-text-claimed\":\"Take ${percentage} off at checkout\",\"amazon-live-video-now-paused\":\"video now paused\",\"sponsored-product-ai-disclosure\":\"May include AI generated people\",\"asv-lns-unfollow-toast-label\":\"Toast message: You no longer follow this creator\",\"copyright-infringement-link-text\":\"Copyright Infringement\",\"amazon-live-livebadge\":\"LIVE\",\"carousel-load-more\":\"Load More\",\"amazon-live-promo-code-claim-success\":\"Up to ${percentage} off eligible products applied at checkout.\",\"amazon-live-promo-code-deal-claimed\":\"Deals claimed!\",\"up-next-title-link-text\":\"Browse all\",\"report-success-header\":\"Thank you for your feedback.\",\"amazon-live-accessibility-chat-keep-livestream-on\":\"Keep livestream on\",\"amazon-live-promo-code-learn-more\":\"Promotion Terms\",\"amazon-live-multiple-reactions-nonreacted-label\":\"${displayCount} people have liked this content, tap to like\",\"amazon-live-influencer-fee-disclosure-link-text\":\"Earns commissions\",\"amazon-live-chat-minimized\":\"Chat currently minimized\",\"amazon-live-immersive-chat\":\"Chat\",\"report-illegal-content-link-text\":\"Report illegal content\",\"amazon-live-previouslylive-badge\":\"Previously Live\",\"amazon-live-see-details-button-text\":\"See details\",\"amazon-live-promo-code-claim-general-error\":\"Oops, please try again. If you are not signed in, please sign in.\",\"amazon-live-promo-code-sign-in-button-text\":\"Sign in\",\"asv-how-to-redeem-label\":\"How to redeem\",\"amazon-live-chat-toggle-expanded\":\"Toggle chat. Currently expanded\",\"asv-lns-unfollow-toast\":\"You no longer follow this creator\",\"amazon-live-catamaran-influencer-fee-disclosure-url\":\"https:\/\/www.shopping.com\/shop\/info\",\"amazonlive-portal-unmute-text\":\"Unmute\",\"amazon-live-new-chats\":\"New chats\",\"amazon-live-promo-code-claim-button-text\":\"Claim Deals\",\"report-illegal-content-description\":\"If you find this video to be inappropriate, please inform us by clicking the \'Report\' button below. If you suspect that this content is illegal, use the \'Report illegal content\' link.\",\"amazon-live-deals-ended-disclaimer-body\":\"The deals from this live stream have already ended and are no longer available.\",\"amazon-live-past-hours-stream-message\":\"Streamed live ${hoursAgo} ago\",\"amazonlive-portal-mute-text\":\"Mute\",\"amazon-live-view-past-livestreams\":\"View all my past livestreams\",\"up-next-footer-link-text\":\"Browse all livestreams\",\"asv-how-to-redeem-sop\":\"1. Press the \u201CClaim Deals\u201D button.\\n2. Select an eligible product.\\n3. Add the product to your cart.\\n4. Complete your purchase.\",\"sponsored-product-label\":\"Sponsored\",\"amazon-live-single-reaction-reacted-label\":\"${displayCount} person has liked this content, tap to unlike\",\"amazonlive-portal-disable-closed-caption-text\":\"Disable Closed Captions\",\"report-success-description\":\"We appreciate your report.\",\"asv-lns-personalized-notifications-toast-label\":\"Toast message: You will get personalized live notifications from this creator\",\"amazon-live-swipe-next-video\":\"Swipe left for next video\",\"share-button-text\":\"Share\",\"amazon-live-watch-now\":\"Watch now\",\"asv-lns-pop-over-label\":\"Pop-over message: Sign up for all live notifications, and never miss a livestream from this creator!  \",\"gb_you_are_on_waitlist\":\"You are on the Waitlist for this item.\",\"percent-claimed-text\":\"% claimed\",\"amazon-live-past-date-stream-message\":\"Streamed live on ${startDate}\",\"amazon-live-past-minutes-stream-message\":\"Streamed live ${minutesAgo} ago\",\"live-video-label\":\"Live video \\\"{videoTitle}\\\" from {creatorName}\",\"amazon-live-products\":\"Shop\",\"asv-lns-no-notifications\":\"No live notifications\",\"amazonlive-portal-volume\":\"Volume\",\"amazon-live-chat-expanded\":\"Chat currently expanded\",\"amazon-live-atc-success-msg\":\"Added to cart\",\"amazon-live-deals-timer-label-top\":\"Extra ${percentage}% Off Ends in\",\"amazon-live-carousel-deal-price\":\"Deal price is ${formattedPrice}\",\"asv-lns-live-notifications\":\"Live notifications\",\"transcript\":\"Transcript\",\"amazon-live-featured-product-title\":\"The product ${title} is currently highlighted\",\"csld-checking_deal_status_alt\":\"Checking Deal Status\",\"report-abuse-description\":\"If you find this content inappropriate and think it should be removed from the Amazon site, let us know by clicking the button below.\",\"amazon-live-promo-code-live\":\"LIVE EXCLUSIVE DEALS \uD83D\uDD25\",\"asv-how-to-redeem-description\":\"(Live-exclusive deals applied at checkout)\",\"sign-in-to-report-message\":\"To submit a report {0}\",\"asv-sponsored-by\":\"Sponsored by\",\"asv-lns-personalized-notifications\":\"Personalized live notifications\",\"report-button-text\":\"Report\",\"amazon-live-show-overlay\":\"Show Overlay\",\"asv-lns-no-notifications-toast\":\"\uD83D\uDCA4 You have muted live notifications from this creator\",\"sign-in-to-report-link-text\":\"log in to your account.\",\"asv-lns-personalized-notifications-toast\":\"You will get personalized live notifications from this creator\",\"amazon-live-future-stream-message\":\"Livestream starting at ${startTime} on ${startDate}\",\"amazon-live-atc-button-text\":\"Add to cart\",\"amazon-live-atc-failure-msg\":\"Unable to add to cart\",\"nonlive-video-label\":\"Video \\\"{videoTitle}\\\" from {creatorName}\",\"amazonlive-close-expanded-player\":\"close expanded player\\r\\n\",\"amazon-live-chat-toggle-minimzed\":\"Toggle chat. Currently minimized\",\"amazon-live-multiple-reactions-react-label\":\"${displayCount} people have liked this content, tap to unlike\",\"asv-how-to-redeem-title\":\"To claim these deals on your purchase:\",\"energy-efficiency-product-sheet\":\"Product Sheet\",\"asv-lns-all-notifications\":\"All live notifications\",\"amazon-live-send\":\"Send\",\"report-abuse-header\":\"Report Abuse\",\"carousel-load-more-accessibility-text\":\"Click to load more product items\",\"amazon-live-expand-player\":\"Expand player\",\"amazon-live-today-stream-message\":\"Livestream starting at ${startTime} today\",\"amazon-live-promo-code-eligible-text-unclaimed\":\"Claim to see deal\",\"energy-efficiency-accessibility-description\":\"Energy class range is from {A} to {G}. This product has energy class {X}.\",\"copy-button-text\":\"Copy\",\"amazon-live-watchmore\":\"Watch more\",\"gb_deal_in_your_cart\":\"This deal is in your Cart.\",\"amazon-live-deals-timer-countdown\":\"${discount}% OFF for Prime members ends in\",\"show-transcript\":\"Show transcript\",\"energy-efficiency-class\":\"Energy Efficiency Class: {X}\",\"asv-see-all-details\":\"See all details\",\"amazon-live-single-reaction-nonreacted-label\":\"${displayCount} person has liked this content, tap to like\",\"amazon-live-grid-checkout-discount-sublabel\":\"no checkout da live\",\"up-next-vod-only-footer-link-text\":\"Browse all videos\",\"gb_you_have\":\"You have\",\"amazon-live-flex-link-text\":\"See more from Amazon Live\",\"amazon-live-promo-code-prefix\":\"Click here to\",\"more-options\":\"More options\",\"amazon-live-accessibility-chat-mute-livestream\":\"Mute livestream\",\"asv-lns-personalized-notifications-label\":\"Click\/Tap to recieve personalized live notifications for this creator\",\"amazon-live-carousel-list-price\":\"List price is ${listPrice}\",\"amazon-live-featured-now\":\"Featured now\",\"amazon-live-desktop-watch-more\":\"Watch More\",\"amazon-live-influencer-fee-disclosure-tooltip-text\":\"This influencer livestream is intended to provide you with information that you may find helpful to your purchasing decisions. This influencer is compensated and is a part of the Amazon Influencer Program.\",\"asv-lns-all-notifications-toast\":\"\uD83D\uDD25 You will get all live notifications from this creator\",\"asv-lns-all-notifications-toast-label\":\"Toast message: \uD83D\uDD25 You will get all live notifications from this creator\",\"asv-lns-no-notifications-toast-label\":\"Toast message: \uD83D\uDCA4 You have muted live notifications from this creator\",\"energy-efficiency-heading\":\"Energy Efficiency & Product Sheet\",\"amazon-live-deals-ended-disclaimer-title\":\"Disclaimer\",\"amazon-live-carousel-image-title\":\"This image is titled ${title}\",\"amazon-live-detailpage-default-title\":\"Livestreams related to this product\",\"amazon-live-past-days-stream-message\":\"Streamed live ${daysAgo} ago\",\"gb_left_to\":\"left to\",\"gbd_join_waitlist\":\"Join Waitlist\",\"amazonlive-portal-now-muted-text\":\"now muted\",\"close-button-text\":\"Close\",\"amazon-live-video-now-playing\":\"video now playing\",\"amazon-live-grid-checkout-discount-label\":\"Economize ${percentage}%\",\"amazon-live-promo-code-deal\":\"DISCOUNT\",\"amazon-live-pause-player\":\"Pause\",\"amazon-live-slate-image-container\":\"Amazon Live Slate Image\",\"amazon-live-more-livestreams\":\"More livestreams\",\"amazon-live-play-player\":\"Play\",\"amazon-live-influencer-fee-disclosure-url\":\"https:\/\/www.shopping.com\/shop\/info\",\"amazon-live-influencer-fee-revenue-disclosure-link-text\":\"Earns Revenue\",\"asv-lns-pop-over\":\"Sign up for all live notifications, and never miss a livestream from this creator!  \",\"amazon-live-influencer-fee-disclosure-tooltip-link-text\":\"Learn more about the Amazon Influencer Program.\",\"asv-lns-no-notifications-label\":\"Click\/Tap to recieve no live notifications for this creator\",\"amazon-live-grace-period-ingress-message\":\"Livestream will begin soon\",\"amazon-live-brand-title\":\"Live from the brand\",\"gbd-checkout\":\"check out\",\"energy-efficiency\":\"Energy Efficiency\",\"amazon-live-promo-code-claim-network-error\":\"Something went wrong! Please try again later.\",\"report-error-message\":\"There was a problem with your request, please try again.\"}");
        
            liveFlagshipStates["amazonlive-react-playlist-data"] = JSON.parse("{\"amazonlive-react-playlist-data\":[{\"chatStartDateTime\":1791425175122,\"captionUrl\":\"https:\/\/d9dk5d4x2qkys.cloudfront.net\/1480b661-b3ac-4e0a-9a63-fa6f34e87275_21ea989a-2016-45fc-9160-b87a07a436ea.vtt\",\"associatedVideos\":{\"inaudibleToneEmbeddedVideo\":null,\"teaserVideo\":null,\"originalVideo\":null,\"postLiveTeaserVideo\":{\"mp4Url\":null,\"contentId\":null,\"workFlowStatus\":null,\"defaultTeaserVideo\":null,\"videoOrientation\":null,\"hlsUrl\":null,\"publicMp4Url\":\"https:\/\/d2ktpyrc961t9h.cloudfront.net\/3ffe1ac4-ed43-4ce5-afb1-f3dbf2f9bc82.mp4\"}},\"trimmingMetadata\":{\"secondsTrimmed\":null,\"hlsUrl\":null,\"trimmingEnabled\":true},\"streamingOrientation\":\"HORIZONTAL\",\"thumbUrl\":null,\"livePlaybackUrl\":\"https:\/\/4b64d6fa612f.us-east-1.playback.live-video.net\/api\/video\/v1\/us-east-1.408268288382.channel.4m8Cgy9ppgN1.m3u8\",\"stage\":\"COMPLETE\",\"videoSource\":\"THIRD_PARTY_ENCODER\",\"captionLocale\":\"en-US\",\"broadcastEndDateTime\":1791428317612,\"statusLastUpdated\":1791428317,\"polls\":null,\"showId\":\"6ba2783b-4897-4b8d-bd22-b7f654800f9e\",\"publicChatroomUrl\":\"1-2d7e3d54-fc72-2814-6846-506acaa778ac\",\"primaryMarketplaceId\":\"ATVPDKIKX0DER\",\"description\":null,\"vseActivateStatus\":\"ACTIVE\",\"createdDateTime\":1791425096446,\"uneditedSlateImageUrl\":null,\"secondaryLiveCaptionUrl\":null,\"moderationEvents\":null,\"contentACI\":\"amzn1.amazonlive.broadcast.1480b661-b3ac-4e0a-9a63-fa6f34e87275\",\"slateImageId\":\"https:\/\/images-na.ssl-images-shopping.com\/images\/S\/amazonlive-media-prod\/broadcast\/1\/1480b661-b3ac-4e0a-9a63-fa6f34e87275_20261008020508\/image\/slate-HORIZONTAL.jpg\",\"businessPrograms\":null,\"associateSubtag\":null,\"title\":\"LEVEL UP FOR LESS: PLAY, CREATE, CONQUER\",\"sponsoredImageId\":null,\"endTime\":null,\"liveCaptionUrl\":null,\"vods\":null,\"expirationDateTime\":1791428617607,\"privateChatroomHuddleId\":\"1-060ada66-2e4a-5e63-6846-506ac96630ed\",\"broadcastType\":null,\"startTime\":1791425100000,\"pinnedMessages\":null,\"creatorACI\":\"amzn1.follows.brand.BFqhRQw73NSSmdeUGB4qBTpQ==\",\"mp4FileName\":\"67181c7f-f17e-4bf8-8ba2-07dab12f449c_2XSAV4HK.MP4\",\"moderationCode\":null,\"segmentIds\":null,\"hlsUrl\":\"https:\/\/d17dupcd3sd4s8.cloudfront.net\/6ba2783b-4897-4b8d-bd22-b7f654800f9e\/1480b661-b3ac-4e0a-9a63-fa6f34e87275\/21ea989a-2016-45fc-9160-b87a07a436ea\/hls\/byte-range-multivariant.m3u8\",\"updatedDateTime\":1791428385109,\"electForDeals\":false,\"autoVerticalEnabled\":null,\"id\":\"1480b661-b3ac-4e0a-9a63-fa6f34e87275\",\"chatStatus\":\"DISABLED\",\"broadcastStartDateTime\":1791425175122,\"asin\":\"1480b661-b3ac-4e0a-9a63-fa6f34e87275\",\"mp4UploadStatus\":\"COMPLETED\",\"ideaListACI\":null,\"distribution\":\"PUBLIC\",\"privateChatroomUrl\":\"1-060ada66-2e4a-5e63-6846-506ac96630ed\",\"publicChatroomHuddleId\":\"1-2d7e3d54-fc72-2814-6846-506acaa778ac\",\"accountId\":\"17a04e26-a7d8-4a78-83c4-a6f8ce5b4097\",\"promotionsMetadata\":null,\"secondaryLivePlaybackUrl\":null,\"closedCaptionsValid\":true,\"electForGiveaways\":null,\"callToAction\":null,\"twitchVideoMetadata\":{\"sessionId\":\"st-1Bs9upaJ6jyhAFjlI1Aj8Mb\",\"contentId\":\"6ba2783b-4897-4b8d-bd22-b7f654800f9e\",\"customerId\":null},\"broadcastVariants\":[{\"videoHeight\":720,\"captionLocale\":\"en-US\",\"playbackUrl\":\"https:\/\/d17dupcd3sd4s8.cloudfront.net\/6ba2783b-4897-4b8d-bd22-b7f654800f9e\/1480b661-b3ac-4e0a-9a63-fa6f34e87275\/21ea989a-2016-45fc-9160-b87a07a436ea\/hls\/byte-range-multivariant.m3u8\",\"captionUrl\":\"https:\/\/d9dk5d4x2qkys.cloudfront.net\/1480b661-b3ac-4e0a-9a63-fa6f34e87275_21ea989a-2016-45fc-9160-b87a07a436ea.vtt\",\"variantType\":\"POST_LIVE_HLS\",\"orientation\":\"HORIZONTAL\",\"videoWidth\":1280,\"secondsTrimmed\":null}],\"showFeatureGroup\":\"3P\",\"slateImages\":[{\"slateImageId\":\"https:\/\/images-na.ssl-images-shopping.com\/images\/S\/amazonlive-media-prod\/broadcast\/1\/1480b661-b3ac-4e0a-9a63-fa6f34e87275_20261008020508\/image\/slate-HORIZONTAL.jpg\",\"orientation\":\"HORIZONTAL\"}],\"moderated\":false,\"chatEndDateTime\":1791428317612,\"carouselItems\":[{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"7b706550-7947-4c95-8848-e60eef1c957c\",\"asin\":\"B0FNBLG4SB\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"58266398-a079-4d79-a082-e658637b745b\",\"asin\":\"B0FNBLG4SD\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"ec8c6f0f-5919-4933-9f32-88a2043eae91\",\"asin\":\"B0CT7D7JVR\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"9103e0b6-9a97-4b1f-ab27-6a43d1654da9\",\"asin\":\"B0CMTQPWQ8\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"3837d6d2-de36-4354-b687-40b66bea04df\",\"asin\":\"B0FJ4CKYPW\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"0a07fdfc-c8cf-432f-830f-8ce65485caec\",\"asin\":\"B0F5FPG64M\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"4e88321e-a191-4fbe-a9d9-270e4450793f\",\"asin\":\"B0D9ZV97P6\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"b8e75692-c35e-4cc1-8335-929bcb9e29d3\",\"asin\":\"B0DJDWWHTV\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"1595a24b-be00-4cc5-8233-c92de9ea558b\",\"asin\":\"B0GFPWZ82H\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"cfdab0a6-1e46-4435-ad44-194baa8c7bbb\",\"asin\":\"B0GFPZ343R\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"beb020af-5226-4c46-95fc-0523fa033e1c\",\"asin\":\"B0BGJTLFN5\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"ebda034f-0d4c-4fc4-9a22-a534b055235e\",\"asin\":\"B0B6Y3XYFG\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"ad4bd6e7-f929-46af-ad13-bb5b3b9f09ac\",\"asin\":\"B0BT3VC25K\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"35d8487a-f5e6-45c3-87ec-bfcc67e69198\",\"asin\":\"B0FD5276Z6\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"9dd910f3-af4d-4840-89af-59e926b0e1da\",\"asin\":\"B0BY1FXC9N\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"5dc7905e-d7e7-43a9-9b6c-a4937031fa2e\",\"asin\":\"B0D4RF55QK\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"30136493-5669-4954-8e1d-672cc380a33d\",\"asin\":\"B0F8678RTT\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"4d59ed5f-38cf-482e-a746-ce688651d4c2\",\"asin\":\"B0FRT1K56P\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"3b47de62-0809-4f8a-b33a-849527254582\",\"asin\":\"B0DVD5RTZ5\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"64ed1c8c-de80-4f1c-a2a1-3538c936c0cb\",\"asin\":\"B0GFYHYCB3\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"7902d66f-fef6-4a8b-bb4e-6e862cac221e\",\"asin\":\"B0FNBN5PB3\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"0ea70508-8e83-4e55-9077-fe0003ec6ed2\",\"asin\":\"B0FNBNZPBH\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"4272be33-7fa3-4b01-85c1-b6e601c18dd6\",\"asin\":\"B0CCWDJ6GF\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"9b328eb4-bcf5-4b6a-9126-e14c61d331b2\",\"asin\":\"B0FJ4F3TJT\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"c4b639f0-b49b-4cee-b60b-36178280a6d3\",\"asin\":\"B0C5FQZHRN\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"1f664ea6-49ca-4dab-8a93-a2cbd49038ff\",\"asin\":\"B09HN5T4X2\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"74f677df-84b9-4049-bdef-b2aec2737bcc\",\"asin\":\"B0CGGPKBCZ\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"2573acbc-d532-45d4-9873-d4fbef993715\",\"asin\":\"B0CGH3KY8Y\",\"productDimensions\":null},{\"type\":\"PRODUCT\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":null,\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"2ca1ab15-eb81-4fbc-9e51-9c6554b7a5da\",\"asin\":\"B0CMGDGRD8\",\"productDimensions\":null},{\"type\":\"CUSTOM_TILE_TEMPLATED\",\"revealMetadata\":null,\"retargetingPixel\":null,\"subType\":\"WATCH_MORE_TILE\",\"advertiserId\":null,\"associatedPromotionIds\":null,\"revealTime\":null,\"integrationId\":null,\"revealText\":null,\"id\":\"1480b661-b3ac-4e0a-9a63-fa6f34e87275\",\"integrationAsins\":null,\"url\":\"\/live?ref=Live_3P_CT\",\"badgeText\":null,\"imageId\":\"s3:\/\/amazonlive-media-prod\/customtile\/3\/3da482a1-7383-42d7-8201-b7872c1f4c8b\/image\/item.jpg\",\"actionButtonText\":\"See more\",\"title\":\"Watch more livestreams\",\"backgroundImageId\":null}]}],\"amazonlive-react-vse-metadata\":null,\"amazonlive-react-endpoints-data\":{\"amazonlive-react-show-data\":\"https:\/\/d2in0p32vp1pij.cloudfront.net\/v2\/show?showId=6ba2783b-4897-4b8d-bd22-b7f654800f9e\",\"amazonlive-react-chat-data\":\"https:\/\/amazonlive-portal.shopping.com\/v2\/chat?broadcastId=1480b661-b3ac-4e0a-9a63-fa6f34e87275\"},\"amazonlive-react-broadcast-events-data\":{\"id\":\"1480b661-b3ac-4e0a-9a63-fa6f34e87275\",\"title\":\"LEVEL UP FOR LESS: PLAY, CREATE, CONQUER\",\"description\":null,\"startDateTime\":\"2026-10-08T02:05Z\",\"highlightedSegmentItemId\":\"9dd910f3-af4d-4840-89af-59e926b0e1da\",\"lcid\":null,\"broadcastStatus\":\"POST_LIVE\",\"isChatEnabled\":false,\"isLiveBadgeEnabled\":null,\"liveViewers\":-1,\"videoMetadata\":{\"videoStack\":\"LVS_TWITCH\",\"metadata\":{}},\"asinPromoCodeMap\":{},\"vods\":null,\"vodEvents\":[{\"eventOffsetMS\":13003,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"7b706550-7947-4c95-8848-e60eef1c957c\"},{\"eventOffsetMS\":243375,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"58266398-a079-4d79-a082-e658637b745b\"},{\"eventOffsetMS\":316273,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"7b706550-7947-4c95-8848-e60eef1c957c\"},{\"eventOffsetMS\":376199,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"58266398-a079-4d79-a082-e658637b745b\"},{\"eventOffsetMS\":425273,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"ec8c6f0f-5919-4933-9f32-88a2043eae91\"},{\"eventOffsetMS\":497253,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"9103e0b6-9a97-4b1f-ab27-6a43d1654da9\"},{\"eventOffsetMS\":524381,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"ec8c6f0f-5919-4933-9f32-88a2043eae91\"},{\"eventOffsetMS\":577078,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"9103e0b6-9a97-4b1f-ab27-6a43d1654da9\"},{\"eventOffsetMS\":618448,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"ec8c6f0f-5919-4933-9f32-88a2043eae91\"},{\"eventOffsetMS\":660069,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"9103e0b6-9a97-4b1f-ab27-6a43d1654da9\"},{\"eventOffsetMS\":699720,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"3837d6d2-de36-4354-b687-40b66bea04df\"},{\"eventOffsetMS\":927211,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"0a07fdfc-c8cf-432f-830f-8ce65485caec\"},{\"eventOffsetMS\":1135606,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"4e88321e-a191-4fbe-a9d9-270e4450793f\"},{\"eventOffsetMS\":1339116,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"b8e75692-c35e-4cc1-8335-929bcb9e29d3\"},{\"eventOffsetMS\":1632756,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"1595a24b-be00-4cc5-8233-c92de9ea558b\"},{\"eventOffsetMS\":1756644,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"cfdab0a6-1e46-4435-ad44-194baa8c7bbb\"},{\"eventOffsetMS\":1847026,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"beb020af-5226-4c46-95fc-0523fa033e1c\"},{\"eventOffsetMS\":2125353,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"ebda034f-0d4c-4fc4-9a22-a534b055235e\"},{\"eventOffsetMS\":2338506,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"ad4bd6e7-f929-46af-ad13-bb5b3b9f09ac\"},{\"eventOffsetMS\":2593214,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"35d8487a-f5e6-45c3-87ec-bfcc67e69198\"},{\"eventOffsetMS\":2798083,\"eventType\":\"highlightedSegmentItemId\",\"eventValue\":\"9dd910f3-af4d-4840-89af-59e926b0e1da\"}],\"pinnedMessage\":null,\"hlsUrl\":\"https:\/\/d17dupcd3sd4s8.cloudfront.net\/6ba2783b-4897-4b8d-bd22-b7f654800f9e\/1480b661-b3ac-4e0a-9a63-fa6f34e87275\/21ea989a-2016-45fc-9160-b87a07a436ea\/hls\/byte-range-multivariant.m3u8\",\"livePlaybackUrl\":\"https:\/\/4b64d6fa612f.us-east-1.playback.live-video.net\/api\/video\/v1\/us-east-1.408268288382.channel.4m8Cgy9ppgN1.m3u8\",\"generatedDateTime\":\"2026-10-08T03:20:00.332042537Z\",\"chatStatus\":\"DISABLED\",\"promotions\":null,\"trimmingMetadata\":{\"secondsTrimmed\":null,\"hlsUrl\":null,\"trimmingEnabled\":true},\"secondaryLivePlaybackUrl\":null,\"broadcastVariants\":[{\"videoHeight\":720,\"captionLocale\":\"en-US\",\"playbackUrl\":\"https:\/\/d17dupcd3sd4s8.cloudfront.net\/6ba2783b-4897-4b8d-bd22-b7f654800f9e\/1480b661-b3ac-4e0a-9a63-fa6f34e87275\/21ea989a-2016-45fc-9160-b87a07a436ea\/hls\/byte-range-multivariant.m3u8\",\"captionUrl\":\"https:\/\/d9dk5d4x2qkys.cloudfront.net\/1480b661-b3ac-4e0a-9a63-fa6f34e87275_21ea989a-2016-45fc-9160-b87a07a436ea.vtt\",\"variantType\":\"POST_LIVE_HLS\",\"orientation\":\"HORIZONTAL\",\"videoWidth\":1280,\"secondsTrimmed\":null}],\"liveCaptionUrl\":null,\"secondaryLiveCaptionUrl\":null,\"captionUrl\":\"https:\/\/d9dk5d4x2qkys.cloudfront.net\/1480b661-b3ac-4e0a-9a63-fa6f34e87275_21ea989a-2016-45fc-9160-b87a07a436ea.vtt\",\"captionLocale\":\"en-US\",\"broadcastType\":null}}");
        
            liveFlagshipStates["amazonlive-react-weblab-v2-data"] = JSON.parse("{\"AL_OSA_INSTRN_357138\":\"T1\",\"AL_FNV_DEP2_569979\":\"T1\",\"ASV_BREADCRUMBS_COMPONENT_1383476\":\"T1\",\"AL_FS_FOR_YOU_677535\":\"C\",\"AL_FS_SKIP_1ST_SEGMENT_712620\":\"C\",\"AL_UNMUTED_AUTOPLAY_E_753832\":\"T1\",\"ANP_ASV_CREATOR_DISCLAIMER_TEXT_1365760\":\"T1\",\"AL_CAT_HOTLOAD_749062\":\"T1\",\"ASV_VSE_FRONTLOAD_DATA_1379756\":\"T1\",\"PD_DO_CODE_334337\":\"C\",\"ASV_FS_TRIMMING_ENABLED_E_862292\":\"T1\",\"ASV_WEB_PURCHASE_AIDS_E_641914\":\"T1\",\"AL_CAT_HOTLOAD_710936\":\"T1\",\"AL_FS_NOTIFICATIONS_632373\":\"T1\",\"AIP_ATTRIBUTION_UPDATES_1374859\":\"T1\",\"ASV_BRAND_UPDATE_1036468\":\"T1\",\"ASV_CREATOR_WALLET_608120\":\"T1\",\"PEAS_DO_CONTENT_489637\":\"C\",\"ASV_FS_INITIALIZE_VSE_CONTENT_L_882828\":\"C\",\"HAUL_LIVE_OOS_CX_1400907\":\"T1\",\"AL_GW_PL_569977\":\"C\",\"AL_GW_ORC_VPL_390257\":\"T1\",\"A2I_AL_FS_CAROUSEL_MODULARISATION_L_942739\":\"T1\",\"AMAZON_LIVE_FLAGSHIP_G2G_LATENCY_REPORT_869538\":\"C\",\"ASV_HAUL_COUNTDOWN_TIMER_TEXT_1473397\":\"C\",\"AL_CAT_BRND_L_372133\":\"T1\",\"ASV_FS_FOLLOW_V3_MIGRATION_1162010\":\"T1\",\"A2I_PREFETCH_PREWARM_CATAMARAN_E_719019\":\"C\",\"ASV_MWEB_REDIRECT_P3_1099309\":\"T1\",\"ASV_FS_REACTIONS_610697\":\"T1\",\"ASV_CLAIM_PROMO_CODE_EP_434062\":\"T1\",\"PBDD_DO_CODE_745375\":\"C\",\"ASV_PORTAL_1124839\":\"C\",\"ASV_SSW_AIP_DISABLE_SWIPE_1459188\":\"T1\",\"ASV_FS_TRANSCRIPTS_1291783\":\"T1\",\"ASV_WEB_REALTIME_METRICS_638605\":\"T1\",\"AL_FS_CA_INGRESS_670085\":\"C\",\"ASV_FS_IC_CONTRACT_713170\":\"T1\",\"AL_SE_BD_306329\":\"C\",\"ASV_FLAGSHIP_PL_BADGE_1157031\":\"C\",\"AL_PL_GW_ORC_L_338858\":\"T1\",\"ASV_MWEB_REDIRECT_FS_1189405\":\"T1\",\"ASV_FS_SOCIAL_PLAYER_IMPROVEMENTS_1368280\":\"T1\",\"ASV_CATEGORY_PLACEMENT_AUTOMATION_ENABLED_1110307\":\"T1\",\"ASV_FS_SPONSORED_PRODUCTS_LIVE_LAUNCH_1300130\":\"C\",\"A2I_PREFETCH_PREWARM_CATAMARAN_IOS_E_748158\":\"C\",\"ASV_ANP_PREW_AND_1028605\":\"T2\"}");
        
            liveFlagshipStates["amazonlive-react-transcript-display-flag-data"] = JSON.parse("true");
        
        liveFlagshipStates["pollingOptions"] = {};
        
            liveFlagshipStates["pollingOptions"]["IS_POLL_ENABLED"] = JSON.parse("true");
        
            liveFlagshipStates["pollingOptions"]["IS_IN_VIEW_POLL_ENABLED"] = JSON.parse("true");
        
            liveFlagshipStates["pollingOptions"]["POLL_DEAL_PRODUCT_DATA_INTERVAL"] = JSON.parse("12");
        
            liveFlagshipStates["pollingOptions"]["POLL_PRODUCT_DATA_INTERVAL"] = JSON.parse("60");
        
        liveFlagshipStates["themingOptions"] = {};
        
            liveFlagshipStates["themingOptions"]["WIDGET_PRIMARY_COLOR"] = "#FFFFFF";
        
            liveFlagshipStates["themingOptions"]["WIDGET_SECONDARY_COLOR"] = "#FF6200";
        
            liveFlagshipStates["themingOptions"]["WIDGET_TEXT_COLOR"] = "#000000";
        
            liveFlagshipStates["themingOptions"]["WIDGET_SCROLLBAR_COLOR"] = "#C1C1C1";
        
        
        // Image optimization parameters that must match the player's poster image URL to prevent duplicate image requests
        const IMAGE_PROCESSING_PARAMS = '._QL85_AC_SCLZZZZZZZ_';
        const FILE_EXTENSION_REGEX = /(\.[^.]+)$/;
        const PLAYLIST_DATA_KEY = 'amazonlive-react-playlist-data';

        /**
         * Extracts and transforms the slate image URL from a playlist container.
         * @param {Object} playlistContainer - The container object holding playlist data
         * @returns {string|undefined} The processed slate image URL, or undefined if unavailable
        */
        function getSlateImageUrl(playlistContainer) {
            const playlistData = playlistContainer && playlistContainer[PLAYLIST_DATA_KEY];
            const slateImageId = Array.isArray(playlistData) && playlistData[0] && playlistData[0].slateImageId;

            return slateImageId
                ? slateImageId.replace(FILE_EXTENSION_REGEX, IMAGE_PROCESSING_PARAMS + '$1')
                : undefined;
        }
        
        // Preload slate image for LCP (Largest Contentful Paint) optimization
        const widgetOptionsData = liveFlagshipStates["amazonlive-react-widget-options-data"] || {};
        
        // Check if the slate image preload widget option is true from ASVH
        if (widgetOptionsData["enableSlateImagePreload"]) {
            const playlistContainer = liveFlagshipStates[PLAYLIST_DATA_KEY];
            const processedSlateImageUrl = getSlateImageUrl(playlistContainer);
            
            if (processedSlateImageUrl) {
                const preloadLink = document.createElement('link');
                preloadLink.rel = 'preload';
                preloadLink.as = 'image';
                preloadLink.fetchPriority = 'high';
                preloadLink.href = processedSlateImageUrl;
                
                document.head.appendChild(preloadLink);
            }
        }
        
        const isWidgetAlreadyRegistered = () => {
            var isRegistered = false;
            P.now('amazonlive:widget:initialized').execute(function (module) {
                isRegistered = !!module;
            });
            return isRegistered;
        }
        const initLiveWidget = (initializeLiveWidget) => {
            if (!isWidgetAlreadyRegistered()) {
                
                const placeholderExperienceEnabled = liveFlagshipStates["amazonlive-react-widget-options-data"]["isPlaceholderThumbnailEnabled"];
                if (placeholderExperienceEnabled) {
                    rootElement.innerHTML = '';
                }
                var widget = initializeLiveWidget(liveFlagshipStates, "live-flagship-root");
                window.P.when('A').execute('amazonlive-flagship-debug', function(A) {
                    A.on('amazonlive:debug', function(callback) {
                        callback({
                           initialState: liveFlagshipStates,
                           currentState: widget.getState(),
                        });
                    });
                });
                // checks if value is in the format number followed by px or % eg: 100px or 20%
                var widgetHeightRegex = /\d*\.?\d+(?:px|%)?/i;
                if (("none").match(widgetHeightRegex)){
                           rootElement.style.maxHeight="none";
                           rootElement.style.overflowY="hidden";
                }
                window.P.trigger('amazonlive:widget:initialized');
                // Hide ASV skeleton overlay once widget is ready
                var skeletonOverlay = document.getElementById('asv-skeleton-overlay');
                if (skeletonOverlay) {
                    skeletonOverlay.classList.add('asv-skeleton-hidden');
                }
            } else if (window.ue && window.ue.count) {
                window.ue.count("LiveWidgetMultipleInitializationAttempted", 1);
            }
        };
        if (false){
            P.when('amazon-live-widget-library').execute(function(amazonLiveLibrary) {
                initLiveWidget(amazonLiveLibrary.initializeWidget);
            })
        }else {
            if (window.initLivePage) {
                initLiveWidget(window.initLivePage);
            } else {
                window.P.when('A').execute((A) => {
                    A.on('amazonLiveEvent:initLivePage:available', function onAvailable() {
                        try{
                            initLiveWidget(window.initLivePage);
                        } catch(e) {
                            window.P.log('Error in initLivePage - could not load live player. ' + e, 'FATAL', 'AmazonLiveFlagshipAssets');
                            if (window.ue && window.ue.count) {
                                window.ue.count("AmazonLivePortal:LiveWidget:PlayerLoadErrorCount", 1);
                            }
                        }
                        A.off('amazonLiveEvent:initLivePage:available', onAvailable);
                    });
                });
            }
        }
    });
}));</script>
</div>
      </div>
    
    
  

</div><script>
              window.P && P.register('sp.load.js');
            </script>
        <section id="desktop-brandstore-dynamic-page-atf-top-slot-container"
                            class="stores-widget-btf"
                            data-widgetgroup-id="desktop-brandstore-dynamic-page-atf"
                            data-widgetgroup-container-id="top-slot-container"
                            data-widget-load-strategy="">
                        </section>
                    <div class="skeleton Ck1b0dln48-skeleton editorialrow-skeleton">
    <div class="box box--large box--externalwidget">
        <div class="pulse"></div>
    </div>
</div>
<div id="Ck1b0dln48" class="a-row stores-row stores-widget-btf"></div><div class="skeleton aqorffcgsu-skeleton editorialrow-skeleton">
    <div class="two-column">
        <div class="column">
            <div class="box box--medium box--image">
        <div class="pulse"></div>
    </div>
</div>
        <div class="column">
            <div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
</div>
    </div>
</div>
<div id="aqorffcgsu" class="a-row stores-row stores-widget-btf"></div><div class="skeleton C5bihrka7f-skeleton editorialrow-skeleton">
    <div class="box box--large box--image">
        <div class="pulse"></div>
    </div>
</div>
<div id="C5bihrka7f" class="a-row stores-row stores-widget-btf"></div><div class="skeleton Ujzuyep9td-skeleton editorialrow-skeleton">
    <div class="two-column">
        <div class="column">
            <div class="box box--small box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
</div>
        <div class="column">
            <div class="box box--medium box--image">
        <div class="pulse"></div>
    </div>
</div>
    </div>
</div>
<div id="Ujzuyep9td" class="a-row stores-row stores-widget-btf"></div><div class="skeleton xaqp7eiklm-skeleton editorialrow-skeleton">
    <div class="box box--large box--video">
        <div class="pulse"></div>
    </div>
</div>
<div id="xaqp7eiklm" class="a-row stores-row stores-widget-btf"></div><div class="skeleton 91d5icz943-skeleton editorialrow-skeleton">
    <div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
<div class="box box--mini box--image">
        <div class="pulse"></div>
    </div>
</div>
<div id="91d5icz943" class="a-row stores-row stores-widget-btf"></div><div class="skeleton Dmdkg5d6f9-skeleton editorialrow-skeleton">
    <div class="box box--large box--text">
        <div class="pulse"></div>
    </div>
</div>
<div id="Dmdkg5d6f9" class="a-row stores-row stores-widget-btf"></div><div class="skeleton lpg4j1354e-skeleton productgrid-skeleton">
    <div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
<div class="box">
        <div class="pulse"></div>
    </div>
</div>
<div id="lpg4j1354e" class="a-row stores-row stores-widget-btf"></div><section id="desktop-brandstore-dynamic-page-atf-bottom-slot-container"
                            class="stores-widget-btf"
                            data-widgetgroup-id="desktop-brandstore-dynamic-page-atf"
                            data-widgetgroup-container-id="bottom-slot-container"
                            data-widget-load-strategy="template">
                        </section>
                    <div class="skeleton share-skeleton editorialrow-skeleton">
    <div class="box box--large box--externalwidget">
        <div class="pulse"></div>
    </div>
</div>
<div id="share" class="a-row stores-row stores-widget-btf"></div></div></div>

<script type="text/javascript">
  if (ue) {
    uet('af');
  }
</script>

<script type="text/javascript">
        if ( window.P && window.P.AUI_BUILD_DATE ) {
            P.when('A', 'jQuery', 'cnuba-lazy-load', 'ready').execute(function (A, $, lazyload) {
                "use strict";
                var getParams = function (paramsStr) {
                    paramsStr = paramsStr.substr(1, paramsStr.length - 2);
                    var variables = paramsStr.split(', ');
                    var params = {};
                    for (var i = 0; i < variables.length; i++) {
                        var delimIndex = variables[i].indexOf('=');
                        var validDelimIndex = delimIndex > 0;
                        var pair = [
                            validDelimIndex > 0 ? variables[i].substring(0, delimIndex) : variables[i],
                            validDelimIndex > 0 ? variables[i].substring(delimIndex+1) : ""
                        ];
                        var key = pair[0].replace(/\s/g, "");
                        params[key] = pair[1];
                    }
                    return params;
                };

                var getDefaultParams = function () {
                    // get default url parameters.
                    var paramsStr = "{slashargs=, ref_=ast_bln, lp_asin=B0FDPJZQNY, store_ref=bl_ast_dp_brandlogo_sto, brandname=Razer, pageId=CDB96030-A7CF-4B56-B70C-67086A740274}";
                    var params = getParams(paramsStr);

                    // get appendedParameters.
                    var appendedParamsStr = "{ingress=2, lp_context_asin=B0FDPJZQNY, visitId=8755ff19-67e4-4972-9990-e583cf886542, store_ref=bl_ast_dp_brandlogo_sto}";
                    var appendedParams = getParams(appendedParamsStr);

                    // override params using calculated appendedParameters if any.
                    for (var i in appendedParams) {
                        params[i] = appendedParams[i];
                    }

                    return params;
                };

              var slots = [{"widgetSkeleton":{"widgetType":"dramswidget"},"widgetGroupId":"desktop-brandstore-dynamic-page-atf","widgetId":"desktop-brandstore-dynamic-page-atf-top-slot-container","widgetGroupContainerId":"top-slot-container"}, {"widgetSkeleton":{"tiles":[{"size":"large","type":"externalwidget"}],"hasMediumTile":false,"widgetType":"editorialrow"},"widgetId":"Ck1b0dln48"}, {"widgetSkeleton":{"rightHalf":[{"size":"mini","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"}],"hasMediumTile":true,"leftHalf":[{"size":"medium","type":"image"}],"widgetType":"editorialrow"},"widgetId":"aqorffcgsu"}, {"widgetSkeleton":{"tiles":[{"size":"large","type":"image"}],"hasMediumTile":false,"widgetType":"editorialrow"},"widgetId":"C5bihrka7f"}, {"widgetSkeleton":{"rightHalf":[{"size":"medium","type":"image"}],"hasMediumTile":true,"leftHalf":[{"size":"small","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"}],"widgetType":"editorialrow"},"widgetId":"Ujzuyep9td"}, {"widgetSkeleton":{"tiles":[{"size":"large","type":"video"}],"hasMediumTile":false,"widgetType":"editorialrow"},"widgetId":"xaqp7eiklm"}, {"widgetSkeleton":{"tiles":[{"size":"mini","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"},{"size":"mini","type":"image"}],"hasMediumTile":false,"widgetType":"editorialrow"},"widgetId":"91d5icz943"}, {"widgetSkeleton":{"tiles":[{"size":"large","type":"text"}],"hasMediumTile":false,"widgetType":"editorialrow"},"widgetId":"Dmdkg5d6f9"}, {"widgetSkeleton":{"asinCount":10,"widgetType":"productgrid"},"widgetId":"lpg4j1354e"}, {"widgetLoadStrategy":"template","widgetSkeleton":{"widgetType":"dramswidget"},"widgetGroupId":"desktop-brandstore-dynamic-page-atf","widgetId":"desktop-brandstore-dynamic-page-atf-bottom-slot-container","widgetGroupContainerId":"bottom-slot-container"}, {"widgetSkeleton":{"tiles":[{"size":"large","type":"externalwidget"}],"hasMediumTile":false,"widgetType":"editorialrow"},"widgetId":"share"}].map(slot => slot.widgetId);

              var path = window.location.pathname.toLowerCase();


                var useAjaxGet = 'true'
                var method = useAjaxGet==='true'? 'get':'post';

                lazyload.triggerLazyLoad(slots, getDefaultParams(), path, method);
           });
        }
    </script>
<!--&&&Portal&Delimiter&&&--><!-- sp:end-feature:host-atf -->
<!-- sp:feature:nav-btf -->
<!-- NAVYAAN BTF START -->







<script type="text/javascript">
  window.$Nav && $Nav.when("data").run(function (data) {
    data({
      "accountListContent": { "html": "<div id='nav-al-container'><div id='nav-al-signin'><div id='nav-flyout-ya-signin' class='nav-flyout-content nav-flyout-accessibility'><a href='https://www.shopping.com/ap/signin?openid.return_to=https%3A%2F%2Fwww.shopping.com%2Fstores%2FRazer%2Fpage%2FCDB96030-A7CF-4B56-B70C-67086A740274%2F%3F_encoding%3DUTF8%26lp_asin%3DB0FDPJZQNY%26store_ref%3Dbl_ast_dp_brandlogo_sto%26ref_%3Dnav_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' rel='nofollow' class='nav-action-signin-button' data-nav-role='signin' data-nav-ref='nav_signin'><span class='nav-action-inner'>Sign in</span></a><div id='nav-flyout-ya-newCust' class='nav_pop_new_cust nav-flyout-content nav-flyout-accessibility'>New customer? <a href='https://www.shopping.com/ap/register?openid.return_to=https%3A%2F%2Fwww.shopping.com%2Fstores%2FRazer%2Fpage%2FCDB96030-A7CF-4B56-B70C-67086A740274%2F%3F_encoding%3DUTF8%26lp_asin%3DB0FDPJZQNY%26store_ref%3Dbl_ast_dp_brandlogo_sto%26ref_%3Dnav_newcust&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' rel='nofollow' class='nav-a' aria-label='New to Amazon? Start here to create an account'>Start here.</a></div></div></div><div id='nav-al-wishlist' class='nav-al-column nav-tpl-itemList nav-flyout-content nav-flyout-accessibility'><div class='nav-title' id='nav-al-title' role='heading' aria-level='6'>Your Lists</div><ul><li><a href='/hz/wishlist/ls?triggerElementID=createList&ref_=nav_ListFlyout_navFlyout_createList_lv_redirect' class='nav-link nav-item'><span class='nav-text'>Create a List</span></a></li><li><a href='/registries?ref_=nav_ListFlyout_find' class='nav-link nav-item'><span class='nav-text'>Find a List or Registry</span></a></li></ul></div><div id='nav-al-your-account' class='nav-al-column nav-template nav-flyout-content nav-tpl-itemList nav-flyout-accessibility'><div class='nav-title' role='heading' aria-level='6'>Your Account</div><ul><li><a href='/gp/css/homepage.html?ref_=nav_AccountFlyout_ya' class='nav-link nav-item'><span class='nav-text'>Account</span></a></li><li><a id='nav_prefetch_yourorders' href='/gp/css/order-history?ref_=nav_AccountFlyout_orders' class='nav-link nav-item'><span class='nav-text'>Orders</span></a></li><li><a href='/gp/yourstore?ref_=nav_AccountFlyout_recs' class='nav-link nav-item'><span class='nav-text'>Recommendations</span></a></li><li><a href='/gp/history?ref_=nav_AccountFlyout_browsinghistory' class='nav-link nav-item'><span class='nav-text'>Browsing History</span></a></li><li><a href='https://www.shopping.com/slc/hub?ref_=nav_AccountFlyout_sl_ph_navflyout' class='nav-link nav-item'><span class='nav-text'>Your Shopping preferences</span></a></li><li><a href='/gp/video/watchlist?ref_=nav_AccountFlyout_ywl' class='nav-link nav-item'><span class='nav-text'>Watchlist</span></a></li><li><a href='/gp/video/library?ref_=nav_AccountFlyout_yvl' class='nav-link nav-item'><span class='nav-text'>Video Purchases & Rentals</span></a></li><li><a href='/gp/kindle/ku/ku_central?ref_=nav_AccountFlyout_ku' class='nav-link nav-item'><span class='nav-text'>Kindle Unlimited</span></a></li><li><a href='/hz/mycd/myx?pageType=content&ref_=nav_AccountFlyout_myk' class='nav-link nav-item'><span class='nav-text'>Content & Devices</span></a></li><li><a href='/gp/subscribe-and-save/manager/viewsubscriptions?ref_=nav_AccountFlyout_sns' class='nav-link nav-item'><span class='nav-text'>Subscribe & Save Items</span></a></li><li><a href='/hz5/yourmembershipsandsubscriptions?ref_=nav_AccountFlyout_digital_subscriptions' class='nav-link nav-item'><span class='nav-text'>Memberships & Subscriptions</span></a></li><li><a href='https://music.shopping.com?ref=nav_youraccount_cldplyr' class='nav-link nav-item'><span class='nav-text'>Music Library</span></a></li></ul></div></div>" },
      "tooltipContent": { "html": "" },
      "signinContent": { "html": "<div id='nav-signin-tooltip'><a href='https://www.shopping.com/ap/signin?openid.return_to=https%3A%2F%2Fwww.shopping.com%2Fstores%2FRazer%2Fpage%2FCDB96030-A7CF-4B56-B70C-67086A740274%2F%3F_encoding%3DUTF8%26lp_asin%3DB0FDPJZQNY%26store_ref%3Dbl_ast_dp_brandlogo_sto%26ref_%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' class='nav-action-signin-button' data-nav-role='signin' data-nav-ref='nav_custrec_signin'><span class='nav-action-inner'>Sign in</span></a><div class='nav-signin-tooltip-footer'>New customer? <a href='https://www.shopping.com/ap/register?openid.return_to=https%3A%2F%2Fwww.shopping.com%2Fstores%2FRazer%2Fpage%2FCDB96030-A7CF-4B56-B70C-67086A740274%2F%3F_encoding%3DUTF8%26lp_asin%3DB0FDPJZQNY%26store_ref%3Dbl_ast_dp_brandlogo_sto%26ref_%3Dnav_custrec_newcust&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0' class='nav-a' aria-label='New to Amazon? Start here to create an account'>Start here.</a></div></div>" },
      "templates": {"itemList":"<# var hasColumns = (function () {  var checkColumns = function (_items) {    if (!_items) {      return false;    }    for (var i=0; i<_items.length; i++) {      if (_items[i].columnBreak || (_items[i].items && checkColumns(_items[i].items))) {        return true;      }    }    return false;  };  return checkColumns(items);}()); #><# if(hasColumns) { #>  <# if(items[0].image && items[0].image.src) { #>    <div class='nav-column nav-column-first nav-column-image'>  <# } else if (items[0].greeting) { #>    <div class='nav-column nav-column-first nav-column-greeting'>  <# } else { #>    <div class='nav-column nav-column-first'>  <# } #><# } #><# var renderItems = function(items) { #>  <# jQuery.each(items, function (i, item) { #>    <# if(hasColumns && item.columnBreak) { #>      <# if(item.image && item.image.src) { #>        </div><div class='nav-column nav-column-notfirst nav-column-break nav-column-image'>      <# } else if (item.greeting) { #>        </div><div class='nav-column nav-column-notfirst nav-column-break nav-column-greeting'>      <# } else { #>        </div><div class='nav-column nav-column-notfirst nav-column-break'>      <# } #>    <# } #>    <# if(item.dividerBefore) { #>      <div class='nav-divider'></div>    <# } #>    <# if(item.text || item.content) { #>      <# if(item.url) { #>        <a href='<#=item.url #>' class='nav-link      <# } else {#>        <span class='      <# } #>      <# if(item.panelKey) { #>        nav-hasPanel      <# } #>      <# if(item.items) { #>        nav-title      <# } #>      <# if(item.decorate == 'carat') { #>        nav-carat      <# } #>      <# if(item.decorate == 'nav-action-button') { #>        nav-action-button      <# } #>      nav-item'      <# if(item.extra) { #>        <#=item.extra #>      <# } #>      <# if(item.id) { #>        id='<#=item.id #>'      <# } #>      <# if(item.dataNavRole) { #>        data-nav-role='<#=item.dataNavRole #>'      <# } #>      <# if(item.dataNavRef) { #>        data-nav-ref='<#=item.dataNavRef #>'      <# } #>      <# if(item.panelKey) { #>        data-nav-panelkey='<#=item.panelKey #>'        role='navigation'        aria-label='<#=item.text#>'      <# } #>      <# if(item.subtextKey) { #>        data-nav-subtextkey='<#=item.subtextKey #>'      <# } #>      <# if(item.image && item.image.height > 16) { #>        style='line-height:<#=item.image.height #>px;'      <# } #>      >      <# if(item.decorate == 'carat') { #>        <i class='nav-icon'></i>      <# } #>      <# if(item.image && item.image.src) { #>        <img class='nav-image' src='<#=item.image.src #>' style='height:<#=item.image.height #>px; width:<#=item.image.width #>px;' />      <# } #>      <# if(item.text) { #>        <span class='nav-text<# if(item.classname) { #> <#=item.classname #><# } #>'><#=item.text#><# if(item.badgeText) { #>          <span class='nav-badge'><#=item.badgeText#></span>        <# } #></span>      <# } else if (item.content) { #>        <span class='nav-content'><# jQuery.each(item.content, function (j, cItem) { #><# if(cItem.url && cItem.text) { #><a href='<#=cItem.url #>' class='nav-a'><#=cItem.text #></a><# } else if (cItem.text) { #><#=cItem.text#><# } #><# }); #></span>      <# } #>      <# if(item.subtext) { #>        <span class='nav-subtext'><#=item.subtext #></span>      <# } #>      <# if(item.url) { #>        </a>      <# } else {#>        </span>      <# } #>    <# } #>    <# if(item.image && item.image.src) { #>      <# if(item.url) { #>        <a href='<#=item.url #>'>       <# } #>      <img class='nav-image'      <# if(item.id) { #>        id='<#=item.id #>'      <# } #>      src='<#=item.image.src #>' <# if (item.alt) { #> alt='<#= item.alt #>'<# } #>/>      <# if(item.url) { #>        </a>       <# } #>    <# } #>    <# if(item.items) { #>      <div class='nav-panel'> <# renderItems(item.items); #> </div>    <# } #>  <# }); #><# }; #><# renderItems(items); #><# if(hasColumns) { #>  </div><# } #>","subnav":"<# if (obj && obj.type === 'vertical') { #>  <# jQuery.each(obj.rows, function (i, row) { #>    <# if (row.flyoutElement === 'button') { #>      <div class='nav_sv_fo_v_button'        <# if (row.elementStyle) { #>          style='<#= row.elementStyle #>'        <# } #>      >        <a href='<#=row.url #>' class='nav-action-button nav-sprite'>          <#=row.text #>        </a>      </div>    <# } else if (row.flyoutElement === 'list' && row.list) { #>      <# jQuery.each(row.list, function (j, list) { #>        <div class='nav_sv_fo_v_column <#=(j === 0) ? 'nav_sv_fo_v_first' : '' #>'>          <ul class='<#=list.elementClass #>'>          <# jQuery.each(list.linkList, function (k, link) { #>            <# if (k === 0) { link.elementClass += ' nav_sv_fo_v_first'; } #>            <li class='<#=link.elementClass #>'>              <# if (link.url) { #>                <a href='<#=link.url #>' class='nav_a'><#=link.text #></a>              <# } else { #>                <span class='nav_sv_fo_v_span'><#=link.text #></span>              <# } #>            </li>          <# }); #>          </ul>        </div>      <# }); #>    <# } else if (row.flyoutElement === 'link') { #>      <# if (row.topSpacer) { #>        <div class='nav_sv_fo_v_clear'></div>      <# } #>      <div class='<#=row.elementClass #>'>        <a href='<#=row.url #>' class='nav_sv_fo_v_lmargin nav_a'>          <#=row.text #>        </a>      </div>    <# } #>  <# }); #><# } else if (obj) { #>  <div class='nav_sv_fo_scheduled'>    <#= obj #>  </div><# } #>","htmlList":"<# jQuery.each(items, function (i, item) { #>  <div class='nav-item'>    <#=item #>  </div><# }); #>"}
    })
  })
</script>

<script type="text/javascript">
  window.$Nav && $Nav.declare('config.flyoutURL', null);
  window.$Nav && $Nav.declare('btf.lite');
  window.$Nav && $Nav.declare('btf.full');
  window.$Nav && $Nav.declare('btf.exists');
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).register('navCF');
</script>

<script type="text/javascript">
      window.$Nav && $Nav.when('$').run('CBIMarketplaceRedirectOverlayNavyaan', function($) {
        $.ajax({
            type: 'POST',
            url: '/cross_border_interstitial_sp/render',
            data: JSON.stringify({
                marketplaceId: 'ATVPDKIKX0DER',
                localCountryCode: 'US',
                   customerId: null,
                sessionId: '147\x2D0099296\x2D5118245',
                deviceType: 'DESKTOP',
                referrer: '',
                url: '\x2Fstores\x2FRazer\x2Fpage\x2FCDB96030\x2DA7CF\x2D4B56\x2DB70C\x2D67086A740274',
                pageType: 'AmazonStores',
                languageOfPreference: 'en_US',
                queryParams: {},
                interstitialRequestType: 'CBI',
                weblabTreatmentMap: {"CBI_355055":"C","NARX_INTERSTITIAL_NEW_CX_372291":"C","NARX_INTERSTITIAL_AUI_MIGRATION_446901":"C","TEST_ACS_CONFIGURATION_486322":"C","CROSS_BORDER_INTERSTITIAL_ACS_SHADOW_TESTING_486317":"C","INTERSTITIAL_PROTOTYPE_IP_ADDRESS_BR_598850":"C","NARX_INTERSTITIAL_LAMBDA_CLOUD_AUTH_880645":"C","CBI_ROBOT_MITIGATION_943387":"C","CBI_REDISPLAY_INTERSTITIAL_1008859":"C","CROSS_BORDER_INTERSTITIAL_GEOLOCATION_US_SA_1417380":"C"}
            }),
            contentType: "application/json",
            dataType: "html",
            success: function(data) {
                if (data) {
                    $('body').append(data);
                }
            }
        });
      });
  </script>
  
<!-- NAVYAAN BTF END -->
<!-- sp:end-feature:nav-btf -->
<!-- sp:feature:host-btf -->


<script type="text/javascript">
    if (ue && ue.event) {
        var data = {
            "navigationType": (window.performance && window.performance.navigation && window.performance.navigation.type) || 0
        };

        data.customerId = null;
        

        data.pageId = null;
        
            data.pageId = "CDB96030-A7CF-4B56-B70C-67086A740274";
        

        data.visitId = null;
        
            data.visitId = "8755ff19-67e4-4972-9990-e583cf886542";
        

        data.producerId = "stores";
        data.schemaId = "stores.PageViewEvent.2";
        ue.event(data, data.producerId, data.schemaId, {n:true});
    }
</script>
<!-- sp:end-feature:host-btf -->
<!-- sp:feature:aui-preload -->
<!-- sp:end-feature:aui-preload -->
<!-- sp:feature:nav-footer -->

  <!-- NAVYAAN FOOTER START -->
  <!-- WITH MOZART -->


<div class="navLeftFooter nav-sprite-v1" id="navFooter">
  <button id="navBackToTop" class="navFooterBackToTopText" aria-label="Back to top"><div class="navFooterBackToTop">Back to top</div></button>
  
<div class="navFooterVerticalColumn navAccessibility" role="presentation">
  <div class="navFooterVerticalRow navAccessibility">
        <div class="navFooterLinkCol navAccessibility">
          <div class="navFooterColHead" role="heading" aria-level="6">Get to Know Us</div>
        <ul>
            <li class="nav_first">
              <a href="https://www.amazon.jobs" class="nav_a">Careers</a>
            </li>
            <li >
              <a href="https://blog.aboutshopping.com/?utm_source=gateway&utm_medium=footer" class="nav_a">Blog</a>
            </li>
            <li >
              <a href="https://www.aboutshopping.com/?utm_source=gateway&utm_medium=footer" class="nav_a">About Amazon</a>
            </li>
            <li >
              <a href="https://www.shopping.com/ir" class="nav_a">Investor Relations</a>
            </li>
            <li >
              <a href="/gp/browse.html?node=2102313011&ref_=footer_devices" class="nav_a">Amazon Devices</a>
            </li>
            <li class="nav_last ">
              <a href="https://www.amazon.science" class="nav_a">Amazon Science</a>
            </li>
        </ul>
      </div>
        <div class="navFooterColSpacerInner navAccessibility"></div>
        <div class="navFooterLinkCol navAccessibility">
          <div class="navFooterColHead" role="heading" aria-level="6">Make Money with Us</div>
        <ul>
            <li class="nav_first">
              <a href="https://services.shopping.com/sell.html?ld=AZFSSOA&ref_=footer_soa" class="nav_a">Sell products on Amazon</a>
            </li>
            <li >
              <a href="https://services.shopping.com/amazon-business.html?ld=usb2bunifooter&ref_=footer_b2b" class="nav_a">Sell on Amazon Business</a>
            </li>
            <li >
              <a href="https://developer.shopping.com" class="nav_a">Sell apps on Amazon</a>
            </li>
            <li >
              <a href="https://affiliate-program.shopping.com/" class="nav_a">Become an Affiliate</a>
            </li>
            <li >
              <a href="https://advertising.shopping.com/?ref=ext_amzn_ftr" class="nav_a">Advertise Your Products</a>
            </li>
            <li >
              <a href="/gp/seller-account/mm-summary-page.html?ld=AZFooterSelfPublish&topic=200260520&ref_=footer_publishing" class="nav_a">Self-Publish with Us</a>
            </li>
            <li >
              <a href="https://go.thehub-shopping.com/amazon-hub-locker" class="nav_a">Host an Amazon Hub</a>
            </li>
            <li class="nav_last nav_a_carat">
              <span class="nav_a_carat" aria-hidden="true">›</span><a href="/b/?node=18190131011&ld=AZUSSOA-seemore&ref_=footer_seemore" class="nav_a">See More Make Money with Us</a>
            </li>
        </ul>
      </div>
        <div class="navFooterColSpacerInner navAccessibility"></div>
        <div class="navFooterLinkCol navAccessibility">
          <div class="navFooterColHead" role="heading" aria-level="6">Amazon Payment Products</div>
        <ul>
            <li class="nav_first">
              <a href="/dp/B07984JN3L?plattr=ACOMFO&ie=UTF-8" class="nav_a">Amazon Business Card</a>
            </li>
            <li >
              <a href="/gp/browse.html?node=16218619011&ref_=footer_swp" class="nav_a">Shop with Points</a>
            </li>
            <li >
              <a href="/dp/B0CHTVMXZJ?th=1?ref_=footer_reload_us" class="nav_a">Reload Your Balance</a>
            </li>
            <li class="nav_last ">
              <a href="/gp/browse.html?node=388305011&ref_=footer_tfx" class="nav_a">Amazon Currency Converter</a>
            </li>
        </ul>
      </div>
        <div class="navFooterColSpacerInner navAccessibility"></div>
        <div class="navFooterLinkCol navAccessibility">
          <div class="navFooterColHead" role="heading" aria-level="6">Let Us Help You</div>
        <ul>
            <li class="nav_first">
              <a href="https://www.shopping.com/gp/css/homepage.html?ref_=footer_ya" class="nav_a">Your Account</a>
            </li>
            <li >
              <a href="https://www.shopping.com/gp/css/order-history?ref_=footer_yo" class="nav_a">Your Orders</a>
            </li>
            <li >
              <a href="/gp/help/customer/display.html?nodeId=468520&ref_=footer_shiprates" class="nav_a">Shipping Rates & Policies</a>
            </li>
            <li >
              <a href="/gp/css/returns/homepage.html?ref_=footer_hy_f_4" class="nav_a">Returns & Replacements</a>
            </li>
            <li >
              <a href="/gp/digital/fiona/manage?ref_=footer_myk" class="nav_a">Manage Your Content and Devices</a>
            </li>
            <li class="nav_last ">
              <a href="/gp/help/customer/display.html?nodeId=508510&ref_=footer_gw_m_b_he" class="nav_a">Help</a>
            </li>
        </ul>
      </div>
  </div>
</div>
<div class="nav-footer-line"></div>

  <div class="navFooterLine navFooterLinkLine navFooterPadItemLine">
    <span>
      <div class="navFooterLine navFooterLogoLine">
        <a  aria-label="Amazon US Home"   lang="en"  href="/?ref_=footer_logo">
        <div class="nav-logo-base nav-sprite"></div>
        </a>
      </div>
</span>
    
      <span class="icp-container-desktop"><div
          class="navFooterLine"><script type="text/javascript">$Nav.declare("flyout.icp.footer.weblabs",{"MOZART_CARD_CONTENT_1359302":"C"});</script>
<style type="text/css">
  #icp-touch-link-language { display: none; }
</style>


<div class="icp-button" id="icp-touch-link-language" >
<a href="/customer-preferences/edit?ie=UTF8&preferencesReturnUrl=%2F&ref_=footer_lang" class="icp-language-link" aria-label="Choose a language for shopping. Current selection is English. ">
  <div class="icp-nav-globe-img-2 icp-button-globe-2"></div><span class="icp-color-base">English</span>
</a>
<button class="nav-arrow icp-up-down-arrow" aria-controls="nav-flyout-icp-footer-flyout" aria-label="Expand to Change Language or Country"></button>
</div>

<style type="text/css">
  #icp-touch-link-cop { display: none; }
</style>

<a href="/customer-preferences/edit?ie=UTF8&ref_=footer_cop&preferencesReturnUrl=%2Fstores%2FRazer%2Fpage%2FCDB96030-A7CF-4B56-B70C-67086A740274" class="icp-button" id="icp-touch-link-cop">
  <span class="icp-currency-symbol">GHS</span><span class="icp-color-base">Ghanaian Cedi</span>
</a>

<style type="text/css">
#icp-touch-link-country { display: none; }
</style>
<a href="/customer-preferences/country?ie=UTF8&preferencesReturnUrl=%2F&ref_=footer_icp_cp" role="button" aria-label="Choose a country/region for shopping. The current selection is United States." class="icp-button" id="icp-touch-link-country">
  <span class="icp-flag-3 icp-flag-3-us"></span><span class="icp-color-base">United States</span>
</a>
</div></span>
    
  </div>
  
  
  <div class="navFooterLine navFooterLinkLine navFooterDescLine" role="navigation" aria-label="More on Amazon">
    <div class="navFooterMoreOnAmazon navFooterMoreOnAmazonWrapper" aria-label="More on Amazon">
      <ul>
<li class="navFooterDescItem"><a href=https://music.shopping.com?ref=dm_aff_amz_com class="nav_a"><h5 class="navFooterDescItem_heading">Amazon Music</h5><span class="navFooterDescText">Stream millions<br>of songs</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://advertising.shopping.com/?ref=footer_advtsing_amzn_com class="nav_a"><h5 class="navFooterDescItem_heading">Amazon Ads</h5><span class="navFooterDescText">Reach customers<br>wherever they<br>spend their time</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.6pm.com class="nav_a"><h5 class="navFooterDescItem_heading">6pm</h5><span class="navFooterDescText">Score deals<br>on fashion brands</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.abebooks.com class="nav_a"><h5 class="navFooterDescItem_heading">AbeBooks</h5><span class="navFooterDescText">Books, art<br>& collectibles</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.acx.com/ class="nav_a"><h5 class="navFooterDescItem_heading">ACX </h5><span class="navFooterDescText">Audiobook Publishing<br>Made Easy</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://sell.shopping.com/?ld=AZUSSOA-footer-aff&ref_=footer_sell class="nav_a"><h5 class="navFooterDescItem_heading">Sell on Amazon</h5><span class="navFooterDescText">Start a Selling Account</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.veeqo.com/?utm_source=amazon&utm_medium=website&utm_campaign=footer class="nav_a"><h5 class="navFooterDescItem_heading">Veeqo</h5><span class="navFooterDescText">Shipping Software<br>Inventory Management</span></a></li></ul>

<ul>
<li class="navFooterDescItem"><a href=/business?ref_=footer_retail_b2b class="nav_a"><h5 class="navFooterDescItem_heading">Amazon Business</h5><span class="navFooterDescText">Everything For<br>Your Business</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=/gp/browse.html?node=20338496011&ref_=footer_amazonglobal class="nav_a"><h5 class="navFooterDescItem_heading">AmazonGlobal</h5><span class="navFooterDescText">Ship Orders<br>Internationally</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://aws.shopping.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter class="nav_a"><h5 class="navFooterDescItem_heading">Amazon Web Services</h5><span class="navFooterDescText">Scalable Cloud<br>Computing Services</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.audible.com class="nav_a"><h5 class="navFooterDescItem_heading">Audible</h5><span class="navFooterDescText">Listen to Books & Original<br>Audio Performances</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.boxofficemojo.com/?ref_=amzn_nav_ftr class="nav_a"><h5 class="navFooterDescItem_heading">Box Office Mojo</h5><span class="navFooterDescText">Find Movie<br>Box Office Data</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.goodreads.com class="nav_a"><h5 class="navFooterDescItem_heading">Goodreads</h5><span class="navFooterDescText">Book reviews<br>& recommendations</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.imdb.com class="nav_a"><h5 class="navFooterDescItem_heading">IMDb</h5><span class="navFooterDescText">Movies, TV<br>& Celebrities</span></a></li></ul>

<ul>
<li class="navFooterDescItem"><a href=https://pro.imdb.com?ref_=amzn_nav_ftr class="nav_a"><h5 class="navFooterDescItem_heading">IMDbPro</h5><span class="navFooterDescText">Get Info Entertainment<br>Professionals Need</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://kdp.shopping.com class="nav_a"><h5 class="navFooterDescItem_heading">Kindle Direct Publishing</h5><span class="navFooterDescText">Indie Digital & Print Publishing<br>Made Easy
</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://videodirect.shopping.com/home/landing class="nav_a"><h5 class="navFooterDescItem_heading">Prime Video Direct</h5><span class="navFooterDescText">Video Distribution<br>Made Easy</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.shopbop.com class="nav_a"><h5 class="navFooterDescItem_heading">Shopbop</h5><span class="navFooterDescText">Designer<br>Fashion Brands</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.woot.com/ class="nav_a"><h5 class="navFooterDescItem_heading">Woot!</h5><span class="navFooterDescText">Deals and <br>Shenanigans</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.zappos.com class="nav_a"><h5 class="navFooterDescItem_heading">Zappos</h5><span class="navFooterDescText">Shoes &<br>Clothing</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://ring.com class="nav_a"><h5 class="navFooterDescItem_heading">Ring</h5><span class="navFooterDescText">Smart Home<br>Security Systems
</span></a></li></ul>

<ul>
<li class="navFooterDescItem" aria-hidden="true">&nbsp;</li>
<li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://eero.com/ class="nav_a"><h5 class="navFooterDescItem_heading">eero WiFi</h5><span class="navFooterDescText">Stream 4K Video<br>in Every Room</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://blinkforhome.com/?ref=nav_footer class="nav_a"><h5 class="navFooterDescItem_heading">Blink</h5><span class="navFooterDescText">Smart Security<br>for Every Home
</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://shop.ring.com/pages/neighbors-app class="nav_a"><h5 class="navFooterDescItem_heading">Neighbors App </h5><span class="navFooterDescText"> Real-Time Crime<br>& Safety Alerts
</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem"><a href=https://www.pillpack.com class="nav_a"><h5 class="navFooterDescItem_heading">PillPack</h5><span class="navFooterDescText">Pharmacy Simplified</span></a></li><li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem" aria-hidden="true">&nbsp;</li>
<li class="navFooterDescSpacer" aria-hidden="true" style="width: 3%"></li>
<li class="navFooterDescItem" aria-hidden="true">&nbsp;</li>
</ul>

    </div>
  </div>

  
<div class="navFooterLine navFooterLinkLine navFooterPadItemLine navFooterCopyright">
  <ul><li class="nav_first"><a href="/gp/help/customer/display.html?nodeId=508088&ref_=footer_cou" id="" class="nav_a">Conditions of Use</a> </li><li ><a href="/gp/help/customer/display.html?nodeId=GX7NJQ4ZB8MHFRNJ&ref_=footer_privacy" id="" class="nav_a">Privacy Notice</a> </li><li ><a href="/gp/help/customer/display.html?ie=UTF8&nodeId=TnACMrGVghHocjL8KB&ref_=footer_consumer_health_data_privacy" id="" class="nav_a">Consumer Health Data Privacy Disclosure</a> </li><li ><a href="/privacyprefs?ref_=footer_iba" id="" class="nav_a">Your Ads Privacy Choices</a> </li><li class="nav_last"><span id="nav-icon-ccba" class="nav-sprite"></span> </li></ul><span>© 1996-2026, Shopping.com, Inc. or its affiliates</span>
</div>

  
</div>
<div id="sis_pixel_r2" aria-hidden="true" style="height:1px; position: absolute; left: -1000000px; top: -1000000px;"></div><script>(function(a,b){a.attachEvent?a.attachEvent("onload",b):a.addEventListener&&a.addEventListener("load",b,!1)})(window,function(){setTimeout(function(){var el=document.getElementById("sis_pixel_r2");el&&(el.innerHTML='<iframe id="DAsis" src="//s.amazon-adsystem.com/iu3?d=shopping.com&slot=navFooter&a2=0101250d35ec371c9acfe19ef1dafd8260e5f4130239538a225718768f2bc3955b79&old_oo=0&ts=1791888168406&s=AdBsAy9fEkIzvlF_IdhMxEwSvWRc9Eb28QcqeANt5QuC&gdpr_consent=&gdpr_consent_avl=&cb=1791888168406" width="1" height="1" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" tabindex="-1" sandbox></iframe>');var event=new Event("SISPixelCardLoaded");document.dispatchEvent(event);},300)});</script>

  <!-- NAVYAAN FOOTER END -->

<!-- sp:end-feature:nav-footer -->
<!-- sp:feature:configured-sitewide-assets -->
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/51U1Uw0rYLL.js?AUIClients/LatencyInteractiveAsset');
});
</script>
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/314MOd7pFFL.js?AUIClients/LoadMonitoringAsset');
});
</script>
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function() {
(function(e,d,f){f=function(){};var k=e.ue||{},m=function(c){return function(){try{return c.apply(this,arguments)}catch(b){l(b,"FATAL")}}},l=function(c){return function(b,a){a||(a="ERROR");b=b&&b.stack&&b.message?b:JSON.stringify(b);c({logLevel:a,attribution:"EdgeRECONAssets",message:b})}}(e.ueLogError||f);(function(c){return function(b,a){c("EdgeRECONAssets:"+b,a)}})(k.count||f)("registered",1);var g=function(){try{var c=d.createElement("link").relList.supports("preload")}catch(b){c=!1}return function(b){var a=
c?d.createElement("link"):new Image;a.onerror=a.onload=m(function(){a&&a.parentElement&&a.parentElement.removeChild(a)});c?(a.rel="preload",a.as="image",a.referrerPolicy="strict-origin-when-cross-origin",a.href=b,d.head.appendChild(a)):(a.style.display="none",a.referrerPolicy="strict-origin-when-cross-origin",a.src=b,d.documentElement.appendChild(a))}}(),h="https://redirect.prod.experiment.routing.cloudfront.aws.a2z.com/x.png?timestamp\x3d"+(new Date).getTime().toString();"loading"!==d.readyState?
setTimeout(g,1E3,h):e.addEventListener&&e.addEventListener("DOMContentLoaded",function(){setTimeout(g,1E3,h)})})(window,document);
});
</script>
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/518dRCZrPeL.js?AUIClients/AmazonLightsaberPageAssets#1403059-T1.1279464-T1');
});
</script>
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/11ekNxhYanL.css?AUIClients/WebFlowIngressJs" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/21a1o3dUMiL.js?AUIClients/WebFlowIngressJs');
});
</script>
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/21j0sUb2jJL._RC|21riOzhfKxL.css_.css?AUIClients/SiteWideActionExecutorAssets#1221147-T1" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/617c30kmp5L._RC|714xshPiF0L.js,01vHH50q3hL.js,21+jePJlqWL.js,01dRgHf14tL.js,31G1DZEighL.js,01c3R5cAW+L.js_.js?AUIClients/SiteWideActionExecutorAssets#us.1358246-T1.1245996-T1.1221147-T1.1339675-T1.1166904-T1');
});
</script>
<link rel="stylesheet" href="https://m.media-shopping.com/images/I/21i4sQKkPjL.css?AUIClients/PortableOffersDisplayAssets" />
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/11OKGselEhL._RC|61BpCey45zL.js,11D5W8uNI8L.js,013tDFvgJuL.js,21Y-yI9SlNL.js,01pZUYnIHzL.js,41NprL9VccL.js_.js?AUIClients/PortableOffersDisplayAssets#language-en.us.1358246-T1.1387700-T1.1221147-T1');
});
</script>
<!-- sp:end-feature:configured-sitewide-assets -->
<!-- sp:feature:customer-behavior-js -->
<script type="text/javascript">if (window.ue && ue.tag) { ue.tag('FWCIMEnabled'); }</script>
<script>
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('afterLoad').execute(function() {
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://m.media-shopping.com/images/I/81xAPm3uFgL.js?AUIClients/FWCIMAssets');
});
</script>
<!-- sp:end-feature:customer-behavior-js -->
<!-- sp:feature:csm:body-close -->
<div id='be' style="display:none;visibility:hidden;"><form name='ue_backdetect' action="get"><input type="hidden" name='ue_back' value='1' /></form>


<script type="text/javascript">
window.ue_ibe = (window.ue_ibe || 0) + 1;
if (window.ue_ibe === 1) {
(function(e,c){function h(b,a){f.push([b,a])}function g(b,a){if(b){var c=e.head||e.getElementsByTagName("head")[0]||e.documentElement,d=e.createElement("script");d.async="async";d.src=b;d.setAttribute("crossorigin","anonymous");a&&a.onerror&&(d.onerror=a.onerror);a&&a.onload&&(d.onload=a.onload);c.insertBefore(d,c.firstChild)}}function k(){ue.uels=g;for(var b=0;b<f.length;b++){var a=f[b];g(a[0],a[1])}ue.deffered=1}var f=[];c.ue&&(ue.uels=h,c.ue.attach&&c.ue.attach("load",k))})(document,window);


if (window.ue && window.ue.uels) {
        var cel_widgets = [ { "c":"celwidget" },{ "s":"#nav-swmslot > div", "id_gen":function(elem, index){ return 'nav_sitewide_msg'; } } ];

                ue.uels("https://images-na.ssl-images-shopping.com/images/I/215h87l68bL.js");
}
var ue_mbl=ue_csm.ue.exec(function(g,b){function m(c){a=c||{};b.AMZNPerformance=a;a.transition=a.transition||{};a.timing=a.timing||{};if(b.csa){var d;a.timing.transitionStart&&(d=a.timing.transitionStart);a.timing.processStart&&(d=a.timing.processStart);d&&(csa("PageTiming")("mark","nativeTransitionStart",d),csa("PageTiming")("mark","transitionStart",d))}g.ue.exec(n,"csm-android-check")()&&a.tags instanceof Array&&(c=-1!=a.tags.indexOf("usesAppStartTime")||a.transition.type?!a.transition.type&&-1<
a.tags.indexOf("usesAppStartTime")?"warm-start":void 0:"view-transition",c&&(a.transition.type=c));"reload"===f._nt&&g.ue_orct||"intrapage-transition"===f._nt?e&&e.timing&&e.timing.navigationStart?a.timing.transitionStart=e.timing.navigationStart:delete a.timing.transitionStart:"undefined"===typeof f._nt&&e&&e.timing&&e.timing.navigationStart&&b.history&&"function"===typeof b.History&&"object"===typeof b.history&&b.history.length&&1!=b.history.length&&(a.timing.transitionStart=e.timing.navigationStart);
c=a.transition;d=f._nt?f._nt:void 0;c.subType=d;b.ue&&b.ue.tag&&b.ue.tag("has-AMZNPerformance");f.isl&&b.uex&&b.uex("at","csm-timing");p()}function q(a){b.ue&&b.ue.count&&b.ue.count("csm-cordova-plugin-failed",1)}function n(){return b.cordova&&b.cordova.platformId&&"android"==b.cordova.platformId}function p(){try{b.P.register("AMZNPerformance",function(){return a})}catch(c){}}function l(){if(!a)return"";ue_mbl.cnt=null;var c=a.timing,d=a.transition,d=["mts",h(c.transitionStart),"mps",h(c.processStart),
"mtt",d.type,"mtst",d.subType,"mtlt",d.launchType];b.ue&&b.ue.tag&&(c.fr_ovr&&b.ue.tag("fr_ovr"),c.fcp_ovr&&b.ue.tag("fcp_ovr"),d.push("fr_ovr",h(c.fr_ovr),"fcp_ovr",h(c.fcp_ovr)));for(var c="",e=0;e<d.length;e+=2){var f=d[e],g=d[e+1];"undefined"!==typeof g&&(c+="&"+f+"="+g)}return c}function h(a){if("undefined"!==typeof a&&"undefined"!==typeof k)return a-k}function r(b,d){a&&(k=d,a.timing.transitionStart=b,a.transition.type="view-transition",a.transition.subType="ajax-transition",a.transition.launchType=
"normal",ue_mbl.cnt=l)}var f=g.ue||{},k=g.ue_t0,e=b.performance,a;if(b.P&&b.P.when&&b.P.register)return b.P.when("CSMPlugin").execute(function(a){a.buildAMZNPerformance&&a.buildAMZNPerformance({successCallback:m,failCallback:q})}),{cnt:l,ajax:r}},"mobile-timing")(ue_csm,ue_csm.window);

(function(d){d._uess=function(){var a="";screen&&screen.width&&screen.height&&(a+="&sw="+screen.width+"&sh="+screen.height);var b=function(a){var b=document.documentElement["client"+a];return"CSS1Compat"===document.compatMode&&b||document.body["client"+a]||b},c=b("Width"),b=b("Height");c&&b&&(a+="&vw="+c+"&vh="+b);return a}})(ue_csm);

(function(a){function d(a){c&&c("log",a)}var b=document.ue_backdetect,c=a.csa&&a.csa("Errors",{producerId:"csa",logOptions:{ent:"all"}});a.ue_err.buffer&&c&&(a.ue_err.buffer.forEach(d),a.ue_err.buffer.push=d);b&&b.ue_back&&a.ue&&(a.ue.bfini=b.ue_back.value);a.uet&&a.uet("be");a.onLdEnd&&(window.addEventListener?window.addEventListener("load",a.onLdEnd,!1):window.attachEvent&&window.attachEvent("onload",a.onLdEnd));a.ueh&&a.ueh(0,window,"load",a.onLd,1);a.ue&&a.ue.tag&&(a.ue_furl?(b=a.ue_furl.replace(/\./g,
"-"),a.ue.tag(b)):a.ue.tag("nofls"))})(ue_csm);

(function(g,h){function d(a,d){var b={};if(!e||!f)try{var c=h.sessionStorage;c?a&&("undefined"!==typeof d?c.setItem(a,d):b.val=c.getItem(a)):f=1}catch(g){e=1}e&&(b.e=1);return b}var b=g.ue||{},a="",f,e,c,a=d("csmtid");f?a="NA":a.e?a="ET":(a=a.val,a||(a=b.oid||"NI",d("csmtid",a)),c=d(b.oid),c.e||(c.val=c.val||0,d(b.oid,c.val+1)),b.ssw=d);b.tabid=a})(ue_csm,ue_csm.window);

(function(a){var e={rc:1,hob:1,hoe:1,ntd:1,rd_:1,_rd:1};"function"===typeof window.addEventListener&&window.addEventListener("pageshow",function(b){if(b&&b.persisted&&(b=+new Date,b={clickTime:b-1,pageVisible:b},"object"===typeof b&&"object"===typeof a.ue.markers&&"object"===typeof a.ue&&"function"===typeof a.uex)){if("function"===typeof a.uet){for(var c in a.ue.markers)!a.ue.markers.hasOwnProperty(c)||c in e||a.uet(c,void 0,void 0,b.pageVisible);a.uet("tc",void 0,void 0,b.clickTime);a.uet("ty",void 0,
void 0,b.clickTime+2)}(c=document.ue_backdetect)&&c.ue_back&&(a.ue.bfini=+c.ue_back.value+1);a.ue.isBFonMshop=!0;a.ue.isBFCache=!0;a.ue.t0=b.clickTime;a.ue.viz=["visible:0"];"function"===typeof a.ue.tag&&(a.ue.tag("cacheSourceMemory"),a.ue.tag("history-navigation-page-cache"));c=ue_csm.csa&&ue_csm.csa("SPA");var d=ue_csm.csa&&ue_csm.csa("PageTiming");c&&d&&(c("newPage",{transitionType:"history-navigation-page-cache"},{keepPageAttributes:!0}),d("mark","transitionStart",b.clickTime));"function"===typeof a.uex&&
a.uex("ld",void 0,void 0,a.ue.t.ld);delete a.ue.isBFonMshop;delete a.ue.isBFCache}})})(ue_csm);

ue_csm.ue.exec(function(e,f){var a=e.ue||{},b=a._wlo,d;if(a.ssw){d=a.ssw("CSM_previousURL").val;var c=f.location,b=b?b:c&&c.href?c.href.split("#")[0]:void 0;c=(b||"")===a.ssw("CSM_previousURL").val;!c&&b&&a.ssw("CSM_previousURL",b);d=c?"reload":d?"intrapage-transition":"first-view"}else d="unknown";a._nt=d},"NavTypeModule")(ue_csm,window);
ue_csm.ue.exec(function(c,a){function g(a){a.run(function(e){d.tag("csm-feature-"+a.name+":"+e);d.isl&&c.uex("at")})}if(a.addEventListener)for(var d=c.ue||{},f=[{name:"touch-enabled",run:function(b){var e=function(){a.removeEventListener("touchstart",c,!0);a.removeEventListener("mousemove",d,!0)},c=function(){b("true");e()},d=function(){b("false");e()};a.addEventListener("touchstart",c,!0);a.addEventListener("mousemove",d,!0)}}],b=0;b<f.length;b++)g(f[b])},"csm-features")(ue_csm,window);


(function(a,e){function d(a){b&&b("recordCounter",a.c,a.v)}var c=e.images,b;a.ue_act?(b=a.csa&&a.csa("Metrics",{producerId:"csa",dimensions:{type:a.ue_act}}))&&b("recordMetric","actorType",1):b=a.csa&&a.csa("Metrics",{producerId:"csa"});c&&c.length&&a.ue.count("totalImages",c.length);a.ue.cv.buffer&&b&&(a.ue.cv.buffer.forEach(d),a.ue.cv.buffer.push=d)})(ue_csm,document);
(function(b){function c(){var f=[];a.log&&a.log.isStub&&a.log.replay(function(a){d(f,a)});a.clog&&a.clog.isStub&&a.clog.replay(function(a){d(f,a)});f.length&&(a._flhs+=1,p&&(a._lpn.csm=(a._lpn.csm||0)+1),q(f))}function h(){a.log&&a.log.isStub&&(a.onflush&&a.onflush.replay&&a.onflush.replay(function(a){a[0]()}),a.onunload&&a.onunload.replay&&a.onunload.replay(function(a){a[0]()}),c())}function d(b,g){var c=g[1],e=g[0],d={};a._lpn[c]=(a._lpn[c]||0)+1;d[c]=e;b.push(d)}function q(a){if(k)a=l(a),b.navigator.sendBeacon(m,
a);else{a=l(a);var c=new b[e];c.open("POST",m,!0);c.setRequestHeader&&c.setRequestHeader("Content-type","text/plain");c.send(a)}}function l(a){return JSON.stringify({rid:b.ue_id,sid:b.ue_sid,mid:b.ue_mid,mkt:b.ue_mkt,sn:b.ue_sn,reqs:a})}var e="XMLHttpRequest",p=1===b.ue_ddq,a=b.ue,r=b[e]&&"withCredentials"in new b[e],k=b.navigator&&b.navigator.sendBeacon,m="//"+b.ue_furl+"/1/batch/1/OE/",n=b.ue_fci_ft||5E3;a&&(r||k)&&(a._flhs=a._flhs||0,a._lpn=a._lpn||{},a.attach&&(a.attach("beforeunload",a.exec(h,
"fcli-bfu")),a.attach("pagehide",a.exec(h,"fcli-ph"))),n&&b.setTimeout(a.exec(c,"fcli-t"),n),a._ffci=a.exec(c))})(window);


(function(k,c){function l(a,b){return a.filter(function(a){return a.initiatorType==b})}function f(a,c){if(b.t[a]){var g=b.t[a]-b._t0,e=c.filter(function(a){return 0!==a.responseEnd&&m(a)<g}),f=l(e,"script"),h=l(e,"link"),k=l(e,"img"),n=e.map(function(a){return a.name.split("/")[2]}).filter(function(a,b,c){return a&&c.lastIndexOf(a)==b}),q=e.filter(function(a){return a.duration<p}),s=g-Math.max.apply(null,e.map(m))<r|0;"af"==a&&(b._afjs=f.length);return a+":"+[e[d],f[d],h[d],k[d],n[d],q[d],s].join("-")}}
function m(a){return a.responseEnd-(b._t0-c.timing.navigationStart)}function n(){var a=c[h]("resource"),d=f("cf",a),g=f("af",a),a=f("ld",a);delete b._rt;b._ld=b.t.ld-b._t0;b._art&&b._art();return[d,g,a].join("_")}var p=20,r=50,d="length",b=k.ue,h="getEntriesByType";b._rre=m;b._rt=c&&c.timing&&c[h]&&n})(ue_csm,window.performance);


(function(c,d){var b=c.ue,a=d.navigator;b&&b.tag&&a&&(a=a.connection||a.mozConnection||a.webkitConnection)&&a.type&&b.tag("netInfo:"+a.type)})(ue_csm,window);


(function(c,d){function h(a,b){for(var c=[],d=0;d<a.length;d++){var e=a[d],f=b.encode(e);if(e[k]){var g=b.metaSep,e=e[k],l=b.metaPairSep,h=[],m=void 0;for(m in e)e.hasOwnProperty(m)&&h.push(m+"="+e[m]);e=h.join(l);f+=g+e}c.push(f)}return c.join(b.resourceSep)}function s(a){var b=a[k]=a[k]||{};b[t]||(b[t]=c.ue_mid);b[u]||(b[u]=c.ue_sid);b[f]||(b[f]=c.ue_id);b.csm=1;a="//"+c.ue_furl+"/1/"+a[v]+"/1/OP/"+a[w]+"/"+a[x]+"/"+h([a],y);if(n)try{n.call(d[p],a)}catch(g){c.ue.sbf=1,(new Image).src=a}else(new Image).src=
a}function q(){g&&g.isStub&&g.replay(function(a,b,c){a=a[0];b=a[k]=a[k]||{};b[f]=b[f]||c;s(a)});l.impression=s;g=null}if(!(1<c.ueinit)){var k="metadata",x="impressionType",v="foresterChannel",w="programGroup",t="marketplaceId",u="session",f="requestId",p="navigator",l=c.ue||{},n=d[p]&&d[p].sendBeacon,r=function(a,b,c,d){return{encode:d,resourceSep:a,metaSep:b,metaPairSep:c}},y=r("","?","&",function(a){return h(a.impressionData,z)}),z=r("/",":",",",function(a){return a.featureName+":"+h(a.resources,
A)}),A=r(",","@","|",function(a){return a.id}),g=l.impression;n?q():(l.attach("load",q),l.attach("beforeunload",q));try{d.P&&d.P.register&&d.P.register("impression-client",function(){})}catch(B){c.ueLogError(B,{logLevel:"WARN"})}}})(ue_csm,window);



var ue_pty = "AmazonStores";

var ue_spty = "LivePage";

var ue_pti = "CDB96030-A7CF-4B56-B70C-67086A740274";


var ue_adb = 4;
var ue_adb_rtla = 1;
ue_csm.ue.exec(function(y,a){function t(){if(d&&f){var a;a:{try{a=d.getItem(g);break a}catch(c){}a=void 0}if(a)return b=a,!0}return!1}function u(){if(a.fetch)fetch(m).then(function(a){if(!a.ok)throw Error(a.statusText);return a.text?a.text():null}).then(function(b){b?(-1<b.indexOf("window.ue_adb_chk = 1")&&(a.ue_adb_chk=1),n()):h()})["catch"](h);else e.uels(m,{onerror:h,onload:n})}function h(){b=k;l();if(f)try{d.setItem(g,b)}catch(a){}}function n(){b=1===a.ue_adb_chk?p:k;l();if(f)try{d.setItem(g,
b)}catch(c){}}function q(){a.ue_adb_rtla&&c&&0<c.ec&&!1===r&&(c.elh=null,ueLogError({m:"Hit Info",fromOnError:1},{logLevel:"INFO",adb:b}),r=!0)}function l(){e.tag(b);e.isl&&a.uex&&uex("at",b);s&&s.updateCsmHit("adb",b);c&&0<c.ec?q():a.ue_adb_rtla&&c&&(c.elh=q)}function v(){return b}if(a.ue_adb){a.ue_fadb=a.ue_fadb||10;var e=a.ue,k="adblk_yes",p="adblk_no",m="https://m.media-shopping.com/images/G/01/csm/showads.v2.js?adspot_=1",b="adblk_unk",d;a:{try{d=a.localStorage;break a}catch(z){}d=void 0}var g=
"csm:adb",c=a.ue_err,s=e.cookie,f=void 0!==a.localStorage,w=Math.random()>1-1/a.ue_fadb,r=!1,x=t();w||!x?u():l();a.ue_isAdb=v;a.ue_isAdb.unk="adblk_unk";a.ue_isAdb.no=p;a.ue_isAdb.yes=k}},"adb")(document,window);




(function(c,l,m){function h(a){if(a)try{if(a.id)return"//*[@id='"+a.id+"']";var b,d=1,e;for(e=a.previousSibling;e;e=e.previousSibling)e.nodeName===a.nodeName&&(d+=1);b=d;var c=a.nodeName;1!==b&&(c+="["+b+"]");a.parentNode&&(c=h(a.parentNode)+"/"+c);return c}catch(f){return"DETACHED"}}function f(a){if(a&&a.getAttribute)return a.getAttribute(k)?a.getAttribute(k):f(a.parentElement)}var k="data-cel-widget",g=!1,d=[];(c.ue||{}).isBF=function(){try{var a=JSON.parse(localStorage["csm-bf"]||"[]"),b=0<=a.indexOf(c.ue_id);
a.unshift(c.ue_id);a=a.slice(0,20);localStorage["csm-bf"]=JSON.stringify(a);return b}catch(d){return!1}}();c.ue_utils={getXPath:h,getFirstAscendingWidget:function(a,b){c.ue_cel&&c.ue_fem?!0===g?b(f(a)):d.push({element:a,callback:b}):b()},notifyWidgetsLabeled:function(){if(!1===g){g=!0;for(var a=f,b=0;b<d.length;b++)if(d[b].hasOwnProperty("callback")&&d[b].hasOwnProperty("element")){var c=d[b].callback,e=d[b].element;"function"===typeof c&&"function"===typeof a&&c(a(e))}d=null}},extractStringValue:function(a){if("string"===
typeof a)return a}}})(ue_csm,window,document);


(function(a){a.ue_cel||(a.ue_cel=function(){function m(a,r){r?r.r=u:r={r:u,c:1};D||(!ue_csm.ue_sclog&&r.clog&&b.clog?b.clog(a,r.ns||s,r):r.glog&&b.glog?b.glog(a,r.ns||s,r):b.log(a,r.ns||s,r))}function n(a,b){"function"===typeof p&&p("log",{schemaId:t+".RdCSI.1",eventType:a,clientData:b},{ent:{page:["requestId"]}})}function c(){var a=q.length;if(0<a){for(var r=[],c=0;c<a;c++){var d=q[c].api;d.ready()?(d.on({ts:b.d,ns:s}),g.push(q[c]),m({k:"mso",n:q[c].name,t:b.d()})):r.push(q[c])}q=r}}function f(){if(!f.executed){for(var a=
0;a<g.length;a++)g[a].api.off&&g[a].api.off({ts:b.d,ns:s});B();m({k:"eod",t0:b.t0,t:b.d()},{c:1,il:1});f.executed=1;for(a=0;a<g.length;a++)q.push(g[a]);g=[];d(v);d(A)}}function B(a){m({k:"hrt",t:b.d()},{c:1,il:1,n:a});y=Math.min(w,e*y);z()}function z(){d(A);A=k(function(){B(!0)},y)}function x(){f.executed||B()}var l=a.window,k=l.setTimeout,d=l.clearTimeout,e=1.5,w=l.ue_cel_max_hrt||3E4,t="robotdetection",q=[],g=[],s=a.ue_cel_ns||"cel",v,A,b=a.ue,F=a.uet,C=a.uex,u=b.rid,D=a.ue_dsbl_cel,h=l.csa,p,y=
l.ue_cel_hrt_int||3E3,E=l.requestAnimationFrame||function(a){a()};h&&(p=h("Events",{producerId:t}));if(b.isBF)m({k:"bft",t:b.d()});else{"function"==typeof F&&F("bb","csmCELLSframework",{wb:1});k(c,0);b.onunload(f);if(b.onflush)b.onflush(x);v=k(f,6E5);z();"function"==typeof C&&C("ld","csmCELLSframework",{wb:1});return{registerModule:function(a,r){q.push({name:a,api:r});m({k:"mrg",n:a,t:b.d()});c()},reset:function(a){m({k:"rst",t0:b.t0,t:b.d()});q=q.concat(g);g=[];for(var r=q.length,e=0;e<r;e++)q[e].api.off(),
q[e].api.reset();u=a||b.rid;c();d(v);v=k(f,6E5);f.executed=0},timeout:function(a,b){return k(function(){E(function(){f.executed||a()})},b)},log:m,csaEventLog:n,off:f}}}())})(ue_csm);
(function(a){a.ue_pdm||!a.ue_cel||a.ue.isBF||(a.ue_pdm=function(){function m(){try{var b=d.screen;if(b){var c={w:b.width,aw:b.availWidth,h:b.height,ah:b.availHeight,cd:b.colorDepth,pd:b.pixelDepth};g&&g.w===c.w&&g.h===c.h&&g.aw===c.aw&&g.ah===c.ah&&g.pd===c.pd&&g.cd===c.cd||(g=c,g.t=t(),g.k="sci",F(g),D&&h("sci",{h:(g.h||"0")+""}))}var k=e.body||{},f=e.documentElement||{},n={w:Math.max(k.scrollWidth||0,k.offsetWidth||0,f.clientWidth||0,f.scrollWidth||0,f.offsetWidth||0),h:Math.max(k.scrollHeight||
0,k.offsetHeight||0,f.clientHeight||0,f.scrollHeight||0,f.offsetHeight||0)};s&&s.w===n.w&&s.h===n.h||(s=n,s.t=t(),s.k="doi",F(s));w=a.ue_cel.timeout(m,q);A+=1}catch(p){d.ueLogError&&ueLogError(p,{attribution:"csm-cel-page-module",logLevel:"WARN"})}}function n(){x("ebl","default",!1)}function c(){x("efo","default",!0)}function f(){x("ebl","app",!1)}function B(){x("efo","app",!0)}function z(){d.setTimeout(function(){e[E]?x("ebl","pageviz",!1):x("efo","pageviz",!0)},0)}function x(a,b,c){v!==c&&(F({k:a,
t:t(),s:b},{ff:!0===c?0:1}),D&&h(a,{t:(t()||"0")+"",s:b}));v=c}function l(){b.attach&&(p&&b.attach(y,z,e),G&&P.when("mash").execute(function(a){a&&a.addEventListener&&(a.addEventListener("appPause",f),a.addEventListener("appResume",B))}),b.attach("blur",n,d),b.attach("focus",c,d))}function k(){b.detach&&(p&&b.detach(y,z,e),G&&P.when("mash").execute(function(a){a&&a.removeEventListener&&(a.removeEventListener("appPause",f),a.removeEventListener("appResume",B))}),b.detach("blur",n,d),b.detach("focus",
c,d))}var d=a.window,e=a.document,w,t,q,g,s,v=null,A=0,b=a.ue,F=a.ue_cel.log,C=a.uet,u=a.uex,D=d.csa,h=a.ue_cel.csaEventLog,p=!!b.pageViz,y=p&&b.pageViz.event,E=p&&b.pageViz.propHid,G=d.P&&d.P.when;"function"==typeof C&&C("bb","csmCELLSpdm",{wb:1});return{on:function(a){q=a.timespan||500;t=a.ts;l();a=d.location;F({k:"pmd",o:a.origin,p:a.pathname,t:t()});m();"function"==typeof u&&u("ld","csmCELLSpdm",{wb:1})},off:function(a){clearTimeout(w);k();b.count&&b.count("cel.PDM.TotalExecutions",A)},ready:function(){return e.body&&
a.ue_cel&&a.ue_cel.log},reset:function(){g=s=null}}}(),a.ue_cel&&a.ue_cel.registerModule("page module",a.ue_pdm))})(ue_csm);
(function(a){a.ue_vpm||!a.ue_cel||a.ue.isBF||(a.ue_vpm=function(){function m(){var a=z(),b={w:k.innerWidth,h:k.innerHeight,x:k.pageXOffset,y:k.pageYOffset};c&&c.w==b.w&&c.h==b.h&&c.x==b.x&&c.y==b.y||(b.t=a,b.k="vpi",c=b,e(c,{clog:1}),s&&v("vpi",{t:(c.t||"0")+"",h:(c.h||"0")+"",y:(c.y||"0")+"",w:(c.w||"0")+"",x:(c.x||"0")+""}));f=0;x=z()-a;l+=1}function n(){f||(f=a.ue_cel.timeout(m,B))}var c,f,B,z,x=0,l=0,k=a.window,d=a.ue,e=a.ue_cel.log,w=a.uet,t=a.uex,q=d.attach,g=d.detach,s=k.csa,v=a.ue_cel.csaEventLog;
"function"==typeof w&&w("bb","csmCELLSvpm",{wb:1});return{on:function(a){z=a.ts;B=a.timespan||100;m();q&&(q("scroll",n),q("resize",n));"function"==typeof t&&t("ld","csmCELLSvpm",{wb:1})},off:function(a){clearTimeout(f);g&&(g("scroll",n),g("resize",n));d.count&&(d.count("cel.VPI.TotalExecutions",l),d.count("cel.VPI.TotalExecutionTime",x),d.count("cel.VPI.AverageExecutionTime",x/l))},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){c=void 0},getVpi:function(){return c}}}(),a.ue_cel&&
a.ue_cel.registerModule("viewport module",a.ue_vpm))})(ue_csm);
(function(a){if(!a.ue_fem&&a.ue_cel&&a.ue_utils){var m=a.ue||{},n=a.window,c=n.document;!m.isBF&&!a.ue_fem&&c.querySelector&&n.getComputedStyle&&[].forEach&&(a.ue_fem=function(){function f(a,b){return a>b?3>a-b:3>b-a}function B(a,b){var c=n.pageXOffset,d=n.pageYOffset,k;a:{try{if(a){var e=a.getBoundingClientRect(),g,m=0===a.offsetWidth&&0===a.offsetHeight;c:{for(var h=a.parentNode,p=e.left||0,w=e.top||0,q=e.width||0,s=e.height||0;h&&h!==document.body;){var l;d:{try{var r=void 0;if(h)var t=h.getBoundingClientRect(),
r={x:t.left||0,y:t.top||0,w:t.width||0,h:t.height||0};else r=void 0;l=r;break d}catch(I){}l=void 0}var u=window.getComputedStyle(h),v="hidden"===u.overflow,x=v||"hidden"===u.overflowX,y=v||"hidden"===u.overflowY,z=w+s-1<l.y+1||w+1>l.y+l.h-1;if((p+q-1<l.x+1||p+1>l.x+l.w-1)&&x||z&&y){g=!0;break c}h=h.parentNode}g=!1}k={x:e.left+c||0,y:e.top+d||0,w:e.width||0,h:e.height||0,d:(m||g)|0}}else k=void 0;break a}catch(J){}k=void 0}if(k&&!a.cel_b)a.cel_b=k,D({n:a.getAttribute(A),w:a.cel_b.w,h:a.cel_b.h,d:a.cel_b.d,
x:a.cel_b.x,y:a.cel_b.y,t:b,k:"ewi",cl:a.className},{clog:1});else{if(c=k)c=a.cel_b,d=k,c=d.d===c.d&&1===d.d?!1:!(f(c.x,d.x)&&f(c.y,d.y)&&f(c.w,d.w)&&f(c.h,d.h)&&c.d===d.d);c&&(a.cel_b=k,D({n:a.getAttribute(A),w:a.cel_b.w,h:a.cel_b.h,d:a.cel_b.d,x:a.cel_b.x,y:a.cel_b.y,t:b,k:"ewi"},{clog:1}))}}function z(d,e){var f;f=d.c?c.getElementsByClassName(d.c):d.id?[c.getElementById(d.id)]:c.querySelectorAll(d.s);d.w=[];for(var g=0;g<f.length;g++){var h=f[g];if(h){if(!h.getAttribute(A)){var l=h.getAttribute("cel_widget_id")||
(d.id_gen||u)(h,g)||h.id;h.setAttribute(A,l)}d.w.push(h);k(Q,h,e)}}!1===C&&(F++,F===b.length&&(C=!0,a.ue_utils.notifyWidgetsLabeled()))}function x(a,b){h.contains(a)||D({n:a.getAttribute(A),t:b,k:"ewd"},{clog:1})}function l(a){K.length&&ue_cel.timeout(function(){if(s){for(var b=R(),c=!1;R()-b<g&&!c;){for(c=S;0<c--&&0<K.length;){var d=K.shift();T[d.type](d.elem,d.time)}c=0===K.length}U++;l(a)}},0)}function k(a,b,c){K.push({type:a,elem:b,time:c})}function d(a,c){for(var d=0;d<b.length;d++)for(var e=
b[d].w||[],h=0;h<e.length;h++)k(a,e[h],c)}function e(){M||(M=a.ue_cel.timeout(function(){M=null;var c=v();d(W,c);for(var e=0;e<b.length;e++)k(X,b[e],c);0===b.length&&!1===C&&(C=!0,a.ue_utils.notifyWidgetsLabeled());l(c)},q))}function w(){M||N||(N=a.ue_cel.timeout(function(){N=null;var a=v();d(Q,a);l(a)},q))}function t(){return y&&E&&h&&h.contains&&h.getBoundingClientRect&&v}var q=50,g=4.5,s=!1,v,A="data-cel-widget",b=[],F=0,C=!1,u=function(){},D=a.ue_cel.log,h,p,y,E,G=n.MutationObserver||n.WebKitMutationObserver||
n.MozMutationObserver,r=!!G,H,I,O="DOMAttrModified",L="DOMNodeInserted",J="DOMNodeRemoved",N,M,K=[],U=0,S=null,W="removedWidget",X="updateWidgets",Q="processWidget",T,V=n.performance||{},R=V.now&&function(){return V.now()}||function(){return Date.now()};"function"==typeof uet&&uet("bb","csmCELLSfem",{wb:1});return{on:function(d){function k(){if(t()){T={removedWidget:x,updateWidgets:z,processWidget:B};if(r){var a={attributes:!0,subtree:!0};H=new G(w);I=new G(e);H.observe(h,a);I.observe(h,{childList:!0,
subtree:!0});I.observe(p,a)}else y.call(h,O,w),y.call(h,L,e),y.call(h,J,e),y.call(p,L,w),y.call(p,J,w);e()}}h=c.body;p=c.head;y=h.addEventListener;E=h.removeEventListener;v=d.ts;b=a.cel_widgets||[];S=d.bs||5;m.deffered?k():m.attach&&m.attach("load",k);"function"==typeof uex&&uex("ld","csmCELLSfem",{wb:1});s=!0},off:function(){t()&&(I&&(I.disconnect(),I=null),H&&(H.disconnect(),H=null),E.call(h,O,w),E.call(h,L,e),E.call(h,J,e),E.call(p,L,w),E.call(p,J,w));m.count&&m.count("cel.widgets.batchesProcessed",
U);s=!1},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){b=a.cel_widgets||[]}}}(),a.ue_cel&&a.ue_fem&&a.ue_cel.registerModule("features module",a.ue_fem))}})(ue_csm);
(function(a){!a.ue_mcm&&a.ue_cel&&a.ue_utils&&!a.ue.isBF&&(a.ue_mcm=function(){function m(a,d){var e=a.srcElement||a.target||{},f={k:n,w:(d||{}).ow||(B.body||{}).scrollWidth,h:(d||{}).oh||(B.body||{}).scrollHeight,t:(d||{}).ots||c(),x:a.pageX,y:a.pageY,p:l.getXPath(e),n:e.nodeName};z&&"function"===typeof z.now&&a.timeStamp&&(f.dt=(d||{}).odt||z.now()-a.timeStamp,f.dt=parseFloat(f.dt.toFixed(2)));a.button&&(f.b=a.button);e.href&&(f.r=l.extractStringValue(e.href));e.id&&(f.i=e.id);e.className&&e.className.split&&
(f.c=e.className.split(/\s+/));x(f,{c:1})}var n="mcm",c,f=a.window,B=f.document,z=f.performance,x=a.ue_cel.log,l=a.ue_utils;return{on:function(k){c=k.ts;a.ue_cel_stub&&a.ue_cel_stub.replayModule(n,m);f.addEventListener&&f.addEventListener("mousedown",m,!0)},off:function(a){f.addEventListener&&f.removeEventListener("mousedown",m,!0)},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){}}}(),a.ue_cel&&a.ue_cel.registerModule("mouse click module",a.ue_mcm))})(ue_csm);
(function(a){a.ue_mmm||!a.ue_cel||a.ue.isBF||(a.ue_mmm=function(m){function n(a,b){var c={x:a.pageX||a.x||0,y:a.pageY||a.y||0,t:l()};!b&&p&&(c.t-p.t<B||c.x==p.x&&c.y==p.y)||(p=c,u.push(c))}function c(){if(u.length){F=H.now();for(var a=0;a<u.length;a++){var c=u[a],d=a;y=u[h];E=c;var e=void 0;if(!(e=2>d)){e=void 0;a:if(u[d].t-u[d-1].t>f)e=0;else{for(e=h+1;e<d;e++){var g=y,k=E,l=u[e];G=(k.x-g.x)*(g.y-l.y)-(g.x-l.x)*(k.y-g.y);if(G*G/((k.x-g.x)*(k.x-g.x)+(k.y-g.y)*(k.y-g.y))>z){e=0;break a}}e=1}e=!e}(r=
e)?h=d-1:D.pop();D.push(c)}C=H.now()-F;s=Math.min(s,C);v=Math.max(v,C);A=(A*b+C)/(b+1);b+=1;q({k:x,e:D,min:Math.floor(1E3*s),max:Math.floor(1E3*v),avg:Math.floor(1E3*A)},{c:1});u=[];D=[];h=0}}var f=100,B=20,z=25,x="mmm1",l,k,d=a.window,e=d.document,w=d.setInterval,t=a.ue,q=a.ue_cel.log,g,s=1E3,v=0,A=0,b=0,F,C,u=[],D=[],h=0,p,y,E,G,r,H=m&&m.now&&m||Date.now&&Date||{now:function(){return(new Date).getTime()}};return{on:function(a){l=a.ts;k=a.ns;t.attach&&t.attach("mousemove",n,e);g=w(c,3E3)},off:function(a){k&&
(p&&n(p,!0),c());clearInterval(g);t.detach&&t.detach("mousemove",n,e)},ready:function(){return a.ue_cel&&a.ue_cel.log},reset:function(){u=[];D=[];h=0;p=null}}}(window.performance),a.ue_cel&&a.ue_cel.registerModule("mouse move module",a.ue_mmm))})(ue_csm);



ue_csm.ue.exec(function(b,c){var e=function(){},f=function(){return{send:function(b,d){if(d&&b){var a;if(c.XDomainRequest)a=new XDomainRequest,a.onerror=e,a.ontimeout=e,a.onprogress=e,a.onload=e,a.timeout=0;else if(c.XMLHttpRequest){if(a=new XMLHttpRequest,!("withCredentials"in a))throw"";}else a=void 0;if(!a)throw"";a.open("POST",b,!0);a.setRequestHeader&&a.setRequestHeader("Content-type","text/plain");a.send(d)}},isSupported:!0}}(),g=function(){return{send:function(c,d){if(c&&d)if(navigator.sendBeacon(c,
d))b.ue_sbuimp&&b.ue&&b.ue.ssw&&b.ue.ssw("eelsts","scs");else throw"";},isSupported:!!navigator.sendBeacon&&!(c.cordova&&c.cordova.platformId&&"ios"==c.cordova.platformId)}}();b.ue._ajx=f;b.ue._sBcn=g},"Transportation-clients")(ue_csm,window);
ue_csm.ue.exec(function(b,l){function B(){for(var a=0;a<arguments.length;a++){var c=arguments[a];try{var g;if(c.isSupported){var f=t.buildPayload(k,e);g=c.send(J,f)}else throw dummyException;return g}catch(d){}}a={m:"All supported clients failed",attribution:"CSMSushiClient_TRANSPORTATION_FAIL",f:"sushi-client.js",logLevel:"ERROR"};b.ue_err.buffer&&b.ue_err.buffer.push(a)}function m(){if(e.length){for(var a=0;a<n.length;a++)n[a]();B(d._sBcn||{},d._ajx||{});e=[];h={};k={};u=v=q=w=0}}function K(){var a=
new Date,c=function(a){return 10>a?"0"+a:a};return Date.prototype.toISOString?a.toISOString():a.getUTCFullYear()+"-"+c(a.getUTCMonth()+1)+"-"+c(a.getUTCDate())+"T"+c(a.getUTCHours())+":"+c(a.getUTCMinutes())+":"+c(a.getUTCSeconds())+"."+String((a.getUTCMilliseconds()/1E3).toFixed(3)).slice(2,5)+"Z"}function x(a){try{return JSON.stringify(a)}catch(c){}return null}function C(a,c,g,f){var p=!1;f=f||{};r++;if(r==D){var s={m:"Max number of Sushi Logs exceeded",f:"sushi-client.js",logLevel:"ERROR",attribution:"CSMSushiClient_MAX_CALLS"};
b.ue_err.buffer&&b.ue_err.buffer.push(s)}if(s=!(r>=D))(s=a&&-1<a.constructor.toString().indexOf("Object")&&c&&-1<c.constructor.toString().indexOf("String")&&g&&-1<g.constructor.toString().indexOf("String"))||L++;s&&(d.count&&d.count("Event:"+g,1),a.producerId=a.producerId||c,a.schemaId=a.schemaId||g,a.timestamp=K(),c=Date.now?Date.now():+new Date,g=Math.random().toString().substring(2,12),a.messageId=b.ue_id+"-"+c+"-"+g,f&&!f.ssd&&(a.sessionId=a.sessionId||b.ue_sid,a.requestId=a.requestId||b.ue_id,
a.obfuscatedMarketplaceId=a.obfuscatedMarketplaceId||b.ue_mid),(c=x(a))?(c=c.length,(e.length==M||q+c>N)&&m(),q+=c,a={data:t.compressEvent(a)},e.push(a),(f||{}).n?0===E?m():u||(u=l.setTimeout(m,E)):v||(v=l.setTimeout(m,O)),p=!0):p=!1);!p&&b.ue_int&&console.error("Invalid JS Nexus API call");return p}function F(){if(!G){for(var a=0;a<y.length;a++)y[a]();for(a=0;a<n.length;a++)n[a]();e.length&&(b.ue_sbuimp&&b.ue&&b.ue.ssw&&(a=x({dct:k,evt:e}),b.ue.ssw("eeldata",a),b.ue.ssw("eelsts","unk")),B(d._sBcn||
{}));G=!0}}function H(a){y.push(a)}function I(a){n.push(a)}var D=1E3,M=499,N=524288,z=function(){},d=b.ue||{},P=b.uex||z;(b.uet||z)("bb","ue_sushi_v1",{wb:1});var J=b.ue_surl||"https://unagi-na.shopping.com/1/events/com.amazon.csm.nexusclient.gamma",Q=["messageId","timestamp"],A="#",e=[],h={},k={},q=0,w=0,L=0,r=0,y=[],n=[],G=!1,u,v,E=void 0===b.ue_hpsi?1E3:b.ue_hpsi,O=void 0===b.ue_lpsi?1E4:b.ue_lpsi,t=function(){function a(a){h[a]=A+w++;k[h[a]]=a;return h[a]}function c(b){if(!(b instanceof Function)){if(b instanceof
Array){for(var f=[],d=b.length,e=0;e<d;e++)f[e]=c(b[e]);return f}if(b instanceof Object){f={};for(d in b)b.hasOwnProperty(d)&&(f[h[d]?h[d]:a(d)]=-1===Q.indexOf(d)?c(b[d]):b[d]);return f}return"string"===typeof b&&(b.length>(A+w).length||b.charAt(0)===A)?h[b]?h[b]:a(b):b}}return{compressEvent:c,buildPayload:function(){return x({cs:{dct:k},events:e})}}}();(function(){if(d.event&&d.event.isStub){if(b.ue_sbuimp&&b.ue&&b.ue.ssw){var a=b.ue.ssw("eelsts").val;if(a&&"unk"===a&&(a=b.ue.ssw("eeldata").val)){var c;
a:{try{c=JSON.parse(a);break a}catch(g){}c=null}c&&c.evt instanceof Array&&c.dct instanceof Object&&(e=c.evt,k=c.dct,e&&k&&(m(),b.ue.ssw("eeldata","{}"),b.ue.ssw("eelsts","scs")))}}d.event.replay(function(a){a[3]=a[3]||{};a[3].n=1;C.apply(this,a)});d.onSushiUnload.replay(function(a){H(a[0])});d.onSushiFlush.replay(function(a){I(a[0])})}})();d.attach("beforeunload",F);d.attach("pagehide",F);d._cmps=t;d.event=C;d.event.reset=function(){r=0};d.onSushiUnload=H;d.onSushiFlush=I;try{l.P&&l.P.register&&
l.P.register("sushi-client",z)}catch(R){b.ueLogError(R,{logLevel:"WARN"})}P("ld","ue_sushi_v1",{wb:1})},"Nxs-JS-Client")(ue_csm,window);


ue_csm.ue_unrt = 1500;
(function(d,b,q){function r(a,b){var c=a.srcElement||a.target||{};e.getXPath(c);c.href&&e.extractStringValue(c.href);c.className&&c.className.split&&c.className.split(/\s+/);f+=1;e.getFirstAscendingWidget(c,function(a){ue.count("unresponsiveClicks",1)})}function t(a){if(!u(a.srcElement||a.target)){h+=1;k=!0;var s=n=d.ue.d(),c;l&&"function"===typeof l.now&&a.timeStamp&&(c=l.now()-a.timeStamp,c=parseFloat(c.toFixed(2)));p=b.setTimeout(function(){r(a,{t:s,dt:c})},v)}}function w(a){if(a){var b=a.filter(x);
a.length!==b.length&&(m=!0,d.ue.d(),k&&m&&(g(),m=!1))}}function x(a){if(!a)return!1;var b="characterData"===a.type?a.target.parentElement:a.target;if(!b||!b.hasAttributes||!b.attributes)return!1;var c={"class":"gw-clock gw-clock-aria s-item-container-height-auto feed-carousel using-mouse kfs-inner-container".split(" "),id:["dealClock","deal_expiry_timer","timer"],role:["timer"]},d=!1;Object.keys(c).forEach(function(a){var e=b.attributes[a]?b.attributes[a].value:"";(c[a]||"").forEach(function(a){-1!==
e.indexOf(a)&&(d=!0)})});return d}function u(a){if(!a)return!1;var b=(e.extractStringValue(a.nodeName)||"").toLowerCase(),c=(e.extractStringValue(a.type)||"").toLowerCase(),d=(e.extractStringValue(a.href)||"").toLowerCase();a=(e.extractStringValue(a.id)||"").toLowerCase();var f="checkbox color date datetime-local email file month number password radio range reset search tel text time url week".split(" ");if(-1!==["select","textarea","html"].indexOf(b)||"input"===b&&-1!==f.indexOf(c)||"a"===b&&-1!==
d.indexOf("http")||-1!==["sitbreaderrightpageturner","sitbreaderleftpageturner","sitbreaderpagecontainer"].indexOf(a))return!0}function g(){k=!1;n=0;b.clearTimeout(p)}function y(){b.ue.onunload(function(){ue.count("armored-cxguardrails.unresponsive-clicks.violations",f);ue.count("armored-cxguardrails.unresponsive-clicks.violationRate",f/h*100||0)})}if(b.MutationObserver&&b.addEventListener&&Object.keys&&d&&d.ue&&d.ue.log&&d.ue_unrt&&d.ue_utils){var v=d.ue_unrt,l=b.performance,e=d.ue_utils,k=!1,n=
0,p=0,m=!1,f=0,h=0;b.addEventListener&&(b.addEventListener("mousedown",t,!0),b.addEventListener("beforeunload",g,!0),b.addEventListener("visibilitychange",g,!0),b.addEventListener("pagehide",g,!0));b.ue&&b.ue.event&&b.ue.onSushiUnload&&b.ue.onunload&&y();(new MutationObserver(w)).observe(q,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}})(ue_csm,window,document);


ue_csm.ue.exec(function(g,e){if(e.ue_err){var f="";e.ue_err.errorHandlers||(e.ue_err.errorHandlers=[]);e.ue_err.errorHandlers.push({name:"fctx",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel)if(f=g.getElementsByTagName("html")[0].innerHTML){var b=f.indexOf("var ue_t0=ue_t0||+new Date();");if(-1!==b){var b=f.substr(0,b).split(String.fromCharCode(10)),d=Math.max(b.length-10-1,0),b=b.slice(d,b.length-1);a.fcsmln=d+b.length+1;a.cinfo=a.cinfo||{};for(var c=0;c<b.length;c++)a.cinfo[d+c+1+""]=
b[c]}b=f.split(String.fromCharCode(10));a.cinfo=a.cinfo||{};if(!(a.f||void 0===a.l||a.l in a.cinfo))for(c=+a.l-1,d=Math.max(c-5,0),c=Math.min(c+5,b.length-1);d<=c;d++)a.cinfo[d+1+""]=b[d]}}})}},"fatals-context")(document,window);


(function(m,a){function c(k){function f(b){b&&"string"===typeof b&&(b=(b=b.match(/^(?:https?:)?\/\/(.*?)(\/|$)/i))&&1<b.length?b[1]:null,b&&b&&("number"===typeof e[b]?e[b]++:e[b]=1))}function d(b){var e=10,d=+new Date;b&&b.timeRemaining?e=b.timeRemaining():b={timeRemaining:function(){return Math.max(0,e-(+new Date-d))}};for(var c=a.performance.getEntries(),k=e;g<c.length&&k>n;)c[g].name&&f(c[g].name),g++,k=b.timeRemaining();g>=c.length?h(!0):l()}function h(b){if(!b){b=m.scripts;var c;if(b)for(var d=
0;d<b.length;d++)(c=b[d].getAttribute("src"))&&"undefined"!==c&&f(c)}0<Object.keys(e).length&&(p&&ue_csm.ue&&ue_csm.ue.event&&ue_csm.ue.event({domains:e,pageType:a.ue_pty||null,subPageType:a.ue_spty||null,pageTypeId:a.ue_pti||null},"csm","csm.CrossOriginDomains.2"),a.ue_ext=e)}function l(){!0===k?d():a.requestIdleCallback?a.requestIdleCallback(d):a.requestAnimationFrame?a.requestAnimationFrame(d):a.setTimeout(d,100)}function c(){if(a.performance&&a.performance.getEntries){var b=a.performance.getEntries();
!b||0>=b.length?h(!1):l()}else h(!1)}var e=a.ue_ext||{};a.ue_ext||c();return e}function q(){setTimeout(c,r)}var s=a.ue_dserr||!1,p=!0,n=1,r=2E3,g=0;a.ue_err&&s&&(a.ue_err.errorHandlers||(a.ue_err.errorHandlers=[]),a.ue_err.errorHandlers.push({name:"ext",handler:function(a){if(!a.logLevel||"FATAL"===a.logLevel){var f=c(!0),d=[],h;for(h in f){var f=h,g=f.match(/amazon(\.com?)?\.\w{2,3}$/i);g&&1<g.length||-1!==f.indexOf("amazon-adsystem.com")||-1!==f.indexOf("amazonpay.com")||-1!==f.indexOf("cloudfront-labs.amazonaws.com")||
d.push(h)}a.ext=d}}}));a.ue&&a.ue.isl?c():a.ue&&ue.attach&&ue.attach("load",q)})(document,window);





var ue_wtc_c = 3;
ue_csm.ue.exec(function(b,e){function l(){for(var a=0;a<f.length;a++)a:for(var d=s.replace(A,f[a])+g[f[a]]+t,c=arguments,b=0;b<c.length;b++)try{c[b].send(d);break a}catch(e){}g={};f=[];n=0;k=p}function u(){B?l(q):l(C,q)}function v(a,m,c){r++;if(r>w)d.count&&1==r-w&&(d.count("WeblabTriggerThresholdReached",1),b.ue_int&&console.error("Number of max call reached. Data will no longer be send"));else{var h=c||{};h&&-1<h.constructor.toString().indexOf(D)&&a&&-1<a.constructor.toString().indexOf(x)&&m&&-1<
m.constructor.toString().indexOf(x)?(h=b.ue_id,c&&c.rid&&(h=c.rid),c=h,a=encodeURIComponent(",wl="+a+"/"+m),2E3>a.length+p?(2E3<k+a.length&&u(),void 0===g[c]&&(g[c]="",f.push(c)),g[c]+=a,k+=a.length,n||(n=e.setTimeout(u,E))):b.ue_int&&console.error("Invalid API call. The input provided is over 2000 chars.")):d.count&&(d.count("WeblabTriggerImproperAPICall",1),b.ue_int&&console.error("Invalid API call. The input provided does not match the API protocol i.e ue.trigger(String, String, Object)."))}}function F(){d.trigger&&
d.trigger.isStub&&d.trigger.replay(function(a){v.apply(this,a)})}function y(){z||(f.length&&l(q),z=!0)}var t=":1234",s="//"+b.ue_furl+"/1/remote-weblab-triggers/1/OE/"+b.ue_mid+":"+b.ue_sid+":PLCHLDR_RID$s:wl-client-id%3DCSMTriger",A="PLCHLDR_RID",E=b.wtt||1E4,p=s.length+t.length,w=b.mwtc||2E3,G=1===e.ue_wtc_c,B=3===e.ue_wtc_c,H=e.XMLHttpRequest&&"withCredentials"in new e.XMLHttpRequest,x="String",D="Object",d=b.ue,g={},f=[],k=p,n,z=!1,r=0,C=function(){return{send:function(a){if(H){var b=new e.XMLHttpRequest;
b.open("GET",a,!0);G&&(b.withCredentials=!0);b.send()}else throw"";}}}(),q=function(){return{send:function(a){(new Image).src=a}}}();e.encodeURIComponent&&(d.attach&&(d.attach("beforeunload",y),d.attach("pagehide",y)),F(),d.trigger=v)},"client-wbl-trg")(ue_csm,window);


(function(k,d,h){function f(a,c,b){a&&a.indexOf&&0===a.indexOf("http")&&0!==a.indexOf("https")&&l(s,c,a,b)}function g(a,c,b){a&&a.indexOf&&(location.href.split("#")[0]!=a&&null!==a&&"undefined"!==typeof a||l(t,c,a,b))}function l(a,c,b,e){m[b]||(e=u&&e?n(e):"N/A",d.ueLogError&&d.ueLogError({message:a+c+" : "+b,logLevel:v,stack:"N/A"},{attribution:e}),m[b]=1,p++)}function e(a,c){if(a&&c)for(var b=0;b<a.length;b++)try{c(a[b])}catch(d){}}function q(){return d.performance&&d.performance.getEntriesByType?
d.performance.getEntriesByType("resource"):[]}function n(a){if(a.id)return"//*[@id='"+a.id+"']";var c;c=1;var b;for(b=a.previousSibling;b;b=b.previousSibling)b.nodeName==a.nodeName&&(c+=1);b=a.nodeName;1!=c&&(b+="["+c+"]");a.parentNode&&(b=n(a.parentNode)+"/"+b);return b}function w(){var a=h.images;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"img",a);g(b,"img",a)})}function x(){var a=h.scripts;a&&a.length&&e(a,function(a){var b=a.getAttribute("src");f(b,"script",a);g(b,"script",a)})}
function y(){var a=h.styleSheets;a&&a.length&&e(a,function(a){if(a=a.ownerNode){var b=a.getAttribute("href");f(b,"style",a);g(b,"style",a)}})}function z(){if(A){var a=q();e(a,function(a){f(a.name,a.initiatorType)})}}function B(){e(q(),function(a){g(a.name,a.initiatorType)})}function r(){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),B(),p<C&&setTimeout(r,D))}var s="[CSM] Insecure content detected ",t="[CSM] Ajax request to same page detected ",v="WARN",
m={},p=0,D=k.ue_nsip||1E3,C=5,A=1==k.ue_urt,u=!0;ue_csm.ue_disableNonSecure||(d.performance&&d.performance.setResourceTimingBufferSize&&d.performance.setResourceTimingBufferSize(300),r())})(ue_csm,window,document);


var ue_aa_a = "T1";
if (ue.trigger && (ue_aa_a === "C" || ue_aa_a === "T1")) {
    ue.trigger("UEDATA_AA_SERVERSIDE_ASSIGNMENT_CLIENTSIDE_TRIGGER_190249", ue_aa_a);
}
(function(f,b){function g(){try{b.PerformanceObserver&&"function"===typeof b.PerformanceObserver&&(a=new b.PerformanceObserver(function(b){c(b.getEntries())}),a.observe(d))}catch(h){k()}}function m(){for(var h=d.entryTypes,a=0;a<h.length;a++)c(b.performance.getEntriesByType(h[a]))}function c(a){if(a&&Array.isArray(a)){for(var c=0,e=0;e<a.length;e++){var d=l.indexOf(a[e].name);if(-1!==d){var g=Math.round(b.performance.timing.navigationStart+a[e].startTime);f.uet(n[d],void 0,void 0,g);c++}}l.length===
c&&k()}}function k(){a&&a.disconnect&&"function"===typeof a.disconnect&&a.disconnect()}if("function"===typeof f.uet&&b.performance&&"object"===typeof b.performance&&b.performance.getEntriesByType&&"function"===typeof b.performance.getEntriesByType&&b.performance.timing&&"object"===typeof b.performance.timing&&"number"===typeof b.performance.timing.navigationStart){var d={entryTypes:["paint"]},l=["first-paint","first-contentful-paint"],n=["fp","fcp"],a;try{m(),g()}catch(p){f.ueLogError(p,{logLevel:"ERROR",
attribution:"performanceMetrics"})}}})(ue_csm,window);


if (window.csa) {
    csa("Events")("setEntity", {
        page:{pageType: "AmazonStores", subPageType: "LivePage", pageTypeId: "CDB96030-A7CF-4B56-B70C-67086A740274"}
    });
}
csa.plugin(function(d){var e,t,n,m="transitionStart",i="pageVisible",o="PageTiming",a="visibilitychange",u="$latency.visible",r=d.global,c=(r.performance||{}).timing,s=["navigationStart","unloadEventStart","unloadEventEnd","redirectStart","redirectEnd","fetchStart","domainLookupStart","domainLookupEnd","connectStart","connectEnd","secureConnectionStart","requestStart","responseStart","responseEnd","domLoading","domInteractive","domContentLoadedEventStart","domContentLoadedEventEnd","domComplete","loadEventStart","loadEventEnd"],l=d.config,f=r.Math,g=f.max,v=f.floor,p=r.document||{},S=(c||{}).navigationStart,E=S,I=0,h=0,b=null;if(r.Object.keys&&[].forEach&&!l["KillSwitch."+o]){if(!c||null===S||S<=0||void 0===S)return d.error("Invalid navigation timing data: "+S);b=new y({schemaId:"<ns>.PageLatency.6",producerId:"csa"}),"boolean"!=typeof p.hidden&&"string"!=typeof p.visibilityState||!p.removeEventListener?d.emit(u):L()?(d.emit(u),T(i,S)):d.on(p,a,function n(){L()&&(E=d.time(),p.removeEventListener(a,n),T(m,E),T(i,E),d.emit(u))}),d.on("$timing:aboveTheFold",function(n){e=n,$()}),d.on("$timing:functional",function(n){t=n,$()}),d.once("$unload",k),d.once("$load",k),d.on("$pageTransition",function(){E=d.time(),t=e=n,h=0}),d.register(o,{mark:T,instance:function(n){return new y(n)}})}function y(n){var i,o=null,a=n.ent||{page:["pageType","subPageType","requestId"]},r=n.logger||d("Events",{producerId:n.producerId,lob:l.lob||"0"});if(!n||!n.producerId||!n.schemaId)return d.error("The producer id and schema Id must be defined for PageLatencyInstance.");function c(){return i||E}function e(){o=d.UUID()}this.mark=function(e,t){if(null!=e)return t=t||d.time(),e===m&&(i=t),d.once(u,function(){r("log",{messageId:o,__merge:function(n){n.markers[e]=function(n,e){return g(0,e-(n||E))}(c(),t),n.markerTimestamps[e]=v(t)},markers:{},markerTimestamps:{},navigationStartTimestamp:c()?new Date(c()).toISOString():null,schemaId:n.schemaId},{ent:a})}),t},e(),d.on("$beforePageTransition",e)}function T(n,e){n===m&&(E=e);var t=b.mark(n,e);d.emit("$timing:"+n,t)}function k(){if(!I){for(var n=0;n<s.length;n++)c[s[n]]&&T(s[n],c[s[n]]);I=1}}function L(){return!p.hidden||"visible"===p.visibilityState}function $(){e===n||t===n||h||(T("timeToInteractive",g(e,t)),h=1)}});csa.plugin(function(f){var e,n,r,o,c="length",i="number",l="addedNodes",s="removedNodes",a="nodeName",u="nodeValue",d="parentElement",v="target",h="getEntriesByName",m="checkVisibility",g={opacityProperty:!0,visibilityProperty:!0},t="_csa_",p=t+"nnh",y=t+"flt",E=t+"llt",S=t+"vlb",b=t+"vla",x=t+"vlab",I=t+"vlta",T=t+"vlr",N=t+"vl_thr",_=t+"vl_sl",w=t+"vl_lm",L=w+"i",M=t+"vl_em",O=t+"vlt",B=t+"vp",C=t+"eb",V=t+"pcc",k=t+"nrm",W=t+"inv_",P=W+"mslt",D=W+"h",H="previousSibling",R="nextSibling",Y="visuallyLoaded",A="vlDbg",F="Total",X="client",$="offset",q="scroll",J="Width",Q="Height",j="width",K="height",U=X+J,z=X+Q,G=$+J,Z=$+Q,tt=q+J,et=q+Q,nt="_elt",rt="_eid",it=10,ot=5,at=35,ut=100,ft="IFRAME",ct={50:1,90:1,100:1},lt={SCRIPT:1,STYLE:1,NOSCRIPT:1,LINK:1,META:1},st=["_csa_visual_load_hidden_"],dt=["a-truncate-cut"],vt={"nav-flyout-anchor":1,"nav-flyout-iss-anchor":1},ht=[ft],mt=f.global,gt=f.timeout,pt=mt.Math,yt=pt.min,Et=pt.max,St=pt.floor,bt=pt.ceil,xt=mt.document||{},It=xt.body||{},Tt=xt.documentElement||{},Nt=mt.performance||{},_t=(Nt.timing||{}).navigationStart,wt=Date.now,Lt=Object.values||(f.types||{}).ovl,Mt=f("PageTiming"),Ot=f("SpeedIndexBuffers"),Bt=0,Ct=[],Vt=[],kt=[],Wt=[],Pt=[],Dt=[],Ht=[],Rt=it,Yt=it,At=.1,Ft=.1,Xt=0,$t=0,qt=0,Jt=0,Qt=0,jt=0,Kt=0,Ut=1,zt=0,Gt={},Zt=[],te=0,ee=0,ne=0,re=0,ie=0,oe={},ae=0,ue=0,fe=0,ce=0,le=0;function se(){var t=wt(),e=0;for(!Bt&&o&&o.d&&(Re("QueStart"+o.d),Bt=1);o;){if(0!==o[c]){if(!1!==o.h(o[0])&&o.shift(),e++,!jt&&e%it==0&&wt()-t>ot)break}else(o=o.n)&&o.d&&Re("QueStart"+o.d)}Xt=0,o&&(Xt||(!0===xt.hidden?(jt=1,se()):f.timeout(se,0)))}function de(t,e,n,r){Re("BufStart"),zt=St(t),Ct=e,Vt=n,Ht=r;var i=xt.createTreeWalker(xt.body,NodeFilter.SHOW_TEXT,null,null);xt.body[nt]=t,kt.push({w:i}),Wt.push({img:xt.images,iter:0}),Pt.push({vid:xt.getElementsByTagName("VIDEO"),iter:0}),ht.forEach(function(t){Dt.push({iel:xt.getElementsByTagName(t),iter:0,rt:ft===t})}),Ct.h=he,Ct.n=Vt,Ct.d="MutInt",Vt.h=Ne,Vt.n=kt,Vt.d="Mut",kt.h=we,kt.n=Wt,kt.d="Txt",Wt.h=Le,Wt.n=Pt,Wt.d="Img",Pt.h=Me,Pt.n=Dt,Pt.d="Vid",Dt.h=Oe,Dt.n=Ht,Dt.d="IntEl",Ht.h=Be,Ht.d="VpUpd",o=Ct,se()}function ve(t,e){for(var n=t;n&&(t===n||!n[y]||!n[E]);){n[y]||(n[y]=t[y]),n[E]||(n[E]=t[E]);var r=n[y]-_t;n[nt]=r,n[_]=r,n=n[e]}}function he(t){var e=t.iter||0;for(Rt=Rt<=0?it:Rt;e<t.m[c]&&0<Rt;){var n=t.m[e];ve(n,H),ve(n,R),re+=1,t.iter=e+=1,Rt-=1}return t.m[c]<=e}function me(e,t){return e&&e.classList&&pe(e.classList.contains)&&t&&0<t[c]&&pe(t.some)&&t.some(function(t){return e.classList.contains(t)})}function ge(t){return typeof t===i&&!isNaN(t)}function pe(t){return"function"==typeof t}function ye(t){return t&&t.endsWith&&t.endsWith("px")?+t.substring(0,t[c]-2):e}function Ee(t){if(t&&p in t)return t[p];var e=t&&!lt[t[a]||""]&&(!pe(t[m])||t[m](g))&&"none"!==(t.style||{}).display&&!function(t){var e=(t||{}).style||{},n=!1;if("absolute"===e.position){var r=ye(e[K]),i=ye(e[j]),o=ye(e.top),a=ye(e.left);(ge(r)&&ge(o)&&r+o<0||ge(i)&&ge(a)&&i+a<0)&&(n=!0)}return n}(t)&&!me(t,st)&&!vt[t.id||""];return t&&(t[p]=e),e}function Se(t){return function(t){return t&&!t[k]&&8!==t.nodeType&&(3!==t.nodeType||0!==(t[u]||"").trim()[c])&&Ee(t)}(t)?t:e}function be(t){t&&(t[k]=1)}function xe(t){t&&!t[M]&&(ne+=t[M]=1)}function Ie(t,e){var n,r=[];if(t&&pe(e)&&0<(n=t[c]))for(var i=0;i<n;i++){var o=e(t[i]);o&&r.push(o)}return r}function Te(t){var e,n,r=0;t&&(t[s]&&1===t[s][c]&&(n=t[s][0]),t[l]&&1===t[l][c]&&(e=t[l][0]),n&&e&&n[u]===e[u]&&(r=1));return r}function Ne(t){var e=t.iter||0;for(Yt=Yt<=0?it:Yt;e<t.m[c]&&0<Yt;){var n=t.m[e];if(n){var r=n[v],i=r&&Ee(r)&&!me(r,dt),o=i?Ie(n[l],Se):[],a=0<o[c],u=a&&Te(n);if(te+=1,a&&r&&!u&&i){var f=t.t-_t;r[nt]=f,ee+=1,r[w]=f,(r[L]=o)&&pe(o.forEach)&&o.forEach(xe)}Ie(n[s],be)}t.iter=e+=1,Yt-=1}return t.m[c]<=e}function _e(t,e){if(t&&!t[rt]){ie+=1;var n=t.tagName||"";oe[n]=(oe[n]||0)+1,Pe(t,e||Ce(t,1))}}function we(t){for(var e,n=t.w,r=it;0<r&&(e=n.nextNode());){r-=1;var i=e[d],o=(i||{})[a];"BODY"===o||lt[o]||0!==(e[u]||"").trim()[c]&&(ae+=1,Pe(i,Ce(e)))}return!e}function Le(t){for(var e=it;t.iter<t.img[c]&&0<e;){var n,r=t.img[t.iter],i=We(r),o=i&&Ce(i)||Ce(r);i?(i[nt]=o,n=ke(i.querySelector('[aria-posinset="1"] img')||r)||o,r=i):n=ke(r)||o,ue+=1,Pe(r,n),t.iter+=1,e-=1}return t.img[c]<=t.iter}function Me(t){for(var e,n=it;t.iter<t.vid[c]&&0<n;){var r,i=t.vid[t.iter],o=We(i),a=o&&Ce(o)||Ce(i);if(o){o[nt]=a;var u=o.querySelector('[aria-posinset="1"] img');r=u&&ke(u)||a,i=o}else r=Ve((e=i).poster,e,1)||Ve(e.currentSrc,e,0)||Ve(e.src,e,0)||a;fe+=1,Pe(i,r),t.iter+=1,n-=1}return t.vid[c]<=t.iter}function Oe(t){for(var e=it,n=t.rt;t.iter<t.iel[c]&&0<e;){var r=t.iel[t.iter],i=0;n&&(i=Ve(r.src,r,1)),_e(r,i),t.iter+=1,e-=1}return t.iel[c]<=t.iter}function Be(t){var n=[],i=0,o=0,a=$t,e=(mt.innerWidth||Et(It[tt]||0,It[G]||0,Tt[U]||0,Tt[tt]||0,Tt[G]||0),0+(mt.innerHeight||Et(It[et]||0,It[Z]||0,Tt[z]||0,Tt[et]||0,Tt[Z]||0))),r=St(0/ut),u=bt(e/ut);Zt.slice(r,u).forEach(function(t){(t.elems||[]).forEach(function(t){if(t.lt in n||(n[t.lt]={}),!(t.id in n[t.lt])){var e=t.a;e&&(n[t.lt][t.id]=t,i+=e)}})}),xt&&xt.body&&(xt.body[S]=1),Lt(n).forEach(function(t){Lt(t).forEach(function(t){var e=1-o/i,n=Et(t.lt,a),r=t.a;le+=e*(n-a),o+=r,a=n,ce+=1,t.e&&(t.e[S]=1,t.e[b]=r,t.e[I]=i,t.e[O]=n),function(t,e){var n;e.e&&(e.e[T]=t);for(;At<=1&&At-.01<=t;)He(Y+(n=(100*At).toFixed(0)),e.lt),ct[n]&&f("Content",{target:e.e})("mark",Y+n,_t+bt(e.lt||0)),e.e&&(e.e[N]=n),At+=Ft}(o/i,t)})}),$t=t.t-_t,He("atfSpeedIndex",le),He("speedIndex",le),He(Y+"0",zt),Re("CalcEnd"),Ye(F+"Blocks",ce),Ye(F+"Mut",te),Ye(F+"ValMut",ee),Ye(F+"MutEl",ne),Ye(F+"MutInter",re),Ye(F+"IntEl",ie),ht.forEach(function(t){Ye(F+"IntEl"+t,oe[t]||0)}),Ye(F+"Txt",ae),Ye(F+"Img",ue),Ye(F+"Vid",fe)}function Ce(t,e){for(var n=e?t:t[d],r=at+(e?1:0);n&&0<r;){if(n[nt]||0===n[nt])return Et(n[nt],zt);n=n[d],r-=1}}function Ve(t,e,n){if(t){if(!t.indexOf("data:"))return Ce(e);var r=Nt[h](t)||[];if(0<r[c])return Et(bt(r[n?r[c]-1:0].responseEnd||0),zt)}}function ke(t){return Ve(t.currentSrc,t,1)||Ve(t.src,t,1)}function We(t){for(var e=10,n=t[d],r=[];n&&0<e;){if(n[V]&&0<n[V][c])return r.push(n[V][0]),n[V][0];if(n[V]=r,n.classList&&n.classList.contains("a-carousel-viewport"))return r.push(n),n;n=n[d],e-=1}return null}function Pe(t,e){var n,r=!e&&0!==e;if(r||t[rt]||(n=!Ee(t)))return t[P]=r,void(t[D]=n);var i=t.getBoundingClientRect(),o={x:i.left+(mt.scrollX||mt.pageXOffset),y:i.top+(mt.scrollY||mt.pageYOffset),w:i[j],h:i[K]},a=i.width*i.height,u=mt.innerWidth||Et(It[tt]||0,It[G]||0,Tt[U]||0,Tt[tt]||0,Tt[G]||0)||i.right,f=mt.innerHeight||Et(It[et]||0,It[Z]||0,Tt[z]||0,Tt[et]||0,Tt[Z]||0)||i.bottom,c=Ut++;if(0!==(a=function(t,e,n,r,i,o,a){if(e&&n&&ge(n.x)&&ge(n.y)&&ge(n.w)&&ge(n.h)&&0<n.w&&0<n.h){var u=n.y+n.h,f=n.x+n.w;if(n.y<i||a<u||n.x<r||o<f){var c=Et(r,n.x),l=Et(i,n.y),s=c-n.x,d=l-n.y,v=yt(o,f)-c,h=yt(a,u)-l,m=Et(0,v),g=Et(0,h),p=Et(0,s),y=Et(0,d);e=m*g,t&&e&&(t[x]={x:p,y:y,w:m,h:g})}}return e}(t,a,o,0,0,0+u,0+f))){for(var l={e:t,lt:e,a:a,id:c},s=St(o.y/ut),d=bt((o.y+o.h)/ut),v=s;v<=d;v++)v in Zt||(Zt[v]={elems:[],lt:0}),Zt[v].elems.push(l);t[rt]=c,t[B]={x:0,y:0,w:u,h:f},t[C]=o}}function De(t,e){Mt("mark",t,e)}function He(t,e){De(t,_t+bt((Gt[t]=e)||0))}function Re(t){De(A+t,wt())}function Ye(t,e){var n=r||f("Metrics",{producerId:"csa"});n&&(r=n)("recordCounter","CSA.Latency.Page.VisualLoad."+t,e)}function Ae(){Kt||(Re("CalcStart"),pe(n)?n(de):Ot("getBuffers",de),Kt=1)}_t&&Lt&&Nt[h]&&(Ot("registerListener",function(){Qt&&(clearTimeout(qt),qt=gt(Ae,2500))}),f.once("$unload",function(){jt=1,Ae()}),f.once("$load",function(){Qt=1,Jt?Ae():(clearTimeout(qt),qt=gt(Ae,2500))}),f.once("$timing:functional",function(){Jt=1,Qt?Ae():(clearTimeout(qt),qt=gt(Ae,2500))}),Ot("replayModuleIsLive",function(t){n=t}),f.register("SpeedIndex",{getMarkers:function(t){t&&t(JSON.parse(JSON.stringify(Gt)))}}))});csa.plugin(function(e){var n=!1,t=e("PageTiming"),i=e.global.PerformanceObserver,r=e.global.performance;function a(){return r.timing.navigationStart}function o(){n||function(r){var a=new i(function(e){var n=e.getEntries();if(0!==n.length){var t=n[n.length-1];a.disconnect(),r({startTime:t.startTime,renderTime:t.renderTime,loadTime:t.loadTime})}});try{a.observe({type:"largest-contentful-paint",buffered:!0})}catch(e){}}(function(e){e&&(n=!0,t("mark","largestContentfulPaint",Math.floor(e.startTime+a())),e.renderTime&&t("mark","largestContentfulPaint.render",Math.floor(e.renderTime+a())),e.loadTime&&t("mark","largestContentfulPaint.load",Math.floor(e.loadTime+a())))})}i&&r&&r.timing&&(e.once("$unload",o),e.once("$load",o),e.register("LargestContentfulPaint",{}))});csa.plugin(function(r){var e=r("Metrics",{producerId:"csa"}),n=r.global.PerformanceObserver;n&&(n=new n(function(r){var t=r.getEntries();if(0===t.length||!t[0].processingStart||!t[0].startTime)return;!function(r){r=r||0,n.disconnect(),0<=r?e("recordMetric","firstInputDelay",r):e("recordMetric","firstInputDelay.invalid",1)}(t[0].processingStart-t[0].startTime)}),function(){try{n.observe({type:"first-input",buffered:!0})}catch(r){}}())});csa.plugin(function(d){var g="Metrics",e=d.config["Events.SushiCsaCustomSourceGroup"],f=d.config,l=0;function r(t){var c,i,e=t.producerId,r=t.logger,o=r||d("Events",{producerId:e,lob:f.lob||"0"}),s=(t||{}).dimensions||{},u={},n=-1;if(!e&&!r)return d.error("Either a producer id or custom logger must be defined");function a(){n!==l&&(c=d.UUID(),i=d.UUID(),u={},n=l)}this.recordMetric=function(r,n){if(!f["KillSwitch."+g]){var e=t.logOptions||{ent:{page:["pageType","subPageType","requestId"]}};e.debugMetric=t.debugMetric,a(),o("log",{messageId:c,schemaId:t.schemaId||"<ns>.Metric.4",metrics:{},dimensions:s,__merge:function(e){e.metrics[r]=n}},e)}},this.recordCounter=function(r,e){if(!f["KillSwitch.InternalCounters"]){var n=t.logOptions||{ent:{page:["pageType","subPageType","requestId"]}};if("string"!=typeof r||"number"!=typeof e||!isFinite(e))return d.error("Invalid type given for counter name or counter value: "+r+"/"+e);a(),r in u||(u[r]={});var c=u[r];"f"in c||(c.f=e),c.c=(c.c||0)+1,c.s=(c.s||0)+e,c.l=e,o("log",{messageId:i,schemaId:t.schemaId||"<ns>.InternalCounters.3",c:{},__merge:function(e){r in e.c||(e.c[r]={}),c.fs||(c.fs=1,e.c[r].f=c.f),1<c.c&&(e.c[r].s=c.s,e.c[r].l=c.l,e.c[r].c=c.c)}},n)}}}new r({producerId:"csa"}).recordMetric("baselineMetricEvent",1),e&&new r({logger:d("Events",{producerId:"csa",lob:f.lob||"0",sushiSourceGroup:e,copyBaseMetadata:!0,copyEntities:!0})}).recordCounter("csa.customsg.baselineMetric",1);d.on("$beforePageTransition",function(){l++}),d.register(g,{instance:function(e){return new r(e||{})}})});csa.plugin(function(s){var n=s.config,r=(s.global.performance||{}).timing,c=(r||{}).navigationStart||s.time(),g=0;function e(){g+=1}function i(i){i=i||{};var o=s.UUID(),t=g,r=i.producerId,e=i.logger,a=e||s("Events",{producerId:r,lob:n.lob||"0"});if(!r&&!e)return s.error("Either a producer id or custom logger must be defined");this.mark=function(e,r){var n=(void 0===r?s.time():r)-c;t!==g&&(t=g,o=s.UUID()),a("log",{messageId:o,schemaId:i.schemaId||"<ns>.Timer.1",markers:{},__merge:function(r){r.markers[e]=n}},i.logOptions)}}r&&(e(),s.on("$beforePageTransition",e),s.register("Timers",{instance:function(r){return new i(r||{})}}))});csa.plugin(function(t){var e="takeRecords",i="disconnect",n="function",o=t("Metrics",{producerId:"csa"}),c=t("PageTiming"),a=t.global,u=t.timeout,r=t.on,f=a.PerformanceObserver,m=0,l=!1,s=0,d=a.performance,h=a.document,v=null,y=!1,g=t.blank;function p(){l||(l=!0,clearTimeout(v),typeof f[e]===n&&f[e](),typeof f[i]===n&&f[i](),o("recordMetric","documentCumulativeLayoutShift",m),c("mark","cumulativeLayoutShiftLastTimestamp",Math.floor(s+d.timing.navigationStart)))}f&&d&&d.timing&&h&&(f=new f(function(t){v&&clearTimeout(v);t.getEntries().forEach(function(t){t.hadRecentInput||(m+=t.value,s<t.startTime&&(s=t.startTime))}),v=u(p,5e3)}),function(){try{f.observe({type:"layout-shift",buffered:!0}),v=u(p,5e3)}catch(t){}}(),g=r(h,"click",function(t){y||(y=!0,o("recordMetric","documentCumulativeLayoutShiftToFirstInput",m),g())}),r(h,"visibilitychange",function(){"hidden"===h.visibilityState&&p()}),t.once("$unload",p))});csa.plugin(function(e){var t,n=e.global,r=n.PerformanceObserver,c=e("Metrics",{producerId:"csa"}),o=0,i=0,a=-1,l=n.Math,f=l.max,u=l.ceil;if(r){t=new r(function(e){e.getEntries().forEach(function(e){var t=e.duration;o+=t,i+=t,a=f(t,a)})});try{t.observe({type:"longtask",buffered:!0})}catch(e){}t=new r(function(e){0<e.getEntries().length&&(i=0,a=-1)});try{t.observe({type:"largest-contentful-paint",buffered:!0})}catch(e){}e.on("$unload",g),e.on("$beforePageTransition",g)}function g(){c("recordMetric","totalBlockingTime",u(i||0)),c("recordMetric","totalBlockingTimeInclLCP",u(o||0)),c("recordMetric","maxBlockingTime",u(a||0)),i=o=0,a=-1}});csa.plugin(function(n){var e,t,r,c="CacheDetection",i="csa-ctoken-",f="csa-pfetch-",o="PreFetch",u="device",a="pre-fetch",s="setUp",l="string",d="function",h="length",g="preFetchTime",p="preFetchedRequestId",v="attribution",I="ERR",y="INVALID",S={ICDP:1},m=[y,"INPUT"].join("_"),R=[I,o,s].join("_"),k=20,w=n.store,b=n.error,q=n.warn,N=n.deleteStored,C=n.config,D=C[c+".RequestID"],E=C[c+".Callback"],O=1,F=n.global,P=F.document||{},T=F.Date,j=T.now,J=n.time,U=n("Events"),_=n("Events",{producerId:"csa",lob:C.lob||"0"});function x(){return C["KillSwitch."+c]}function A(e){return e&&typeof e===l&&S[e]}function K(e,t,n,r,c){var i=H("session-id");!function(e,t,n,r,c,i){var o={pageSource:"cache",requestId:e,cacheRequestId:c||D,cacheSource:n},u={page:o};r&&(o[v]=r);i&&(o[g]=i);t&&(u.session={id:t});U("setEntity",u)}(n,i,e,t,r,c),e!==u&&e!==a||_("log",{schemaId:"<ns>.CacheImpression.2"},{ent:"all"}),E&&E(n,i,e)}function L(){return j()+60*O*60*1e3}function V(e,t){return t&&e&&e.length<=t.length&&t.slice(0,e.length)===e}function $(e){var t;try{t=JSON.parse(e||"{}")}catch(e){}return t}function z(e,t){var n=!1,r=t||e.resultCallback;if(x())return B(r,{e:!1,ks:!0});var c=e||{},i=function(e,t){var n,r=+e;return t||r||(r=J()),(n=new T(r)).getTime()?n.toISOString():t?null:J("ISO")}(c[g],!1),o=c[p],u=c[v];if(function(e){return e&&typeof e===l&&e[h]===k}(o)&&A(u)&&function(e){return e&&typeof e===l&&0<e[h]}(i)){var a=f+o,s=L();try{w(a,JSON.stringify({e:s,t:i,a:u})),n=!0}catch(e){}n?B(r,{e:!1,ks:!1}):G(b,r,I,R,e)}else G(q,r,y,m,e)}function B(e,t){typeof e===d&&e(t)}function G(e,t,n,r,c){e(r),B(t,{e:!0,ks:!1,c:r,l:n,d:c})}function H(e){try{var t=P.cookie.match(RegExp("(^| )"+e+"=([^;]+)"));return t&&t[2].trim()}catch(e){}}n.register(o,((e={})[s]=z,e)),x()||(t=function(){var e=n.store(f+D);if(e){var t=$(e);if(t&&A(t.a))return{r:n.generateNewRequestId(),t:t.t,a:t.a,s:a}}}()||function(){var e=H("cdn-rid");if(e)return{r:e,s:"cdn"}}()||function(){if(n.store(i+D))return{r:n.generateNewRequestId(),s:u}}()||{},(r=t.r)&&K(t.s,t.a,r,D,t.t),w(i+D,L()),n.once("$load",function(){var r=T.now();N(function(e,t){if(V(i,e))return parseInt(t)<r;if(V(f,e)){var n=$(t);return!n||+n.e<r}return!1})}))});csa.plugin(function(a){var i,e="Content",t="MutationObserver",f="querySelectorAll",s="matches",o="getAttributeNames",r="getAttribute",l="dataset",c="widget",u="producerId",d="slotId",n="iSlotId",g="$csaWidget",h={ent:{element:1,page:["pageType","subPageType","requestId"]}},p=5,m=a.config[e+".BubbleUp.SearchDepth"]||35,v=a.config[e+".SearchPage"]||0,y="csaC",b=y+"Id",I="logRender",E={},w=a.config,C=w[e+".Selectors"]||[],S=w[e+".WhitelistedAttributes"]||{href:1,class:1},O=w[e+".EnableContentEntities"],A=w["KillSwitch.ContentRendered"],N=a.global,$=N.document||{},k=$.documentElement,R=N.HTMLElement,U={},j=[],D=0,L=0,M=0,P=function(e,t,n,i){var r=this,o=a("Events",{producerId:e||"csa",lob:w.lob||"0"});t.type=t.type||c,r.id=t.id,r.l=o,r.e=t,r.el=n,r.rt=i,r.dlo=h,r.op=V(n,"csaOp"),r.log=function(e,t){o("log",e,t||h)},r.entities=function(e){e(t)},t.id&&o("setEntity",{element:t})},T=P.prototype;function _(e){var t=(e=e||{}).element,n=e.target;return t?function(e,t){var n;n=e instanceof R?Q(e)||z(t[u],e,Z,a.time()):U[e.id]||G(t[u],0,e,a.time());return n}(t,e):n?x(n):a.error("No element or target argument provided.")}function x(e){var t=function(e){var t=null,n=0;for(;e&&n<m;){if(n++,B(e,b)){t=e;break}e=e.parentElement}return t}(e);return t?Q(t):new P("csa",{id:null},null,a.time())}function B(e,t){if(e&&e.dataset)return e.dataset[t]}function W(e,t,n){j.push({n:n,e:e,t:t}),X()}function q(){for(var e=a.time(),t=0;0<j.length;){var n=j.shift();if(E[n.n](n.e,n.t),++t%10==0&&a.time()-e>p)break}i=0,j.length&&X()}function X(){i=i||a.raf(q)}function Y(e){return e&&e.constructor&&"NodeList"===e.constructor.name}function H(e,t,n){return{n:e,e:t,t:n}}function K(o,c,u){f in o&&s in o&&C.forEach(function(e){for(var t=e.selector,n=o[s](t),i=o[f](t),r=i.length-1;0<=r;r--)j.unshift(H(u,{e:i[r],s:e},c));n&&j.unshift(H(u,{e:o,s:e},c))})}function z(e,t,n,i){var r=t&&t[g];if(r)return r.el=t,a.emit("$content.reregister",{c:r,t:i}),M+=1,U[r.id]=r;var o=a.UUID(),c={id:o},u=x(t);return t[l][b]=o,n(c,t),u&&u.id&&(c.parentId=u.id,!c[d]&&u.e&&(u.e.slotId?c.relatedSlotId=u.e.slotId:u.e.relatedSlotId&&(c.relatedSlotId=u.e.relatedSlotId))),G(e,t,c,i)}function F(e){return isNaN(e)?null:Math.round(e)}function G(e,t,n,i){O&&(n.schemaId="<ns>.ContentEntity.2"),n.id=n.id||a.UUID();var r=new P(e,n,t,i);return function(e){return!A&&((e.op||{}).hasOwnProperty(I)||v)}(r)&&function(e,t){var n={},i=a.exec(F);e.el&&(n=e.el.getBoundingClientRect()),e.log({schemaId:"<ns>.ContentRender.3",timestamp:t,width:i(n.width),height:i(n.height),positionX:i(n.left+N.pageXOffset),positionY:i(n.top+N.pageYOffset)})}(r,i),a.emit("$content.register",r),D+=1,U[n.id]=r}function J(){var e=a("Metrics",{producerId:"csa"});if(e){var t="recordCounter",n="CSA.Content.Base.Widgets.",i="Registered";e(t,n+"Instrumented",Object.keys(U).length),e(t,n+i,D),e(t,n+"De"+i,L),e(t,n+"Re"+i,M),D=L=M=0}}function Q(e){return U[(e[l]||{})[b]]}function V(n,i){var r={};return o in(n=n||{})&&Object.keys(n[l]).forEach(function(e){if(!e.indexOf(i)&&i.length<e.length){var t=function(e){return(e[0]||"").toLowerCase()+e.slice(1)}(e.slice(i.length));r[t]=n[l][e]}}),r}function Z(e,t){o in t&&(function(e,t){var n=V(e,y);Object.keys(n).forEach(function(e){t[e]=n[e]})}(t,e),d in e&&(e[n]=e[d]),function(t,n){(t[o]()||[]).forEach(function(e){e in S&&(n[e]=t[r](e))})}(t,e))}k&&$[f]&&N[t]&&(C.push({selector:"*[data-csa-c-type]",entity:Z}),C.push({selector:".celwidget",entity:function(e,t){Z(e,t),e[d]=e[d]||t[r]("cel_widget_id")||t.id,e.legacyId=t[r]("cel_widget_id")||t.id,e.type=e.type||c}}),E[1]=function(e,i){e.forEach(function(e){var t=e.addedNodes;Y(t)&&Array.prototype.forEach.call(t,function(e){j.unshift(H(2,e,i))});var n=e.removedNodes;Y(n)&&Array.prototype.forEach.call(n,function(e){j.unshift(H(5,e,i))})})},E[2]=function(e,t){K(e,t,3)},E[3]=function(e,t){var n=e.e;Q(n)||z("csa",n,e.s.entity,t)},E[4]=function(){a.register(e,{instance:_})},E[5]=function(e,t){K(e,t,6)},E[6]=function(e,t){var n=e.e||{},i=(n[l]||{})[b];if(i&&i in U&&function(e){return!e||!e.isConnected}(n)){var r=U[i];!function(e,t){a.emit("$content.deregister",{c:e,t:t}),delete U[e.id],e.el=null,L+=1}(r,t),n[g]=r}},new N[t](function(e){W(e,a.time(),1)}).observe(k,{childList:!0,subtree:!0}),W(k,a.time(),2),W(null,a.time(),4),a.on("$content.export",function(t){Object.keys(t).forEach(function(e){T[e]=t[e]})}),a.on("$beforePageTransition",J),a.on("$beforeunload",J))});csa.plugin(function(r){var o,t="ContentImpressions",e="KillSwitch.",i="IntersectionObserver",s="getAttribute",c="dataset",a="intersectionRatio",m="impressionData",l="observe",u="unobserve",f="csaCId",v=1e3,d=r.global,n=r.config,g=n[e+t],h=n[e+t+".ContentViews"],p=((d.performance||{}).timing||{}).navigationStart||r.time(),I={};function w(t){t&&(t.v=1,function(t){if(h)return;t.vt=r.time(),t.el.log({schemaId:"<ns>.ContentView.4",timeToViewed:t.vt-t.el.rt,pageFirstPaintToElementViewed:t.vt-p})}(t))}function T(t){t&&!t.it&&(t.i=r.time()-t.is>v,function(t){if(g)return;t.it=r.time(),t.el.log({schemaId:"<ns>.ContentImpressed.3",timeToImpressed:t.it-t.el.rt,pageFirstPaintToElementImpressed:t.it-p})}(t))}d[i]&&(o=new d[i](function(t){var n=r.time();t.forEach(function(t){var e=function(t){if(t&&t[s])return I[t[c][f]]}(t.target);if(e){r.emit("$content.intersection",{meta:e.el,t:n,e:t});var i=t.intersectionRect;t.isIntersecting&&0<i.width&&0<i.height&&(e.v||w(e),.5<=t[a]&&!e.is&&(e.is=n,e.timer=r.timeout(function(){T(e)},v))),t[a]<.5&&!e.it&&e.timer&&(d.clearTimeout(e.timer),e.is=0,e.timer=0)}})},{threshold:[0,.5,.99]}),r.on("$content.register",function(t){var e=t.el;e&&(I[t.id]={el:t,v:0,i:0,is:0,vt:0,it:0},o[l](e))}),r.on("$content.deregister",function(t){var e=(t||{}).c,i=e.el;if(e.id in I){var n=I[e.id];n&&(d.clearTimeout(n.timer),n.is=0,n.timer=0),e[m]=n,delete I[e.id]}i&&o[u]&&o[u](i)}),r.on("$content.reregister",function(t){var e=(t||{}).c,i=e.el,n=e[m];n&&(I[e.id]=n),i&&o[l](i)}))});csa.plugin(function(e){e.config["KillSwitch.ContentLatency"]||e.emit("$content.export",{mark:function(t,n){var o=this;o.t||(o.t=e("Timers",{logger:o.l,schemaId:"<ns>.ContentLatency.4",logOptions:o.dlo})),o.t("mark",t,n)}})});csa.plugin(function(t){function n(i,e,o){var c={};function r(t,n,e){t in c&&o<=n-c[t].s&&(function(n,e,i){if(!m)return;E(function(t){T(n,t),t.w[n][e]=a((t.w[n][e]||0)+i)})}(t,i,n-c[t].d),c[t].d=n),e||delete c[t]}this.update=function(t,n){n.isIntersecting&&e<=n.intersectionRatio?function(t,n){t in c||(c[t]={s:n,d:n})}(t,s()):r(t,s())},this.stopAll=function(t){var n=s();for(var e in c)r(e,n,t)},this.reset=function(){var t=s();for(var n in c)c[n].s=t,c[n].d=t},this.stop=r}var e=t.config,s=t.time,i="ContentInteractionsSummary",o=e[i+".FlushInterval"]||5e3,c=e[i+".FlushBackoff"]||1.5,r=t.global,u=t.on,a=Math.floor,f=(r.document||{}).documentElement||{},l=((r.performance||{}).timing||{}).responseStart||t.time(),d=o,p=0,m=!0,v=t.UUID(),g=t("Events",{producerId:"csa",lob:e.lob||"0"}),w=new n("it0",0,0),I=new n("it50",.5,1e3),h=new n("it100",.99,0),b={},A={};function $(){w.stopAll(!0),I.stopAll(!0),h.stopAll(!0),S()}function C(){w.reset(),I.reset(),h.reset(),S()}function S(){d&&(clearTimeout(p),p=t.timeout($,d),d*=c)}function U(n){E(function(t){T(n,t),t.w[n].mc=(t.w[n].mc||0)+1})}function E(t){g("log",{messageId:v,schemaId:"<ns>.ContentInteractionsSummary.2",w:{},__merge:t},{ent:{page:["requestId"]}})}function T(t,n){t in n.w||(n.w[t]={})}e["KillSwitch."+i]||(u("$content.intersection",function(t){if(t&&t.meta&&t.e){var n=t.meta.id;if(n in b){var e=t.e.boundingClientRect||{};e.width<5||e.height<5||(w.update(n,t.e),I.update(n,t.e),h.update(n,t.e),!t.e.isIntersecting||n in A||(A[n]=1,function(n,e){E(function(t){T(n,t),t.w[n].ttfv=a(e)})}(n,s()-l)))}}}),u("$content.register",function(t){(t.e||{}).slotId&&(b[t.id]={},function(e){E(function(t){var n=e.id;T(n,t),t.w[n].sid=(e.e||{}).slotId,t.w[n].cid=(e.e||{}).contentId})}(t))}),u("$content.deregister",function(t){if(t){var n=t.c,e=t.t;if(n){var i=n.id;w.stop(i,e),I.stop(i,e),h.stop(i,e)}}}),u("$beforePageTransition",function(){$(),C(),v=t.UUID(),S()}),u("$beforeunload",function(){w.stopAll(),I.stopAll(),h.stopAll(),d=null}),u("$visible",function(t){t?C():($(),clearTimeout(p)),m=t},{buffered:1}),u(f,"click",function(t){for(var n=t.target,e=25;n&&0<e;){var i=(n.dataset||{}).csaCId;i&&U(i),n=n.parentElement,e-=1}},{capture:!0,passive:!0}),S())});csa.plugin(function(d){var t,o,i="normal",u="reload",e="history",s="new-tab",n="ajax",r=1,a=2,c="lastActive",l="lastInteraction",f="used",p="csa-tabbed-browsing",y="visibilityState",g="page",v="experience",b="request",I="initialized",m={"back-memory-cache":1,"tab-switch":1,"history-navigation-page-cache":1},h="TabbedBrowsing",T="<ns>."+h+".4",S="visible",w=d.global,x=d.config,P=d("Events",{producerId:"csa",lob:x.lob||"0"}),q=w.location||{},$=w.document,z=w.JSON,A=((w.performance||{}).navigation||{}).type,C=d.store,E=d.on,O=d.storageSupport(),k=!1,R={},j={},B={},J={},K={},M=!1,N=!1,D=!1,F=0,G=0,H=x["CSA.isRunningInsideMShop"];function L(i){try{return z.parse(C(p,void 0,{session:i})||"{}")||{}}catch(i){d.error('Could not parse storage value for key "'+p+'": '+i)}return{}}function Q(i,e){C(p,z.stringify(e||{}),{session:i})}function U(i){return"string"==typeof i}function V(i,e){return U(i)?i:e}function W(i){var e=j.tid||i.id,t={},n=R[c]||{};for(var r in n)n.hasOwnProperty(r)&&(t[r]=n[r]);!H&&t.tid!==e||(t.tid=e,t.pid=i.id,t.ent=K),J={pid:i.id,tid:e,ent:K,lastInteraction:j[l]||{},initialized:!0},B={lastActive:t,lastInteraction:R[l]||{},time:d.time(),initialized:!0}}function X(i){var e=i===s,t=$.referrer,n=!(t&&t.length)||!~t.indexOf(q.origin||""),r=e&&!H&&n,a={type:i,toTabId:J.tid,toPageId:J.pid,transitTime:d.time()-R.time||null};r||function(i,e,t){var n=i===u,r=e||H&&(!(j[I]&&j.ent)||D)?R[c]||{}:j,a=R[l]||{},d=j[l]||{},o=e||H&&!(d.id&&!d[f])?a:d;t.fromTabId=r.tid,t.fromPageId=r.pid;var s=r.ent||{};U(s.rid)&&(t.fromRequestId=s.rid||null),U(s.ety)&&(t.fromExperienceType=s.ety||null),U(s.esty)&&(t.fromExperienceSubType=s.esty||null),n||!o.id||o[f]||(t.interactionId=o.id||null,o.sid&&(t.interactionSlotId=o.sid||null),a.id===o.id&&(a[f]=!0),d.id===o.id&&(d[f]=!0))}(i,e,a),P("log",{navigation:a,schemaId:T},{ent:{page:["pageType","subPageType","requestId"]}})}function Y(i){D=function(i){return i&&i in m}(i.transitionType),function(){R=L(!1),j=L(!0);var i=R[l],e=j[l],t=!1,n=!1;i&&e&&i.id===e.id&&i[f]!==e[f]&&(t=!i[f],n=!e[f],e[f]=i[f]=!0,t&&Q(!1,R),n&&Q(!0,j))}(),W(i),M=!0,function(i){var e,t;e=_(),t=ei(!0),(e||t)&&W(i)}(i),F=1}function Z(){k&&!D?X(n):(k=!0,function(){if(A===a||D)X(e);else if(A===r)X(j[I]?u:s);else{X(j[I]||H&&R[I]?i:s)}}())}function _(){var i=t,e={};return!!(M&&i&&i.e&&i.w)&&(i.w("entities",function(i){e=i||{}}),j[l]={id:i.e.messageId,sid:e.slotId,used:!(R[l]={id:i.e.messageId,sid:e.slotId,used:!1})},!(t=null))}function ii(i,e){var t=i||{},n=e||{};return t.rid!==n.rid||t.ety!==n.ety||t.esty!==n.esty}function ei(i){var e=!1;if(N=H&&i||$[y]===S,M){var t=R[c]||{};e=function(i,e,t,n){var r=!1,a=i[c];return N?(!a||a.tid!==J.tid||!a[S]||a.pid!==t||!a.ent&&n||n&&ii(a.ent,n))&&(i[c]={visible:!0,pid:t,tid:e,ent:n},r=!0):!H&&a&&a.tid===J.tid&&a[S]&&(r=!(a[S]=!1)),r}(R,(D?t.tid:null)||j.tid||t.tid||J.tid,(D?t.pid:null)||j.pid||t.pid||J.pid,(D?t.ent:null)||j.ent||t.ent||J.ent)}return e}x["KillSwitch."+h]||O.local&&O.session&&z&&$&&y in $&&(o=function(){try{return w.self!==w.top}catch(i){return!0}}(),E("$beforePageTransition",function(){G=1}),E("$entities.set",function(i){if(!o&&i){var e=(i[b]||{}).id||(i[g]||{}).requestId,t=(i[v]||{}).experienceType||(i[g]||{}).pageType,n=(i[v]||{}).experienceSubType||(i[g]||{}).subPageType,r=ii(K,{rid:e,ety:t,esty:n});if(K.rid=V(e,K.rid),K.ety=V(t,K.ety),K.esty=V(n,K.esty),!G&&r&&F){var a=R[c]||{};a.tid===j.tid&&(a.ent=K,Q(!1,R)),j.ent=K,Q(!0,j)}}},{buffered:1}),E("$pageChange",function(i){o||(Y(i),Z(),Q(!1,B),Q(!0,J),j=J,R=B,G=0)},{buffered:1}),E("$content.interaction",function(i){t=i,_()&&(Q(!1,R),Q(!0,j))}),E($,"visibilitychange",function(){!o&&ei()&&Q(!1,R)},{capture:!1,passive:!0}))});csa.plugin(function(c){var e=c("Metrics",{producerId:"csa"});c.on(c.global,"pageshow",function(c){c&&c.persisted&&e("recordMetric","bfCache",1)})});csa.plugin(function(n){var e,t,i,o,r,a,c,u,f,s,l,d,p,g,m,v,h,b,y="hasFocus",S="$app.",T="avail",$="client",w="document",I="inner",P="offset",D="screen",C="scroll",E="Width",F="Height",O=T+E,q=T+F,x=$+E,z=$+F,H=I+E,K=I+F,M=P+E,W=P+F,X=C+E,Y=C+F,j="up",k="down",A="none",B=20,G=n.config,J=G["KillSwitch.PageInteractionsSummary"],L=n("Events",{producerId:"csa",lob:G.lob||"0"}),N=1,Q=n.global||{},R=n.time,U=n.on,V=n.once,Z=Q[w]||{},_=Q[D]||{},nn=Q.Math||{},en=nn.abs,tn=nn.max,on=nn.ceil,rn=((Q.performance||{}).timing||{}).responseStart,an=function(){return Z[y]()},cn=1,un=100,fn={},sn=1,ln=0,dn=0,pn=k,gn=A;function mn(){c=t=o=r=e,i=d=0,a=u=f=s=l=0,pn=k,gn=A,dn=ln=0,yn(),bn()}function vn(){rn&&!o&&(c=on((o=p)-rn),sn=1)}function hn(){var n=m-i;(!t||t&&t<=p)&&(n&&(++a,sn=dn=1),i=m,n),function(){if(gn=d<m?k:j,pn!==gn){var n=en(m-d);B<n&&(++l,ln&&!dn&&++a,pn=gn,sn=ln=1,d=m,dn=0)}else dn=0,d=m}(),t=p+un}function bn(){u=on(tn(u,m+b)),g&&(f=on(tn(f,g+h))),sn=1}function yn(){p=R(),g=en(Q.pageXOffset||0),m=tn(Q.pageYOffset||0,0),v=0<g||0<m,h=Q[H]||0,b=Q[K]||0}function Sn(){yn(),vn(),hn(),bn()}function Tn(){if(r){var n=on(R()-r);s+=n,r=e,sn=0<n}}function $n(){r=r||R()}function wn(n,e,t,i){e[n+E]=on(t||0),e[n+F]=on(i||0)}function In(n){var e=n===fn,t=an();if(t||sn){if(!e){if(!N)return;N=0,t&&Tn()}var i=function(){var n={},e=Z.documentElement||{},t=Z.body||{};return wn("availableScreen",n,_[O],_[q]),wn(w,n,tn(t[X]||0,t[M]||0,e[x]||0,e[X]||0,e[M]||0),tn(t[Y]||0,t[W]||0,e[z]||0,e[Y]||0,e[W]||0)),wn(D,n,_.width,_.height),wn("viewport",n,Q[H],Q[K]),n}(),o=function(){var n={scrollCounts:a,reachedDepth:u,horizontalScrollDistance:f,dwellTime:s,vScrollDirChanges:l};return"number"==typeof c&&(n.clientTimeToFirstScroll=c),n}();e?sn=0:(mn(),rn=R(),t&&(r=rn)),L("log",{activity:o,dimensions:i,schemaId:"<ns>.PageInteractionsSummary.3"},{ent:{page:["pageType","subPageType","requestId"]}})}}function Pn(){Tn(),In(fn)}function Dn(n,e){return function(){cn=e,n()}}function Cn(){an=function(){return cn},cn&&!r&&(r=R())}"function"!=typeof Z[y]||J||(mn(),v&&vn(),U(Q,C,Sn,{passive:!0}),U(Q,"blur",Pn),U(Q,"focus",Dn($n,1)),V(S+"android",Cn),V(S+"ios",Cn),U(S+"pause",Dn(Pn,0)),U(S+"resume",Dn($n,1)),U(S+"resign",Dn(Pn,0)),U(S+"active",Dn($n,1)),an()&&(r=rn||R()),V("$beforeunload",In),U("$beforeunload",In),U("$document.hidden",Pn),U("$beforePageTransition",In),U("$afterPageTransition",function(){sn=N=1}))});csa.plugin(function(e){var o,n,r="Navigator",a="<ns>."+r+".5",i=e.global,c=e.config,d=i.navigator||{},t=d.connection||{},l=i.Math.round,u=e("Events",{producerId:"csa",lob:c.lob||"0"});function v(){o={network:{downlink:void 0,downlinkMax:void 0,rtt:void 0,type:void 0,effectiveType:void 0,saveData:void 0},language:void 0,doNotTrack:void 0,hardwareConcurrency:void 0,deviceMemory:void 0,cookieEnabled:void 0,webdriver:void 0},w(),o.language=d.language||null,o.doNotTrack=function(){switch(d.doNotTrack){case"1":return"enabled";case"0":return"disabled";case"unspecified":return d.doNotTrack;default:return null}}(),o.hardwareConcurrency="hardwareConcurrency"in d?l(d.hardwareConcurrency||0):null,o.deviceMemory="deviceMemory"in d?l(d.deviceMemory||0):null,o.cookieEnabled="cookieEnabled"in d?d.cookieEnabled:null,o.webdriver="webdriver"in d?d.webdriver:null}function k(){u("log",{network:(n={},Object.keys(o.network).forEach(function(e){n[e]=o.network[e]+""}),n),language:o.language,doNotTrack:o.doNotTrack,hardwareConcurrency:o.hardwareConcurrency,deviceMemory:o.deviceMemory,cookieEnabled:o.cookieEnabled,webdriver:o.webdriver,schemaId:a},{ent:{page:["pageType","subPageType","requestId"]}})}function w(){!function(n){Object.keys(o.network).forEach(function(e){o.network[e]=n[e]})}({downlink:"downlink"in t?l(t.downlink||0):null,downlinkMax:"downlinkMax"in t?l(t.downlinkMax||0):null,rtt:"rtt"in t?(t.rtt||0).toFixed():null,type:t.type||null,effectiveType:t.effectiveType||null,saveData:"saveData"in t?t.saveData:null})}function f(){w(),k()}function y(){v(),k()}c["KillSwitch."+r]||(v(),k(),e.on("$afterPageTransition",y),e.on(t,"change",f))});csa.plugin(function(a){a.emit("$csa.loaded")});
(function(p,n,w,l){var r={EX:{}};(function(){return"object"===typeof performance&&"function"===typeof performance.now?function(){return performance.now()}:"function"===typeof Date.now?Date.now:function(){return(new Date).getTime()}})();var u=function(a,b,c,e){var f={};try{if(5<=e)return{};b=b||n;c=c||a;for(var k,g=Object.keys(c),d,h=0;h<g.length;h++)d=g[h],k=c[d],"object"!==typeof k||Array.isArray(k)?f[d]=b[d]:f[d]=null==b[d]?null:u(a,b[d],c[d],e+1)}catch(l){m(l,"ex in collecting-")}return f},v=function(a,
b){var c="";try{var e=b.toString(),e=e.replace(/\n/g,"").replace(/\s\s+/g," ");c=e==="function "+a+"() { [native code] }"||e==="function "+a+"() { [native code]}"?"0x6":e=e.replace(/function/,"fx").replace(/\[native code\]/,"nc")}catch(f){c="ex"}return c},s=function(a,b,c,e){var f=[];try{if(5<=e)return[];c=c||b;for(var k=Object.keys(c),g=0;g<k.length;g++){var d=k[g];if("object"!=typeof c[d]||null==c[d]||Array.isArray(c[d]))switch(!0){case !0===a[d]:f[g]=1;break;case !1===a[d]:f[g]=0;break;case 0===
a[d]:f[g]=0;break;case "function"===typeof a[d]:f[g]=v(d,a[d]);break;case null!=a[d]:f[g]=a[d];break;default:f[g]=null}else f[g]=null!=a[d]?s(a[d],b,c[d],e+1):s({},b,c[d],e+1)}}catch(h){m(h,"ex in compression-")}return f},q=function(a,b){try{p.ue&&p.ue.event&&p.ue.event(x(b,a),"a9_tq","a9_tq.FraudMetrics.3")}catch(c){m(c,"ex in logging-")}},h=function(a,b,c){try{q(b+a.stack,c)}catch(e){m(e,"ex in logging-")}},m=function(a,b){p.ueLogError&&p.ueLogError(a,{logLevel:"ERROR",attribution:"A9TQForensics",
message:b})},y=function(){try{if(l&&l.userAgent&&/chrome/i.test(l.userAgent)&&l.userAgentData&&l.userAgentData.brands)for(var a=l.userAgentData.brands,b=0;b<a.length;b++)if(a[b].brand&&/google/i.test(a[b].brand))return!0;return!1}catch(c){h(c,"ex in identifying Chrome Browser ","103")}},t=function(a){try{a&&!a.stack&&(a.stack=a.toString())}catch(b){h(b,"ex in populating stack trace ","100")}},x=function(a,b){try{var c={vfrd:a};"object"===typeof b?c.info=JSON.stringify(b,function(a,b){return"function"===
typeof b?v(a,b):b}):"string"===typeof b&&(c.info=b);return{server:window.location.hostname,fmp:c}}catch(e){return m(e,"ex in constructing pixel - "),{server:window.location.hostname,fmp:{vfrd:"0"}}}};(function(a,b){try{try{try{r.mimeTypesLength=n.navigator.mimeTypes.length,r.pluginsLength=n.navigator.plugins.length}catch(c){h(c,"ex in basic props ","30")}n.a9tqDerivedFeatures=r}catch(e){h(e,"ex in evaluation-","30")}var f=u(a,b,null,0);try{n.a9tqDerivedFeatures=null,delete n.a9tqDerivedFeatures}catch(k){h(k,
"ex in deleting derivedFeatures-","30")}var g=s(f,a,null,0);q(g,"2")}catch(d){m(d,"ex in full attribute flow-")}})({window:{innerHeight:0,innerWidth:0,outerWidth:0,outerHeight:0,length:0,callPhantom:"",__phantomas:"",PhantomEmitter:"",_phantom:"",_WEBDRIVER_ELEM_CACHE:"",domAutomationController:"",domAutomation:"",spawn:"",emit:"",Buffer:"",TEMPORARY:"",external:"",Components:{classes:"",wdIStatus:"",wdIMouse:"",wdICoordinate:"",interfaces:"","interface":{nsICommandProcessor:""}},netscape:{security:{privilegemanager:""}},
isExternalUrlSafeForNavigation:0,opera:{_browserjsran:""},onabsolutedeviceorientation:"",onstorage:"",chrome:"",clearInterval:"",clearTimeout:"",eval:"",alert:"",prompt:"",scroll:"",onhelp:"",maxConnectionsPerServer:"",opr:"",devicePixelRatio:"",webdriver:"",InstallTrigger:"",safari:"",ontouchstart:""},screen:{availHeight:0,availWidth:0,width:0,height:0,colorDepth:0,pixelDepth:0,orientation:{angle:0,onchange:0}},navigator:{appCodeName:"",appName:"",appVersion:"",deviceMemory:0,doNotTrack:0,hardwareConcurrency:0,
language:"",maxTouchPoints:0,product:"",productSub:0,vendor:"",vendorSub:"",userAgent:"",languages:[],platform:"",webdriver:0,msLaunchUri:"",permissions:"",oscpu:"",msMaxTouchPoints:"",userAgentData:""},document:{id:"",height:"",width:"",except:"",style:{position:"",top:"",left:"",visibility:"",opacity:"",hidden:"",webkitHidden:"",msHidden:"",mozHidden:""},referer:"",webdriver:""},a9tqDerivedFeatures:{mimeTypesLength:"",pluginsLength:"",EX:{a:[],b:[]}},history:{length:""}},n);(function(){var a=[];
try{var b=Date.now(),c="function"===typeof w.hasPrivateToken?1:0,e="www.shopping.com"===n.location.hostname?1:0,f="function"===typeof AbortController?1:0,k=y()?1:0;if(k&&c&&e&&f){var g=atob("aHR0cHM6Ly93d3cuYW1hem9uLmNvbS90dC9p"),d=new AbortController,l=setTimeout(function(){try{d.abort()}catch(a){t(a),h(a,"ex in set PST timeout ","100")}},2E3);fetch(g,{privateToken:{version:1,operation:"token-request"},signal:d.signal}).then(function(c){a=[1,Date.now()-b,c.status];q(a,"101")})["catch"](function(a){t(a);
h(a,"ex in PST Issuance API call ","100")})["finally"](function(){clearTimeout(l)})}else a=[0,Date.now()-b,k,c,e,f],q(a,"101")}catch(m){t(m),h(m,"ex in PST issuance flow ","102")}})()})(ue_csm,window,document,navigator);



ue.exec(function(d,c){function g(e,c){e&&ue.tag(e+c);return!!e}function n(){for(var e=RegExp("^https://(.*\.(images|ssl-images|media)-shopping\.com|"+c.location.hostname+")/images/","i"),d={},h=0,k=c.performance.getEntriesByType("resource"),l=!1,b,a,m,f=0;f<k.length;f++)if(a=k[f],0<a.transferSize&&a.transferSize>=a.encodedBodySize&&(b=e.exec(String(a.name)))&&3===b.length){a:{b=a.serverTiming||[];for(a=0;a<b.length;a++)if("provider"===b[a].name){b=b[a].description;break a}b=void 0}b&&(l||(l=g(b,"_cdn_fr")),
a=d[b]=(d[b]||0)+1,a>h&&(m=b,h=a))}g(m,"_cdn_mp")}d.ue&&"function"===typeof d.ue.tag&&c.performance&&c.location&&n()},"cdnTagging")(ue_csm,window);


}
(n=>{var A,E=1e6,M=(n.Symbol||{}).iterator;n.RXVM=function(r){(r=r||{}).mi&&(E=r.mi);var i=n([1,function(n){n.u.t[m(n)]=h(n)},2,function(n){n.i[0].t[m(n)]=h(n)},3,h,4,function(n){var r=h(n),t=h(n),n=h(n);w(n)&&(n[t]=r)},5,function(n){var r=h(n),t=m(n);w(r)&&"function"==typeof r[M]&&(n.u.t[t]=r[M]())},6,function(n){var r=n.u.t[m(n)],r=r&&r.next?r.next():A,t=m(n),u=x(n);w(r)&&!1===r.done?n.u.t[t]=r.value:d(n,u)},10,function(n){n.u.o.push(h(n))},11,function(n){n.u.o.push(n.v)},12,function(n){for(var r=F(n);0<r--;)n.l.push(S(n))},30,function(n){return!h(n)},42,function(){},43,function(n){for(var r=F(n);0<r--;)n.u.t.push(n._.pop())},45,a(!0),44,a(!1),48,v(0,y),49,v(1,y),50,v(2,y),51,v(-1,y),52,v(0,_),53,v(1,_),54,v(2,_),55,v(-1,_),58,function(n){d(n,x(n))},59,s(!0),60,s(!1),64,function(n){var r=x(n),t=p(n,n.u.h);return d(n,r),t},65,function(n){var r=F(n),t=x(n),u=p(n,n.u.h);n.u.t[r]=u,d(n,t)}]),o={40:function(n,r){return"__rx_cls"in n?n.__rx_cls===r.__rx_ref:n instanceof r}},t=(o[20]=Math.pow,l(16,"+"),l(17,"-"),l(18,"*"),l(19,"/"),l(21,"%"),l(22,"&"),l(23,"|"),l(24,"^"),l(25,"<<"),l(26,">>"),l(27,">>>"),l(28,"&&"),l(29,"||"),l(31,">"),l(33,">="),l(32,"<"),l(34,"<="),l(35,"=="),l(36,"==="),l(37,"!="),l(38,"!=="),l(39," in "),n([10,A,11,null,14,!0,15,!1])),u=n([1,function(n){return n.v},17,F,18,function(n){n=m(n)|m(n)<<8|m(n)<<16|m(n)<<24;return n=2147483647<n?-4294967295+n-1:n},19,function(n){for(var r=[],t=0;t<4;t++)r.push(m(n));return new Float32Array(new Uint8Array(r).buffer)[0]},12,S,13,function(n){return n.l[F(n)]},20,function(){return[]},21,function(n){for(var r=F(n),t=[];0<r--;)t.unshift(h(n));return t},24,function(n){for(var r,t,u,i=F(n),o=[];0<i--;)o.unshift((u=t=void 0,r=m(r=n),t=128&r?-1:1,u=r>>3&15,r&=7,15!=u?0==u?r/8*t*.015625:t*(1+r/8)*Math.pow(2,u-7):NaN));return o},22,function(){return{}},23,function(n){for(var r=F(n)/2,t={};0<r--;){var u=h(n);t[h(n)]=u}return t},32,function(n){return n.u.t[F(n)]},33,function(n){return n.i[0].t[F(n)]},48,function(n){var r=h(n),n=h(n);return w(n)?("function"==typeof(r=n[r])&&(r.__rx_this=n),r):n},50,function(n){return n.u.o.pop()},52,function(n){return typeof h(n)}]);function f(n){for(;0<n.p--&&(r=n).u&&r.u.h<r.m.length;){r=m(n);n.v=e(r,n)}var r}function e(n,r){var t,u;return n in o?(t=h(r),u=h(r),o[n](u,t)):n in i?i[n](r):void k("e2:"+n+":"+r.u.h)}function c(n,r){return{F:n,h:n,t:[],o:[],S:r}}function n(n){for(var r={},t=0;t<n.length;t+=2)r[n[t]]=n[t+1];return r}function a(i){return function(n){var r=i?h(n):A,t=n.i.pop(),u=A,u=t.S?t.t[0]:r;return n._=[],n.u=n.i[n.i.length-1],b(n,n.u.F),u}}function v(u,i){return function(n){var r=h(n),t=u;for(-1===u&&(t=F(n));0<t--;)n._.push(h(n));if(n.v=A,r)return i(r,n)}}function s(u){return function(n){var r=h(n),t=x(n);(u&&r||!r&&!u)&&d(n,t)}}function l(u,i){o[u]=function(n,r){var t=Function("a","b","return a"+i+"b");return(o[u]=t)(n,r)}}function _(n,r){var t;if(n.__rx_ref&&n.g===r){var u=c(n.__rx_ref,!0);u.t.push({__rx_cls:n.__rx_ref}),r.i.push(u),r.u=u,b(r,u.F)}else if("function"==typeof n){u=r._.reverse().splice(0),u=Function.prototype.bind.apply(n,[null].concat(u));try{t=new u,r._=[]}catch(n){}}else k("e5:"+n+":"+r.u.h);return t}function y(n,r){var t;if(n.__rx_ref&&n.g===r){var u=c(n.__rx_ref);u.t.push(n.__rx_this||this),r.i.push(u),r.u=u,b(r,u.F)}else if("function"==typeof n){u=r._.reverse().splice(0);try{t=n.apply(n.__rx_this||this,u),r._=[]}catch(n){}}else k("e4:"+n);return t}function h(n){var r=m(n);return 0<(128&r)?e(127&r,n):r in t?t[r]:r in u?u[r](n):void k("e3:"+r)}function p(t,u){var n=g(function(){var n=c(u),r=n.t;return r.push(this),r.push.apply(r,arguments),t.i.push(n),t.u=n,t.p=E,b(t,n.F),f(t),t.v});return n.__rx_ref=u,n.g=t,n}function w(n){if(n!==A&&null!==n)return 1;r.unsafe&&k("e10"+n)}function b(n,r){n.k=r%127+37}function d(n,r){n.u.h+=r}function m(n){return n.m[n.u.h++]^n.k}function x(n){n=m(n)|m(n)<<8;return n=32767<n?-65535+n-1:n}function F(n){for(var r,t=0,u=0,i=n.u.h,o=n.m,f=n.k;t+=(127&(r=o[i+u]^f))*(1<<7*u),u+=1,0<(128&r););return n.u.h+=u,t}function S(n){for(var r=F(n),t="";0<r--;)t+=String.fromCharCode(m(n));return t}function g(n){return function(){try{return n.apply(this,arguments)}catch(n){k(n)}}}function k(n){if(r.unsafe)throw Error(n)}this.execute=g(function(n,r){var t,u;return 82!==n[0]&&88!==n[1]?k("e1"):(n=n,t=3,(u=c(0)).t[0]=(r=r)||{},u.h=t,b(r={m:n,p:E,v:0,i:[u],u:u,_:[],l:[],k:0},0),f(t=r),t)})}})("undefined"==typeof window?global:window);
(n=>{for(var t="undefined"==typeof window?n:window,i=0,n="addEventListener",e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""),u=[],r=t.rx||{},o=r.c||{},f=o.rxp||"/rd/uedata",c=o.fi||1e3,a=1.5,d=1e4,x={},w={},m={},v={},h=0,l=0;l<e.length;l++)u[e[l]]=l;function p(n,r){return function(){try{return n.apply(this,arguments)}catch(n){s(n.message||n,n)}}}function s(n,r){if(m[i]=[(n=(""+(n||"")).substring(0,100)).length].concat((new TextEncoder).encode(n)),o.DEBUG)throw r||n;b()}function y(n,r){r=p(r),n in w||(w[n]=[]),w[n].push(r),n in x&&r()}function g(n,r){n in x||(x[n]=r,(w[n]||[]).forEach(function(n){n(r)}))}function A(n){for(var r=0,t=0,i="",o=0;o<n.length;o+=1)for(t+=8,r=r<<8|n[o];6<=t;)i+=e[r>>t-6],r&=255>>8-(t-=6);return 0<t&&(i+=e[r<<6-t]),i}function U(n){for(var r=0,t=0,i=[],o=0;o<n.length&&"="!==n[o];o+=1)for(t+=6,r=r<<6|u[n[o]];8<=t;)i.push(r>>t-8),r&=255>>8-(t-=8);return new Uint8Array(i)}function b(){!h&&0<c&&(setTimeout(p(I),c),c=Math.min(d,c*a),h=1)}function E(r){let t=[];return Object.keys(r).forEach(n=>{t.push(parseInt(n)),t=t.concat(r[n])}),t}function I(){h=0;var n=E(m);0<n.length&&rx.ep(n,T),m={}}function T(n){n=A(new Uint8Array(n));n=f+"?rid="+rx.rid+"&sid="+rx.sid+"&rx="+n;(new Image).src=n}function j(n){g("load",n)}function L(n){j(n),g("unload",n),I()}(t.rx=r).err=s,r.r=p(y),r.e=p(g),r.exec=p,r.p=p(function(n,r){g("rxm:"+n,r),m[255&n]=r,b()}),r.pc=p(function(n,r){v[255&n]=r,n=E(v),r=rx.ep4(n,rx.fnpb),n=A([rx.fnpv].concat(rx.fnpb,r)),document.cookie="rxc="+n+"; max-age=86400; path=/"}),r.ex64=p(function(r,n){y(n||"init",function(){var n;t.RXVM&&(n=U(r),t.$RX||(t.$RX=new t.RXVM({mi:o.mi})),$RX.execute(n,t))})}),r.e64=p(A),r.d64=p(U),r.erc4=p(function(){var n=rx.fnpb,r=rx.fnpv,t=rx.ep4(E(m),n);return A(new Uint8Array([r].concat(n,t)))}),g("init",{}),"complete"===document.readyState?j({}):n in t&&(t[n]("load",p(j)),t[n]("beforeunload",p(L)),t[n]("pagehide",p(L)))})(window);
rx.ex64("UlgBKT4nV10haERRTSFMSFBJIUFKS0AgU0RJUEAjSUBLQlFNIVFNQEsvSktGSkhVSUBRQC1GRElJR0RGTidCUSBDSUpKVyFhRFFAJktKUi9wTEtRHWRXV0RcJlZAUS5wTEtRFhdkV1dEXCNHUENDQFcjVlBHUUlAIkBLRldcVVEhS0RIQCJkYHYIZmdmI0FMQkBWUSJ2bWQIFxATIGFgZ3BiIUBdQEYmV0xBJlZMQSQkFSglBSUkJ7gzFSkkRgUkJCa4FSkjRldcVVFKBSUVKS1IVmZXXFVRSgUlZCIBJa6EsbWJjtHg/fHA6+bq4eD3pIWGtYmD4Ovm6uHghLSEpYSohGQtoiUFLy8sP8HTmNsjHw8pDi8rLy0oLSo0LhweIyweIy8PLj+f3fPfJ7YOKg4sLywvFM/RLyy2HiMrDi8OLC8strU/Pg4sDiwcHiMsHiMvDy4/xbqBgSYOLC8sLy8strU/Iw4sDiwcHiMsHiMvDy4/m/LkuyIOLC8sLy8strU/Pg4sDiwDtT8uDixkLD4lETk7PgoaOBo7PgoaORo7GjgaOz4aPho5GjsWZC+bJXJbWFpNWF1NWFxIWVhfSFlYXkhZWFFIWWX5SNlbeVFIWV15UXlReVpYUclIWHlRY7+mWFFIWWX5SNlbeVF3WVhczEjZW8lpzGlUXHlbeVF5W8lpeVF5WnlcanhQWnlceVF5WlhRyUhYeVFjkKZceVhQX1BTHFlYXsxI2VvJSFh5XlhfzEjZW8lpeV55WnlfanhQWnlfeV55WmhpVV0pLCoxeV3BacxI2VvJaXlfeVppeV55WnlaeVNj76Z0eV1kLmIlt56gO7ydkZqRnK2skZq8nbyesZ2ms5ygO7ydkZu7nJi8npGUvJ3cj5xsd3ZLTmZGdkpANCM1MyoyZkZql5iukZu8nbG8nbBkKbElQ2pU9fZJbPZJbmloRFhYZWRYZWNJaHt5gG9pY1lYZWJYZWlJaFp1aVhlYVhlaEloaWtpXVhlZUlo+FhlbUhpeWxpbGldWGVnSWh9aUhra1hleGljXVhlZUloWmNZWGVmSGxaWlhlZkhseWxIaVtYZXpYZXlJa2tIbElsf2556GllbUluZGoBHmV8ZXtjWkljSGpaRGQoXCWqg4CDHKCEoYO9H6GDgIGtsbGMjbGMiqCBkpBphoCKsLGMi7GMgKCBs5yAsYyIsYyBoIGAgoC0sYyMoIERsYyEoYCQhYCFgLSxjI6ggZSAoYKCsYyRgIq0sYyMoIGzirCxjI+hhbOzsYyPoYWQhaGAs6CLoYOhhayAZCsiJFR9Tl54X35+fn5OXnhffX59fk1PcmpPcm5efF9+cml0PxZ/iaOXkq+vg6KCo6Cno5GSrqvLz9LN0Nbpx9uSr7ODoae3oK6lxsfB0NvS1q+wrbWmsyKjr6evtq+xgqOuodDD1aniv6JMZmVjR2ZbV2pwRmVrZ2NGY2tiODgCFQxGZkpGY6mQg6mQkI+jdE1edE1Nfnx+TU9yak9ybl58X31yaXQ/VH8MJhUXKyJUS05EQgcmNjc2JyUhJhsXKjAGJSsnIwYhKyJ4eEJVTgYmCgYhdE1edE1Nfnt+Q09yaF59W39OT3N8HhMTT3N4Lw0QEhYMGl5/an1fe198dHtNc3sgIBoNXn5TFBUoPQUkBSkuIRcpJ0BVBSQUFSg9BSQFKC4hFykmQFURBSQUFSg9BSQFLy4hFyknQBEFJBQVKD0FJAUtLiEXKSRNBSQZuRUoPwUkFSg8BSQxJRQVKD0FJAUrFyQVKD8FJBUoPAUk","load");
rx.ex64("UlgBKSInV10hQUpLQCBTRElQQCNJQEtCUU0mVUpSIENJSkpXIFdKUEtBJCQVKSFAXUBGFSglBSUkJxUpIWhEUU0FJSQmFSkja1BIR0BXBSVkITklUnh4e2h5fFl4en96fXN5eHvpWX1Ze0OIhlRZe2QgNSWymKi4nbmYiqmUmrmYmLSYZCNnJQUvHw8rDi8vLC8vLT8uKw4vKigqKzkuHB4jKg8sPyy/DiwOKz4vDi0vLS8UytEfHiIqXV9cWg8svR4jLQ4vDi0DL2QiayVfdXV2RHl3VHVFVXFUdXV3dUVVclR1dXB1RUR5cVV2VHZiZYuLd3V/RUR5cVV2VHdiZYuLd3V/RUR5cVV2VHBiZYuLd3V/d2F3RkZGWXVkLWUlbEZ2ZkBnRkZFRmpSQdFWuEZ3VkVnRd1WT3dWRWdF0Va4RndWRmdF3VZPd1ZGZ0XRVrhGd1ZHZ0XdVk93VkdnRWQs1SWgirq7h4Pi+M3i5eL/7qqIq4qVipaKLYeN5f7m6e75v6uKgLq7h47i+MXqxaqIq4qAlrm5t4qDi6aeiZp3ipqLiomai7crmourioaLiomaCwuJiooaq4qai7cvmourioyLpp6Jmouai7q7h4/n5Oy5qomrioC6u4aOqom5ioiKubuGj6qJq4iaiZiKq4qamoqKmZoLg4qAuruGjaqJuYqPioqIG5qEq4i3KZqLq4iui7m7ho+qiZl5dHR0momYiquKmZoLg4qAuruGjaqJuYqPioqImouKjhyrjxwSmoGriKuJpp6JEZqDq44dmnSKq45kL6glqoCAgxaxkIGhgBiQibGQgKGAgIKQgL0XkAEBg6GDhoGAgpN+fn5+gIUXkJ4bkIuhg4CEF5B+hqGDvSWQnqGFiIGssY2Cz+DPoIK9JZCBoYWcgbOxjIWgg5Nzfn5+kIOTgBMSkAGJoYShgqyAu5yBs7GMhaCDEJCOoYWQg5OAExESkAGJoYSQgKGCrICtFAUkBSIuIRcpJ1ZEFSglBSUUBSQFLS4hFykmVkRHFSglBSUUBSQFLC4hFykhQEMUExUoJQUlFAUkBS8uIRcpIUFDFBMVKCUFJRQFJAUhLiEXKSFEVlBIFSglBSUUBSQFIC4hFykhRERTQhUoJQUlFAUkBSMuIRcpIURWUUEVKCUFJQ==","load");
rx.ex64("UlgBKSQnV10kJCkjGWtqa2AbJCc0JWQmbyUVPj4zPz4+r6IePg8zNkpMWk1+WFpRS6IpDzM2UV5JVlheS1BNHj8fPj4+r6IePg8zPExWWw8yPx4/Hz4ODzM+Vw8yPx4/Hz4SPhQVKSFAXUBGFSglBSUFJhUkJCEkIQUhKSZDS1UVKCUFJSEwIbM02iQFIbM02iS+NC0FIbM02iS+NDUFIbM02iS+ND0FISkhQ0tVRxUoJQUlIQUnKSFDS1VTFSglBSU=","load");
rx.ex64("UlgBKSMnV10hQF1ARiBWSUxGQCdAESdAQydWUyQkFSglBSUkJxUpIW92amsFJSQmFSkhaERRTQUlJCEVKSlJSkZESXZRSldEQkAFJSQgFSktTFZjTEtMUUAVKSNrUEhHQFcFJSQjKCUkIhUpIUNLVVMFJCQtFSkhQ0tVRwUkJCw0QSQuMSQpLmQoviUYcrYyHDc3BhcwFzIKkDwWN0I2BwY6NVIAAhc3Fjc3NDcEBjs0FjQnMyc3NzU3BwY7NBY0JzM9BAY7NRc3FjUENzI3AwY6PGNfWEIOd0REV08XNhYyPQIGOj1iU05CclNVWVJTRBc2NQY6MFJTVVlSUzcHNwQ3MzcHBjozRldERVMXNBYzGzcaOQMCPzMTMwACMy8lMCQ/NjMfM2QrUCV5U2NiXlshJiA7PDU7NCtzUHJTU1BTZmJeWQY3KiYXPDE9Njcgc1JRYl5UNzwxPTY3U2NTclBZYGJfUXNTc1pgU1FTYGJeVDE9PDEzJkdTc1VyUXNaWWNiXlE3ZGZzU2BZVmBzVHNWVsJDU2JfV3NTX1dzU35kKhwlZk5GRnxtQU5ATUltR01KTU5RTH18QU5sTl1NR358QEktPDwgNXxdTGxOfmxMdpKzfW1CbUBOR1hgZDUFJaO1LYOog56Ju7mFg/rs/d3g5Ozm/P2oiaiAqIaLg4ilZDRbJQUqLyqzPS4uLhEOKi8rszgeIyoPIi8oHg4vDisfDysOKBIvaC4fDysOLRIvPi4vKL2/Dio/L7+8Di0OKg4oLyi+vA4ovw4qPy+8DiwOKh8eIi1PTF0PLQ4oDj3j4uITLxIvKi4vKD8uFCouLygOLCoOKA4vDisqDisjKg8iAmQ3OSUaNQABPTVBREJZEDokNBE1ETIRMxEwECABECEdITQlKCAFJBQVKCQFJAU3LiEXKSZWQ0AFJBQVKCQFJAUoLiEXKSdCQQUk","load");
rx.ex64("UlgBKS8sUkBHQVdMU0BXI2pHT0BGUSFOQFxWIkxLQUBdakMhQUpLQCBTRElQQCBkV1dEXCN2XEhHSkkgdVdKXVwnV10kJDQ1JCc0JCQmuDMVKSxLRFNMQkRRSlcFJSQhuDMVKS1BSkZQSEBLUQUlZCA2JbK1BgaolJLo9Pnh7+rx//DsuZhkIyglGh2tlxEwPTAAPTARM2QiCiVrcHFMQ3FMQGBBYEFEQEBHQENYQXBxTEJhQ01FIiUiHmVQQUB9QENBbE97o75sTmQtuyVeRUR5dkR5dVV0VXRxdXVydXb8dEVEeXdUdnhyKzUGBhUNVWV0dWh10nlyVHZo0ER5clV0RFR2VXR1SHV2dFl6RUR5d1R2eHMrJw0ZFhsYVWV0dWh10nlzVHZo0ER5c1V0RFR2VXR1SHV2dFl6RUR5d1R2eHIrJAYbDA1VZXR1aHXSeXxUdmjQRHl8VXREVHZVdHVIdXZ0WXpOB4tZe2QsBSW9ugowtpebnPT2+/vH//b54/j6MLaXm5/I5//2+eP4+mQv5iUWDQwwMV9OWV1IWXlQWVFZUkgdODA6X11SSl1PPT09DQwwNltZSH9TUkhZREgcPTA5S1leW1A9Pj0Aohw+PjwRMg0MMDBbWUh5REhZUk9VU1IcPjAla3l+e3BjWFleSVtjTllSWFlOWU5jVVJaUz8MMCtpcnF9b3d5eGNueXJ4eW55bmNreX57cD03DQwwMFtZSGxdTl1RWUhZThw+Dj0/PQCYNhw/PjwRMg0MMT8cPzA3b0tVWkhvVF1YWU4dLTw9ET1kLgYlrqkgtIiP7erq4fbM4e3j7PClhLSIj+vx8OH2zOHt4+zwpYRkKQ4lBgGIHCAmRUJCSV57RUhYRA0sHCAnT0BFSUJYe0VIWESxOhwgKE5DSFUNKCQoMC0FKQUuBS8FLAUtBSIFIwUgZCtTJUVubn5vbm1+b2pOYmxpbGs+b15fY2sKFwoMX2JmTm9Pa19ubmpuU8tlT2psb25qYVNPamVvbm749k9tfm5Pbm5t/35uT21dX2NsHAkKX2JmTm/4fm9Pav9PbWNrBwsDMFXFkF1fY24fX2JmTm96bU9uTm1ObkMXFSkkVxUoLAUlBSspIUlKREE=","load");
rx.ex64("UlgBKS8mVkNANURBQWBTQEtRaUxWUUBLQFcsSEpQVkBBSlJLIkhKUFZAUFUhQF1ARjZXQEhKU0BgU0BLUWlMVlFAS0BXLFFMSEB2UURIVS5VQFdDSldIREtGQCZLSlIkVyQkNAUkJzQqJCYyISspIkZEVVFQV0ArKSJVRFZWTFNAJCE0zSIkILgzFSktQUpGUEhAS1EFJSQjFSkhaERRTQUlJCIVKSdXXQUlJC0VKS5WQFFsS1FAV1NESQUlJCwVKShGSUBEV2xLUUBXU0RJBSUkLyskLiskKjQlJDQxJDcxZDZDJaG3FhWqgBWqgYqLp4mAhLq7h4n46qqMqpqKioq4u4aLqoyIu5qLqpm7mourioeP5ujU6Li7houqjIi7moqqmbuaiquKh4/m6NTmuLuGi6qMiLuaiaqZu5qJq4qHj+bo1PiJmauKp2QxFCVcRUZ7d1dzdVd1V3p7dEVGe3dXc3VXdVd7e3VGV2VHRntyV3FXZX1EV35XckR0eHdaZDABJQYuJiMfHCEpDSkvDS8NICEuHxwhKQ0pLw0vDSEhLx0NJQ0iAGQzACV+aMp1XlVUeFZeW2VkWFcnNTZ1U3VFVVVVZmRYVSR1U3RVdVV4ZDIzJVZ8TU1wdU1welx9YHxNcHtdfH9tfFFkPWElvJanp5qfp5qQtpeKlqeakbeWlpWWlpQGtoe3lZWYB4aWtpiVnJmmp5uT5+Lk/7aGt5SrNraVtpiel6e2gae2hKe2grsUFSghBSIFMiQpJBQVKCEFIgU9JCgkFxUoLAUiBTEpIUlKREEXFSgsBSIFMykjUEtJSkRB","load");
rx.ex64("UlgBKS8nVkQjRkpLRkRRJlZDQCxISlBWQEhKU0AhQF1ARiZWREchRkBMSSFVUFZNJkRHViRXJCQ0BCQnNO0kJCY02iQkITIhKykiRkRVUVBXQCspIlVEVlZMU0AkIDTNIiQjuDMVKS1BSkZQSEBLUQUlJCIVKSFoRFFNBSUkLRUpJ1ddBSUkLBUpLlZAUWxLUUBXU0RJBSUkLxUpKEZJQERXbEtRQFdTREkFJSQoKyQrKyQ2NCUkMTEkMDEkMzFkMp8lQ1X090hn90hkaGlFa2dmWFlkaUhhSHxiWFlkaUhhSH1qWWRoaFhoW2hoaFpZZGtIYWpZeGlIf1l4aUloZW0EGjYKWllka0hhall4aEh/WXhoSWhlbQQaNgRaWWRrSGFqWXhrSH9ZeGtJaGVtBBo2GlpZZGtIYWpZeGpIf1l4akloZW0ECDYKWllka0hhall4bUh/WXhtSWhlbQQINgRaWWRrSGFqWXhsSH9ZeGxJaGVtBAg2Gmt/SWhFZD0RJQMaGSU5SE1NbF9MR11lQFpdTEdMWwgvKggtCCIkKhkIPhgZJC0IIQg+IhsIIAgsGyslKAVkPA8lS2NsblJRbXITBAwOFwQkFwQPFS0IEhUEDwQTQGdiQGVAamxiUEBrQG1NZD8QJaWzEa6Cjo+jjYKAvr+Ciq6HrpuOjo6+v4KKroeumoS+v4KOr469jo6Ovb+Djv+uh6+Oro6jZD56JGJIeXlFSicmPnlFQjksOy8mOyQoJyosaElUSHlFQD0gJCwaPSgkOWlISEtISErUWEl5RUw5KC4sEWlISE3UWEl5RUw5KC4sEGlIddXtaFhpTe1oWWlKSEllddXWaEvYaEZpS2hGRUlLRkNLWUNLWENLW0N170NoRj1Je3lFTCg9KCd7aE7YaFlpSthoWGlNSExIeHlFTTo4Oz1oTtndWEvYaUpoWd1YS9hpTWhYQnh5RE9oTntIT0h11O1oRmlL7VhJaU9CSXh5RE5oXVhJc1RJeHlET2hO21ihTtrYaEZpS2lPSE5IeHlETmhdaU5170NoW3dJeHlEQWhO2GhbaUxYSNt5RUsZAGhOWEtCeHlEQWhO2GhbaUxCe3lFSiQgJ2hOe3tIQUh4eUROaFzbWKFOaUFLWtlYSGhaS0ZpS0tZaUpLWGlNS1tpTEtHR3XWaEpoWkBJeWhTeWheeWhQZRQVKCEFLQU+JC4kFxUoLAUtBT0pIUlKREEXFSgsBS0FPykjUEtJSkRB","load");
rx.ex64("UlgBKSAnV10mVkNAI1ZGV0pJSSFAXUBGJFckJDQHJCc07SQkJjTaJCQhMiErKSJGRFVRUFdAKykiVURWVkxTQCQgNM0iJCMVKSFoRFFNBSUkIhUoJQUlJC0VKS5WQFFsS1FAV1NESQUlJCwVKShGSUBEV2xLUUBXU0RJBSUkLyskKCskNDQlJDcxJDYxZDFDJR0LqqkWOqkWPTY3GzU6OAYHOzVEVhYwFiU2NjYEBzo2FjA0ByY3FiQHJjcXNjszRFRoVAQHOjYWMDQHJjYWJAcmNhc2OzNEVGhaBAc6NhYwNAcmNRYkByY1FzY7M0RUaEQ1JBc2G2QwESWLkpGtscDFxeTXxM/V7cjS1cTPxNOAoaKApYCqrKORgLWQkayigKaAtaqTgKmApJOjraCNZDMPJXBYUFVpalZJKD83NSw/Hyw/NC4WMykuPzQ/KHtaWXtee1FXWGt7U3tWdmQyDiWitBapgomIpIqCh7m4hIv76eq4hYipiKmaiYmJuriEifi4hYipiKiJqYmkZD2QJRM5CAg0O1ZXTwg0M0hdSl5XSlVZVltdGTglOQg0MUxRVV1rTFlVSBg5OTo5OTulKTgIND9LW0pXVFRhGTgEpKcZOqkZNhg6GTYxODo2Mjo3MjooMgSeMhk2DjgJCDQ7WVpLGT6pGTcYOzk8OQkINDxbXVFUGT6qKdA/q6kZNhg6GDw5PTkJCDQ8SE1LUBkqGD06KagpORkpOjYYOjo3GDs6NTYEpxk7GSkxOAgZLwgZLAgZLhQUFSgmFSglBSUFPSQuJBcVKCEVKCUFJQUwKSFJSkRBFxUoIRUoJQUlBTIpI1BLSUpEQQ==","load");
rx.ex64("UlgBKSEnV10kWS1VRFdWQGxLUSZWQ0AkJDQGJCcpI1ddCFVLUSQmNP0hJCEVKCUFJSQgFSkpSUpGREl2UUpXREJABSVkIzQkR2xs+nxt/nyFal1hYgMMGwQKDBkEAgM+GQwfGfB7XWFrGQQABAMK8HtdYWYdCB8LAh8ADAMOCExtbG9dTG9MaGxuZmxpfGxRy2dNbzhtXF1haB4dAQQZTW9gbGxvbFxdYG9MbV18bU1vcE1sbGxobFxdYG9MbV18bE1vcHxtbGxrbF9dYW4ADBVdYWkgDBkFTG18bfxNaE1sbG5sbGn9fGxNa1HMTG5NbmptbG5mbGl8bGn9TWn9YGz9TWxhbUxvTGheXWBuTGlpfGxn8HxsTWlhbx4BX11gbkxpTW5hbwMJXl1gbkxpaX6goaFQZ01uYWkDCTIBXF1haQgLXFtdYG1MbU1uZl9dYWwdTGlfTGxBFxUpJFcFIQUjKSFJSkRB","load");
rx.ex64("UlgBKScnV10mVkNAJCQ0FSQnFSglBSUkJhUpIUBDFBMVKCUFJWQhISRkT0/TWH5CSD0tPCsrIG9OT0x+Qks5Jyo6Jm5PT01+QkgmKycpJjpuT09KfkJEJyAgKzwZJyo6Jm9OT0t+QkUnICArPAYrJykmOm9OfH5DT29MbkxCTD05fX5DT29MSl2DgoJzRG5MQko9OREifH5DT29Mbk1CTD0mfX5DT29MSl2DgoJzRG5NQko9JhEifH5DT29MbkpCTDg5fX5DT29MSl2DgoJzRG5KQko4OREifH5DT29MbktCTDgmfX5DT29MSl2DgoJzRG5LQko4JhEif29NbkxFf29Nbk1Ff29NbkpFf29NbktFfX5CSC0hIC0vOlpKfHx8fEV8fkJPPm9MfG9PYhcVKSRXFSglBSUFISkhSUpEQQ==","load");
(i=>{let n=i.Math;function e(){for(let t=0;t<this.length;t+=1)this[t]=n.max(0,this[t])}function o(){for(let t=0;t<this.length;t+=1)this[t]=1/(1+n.exp(0-this[t]))}function r(t,n){var r=new i.Float32Array(t*n);return r.rows=t,r.columns=n,r.R=e,r.S=o,r}i.rx.M=function(t,n,r){return t.rows=n,t.columns=r,t.R=e,t.S=o,t},i.rx.M.zero=r,i.rx.M.mul=function(e,o,t){var n=e.rows,f=e.columns,u=o.columns,l=r(n,u);for(let i=0;i<n;i+=1)for(let r=0;r<u;r+=1){let n=t[r];for(let t=0;t<f;t+=1)n+=e[i*f+t]*o[t*u+r];l[i*u+r]=n}return l}})(window);
rx.ex64("UlgBKTcnV10kaCJSQExCTVFWI0lAS0JRTSFHTERWIkNKV1JEV0EgQkRISEQgVklMRkAhR0BRRCFIQERLLVNEV0xES0ZAIkBVVkxJSkspQ0BEUVBXQGtKV0hWI0lEXEBXViFBSktAIFNESVBAIVFcVUAhVVBWTSQkFSkhaERRTQUlJCcVKCUFJSQmuDMVKSRGBSckIRUoJBUoJQUlZCBnJW1FdWdCRXZLRWZEZkVmR01CdEtEZkZCZkRLQmZGBlxGTWdVVmplCxMKR2JlVmtiRmZWa2RGZkZnS2dNQnRLQ2ZGamQj4iWnj768gYusjayOnYyHiL6BiqyMvryBi6yNHp2OrI6sjoeIvoGErIy+vIGLrI0enY+sjh6djqyOh4i+gYWsjL68gYusjR6diKyOHp2PrI6HiL6BhqyMiKyPgYesjMzsjEdtbW59bFDMXGFvTG1MbiBsXVxgaB8dHhhNbfxcYWdMbFxMblxhZkxsf23+/VxMblxhZUxsXExuTG1cTG5cYWpMbHxcTG5cYWRMbG1naF5MbkxtbW78fW1MblbFk0FMbYeIvoGJrIygZCI9JXMZVVl2XG1tUVwPfVxwfVxSXWtUXHlZdWQtPSVfNXl1UnhJSXV4Kll4VFl4fnFHeHBVdVlkLMUlupOVsZCcnbGRlbGTnJyxkdFUkQ4kJCc0JRmFFSgmBSQFJ6IlFxUoIhUoKQUltTQgtzQgBSe3NCAFJyQmJBQVKS1MVmNMS0xRQBUpI2tQSEdAVwQlFQUnBSQ7JBkkLyUhFTQlBSYFJwUkFxUpJkhMSwQkFQUnBSQVNCcFJi4XFSkmSERdBCQXFTQkBSY0FTQmBSYkNhU0IQUmJC4hFwUnBSQkJ7U0JAUnH0vaFgQhJhUoJgUkNCQFJCQkJCAVKCgFJSEjISArJRQVKCAFIAUkJCQkH8jaCAUkmpWjnJSxkb1kL/IlXHZ2dWNGR3tyERsYGAVWduRmckd6dEd6e1d2dnR2ckd6eld2c3FzctZ3S9N7chMSGQQSR3pnV3JSd0BWcnRXdEd6c1dyR3p1V3J8Rkd6Zld1RXZ0R3p0R3pzV3JNHndL03t+FRYDFB8ZGAUaR3pnV3Jsd0BWcXRHenxXcld0R3p1V3J8Rkd6Zld1RU1Nd0vTe3MFEhsCR3pnV3J5d0NWcHxGR3pmV3VFTWp3S9N7cAQeEBoYHhNHemdXcnx3Q1Z/fEZHemZXdUVNLYhBVn5XdUd6e1d2WnYhBSEoJAUnIQUsKSdoaQUnIQUvKSBWVUBGVgUsGRUpIGFgZ3BiBSYQJSEFICkgYUBLVkAFLCEFIyksZ0RRRk1rSldIBSwhBSIpIXdAaXAFLCEFLSkidkxCSEpMQQUs","load");
rx.ex64("UlgBKSgnTEEtQ0BEUVBXQFYhQUpLQCBTRElQQCBISkFASSFRXFVAIEFAS1ZAIlJATEJNUVYhR0xEVixHRFFGTUtKV0giQFVWTElKSyFXQElQJ1ZTJCQVKSdXXQUlJCe4MxUpJEYFJCQmNGUkITTpLSQgLiQjMDopIVZGelYpIVZGekgpIVZGekYpIUhWelYpIUhWekgpIUhWekYpIUhEelYpIUhEekgpIUhEekYpIUhGelYpIUhGekgpIUhGekYpIE1BSXodKSBNQUl6EikgTUFJehMpIE1BSXoQKSBNQUl6ESkgTUFJehYpIE1BSXoXKSBNQUl6FCkhU016SSknU00pIVNSekkpJ1NSKSFWTXpJKSdWTSkhVlJ6SSknVlIpIUtBekkpJ0tBKSdWSWULJXxWVlVDVlTKQWdbVTIxd1ZSdlFTUVNSRVdmZ1tTJyIkP3dVZ3dSd1Rtvqh6d1UuFBUpIFZVQEZWFSknaGkFJDIhMC0yJykiVkxCSEpMQSggMiMwJDYkUCiaKC09NRwenh+SmRocmp+dZx1nExkoIigjKCAyJyguKCAyIzZKN6YfKC8wZTbdzEkfNsB3TR82XPmGHzacFygfNsqkYB82t9lMHzbIbf4fNrIS5x823yVvHzZa5zQeNjgk5x82gb7nHzZRtJsfNn3/yR82JsqVHzZpbiofNhtBamU2fN1zZTYAR31lNnYOe2U25OQpZTbTcmJlNqJ/HGU2nuJEZTbyQiFlNgFQQmU2iFh7ZTZMTnllNhRpQGU2JNR5ZTYucnplNn3cHmU2rTUWmzbfEOabNjC0jZs2J6SZmzb3pPCbNqBv5Js2jNIcmjZV2vcZNqAwHZo2u/qvmzYU3LKbNr+Ubpo25NClGzZh4oaaNvOWoRs2uSH4mza8NPoaNmAI5Bo2gBv5Gjb+qPwaNvae2Ro2s1v/Gja0R/8aNrbNyBo2g8uBGjYHG+YaNmnJ6Bo2g9zPGjbmLZkaNo3SMGU2LSSRGjbtE5oaKCIoLCggMiMwNTbQG3VlNqNCfWU2bJZ9ZTYLy3tlNjrkKWU2k5tiZTYNyR9lNgyIRGU2es4gZTbhMk1lNjbTe2U2gmd7ZTbmPkBlNhEMemU2fSV6ZTa/DxhlKC09pScjIa0mp6gmIaiuricsJC8hICegJKWhry6goqQlLqIvpKenI6OjLaeiLS0jo6IloiWkoi+jpi2gpCItLKCioKKlrK4loKEktqIhoSS3obehrSQkrye1qSUkoqmqJCSvJK+qtCa3pCWtrCclIaqgtaG3JiepJKCoJyGpqakkIaUjJKyjIq8nI6OpIikupqOioqIkJK4kr6MhJKyotScjJyIkoKIkpConqKaxJiSspKmkoa6jtKmgqqesrqOhoK6vrKmtriC2oSKmrCAgLa6gqaCqoKMkp6ChrackLCexpaoloaKip6Oup6CgpbW1oySjJ6KotSe3oSSirCekIbWgtaG3KCIoIyggMicoLiggMiM2SjemHygvMGU2ht0tGTaJhd0eNiWuSB42U659GTakDS4ZNsKavh42uvV1GTY91RYZNmZdGRk27lZIGTa0sJgZNjxzTB42MT8fGTZ1FioZNgkFTR42/7K6GTaBpJ8eNrBZRZk2w34tGTbLRMafNrUaIp42fBjcnjYKjeKeNj2PPhk2CX/OHzZR5SkZNsPcmxk2LzfGHzZehaOZNllKMpk2xBVjHjaJmmMeNilpBJo2CWxEnzbavoqaNvREs5s2AfrDmDa7wa+aNqEfC5o2UbWkmzZMHUiaNhBnDps24OXtmzaQcLuaNuBhT5o2JFRvmTZnX5iaNuqgBJo2qxK0GjbsjJEaNsYuXxo2BbgdGjZNmGYaNr9gsho2WLu0GjYkX3IaNmntuxo2gJh+GjZXxpEaNqeJhRo2nH2xGjZXtDAaNq5BaRo2zhWXGigiKCwoIDIjMDU2TzvqHjYoMEOZNiYLNBk2thISnjaE7iWeNoL5IZk2R8zxnjZXnhQZNh7kdx82SIM6GTbloZYZNmfQ9x82vPWomTagSD+ZNuabBB42SSd1HigtPdUmJSSlISSltKcmJSS3tSQlJaylJCEnJaQkI6QiJScmISEnpLazpCezJKEhoiS9pKeyJSWlpCUlpaWjJSSkpaWppKWnJackpCQlpqUhJSQmJSYlpyQnpaWlJSaloSUlpyW2pCQkpCQnJSUkJL0ltKeppKenpbYkpSQlpaeppKQmpSSkPqCpviu8J68zt6ysvKy/LCUlJCWlJScnJiUlpCUlpaukpCMlJKUko6UnJSSkJyWxJaWgJSQlp6QnpaokJKSlJichoaaxpCC2KrSvoaSgp6IntiynqSSiI6Imt6YkLKSnoKEpIiAkJCmsKiQgLKEnJaWkpKQnJSWkpKUlJaQlJSckJ6QkoCWkpCGkpaQkpSWkpyWnpaalpKetp6akpKElpqQhIyK3paEqsSwgpy+3JSWlpKSkJSUlpKSkpSWlJyWkpaYlpKGlJaSipKSkpKelJKWjJKSkJaanIackJCcvJaAmJSQkICSuJCMkJCYkpCSgJKSgpK+loKSipKWloKaloSShJ6Wrp6QkJCWlo6GmpCSjJCcloaclJSEkpqOgI6YvoSQnJSEktCclIaUnJiclty8kJSIhIKMnIyInISg0ISQnpSYkJSUmJSUnJSUkJKUnJCQgJ6clJi4iIyWkpSWlJiampKUlpCInIqcloKynpSgiKCMoICkjSURcQFdWML4kNsdDJGE2VKOkZjT1KjQlNCU2J8EkYTYGV6VmNPUqNCU0JTY8dLVnNpQAbGc03yQ0JTQlNrtfv2Y2foGxZzT1KjQlNCU2jd+yZjYWkrFnNPUqNCU0JTZ/ahxnNv30Z2Q03yQ0JTQlNhZThmc2foKCZDS1JjQlNCU2g/eQZzZT2oZkNIUjNCU0JTZjLTlnNqIaMGQ03yQ0JTQlNom0sWQ213ypZTRBNCU0JTYBphpnNuxBfmQ03yQ0JTQlNpLeDmU26V93GjQqNCU0JTbEyv4bNucK/hs0QTQlNCU2MOzqGzb4oaUbNEE0JTQlNpKo9Bs256lcGzRBNCU0JTaJoecZNk2Lix80QTQlNCU2OhbCGDaWVFUZNEE0JTQlNkzXxRg2V4ZBGTRBNCU0JTY4cu8bNhE4RRs0QTQlNCU2Tr/sGTYl8IofNEE0JTQlNszuO2Y21fMbYTStAjQlNtXzG2E2EFg7ZjauwhthNK0CNCU2rsIbYTYeFyRhNkHqcWE0rQI0JTZB6nFhNrkOJGE2fOdxYTStAjQlNnzncWE2xnBLZjYqHk5hNK0CNCU2Kh5OYTY8FElmNkICTmE0rQI0JTZCAk5hNpv+PmE2BRhEYTStAjQlNgUYRGE2W/U+YTZ9BURhNK0CNCU2fQVEYTZTdPRnNpPyA2Y0iSc0JTSJJzYpNshnNvU/K2Y0iSc0JTSJJzaTEMhlNrYxfGQ0MTQlNCUpKUNARFFQV0BrSldIVi4mMiMXKCEXKCQ0JSglLiYwJBckIiRkLYIlo7UtuYSFqIiojIiJpYuMuYSFqIi5uYWL7u2oiIiIiIiLnIi5hY/l7Ofu/eGojoyojoqPio3Dibi5hIipjamIiIyIuLmFju/m+/7o++25hI2pjamMiI+IuLmFjezvuL+oiLmYiamPgru5hY/q5ufq6P2pi7uciLmEiamNiIuIszh2tRe5hYzk5dbt5aiLgom7uYWI+aiIqYuoiru5hYv56qiIqYuoiqVkLDIlHAQGOj1FU0J/WEJTREBXWhc2FzIXPhoXFSkkVwUkBSwpIUlKREEZFSkgYWBncGIFJyglIQUiKSN6ekhBSVYFJA==","load");
rx.ex64("UlgBKSghaERRTTZXQEhKU0BgU0BLUWlMVlFAS0BXLEhKUFZASEpTQCBGSUxGTiNWRldKSUkmUURCJ1ddIEZKUEtRIkZJTEBLUX0iRklMQEtRfCJWRldKSUl8IUBdQEY1REFBYFNAS1FpTFZRQEtAVyQkuDMVKS1BSkZQSEBLUQUlJCe4MxUpJ1BABSUkJhUpJlBAXQUlJCEVKSFWVFdRFSglBSUkIBUpJlVKUhUoJQUlJCMVKSZER1YVKCUFJSQiMiErKSJVRFZWTFNAKykiRkRVUVBXQCQtNEEkLDRBJC8uJC4uJCkuJCguJCsuJCouJDU0JSQ0NCVkNwwliJGSr6ODoqGDpYOor6CRkq+jg6Khg6WDqa+hkZKvo4OioYOlg66vpo5kNkAlemxgXVVxUmVQYWBdVXFSXEY4MSN9IyQiPz43fTk+JDUiMTMkOT8+bMxxU2BcUzkjPHFSWVBicVNdVlxSMSRsYF1XcVJLUGJgXVdxUkFRXEEDJCI/PjcZPiQ1IjEzJDk/PmBxQnxkMT8lETsGpqUrOgo3Mxo7pSs6CjcyGjs5OgobKRZkMHMlc1lkxP5TeVb+U3lVdlhqeV1JWsl5VWhVUHhZU2p5XUlayXlWaFVReFlTSGpqU2l5XGpZWllaSch4WnlJZPl5UHlJW1hoeUtaVWhVUHhZWlZoVVF4WXRkMwslGDIPlTgSPCEzAhI1ohI8Az45EjMjMhIjMSMyD5ISOhIjMDMDEiAxPAM+ORIzH2QydiVPVFVoblVoY0RlRHBnb2RUVWhuVWhjRGVEcWduZFRVaG5VaGNEZURzZ2lkVlVoaURlZkRiRG9oZ1ZVaGlEZWZEYkRuaGZWVWhpRGVmRGJEaWhhSRcVKSRXFSgjBSUFMikhSUpEQQ==","load");
rx.ex64("UlgBKScmUURCJ1ddJCS4MxUpLUFKRlBIQEtRBSUkJ7gzFSknUEAFJSQmFSkmUEBdBSVkIWolcFpua1ddCT48HiMrelvLV1NmcwAFYAZwcst7WldecwUne3JQamtXXjY6Lzgza1ddODQ0MDI+elppWllaa2tXXy8pMjZrSll7WUdae1l2WmQgGiUELhMfIi8OLRsvHh8iLw4tvw8uIz1dVwJHRkhHSlxbAk5MW0ZAQRUTsw4sHyMsRlxDDi0mLx0OLCIuIy1OWwNkI3clWENTdn9zc3NzQ0J+dwECHhsGUnN+czJxQmNzc25zUnNzcHNOUnBbckNCfnYTBh0QU3JScHNxc0NCfngRGhMAMR0WFzMGUnFjcnN2c0NTd1J2XhcVKSRXFSgkBSUFIykhSUpEQQ==","load");
rx.ex64("UlgBKS4nV10jd0BCYF1VI0ZKSk5MQCNJQEtCUU0gQ0lKSlctRlZWd1BJQFYsUEtBQENMS0BBIFdQSUBWNVRQQFdcdkBJQEZRSldkSUkhUUBWUSUkJBUpIWhEUU0FJSQnFSglBSUkJrgzFSkkRgUnJCEVKS1BSkZQSEBLUQUlJCAVKS5WQFFsS1FAV1NESQUlJCMVKShGSUBEV2xLUUBXU0RJBSUkIhUpL1ZAUXFMSEBKUFEFJRAVKCQFJSlne1VVSV0IREJAS1ENGh8IfhUIHHgOen4VCBx4DgwaCEpTQFdJRFwNGh8IDRofR0RWQFkIVlFKVQhHUFFRSksMDBoBJC0kExUoJAUlKSRMKRpVVUldCERCQEtRDRofCH4VCBx4Dnp+FQgceA4MGghKU0BXSURcDRofCA0aH0dEVkBZVlFKVQhHUFFRSksMDBokLCQkLykpREhfSwhGUV1TCExBJC4pLkRIX0sIRlZWCExBJCm4NPUqFSkgRkF6V0wFJiQouDTljCIVKSBGQXpWRgUmZCp3JRA6Cgs3PkhLV1JPCzY5Gj83OQAbOjk6OjgqOwebCzY4GzkbOBE7Cgs3PFJVX15DdF0LGzgbOas3OgYbOh8qOzoHOjk7FjU6OKsqOhs4AfDEFjRkNR8lupOQkgOArQOArbGQkJUDgK0DgK2xk6GhnZfj8P/1/vywkIMBgJAAsZKxlZCaoKGclbCQo4GxkpC8kGQ0nSV7U2FxX3BRbFFRUHxgYFxTPj8nYFxUFDEkNXFQQ0G4V1FbYWBdVHFRYlNgXFgkPwMkIjk+N1FhUUF0UVRRYnFAcFNwUlFVUVFWwFxea3ADMT01AzkkNW0cMSjAcFXAXEJrcAAxJDhtf2twHTEofRE3NW3AcFTAXFNtYX5wUWz0XFY4JCQgI2pgXFggIj8kPzM/PGBcWDw/MzEkOT8+cVBfUFFWwFxYa3ADNTMlIjVwVlRwVl1ScVR8ZDcVJaaMsROtjI+NoIaxK4CLub2AiK2Mi42gvYCIrYyxK4CLub2Aiq2Mi42gvYCKrYyghmQ2dSRoc3JPSmNGTlAZKyYcf2AyMi46byMlJyw2YB9DQ0NDQFNCfuJyT0FiQ2JAc0Jzck9LY0pyTkArJnJiQGJDfkNRQnFjU0FT6kNT0kNjSHNjRGNMb0xDQNJTQ2JAeIa9c3JPSmNGTkcxNjsuJ19WQ0NBQ0NGU0J+4nJPQWJBYkYDQkNH309Ick5JNic6NgEtLDYnLDZyYkZiQXNyT0tjS2JHfkNRQnFjU0FT/AZTxntjSXNjRGNMb0xDRtJTQ2JGePa9Q0TfVnJOSTE2Oy4nESonJzYxY0ZDRVNCfuJyT0FiRGJFKEJzY1ByYkViRENKQ37cYkpBQngOQkNLU0J+4nJPQWJKYkt/QkNI309Ick5FITExFic6NnJiS2JKc3JPS2NLYkh+Q1FCcWNTQVP8BlPGe2NJc2NEY0xvTENL0lNDYkt4+r1DRdJTQ2JFeMm9b01kMSklsqS5lp2YqbmeuZa0ZDA5JQMZCDo3KBUoOCkbCCwIJQg6KycoGwguCCQIPQUXFSkkVxUoJQUlBTApIUlKREE=","load");
/* ◬ */
</script>

</div>

<noscript>
    <img height="1" width="1" style='display:none;visibility:hidden;' src='//fls-na.shopping.com/1/batch/1/OP/ATVPDKIKX0DER:147-0099296-5118245:KAS98C370K01G4FPVKFV$uedata=s:%2Frd%2Fuedata%3Fnoscript%26id%3DKAS98C370K01G4FPVKFV:0' alt=""/>
</noscript>

<script>window.ue && ue.count && ue.count('CSMLibrarySize', 101918)</script>
<!-- sp:end-feature:csm:body-close -->
</div></body></html>
<!--       _
       .__(.)< (MEOW)
        \___)   
 ~~~~~~~~~~~~~~~~~~-->
<!-- sp:eh:AIBjABwVTmOjQHJ6IZYmRuErD4iFxe4LwZMRouTgFWT9pS5uiBEetbCkkaLKetBZopZ7rOtuuFedg7XzYlgujdVac+DcIBU/NM2cB3dyDfURWnUjsLl/WAED/tY= -->
